"""관제 허브: 이벤트 수신·중복 거름·SSE·jsonl·heartbeat. 실제 HTTP로 띄워 확인한다."""

import asyncio
import json
import socket
import threading
import time

import httpx
import pytest
import uvicorn
from fastapi import FastAPI

from obs_hub.app import build_app, build_auth
from obs_hub.hub import Hub
from obs_hub.settings import Settings, load_settings
from obs_hub.store import EventStore


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class ThreadServer:
    def __init__(self, app, port: int) -> None:
        self.server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
        self.thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> "ThreadServer":
        self.thread.start()
        deadline = time.time() + 10
        while not self.server.started:
            if time.time() > deadline:
                raise RuntimeError("서버가 뜨지 않았다")
            time.sleep(0.02)
        return self

    def stop(self) -> None:
        self.server.should_exit = True
        self.thread.join(timeout=5)


def make_settings(tmp_path, port: int, heartbeat_s: float = 0, watch=(), **auth) -> Settings:
    return Settings(bind_host="127.0.0.1", port=port, public_url=f"http://127.0.0.1:{port}",
                    db_path=tmp_path / "data" / "obs_hub.sqlite3", heartbeat_s=heartbeat_s, watch_urls=tuple(watch),
                    **auth)


def event(n: int, type_: str = "task.state", agent: str = "http://127.0.0.1:1", **payload) -> dict:
    return {"v": 1, "eventId": f"test-{n}", "ts": int(time.time() * 1000), "agentId": agent, "side": "server",
            "type": type_, "taskId": "t1", "contextId": "c1", "process": "test", "payload": payload}


@pytest.fixture
def hub_server(tmp_path):
    port = free_port()
    settings = make_settings(tmp_path, port)
    server = ThreadServer(build_app(settings), port).start()
    yield settings
    server.stop()


def test_receive_dedupe_and_jsonl(hub_server):
    url = hub_server.public_url
    assert httpx.post(f"{url}/events", json=event(1, to="TASK_STATE_WORKING")).json() == {"ok": True, "duplicate": False}
    assert httpx.post(f"{url}/events", json=event(1)).json()["duplicate"] is True
    httpx.post(f"{url}/events", json=event(2, text="견적 요청 한글"))

    lines = httpx.get(f"{url}/events.jsonl").text.splitlines()
    assert [json.loads(line)["eventId"] for line in lines] == ["test-1", "test-2"]
    assert json.loads(lines[1])["payload"]["text"] == "견적 요청 한글"
    assert httpx.get(f"{url}/healthz").json()["events"] == 2
    again = EventStore(hub_server.db_path)                      # 허브를 다시 켜도 DB에 남아 있다
    assert [e["eventId"] for e in again.all()] == ["test-1", "test-2"]


def test_rejects_event_without_id_or_type(hub_server):
    response = httpx.post(f"{hub_server.public_url}/events", json={"type": "x"})
    assert response.status_code == 422
    assert httpx.post(f"{hub_server.public_url}/events", json=[1, 2]).status_code == 422


def test_sender_and_target_are_watched(hub_server):
    url = hub_server.public_url
    httpx.post(f"{url}/events", json=event(1, "agent.started", agent="http://127.0.0.1:5021", name="물류사 A"))
    httpx.post(f"{url}/events", json=event(2, "request.sent", agent="http://127.0.0.1:5010/",
                                           to="http://127.0.0.1:5022", requestId="r1"))
    agents = {a["url"]: a for a in httpx.get(f"{url}/agents").json()}
    assert set(agents) == {"http://127.0.0.1:5021", "http://127.0.0.1:5010", "http://127.0.0.1:5022"}
    assert agents["http://127.0.0.1:5021"]["name"] == "물류사 A"


def test_stream_replays_history_then_live(hub_server):
    url = hub_server.public_url
    httpx.post(f"{url}/events", json=event(1))
    received = []
    with httpx.stream("GET", f"{url}/stream", timeout=5) as response:
        assert response.headers["content-type"].startswith("text/event-stream")
        for line in response.iter_lines():
            if not line.startswith("data:"):
                continue
            received.append(json.loads(line[5:])["eventId"])
            if len(received) == 1:   # 지난 기록을 받은 뒤 새 이벤트를 보낸다
                threading.Thread(target=httpx.post, args=(f"{url}/events",), kwargs={"json": event(2)}).start()
            else:
                break
    assert received == ["test-1", "test-2"]


def test_ui_page(hub_server):
    response = httpx.get(f"{hub_server.public_url}/")
    assert response.status_code == 200 and "/stream" in response.text
    assert "window.OFFICE" in response.text                         # 첫 화면은 사무 공간
    classic = httpx.get(f"{hub_server.public_url}/classic")
    assert classic.status_code == 200 and "window.OFFICE" not in classic.text


def test_ui_page_falls_back_without_office(hub_server, tmp_path, monkeypatch):
    monkeypatch.setattr("obs_hub.app.OFFICE", tmp_path / "missing.html")
    response = httpx.get(f"{hub_server.public_url}/")
    assert response.status_code == 200 and "window.OFFICE" not in response.text


def card_app(name: str) -> FastAPI:
    app = FastAPI()

    @app.get("/.well-known/agent-card.json")
    def card() -> dict:
        return {"name": name, "skills": [{"id": "quote"}, {"id": "book-shipment"}]}

    return app


def test_heartbeat_online_offline(tmp_path):
    hub = Hub(EventStore(tmp_path / "hub.sqlite3"))
    port = free_port()
    agent_url = f"http://127.0.0.1:{port}"
    never_url = f"http://127.0.0.1:{free_port()}"
    hub.watch(agent_url)
    hub.watch(never_url)

    async def check():
        async with httpx.AsyncClient(timeout=1) as http:
            await hub.check_all(http)

    asyncio.run(check())   # 둘 다 꺼짐 — 한 번도 켜진 적 없으면 알리지 않는다
    assert hub.total == 0

    agent = ThreadServer(card_app("물류사 A"), port).start()
    try:
        asyncio.run(check())
        asyncio.run(check())   # 상태가 그대로면 다시 알리지 않는다
    finally:
        agent.stop()
    asyncio.run(check())

    events = list(hub.store.all())
    types = [(e["type"], e["agentId"]) for e in events]
    assert types == [("agent.online", agent_url), ("agent.offline", agent_url)]
    assert events[0]["payload"] == {"name": "물류사 A", "skills": ["quote", "book-shipment"]}
    assert hub.agents[agent_url].online is False and hub.agents[never_url].online is False


def test_heartbeat_runs_in_app(tmp_path):
    agent_port, hub_port = free_port(), free_port()
    agent = ThreadServer(card_app("물류사 B"), agent_port).start()
    settings = make_settings(tmp_path, hub_port, heartbeat_s=0.2, watch=[f"http://127.0.0.1:{agent_port}"])
    hub = ThreadServer(build_app(settings), hub_port).start()
    try:
        deadline = time.time() + 5
        while time.time() < deadline:
            agents = httpx.get(f"{settings.public_url}/agents").json()
            if agents and agents[0]["online"]:
                break
            time.sleep(0.1)
        assert agents[0]["name"] == "물류사 B"
    finally:
        hub.stop()
        agent.stop()


def test_settings(tmp_path):
    (tmp_path / ".env").write_text("APP_PORT=8191\nAPP_WATCH_URLS=http://a:1/, http://b:2\n", encoding="utf-8")
    s = load_settings(tmp_path, environ={"APP_PUBLIC_URL": "http://hub.example:8191/"})
    assert s.port == 8191 and s.public_url == "http://hub.example:8191"
    assert s.watch_urls == ("http://a:1", "http://b:2")
    assert s.db_path == tmp_path / "data" / "obs_hub.sqlite3"
    assert s.staff_auth and s.ingest_auth                        # 실제 실행 기본값은 인증 켜짐
    with pytest.raises(ValueError):
        load_settings(tmp_path, environ={"APP_BIND_HOST": "0.0.0.0"})


# ---------- 인증 (Part 4) ----------

@pytest.fixture
def secure_hub(tmp_path):
    port = free_port()
    settings = make_settings(tmp_path, port, staff_auth=True, ingest_auth=True)
    store = build_auth(settings)
    store.add_user("watcher", "pass-word-1", "viewer")
    _, key = store.issue_key("carrier-a", ["ingest"])
    server = ThreadServer(build_app(settings, auth_store=store), port).start()
    yield settings.public_url, key
    server.stop()


def test_ingest_needs_key_of_the_same_system(secure_hub):
    url, key = secure_hub
    evt = {**event(1), "process": "carrier-a"}
    assert httpx.post(f"{url}/events", json=evt).status_code == 401
    assert httpx.post(f"{url}/events", json=evt, headers={"X-Obs-Key": "wrong"}).status_code == 401
    spoof = {**event(2), "process": "kpw-buyer"}                   # 다른 시스템인 척
    assert httpx.post(f"{url}/events", json=spoof, headers={"X-Obs-Key": key}).status_code == 403
    assert httpx.post(f"{url}/events", json=evt, headers={"X-Obs-Key": key}).json()["ok"] is True


def test_viewing_needs_login(secure_hub):
    url, _ = secure_hub
    for path in ("/stream", "/events.jsonl", "/agents"):
        assert httpx.get(url + path).status_code == 401
    assert httpx.get(f"{url}/").status_code == 200 and httpx.get(f"{url}/healthz").status_code == 200
    web = httpx.Client(base_url=url)
    assert web.post("/api/login", json={"username": "watcher", "password": "pass-word-1"}).status_code == 200
    assert web.get("/agents").status_code == 200
    assert web.get("/api/users").status_code == 403                # 보기 역할은 관리 못 함
