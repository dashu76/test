# 파일명: hub.py
"""관찰 이벤트를 모으고, 구독 중인 화면에 흘려 보내고, 에이전트의 켜짐·꺼짐을 판단한다.

이벤트 모양 (업무 시스템의 obs_hook.py가 만든다):
    {v, eventId, ts, agentId, side(server|client|hub), type, taskId, contextId, process, payload}

- 이벤트를 보낸 에이전트(agentId)와 요청 상대(payload.to·payload.url)는 자동으로 지켜본다.
- 지켜보는 주소는 heartbeat가 Agent Card를 읽어 켜짐·꺼짐을 판단한다. 에이전트가 신고하지 않아도 된다.
- 같은 eventId는 한 번만 기록한다. 기록은 SQLite(store.py)에 남아 허브를 다시 켜도 이어진다.
"""

import asyncio
import itertools
import time
from dataclasses import dataclass

import httpx

from .store import EventStore

CARD_PATH = "/.well-known/agent-card.json"


@dataclass
class AgentInfo:
    url: str
    online: bool | None = None   # None: 아직 한 번도 확인하지 못함
    name: str = ""
    skills: tuple[str, ...] = ()
    checked_at: int = 0


class Hub:
    def __init__(self, store: EventStore, replay: int = 2000) -> None:
        self.store = store
        self.replay = replay                 # 화면을 새로 열면 다시 보내 줄 최근 이벤트 수
        self.subscribers: set[asyncio.Queue] = set()
        self.agents: dict[str, AgentInfo] = {}
        self._boot = f"{int(time.time())}"   # 허브를 다시 켜도 허브 이벤트 id가 겹치지 않게
        self._numbers = itertools.count(1)

    @property
    def total(self) -> int:
        return self.store.count()

    # 이벤트 ------------------------------------------------------------------

    def publish(self, event: dict) -> bool:
        """처음 보는 이벤트면 기록하고 구독자에게 보낸다. 이미 받은 것이면 False."""
        if not self.store.add(event):
            return False
        for q in self.subscribers:
            q.put_nowait(event)
        return True

    def receive(self, event: dict) -> bool:
        """업무 시스템이 보낸 이벤트."""
        payload = event.get("payload") or {}
        self.watch(event.get("agentId"))
        self.watch(payload.get("to"))
        self.watch(payload.get("url"))
        if event.get("type") == "agent.started" and payload.get("name"):
            self.watch(event.get("agentId")).name = payload["name"]
        return self.publish(event)

    def hub_event(self, type_: str, agent_url: str, payload: dict) -> None:
        self.publish({"v": 1, "eventId": f"hub-{self._boot}-{next(self._numbers)}", "ts": int(time.time() * 1000),
                      "agentId": agent_url, "side": "hub", "type": type_, "taskId": "", "contextId": "",
                      "process": "obs-hub", "payload": payload})

    def subscribe(self) -> asyncio.Queue:
        """화면 하나의 구독. 늦게 열어도 최근 기록부터 받는다."""
        q: asyncio.Queue = asyncio.Queue()
        for event in self.store.recent(self.replay):
            q.put_nowait(event)
        self.subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self.subscribers.discard(q)

    # 에이전트 켜짐·꺼짐 --------------------------------------------------------

    def watch(self, url) -> AgentInfo | None:
        if not isinstance(url, str) or not url.startswith(("http://", "https://")):
            return None
        url = url.rstrip("/")
        if url not in self.agents:
            self.agents[url] = AgentInfo(url)
        return self.agents[url]

    async def check(self, http: httpx.AsyncClient, info: AgentInfo) -> None:
        try:
            response = await http.get(info.url + CARD_PATH)
            response.raise_for_status()
            card, online, reason = response.json(), True, ""
        except Exception as error:
            card, online, reason = None, False, type(error).__name__
        info.checked_at = int(time.time() * 1000)
        if online == info.online:
            return
        was, info.online = info.online, online
        if online:
            info.name = card.get("name", info.url)
            info.skills = tuple(s.get("id", "") for s in card.get("skills", []))
            self.hub_event("agent.online", info.url, {"name": info.name, "skills": list(info.skills)})
        elif was is not None:   # 한 번도 켜진 적 없는 주소는 '꺼짐'으로 알리지 않는다
            self.hub_event("agent.offline", info.url, {"reason": reason})

    async def check_all(self, http: httpx.AsyncClient) -> None:
        # 꺼진 주소는 거부까지 시간이 걸리므로 모든 주소를 동시에 확인한다
        await asyncio.gather(*(self.check(http, info) for info in list(self.agents.values())))

    async def heartbeat(self, interval_s: float) -> None:
        async with httpx.AsyncClient(timeout=1) as http:
            while True:
                await self.check_all(http)
                await asyncio.sleep(interval_s)

    def agent_list(self) -> list[dict]:
        return [{"url": a.url, "online": a.online, "name": a.name, "skills": list(a.skills),
                 "checked_at": a.checked_at} for a in self.agents.values()]
