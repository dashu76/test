# 파일명: settings.py
"""설정 읽기. 우선순위: 환경변수 > 이 폴더의 .env > 기본값. 상대 경로는 이 폴더(obs-hub) 기준."""

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

APP_ROOT = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "APP_BIND_HOST": "127.0.0.1",
    "APP_PORT": "5090",
    "APP_PUBLIC_URL": "",
    "APP_DB_PATH": "data/obs_hub.sqlite3",
    "APP_MAX_EVENTS": "100000",
    "APP_REPLAY_EVENTS": "2000",
    # 다섯 회사의 기본 주소. 한 번도 켜지지 않은 주소는 '꺼짐'으로 알리지 않으므로 없는 회사가 있어도 된다
    "APP_WATCH_URLS": ",".join(f"http://127.0.0.1:{p}" for p in (5010, 5020, 5021, 5022, 5023)),
    "APP_HEARTBEAT_S": "2",
    "APP_STAFF_AUTH": "true",
    "APP_INGEST_AUTH": "true",
    "APP_SESSION_HOURS": "12",
    "APP_LOGIN_HINT": "",
}


@dataclass(frozen=True)
class Settings:
    bind_host: str
    port: int
    public_url: str
    db_path: Path                     # 이벤트·사용자·수집 키·감사 기록 (SQLite)
    max_events: int = 100_000         # DB에 남겨 둘 최근 이벤트 수
    replay_events: int = 2000         # 화면을 새로 열면 다시 보내 줄 최근 이벤트 수
    watch_urls: tuple[str, ...] = ()  # 처음부터 지켜볼 에이전트 주소
    heartbeat_s: float = 2.0          # Agent Card로 켜짐·꺼짐을 판단하는 간격. 0이면 끔
    # 인증 (Part 4). 코드 기본값은 꺼짐(테스트가 Settings를 직접 만든다). 실제 실행(load_settings)은 켜짐이 기본
    staff_auth: bool = False          # 화면·조회 API 로그인 요구
    ingest_auth: bool = False         # POST /events에 수집 키(X-Obs-Key) 요구
    session_hours: float = 12.0
    login_hint: str = ""              # 로그인 화면 시험 계정 안내 (예: "admin3 / 1234"). 운영에서는 비운다


def read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _flag(value: str) -> bool:
    return value.strip().lower() in ("1", "true", "yes", "on")


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def load_settings(root: Path = APP_ROOT, environ: Mapping[str, str] | None = None) -> Settings:
    environ = os.environ if environ is None else environ
    values = {**DEFAULTS, **read_env_file(root / ".env")}
    values.update({k: v for k, v in environ.items() if k in DEFAULTS})

    bind_host = values["APP_BIND_HOST"]
    port = int(values["APP_PORT"])
    public_url = values["APP_PUBLIC_URL"].rstrip("/")
    if not public_url:
        if bind_host in ("0.0.0.0", "::"):
            raise ValueError("APP_BIND_HOST가 모든 주소일 때는 APP_PUBLIC_URL을 반드시 지정해야 한다")
        public_url = f"http://{bind_host}:{port}"
    if urlsplit(public_url).scheme not in ("http", "https"):
        raise ValueError(f"APP_PUBLIC_URL이 http(s) 주소가 아니다: {public_url}")

    return Settings(
        bind_host=bind_host,
        port=port,
        public_url=public_url,
        db_path=_resolve(root, values["APP_DB_PATH"]),
        max_events=int(values["APP_MAX_EVENTS"]),
        replay_events=int(values["APP_REPLAY_EVENTS"]),
        watch_urls=tuple(u.strip().rstrip("/") for u in values["APP_WATCH_URLS"].split(",") if u.strip()),
        heartbeat_s=float(values["APP_HEARTBEAT_S"]),
        staff_auth=_flag(values["APP_STAFF_AUTH"]),
        ingest_auth=_flag(values["APP_INGEST_AUTH"]),
        session_hours=float(values["APP_SESSION_HOURS"]),
        login_hint=values["APP_LOGIN_HINT"].strip(),
    )
