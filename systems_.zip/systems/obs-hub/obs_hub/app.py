# 파일명: app.py
"""FastAPI 조립.

POST /events        업무 시스템이 관찰 이벤트 한 건을 보낸다 (수집 키 X-Obs-Key, APP_INGEST_AUTH)
GET  /stream        이벤트를 실시간으로 내보낸다 (SSE). 최근 기록부터 보낸다 — 화면이 구독한다 (로그인)
GET  /events.jsonl  DB에 남은 이벤트 전체 (로그인)
GET  /agents        지켜보는 에이전트와 켜짐·꺼짐 (로그인)
GET  /healthz       상태 확인 (공개)
GET  /              사무 공간 화면 (ui/office.html, 로그인 창 포함). 파일이 없으면 기존 관제 화면
GET  /classic       기존 관제 화면 (ui/index.html, 로그인 폼 포함)
/api/login · /api/me · /api/users · /api/keys …  로그인·사용자·수집 키·감사 기록 (auth.py)

설계: systems/docs/security-and-db.md
"""

import asyncio
import contextlib
import json
import logging
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from sse_starlette.sse import EventSourceResponse

from . import __version__, auth
from .hub import Hub
from .permissions import PERMISSION_LABELS, ROLES
from .settings import Settings
from .store import EventStore

UI = Path(__file__).resolve().parent / "ui" / "index.html"
OFFICE = UI.with_name("office.html")   # 사무 공간 화면 (vertualOfficeSource/office/agentUI.html + 허브 설정)
REQUIRED = ("eventId", "type")
INGEST_HEADER = "X-Obs-Key"
log = logging.getLogger("obs_hub")


def build_auth(settings: Settings) -> auth.AuthStore:
    return auth.AuthStore(settings.db_path, ROLES, settings.session_hours)


def build_app(settings: Settings, hub: Hub | None = None, auth_store: auth.AuthStore | None = None) -> FastAPI:
    hub = hub or Hub(EventStore(settings.db_path, settings.max_events), settings.replay_events)
    auth_store = auth_store or build_auth(settings)
    can_read = auth.require("read")

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        for url in settings.watch_urls:
            hub.watch(url)
        if settings.staff_auth and not auth_store.has_users():
            log.warning("로그인이 켜져 있는데 사용자가 없다. 먼저 만든다: "
                        "uv run python -m obs_hub.admin user add <이름> --role admin")
        task = None
        if settings.heartbeat_s > 0:
            task = asyncio.create_task(hub.heartbeat(settings.heartbeat_s))
        yield
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    app = FastAPI(title="관제 허브", version=__version__, lifespan=lifespan)
    app.state.hub = hub
    app.state.auth = auth_store
    app.state.staff_auth = settings.staff_auth
    app.state.login_hint = settings.login_hint
    app.state.session_cookie = f"session_{settings.port}"   # 한 PC에 여러 서버를 띄워도 로그인이 섞이지 않게
    app.state.permission_labels = PERMISSION_LABELS
    app.include_router(auth.router)

    @app.post("/events")
    async def receive(request: Request, event: dict) -> dict:
        if settings.ingest_auth:
            sender = auth_store.partner_for_key(request.headers.get(INGEST_HEADER))
            if sender is None or "ingest" not in sender.skills:
                raise HTTPException(401, f"수집 키가 없거나 맞지 않는다 ({INGEST_HEADER})")
            if event.get("process") != sender.name:   # 다른 시스템인 척 이벤트를 넣지 못하게
                raise HTTPException(403, f"{sender.name}의 키로 {event.get('process')} 이벤트를 넣을 수 없다")
        missing = [k for k in REQUIRED if not isinstance(event.get(k), str) or not event[k]]
        if missing:
            raise HTTPException(422, f"이벤트에 {', '.join(missing)}가 없다")
        return {"ok": True, "duplicate": not hub.receive(event)}

    @app.get("/stream", dependencies=[Depends(can_read)])
    async def stream(request: Request):
        q = hub.subscribe()

        async def generate():
            try:
                while not await request.is_disconnected():
                    try:
                        event = await asyncio.wait_for(q.get(), timeout=1)
                    except asyncio.TimeoutError:
                        continue
                    yield {"data": json.dumps(event, ensure_ascii=False)}
            finally:
                hub.unsubscribe(q)

        return EventSourceResponse(generate())

    @app.get("/events.jsonl", dependencies=[Depends(can_read)])
    async def dump() -> StreamingResponse:
        lines = (json.dumps(e, ensure_ascii=False) + "\n" for e in hub.store.all())
        return StreamingResponse(lines, media_type="application/x-ndjson; charset=utf-8")

    @app.get("/agents", dependencies=[Depends(can_read)])
    async def agents() -> list[dict]:
        return hub.agent_list()

    @app.get("/healthz")
    async def healthz() -> dict:
        return {"status": "ok", "app_version": __version__, "public_url": settings.public_url,
                "events": hub.total, "agents": len(hub.agents)}

    @app.get("/")
    async def page() -> FileResponse:
        return FileResponse(OFFICE if OFFICE.exists() else UI, media_type="text/html; charset=utf-8")

    @app.get("/classic")
    async def classic() -> FileResponse:
        return FileResponse(UI, media_type="text/html; charset=utf-8")

    return app
