# 파일명: permissions.py
"""관제 허브의 역할과 권한. 보기만 하는 사람과 관리하는 사람. 설계: systems/docs/security-and-db.md 3.1"""

from .auth import Role

PERMISSION_LABELS = {
    "read": "관제 화면·기록 보기",
    "admin": "사용자·수집 키·감사 기록 관리",
}

ROLES = {
    "viewer": Role("보기", frozenset({"read"})),
    "admin": Role("관리자", frozenset({"read", "admin"})),
}

# 업무 시스템에 발급하는 수집 키의 허용 스킬. 키의 회사 이름 = 그 시스템 이름(이벤트의 process)
PARTNER_SKILLS = ["ingest"]
