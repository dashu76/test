# 파일명: store.py
"""관찰 이벤트 저장소 (SQLite). 허브를 다시 켜도 기록이 남는다. 최근 max_events건만 둔다."""

import json
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    seq        INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id   TEXT NOT NULL UNIQUE,
    ts         INTEGER NOT NULL,
    agent_id   TEXT NOT NULL DEFAULT '',
    side       TEXT NOT NULL DEFAULT '',
    type       TEXT NOT NULL,
    task_id    TEXT NOT NULL DEFAULT '',
    process    TEXT NOT NULL DEFAULT '',
    event_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_task ON events (task_id);
"""
PRUNE_EVERY = 500   # 이만큼 넣을 때마다 오래된 것을 지운다


class EventStore:
    def __init__(self, path: Path, max_events: int = 100_000) -> None:
        self.path = path
        self.max_events = max_events
        self._added = 0
        self._lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as conn:
            conn.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        try:
            yield conn
        finally:
            conn.close()

    def add(self, event: dict) -> bool:
        """처음 보는 eventId면 저장하고 True. 이미 있으면 False."""
        with self._lock, self._conn() as conn:
            cur = conn.execute(
                "INSERT OR IGNORE INTO events (event_id, ts, agent_id, side, type, task_id, process, event_json)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (event["eventId"], int(event.get("ts") or 0), str(event.get("agentId") or ""),
                 str(event.get("side") or ""), event["type"], str(event.get("taskId") or ""),
                 str(event.get("process") or ""), json.dumps(event, ensure_ascii=False)))
            if cur.rowcount == 0:
                return False
            self._added += 1
            if self._added % PRUNE_EVERY == 0:
                conn.execute("DELETE FROM events WHERE seq <= (SELECT MAX(seq) FROM events) - ?", (self.max_events,))
            return True

    def recent(self, limit: int) -> list[dict]:
        """최근 limit건 (오래된 것부터)."""
        with self._conn() as conn:
            rows = conn.execute("SELECT event_json FROM (SELECT seq, event_json FROM events ORDER BY seq DESC LIMIT ?)"
                                " ORDER BY seq", (limit,)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def all(self) -> Iterator[dict]:
        with self._conn() as conn:
            for (data,) in conn.execute("SELECT event_json FROM events ORDER BY seq"):
                yield json.loads(data)

    def count(self) -> int:
        with self._conn() as conn:
            return conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
