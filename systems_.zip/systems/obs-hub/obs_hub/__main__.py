# 파일명: __main__.py
"""실행: uv run python -m obs_hub  (이 폴더에서)"""

import logging

import uvicorn

from .app import build_app
from .settings import load_settings


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    settings = load_settings()
    app = build_app(settings)
    print(f"[관제 허브] {settings.bind_host}:{settings.port} 에서 대기 · 공개 주소 {settings.public_url}"
          f" · DB {settings.db_path}", flush=True)
    print(f"  화면: {settings.public_url}/  · 업무 시스템은 A2A_OBS_URL={settings.public_url}", flush=True)
    if settings.watch_urls:
        print(f"  지켜보는 에이전트: {', '.join(settings.watch_urls)}", flush=True)
    uvicorn.run(app, host=settings.bind_host, port=settings.port, log_level="warning")


if __name__ == "__main__":
    main()
