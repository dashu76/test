# 관제 허브 (obs-hub) — 선택 시스템

업무 시스템(구매사·물류사)이 보내는 관찰 이벤트를 모아 한 화면에서 보여 줍니다. **업무에는 필요 없습니다.** 허브를 켜지 않아도, 중간에 꺼도 회사 간 업무는 그대로 진행됩니다(S-25). 이 폴더만 복사해 가도 설치·실행·테스트가 됩니다.

## 설치·실행

```cmd
cd obs-hub
uv sync
copy .env.example .env      :: 필요하면 값 수정
uv run python -m obs_hub
```

- 화면: `http://127.0.0.1:5090/`
- 업무 시스템은 각자 `.env`(또는 환경변수)에 `A2A_OBS_URL=http://127.0.0.1:5090`을 넣고 띄웁니다.

## 이벤트를 모으는 방법

- **받기**: 업무 시스템이 `POST /events`로 직접 보냅니다(각 시스템의 `obs_hook.py`). 허브는 업무 시스템 코드를 모릅니다.
- **켜짐·꺼짐**: 허브가 `APP_HEARTBEAT_S`(기본 2초)마다 지켜보는 주소의 Agent Card를 읽어 `agent.online` / `agent.offline`을 스스로 만듭니다. 업무 시스템이 신고하지 않아도 됩니다. 한 번도 켜진 적 없는 주소는 '꺼짐'으로 알리지 않습니다.
- 지켜보는 주소: `APP_WATCH_URLS`(기본: 다섯 회사의 기본 주소) + 이벤트를 보낸 에이전트 + 요청 상대(`payload.to`·`payload.url`).
- 같은 `eventId`는 한 번만 기록합니다. 기록은 SQLite(`APP_DB_PATH`)에 남아 **허브를 다시 켜도 이어집니다**(최근 `APP_MAX_EVENTS`건 유지).

이벤트 모양:

```json
{"v": 1, "eventId": "carrier-a-1234-7", "ts": 1791989253147, "agentId": "http://127.0.0.1:5021",
 "side": "server", "type": "task.state", "taskId": "…", "contextId": "RFQ-20261015-001",
 "process": "carrier-a", "payload": {"from": "TASK_STATE_WORKING", "to": "TASK_STATE_COMPLETED", "result": "quote quoted RFQ-… 174000 3"}}
```

| side | type | 보내는 쪽 |
|---|---|---|
| server | `agent.started` · `agent.stopped` | 모든 시스템. `payload.console`(예: `/ui`)이 있으면 화면이 이름 옆에 **업무 화면** 링크를 건다 |
| server | `task.received` · `task.state` (· `task.resumed`) | A2A 요청을 받은 시스템 (`task.resumed`는 K-Logistics: 질문에 대한 답으로 재개) |
| client | `request.sent` · `request.done` · `request.error` | 요청을 보낸 시스템 (구매사: 견적·발주·취소·조회·답 / 물류사: 배송 알림) |
| client | `card.fetched` · `card.failed` | 상대 카드 조회 결과가 바뀔 때 |
| server | `outbox.sent` · `outbox.retry` · `outbox.failed` | 물류사 배송 알림 발송 결과 |
| hub | `agent.online` · `agent.offline` | 허브 (heartbeat) |

## API

| 경로 | 내용 |
|---|---|
| `POST /events` | 이벤트 한 건 (`eventId`·`type` 필수, 수집 키 `X-Obs-Key`). 응답 `{"ok": true, "duplicate": false}` |
| `GET /stream` | SSE. 최근 `APP_REPLAY_EVENTS`건부터 보낸 뒤 새 이벤트를 실시간으로 (로그인) |
| `GET /events.jsonl` | DB에 남은 이벤트 전체 (`?snapshot=1`로 화면을 열면 이것만 한 번 그림) (로그인) |
| `GET /agents` | 지켜보는 에이전트와 켜짐·꺼짐 (로그인) |
| `/api/login` · `/api/me` · `/api/users` · `/api/keys` · `/api/audit` | 로그인·사용자·수집 키·감사 기록 (업무 시스템과 같은 `auth.py`) |
| `GET /healthz` | 상태 확인 (`public_url` 포함) |
| `GET /` | **사무 공간 화면**(`ui/office.html`): 회사마다 구역별 책상에 앉고, 받은 일·맡긴 일·승인 대기·실패가 말풍선과 경보로 보임. 파일이 없으면 `/classic`과 같은 화면 |
| `GET /classic` | 기존 관제 화면(`ui/index.html`): 서버 뷰(받은 Task와 상태 변화) · 클라이언트 뷰(보낸 요청과 시간 막대) · 이벤트 기록. taskId를 누르면 양쪽에서 같은 Task를 표시 |

## 설정 (`.env` 또는 환경변수, 환경변수가 우선)

| 이름 | 기본값 | 설명 |
|---|---|---|
| `APP_BIND_HOST` / `APP_PORT` | `127.0.0.1` / `5090` | 듣는 주소 |
| `APP_PUBLIC_URL` | `http://{bind}:{port}` | 업무 시스템이 이벤트를 보낼 주소. `0.0.0.0`으로 들을 때는 반드시 지정 |
| `APP_DB_PATH` | `data/obs_hub.sqlite3` | 이벤트·사용자·수집 키·감사 기록 (상대 경로는 이 폴더 기준) |
| `APP_MAX_EVENTS` | `100000` | DB에 남겨 둘 최근 이벤트 수 |
| `APP_REPLAY_EVENTS` | `2000` | 화면을 새로 열면 다시 보내 줄 최근 이벤트 수 |
| `APP_WATCH_URLS` | 다섯 회사 기본 주소 (`5010,5020~5023`) | 처음부터 지켜볼 에이전트 (쉼표 구분) |
| `APP_HEARTBEAT_S` | `2` | Agent Card로 켜짐·꺼짐을 판단하는 간격. `0`이면 끔 |
| `APP_STAFF_AUTH` | `true` | 화면·조회에 로그인 필요 |
| `APP_INGEST_AUTH` | `true` | 이벤트 수집에 키 필요 |
| `APP_SESSION_HOURS` | `12` | 로그인 세션 유효 시간 |
| `APP_LOGIN_HINT` | (비움) | 로그인 화면 시험 계정 안내(예: `admin3 / 1234`, 사용자 이름을 미리 넣음). 운영에서는 비운다 |

## 사무 공간 화면 (`ui/office.html`)

`vertualOfficeSource/office/agentUI.html`에 허브용 설정(회사·주소·구역, 허브 주소 = 지금 열린 주소, 로그인 창)을 넣은 파일입니다. 원본은 `systems/docs/office-hub/office.html`, 안내서는 같은 폴더의 `관제허브_사무공간_변경방법.docx`.

- 회사·구역은 파일 맨 위 설정 블록 `window.OFFICE`만 고칩니다. `agents[].url`은 각 서버의 `APP_PUBLIC_URL`과 글자까지 같아야 그 구역에 앉습니다.
- 회사를 늘리면: `APP_WATCH_URLS`에 주소 추가 + `window.OFFICE.agents`에 한 줄 + 그 회사에 수집 키 발급.
- 잠깐 바꿔 보기: `/?preset=dept&theme=night`. 배치가 꼬이면 화면의 「처음부터」.
- 되돌리기: `ui/office.html`을 지우고 허브를 다시 켜면 `/`가 기존 관제 화면이 됩니다.

## 인증 (Part 4)

관제 기록에는 회사 사이에서 오간 일이 모두 보이므로 허브도 로그인한 사람만 봅니다(`viewer` 보기, `admin` 관리). 이벤트를 넣으려면 시스템마다 발급한 **수집 키**가 필요하고, 키의 이름과 이벤트의 `process`가 같아야 합니다(다른 시스템인 척 이벤트를 넣지 못하게).

```cmd
uv run python -m obs_hub.admin user add kim --role admin
uv run python -m obs_hub.admin key issue carrier-a --skills ingest     :: 키를 그 시스템에: uv run python -m carrier_a.admin outbound set obs <키>
```

로컬에서 한 번에 준비: `systems\dev-env\setup_dev_auth.ps1`. 설계: `systems/docs/security-and-db.md`.

## 테스트

```cmd
uv run pytest
```

이벤트 수신·중복 거름·잘못된 이벤트 거부, DB에 남는 기록, `events.jsonl`, SSE(지난 기록 → 실시간), heartbeat(켜짐·꺼짐·한 번도 켜지지 않은 주소), 수집 키·로그인, 설정, 화면(`/` 사무 공간 · `/classic` · `office.html`이 없을 때)을 실제 HTTP로 확인합니다. 업무 시스템은 필요 없습니다.

## 아직 없는 것

- TLS 없음 — 로컬·사내망 전제
