# systems — 회사별 독립 시스템

Part 1~6 실습 코드와 별개로, 각 회사가 실제로 운영하는 형태를 흉내 낸 시스템들입니다. 설계는 `part3_orchestration/plan_2.md`(업무 시나리오)와 `plan_3.md`(독립 구조)를 따릅니다. 작업을 이어받을 때는 **`HANDOFF.md`**부터 읽으세요.

| 폴더 | 시스템 | 기본 포트 | 계약 | 특징 |
|---|---|---|---|---|
| `interop-spec/` | 회사 간 계약 패키지 `logistics-contract` | — | 1.0.0, 1.1.0 | 1.1.0은 견적에 선택 필드 `co2_kg` 추가 |
| `kpw-buyer/` | K정밀웍스 구매 시스템 | 5010 | 1.0.0 | 견적 수집·비교·발주·취소, 물류사 질문에 답, 배송 알림 수신·보조 조회, 납기 위험, 입고 확인·지급 기록, CLI |
| `klogistics-carrier/` | K-Logistics | 5020 | 1.0.0 | **담당자 확인**(견적·발주 수락), 구매사에 질문, 처리 마감 후 자동 처리, 기존 ORDER-1001/1002, 배송 알림 outbox, 담당자 CLI |
| `carrier-a/` | 물류사 A | 5021 | 1.0.0 | 자동 견적·자동 수락, 배송 알림 outbox, 담당자 CLI |
| `carrier-b/` | 물류사 B | 5022 | **1.1.0** | 견적에 `co2_kg` 포함 (1.0 구매사와 호환), 배송 알림 outbox, 담당자 CLI |
| `carrier-c/` | 물류사 C | 5023 | 1.0.0 | 가장 싸지만 **견적 응답이 느림** (기본 20초), 배송 알림 outbox, 담당자 CLI |
| `obs-hub/` | 관제 허브 (선택) | 5090 | — | 각 시스템이 보내는 관찰 이벤트를 모아 가상 사무 공간(`/`)과 서버 뷰·클라이언트 뷰(`/classic`)로 보여 줌. 꺼져 있어도 업무에 영향 없음 |
| `dev-env/` | 로컬 도구 | — | — | 독립성 검사, 개발용 인증 준비(`setup_dev_auth.ps1`) |
| `docs/` | 설계 문서 | — | — | `p6-carrier-ui.md` — 물류사 업무 화면 (전체 개념 포함) · `p6-buyer-ui.md` — 구매사 업무 화면 · `security-and-db.md` — 인증·권한과 DB (Part 4) |

## 규칙

- 서버 폴더 하나 = 시스템 하나. 각자 `pyproject.toml`·`uv.lock`·`.venv`·DB·설정을 가집니다.
- 서버끼리 서로의 폴더를 참조하지 않습니다. 소통은 A2A(HTTP)로만 합니다.
- 계약은 `interop-spec`에서 빌드한 wheel을 각 서버 `vendor\`에 넣어 버전 고정으로 설치합니다. 서버마다 버전이 달라도 됩니다.
- 오래 걸리는 처리(담당자 확인, 느린 산출)는 A2A Task를 `working`으로 두고, 구매사는 기다리지 않고 `tasks/get`으로 나중에 확인합니다.
- **인증(Part 4)**: 회사 사이는 받는 쪽이 발급한 파트너 키(`X-Partner-Key`), 회사 안은 로그인과 역할별 권한. 사용자·키·감사 기록·설정(요금·거래처)은 각 시스템 자기 SQLite에 있습니다. 설계: `docs/security-and-db.md`. 지금은 "인증이 된다" 수준이며, 운영 전에 필요한 보강(HTTPS, Task 소유 확인, 키 보관·교체 등)은 같은 문서 8장(P7)에 있습니다.

## 처음 준비 — 사용자와 회사 사이 키 (로컬 개발용)

인증이 기본으로 켜져 있으므로 처음 한 번 사용자를 만들고 회사끼리 키를 주고받아야 합니다. 로컬에서는 스크립트 하나로 합니다(각 시스템의 관리 도구 `<패키지>.admin`만 부름):

```powershell
.\dev-env\setup_dev_auth.ps1
```

| 시스템 | 화면 | 로그인 |
|---|---|---|
| K정밀웍스 (구매사) | http://127.0.0.1:5010/ | `admin1` / `1234` |
| K-Logistics | http://127.0.0.1:5020/ | `admin2` / `1234` |
| 물류사 A · B · C | http://127.0.0.1:5021/ · 5022/ · 5023/ | `admin3` · `admin4` · `admin5` / `1234` |
| 관제 허브 | http://127.0.0.1:5090/ | `admin6` / `1234` |

시험용 계정입니다(운영 전에 바꾼다, `docs/security-and-db.md` 8장). 각 시스템 `.env`에 `APP_LOGIN_HINT=admin3 / 1234`처럼 두면 로그인 화면에 안내가 보이고 사용자 이름이 미리 들어갑니다(지우면 사라짐). 한 PC에서 여러 화면에 동시에 로그인해도 서로 로그아웃되지 않습니다(세션 쿠키 이름에 포트를 붙임 — 브라우저는 쿠키를 포트로 나누지 않는다). 역할별 사용자(구매 담당·승인권자, 물류사 승인·운영 등)가 필요하면 각 화면 "관리" 탭에서 만듭니다. CLI도 먼저 로그인합니다: `uv run python -m kpw_buyer.cli login admin1`.

## 해 보기 — 다섯 회사 전부

터미널 5개에서 각 폴더로 들어가 실행합니다.

```cmd
cd systems\klogistics-carrier & uv run python -m klogistics_carrier
cd systems\carrier-a          & uv run python -m carrier_a
cd systems\carrier-b          & uv run python -m carrier_b
cd systems\carrier-c          & uv run python -m carrier_c
cd systems\kpw-buyer          & uv run python -m kpw_buyer
```

**한 번에 실행** — `systems\start_all.bat`을 실행(더블클릭 또는 아무 폴더에서 경로로 실행)하면 다섯 서버가 각자의 창에서 뜹니다(창 제목 = 폴더 이름). 끌 때는 각 창에서 `Ctrl+C` 후 창을 닫습니다.

```cmd
systems\start_all.bat
```

K정밀웍스 담당자는 **업무 화면** `http://127.0.0.1:5010/`(`buy`로 요청·답장·입고, `appr`로 발주·지급)이나 CLI(`kpw-buyer` 폴더에서)로 일합니다:

```cmd
uv run python -m kpw_buyer.cli rfq create --item "정밀 베어링 2팔레트" --weight 480 --origin 창원 --dest 평택 --need-by 2026-10-20 --deadline-min 10
uv run python -m kpw_buyer.cli rfq show RFQ-YYYYMMDD-001
```

→ A·B는 바로 견적, C는 "물류사 확인 중"(20초 뒤 도착), K-Logistics는 "물류사 확인 중"(담당자 대기).

물류사 담당자는 CLI 대신 **업무 화면**을 써도 됩니다: K-Logistics `http://127.0.0.1:5020/`, 물류사 A·B·C `http://127.0.0.1:5021/`·`5022/`·`5023/`. 로그인한 역할에 맞는 버튼만 보이고(견적 승인·발주 수락은 `mgr`, 배송 상태 변경은 `op`), 다른 곳에서 바뀐 것도 바로 반영됩니다. `admin`은 "관리" 탭에서 사용자·키·감사 기록을 봅니다.

K-Logistics 담당자 (`klogistics-carrier` 폴더에서):

```cmd
uv run python -m klogistics_carrier.cli inbox
uv run python -m klogistics_carrier.cli quote ask RFQ-YYYYMMDD-001 "팔레트 규격과 2단 적재 가능 여부는?"
```

→ K정밀웍스 화면에 "질문 받음". 답하고(`rfq answer RFQ-… klogistics "…"`), K-Logistics가 승인(`quote approve RFQ-…`)하면 견적이 들어옵니다.

발주부터 지급까지:

| 누가 | 명령 | 결과 |
|---|---|---|
| K정밀웍스 | `rfq award RFQ-… klogistics` | "물류사 수락 대기" |
| K-Logistics | `booking accept K-B-…` | K정밀웍스 "발주 완료" |
| 물류사 | `shipment advance <운송장> picked_up` … `delivered` | 구매사에 알림이 자동 발송 → K정밀웍스 화면이 바로 바뀜 |
| K정밀웍스 | `rfq receive RFQ-…` → `rfq pay RFQ-…` | 입고 완료 → 지급 완료 (두 번 해도 지급 1건) |

K정밀웍스 서버를 잠시 꺼도 물류사는 계속 상태를 바꿀 수 있습니다. 알림은 물류사 outbox(`outbox list`)에 쌓였다가 다시 켜지면 순서대로 도착합니다.

## 관제 허브와 함께 (선택)

여섯 번째 터미널에서 허브를 띄우고, 다섯 서버는 `A2A_OBS_URL`을 넣어 띄웁니다(각 `.env`에 적어도 됩니다).

```cmd
cd systems\obs-hub & uv run python -m obs_hub
```

각 서버 터미널에서는 실행 전에:

```cmd
set A2A_OBS_URL=http://127.0.0.1:5090
```

`start_all.bat`을 쓸 때는 같은 터미널에서 먼저 `set A2A_OBS_URL=http://127.0.0.1:5090`(PowerShell이면 `$env:A2A_OBS_URL='http://127.0.0.1:5090'`)을 실행한 뒤 bat을 실행하세요. 새로 뜨는 다섯 창이 이 값을 물려받습니다. 더블클릭으로 실행할 때는 각 서버 `.env`에 적어 두세요.

브라우저로 `http://127.0.0.1:5090/`을 열고 로그인하면 **가상 사무 공간**에 다섯 회사가 구역별 책상으로 앉고, 일을 받으면 「작업 중」·요청 말풍선, 담당자 확인 대기면 빨강 「승인 대기」, 끝나면 결과 말풍선이 실시간으로 보입니다. 서버를 끄면 그 책상이 회색 「응답 없음」이 됩니다. 기존 관제 화면(서버 뷰·클라이언트 뷰·이벤트 기록)은 `http://127.0.0.1:5090/classic`에 그대로 있습니다. 허브를 꺼도 업무는 그대로 진행되고, 허브가 없는 동안의 이벤트는 기록되지 않습니다.

### 시연 — 샘플 20개를 자동으로 흘려 보기

```cmd
python dev-env\demo\demo_runner.py
```

다섯 서버와 허브가 떠 있는 상태에서 실행한 뒤 `http://127.0.0.1:5090/`을 열면 `dev-env\demo\samples.json`의 샘플(견적→발주→배송→입고→지급)을 5초마다 하나씩 실행합니다. K-Logistics 승인·거절, 통관 보류, 입고 이상(지급 보류)도 섞여 있습니다. 같은 차례에 자재대응 Agent(:9102)에도 질문 20개(일부는 같은 대화로 이어 묻기)를 하나씩 보냅니다. 사무 공간에 보이려면 a2a 쪽(`run_agents.py --mock --office`)과 중계(`docs/office-hub/a2a-bridge/office_bridge.py --only http://127.0.0.1:9102`)가 떠 있어야 합니다. 말풍선은 받음(파랑)·보냄(보라)·완료(초록)·주의(주황)·실패(빨강)로 색이 나뉘고, 견적 금액·예약·운송장이 따로 보입니다. 「일시 정지」 옆에 진행(`샘플 3/20 · 불러오는 중`)이 보이고, 「일시 정지」를 누르면 새 샘플을 더 불러오지 않습니다(진행 중인 샘플은 끝까지). 20개를 다 불러온 뒤 화면을 새로 고치면 처음부터 다시 불러옵니다. 실행기 주소는 `office.html` 설정 블록의 `demo`.

## 독립성 검사

```powershell
.\dev-env\check_independence.ps1                  # 모든 서버
.\dev-env\check_independence.ps1 -System carrier-b
```

서버 폴더를 임시 디렉터리로 혼자 복사해 설치·테스트·기동하고, Agent Card 주소와 DB 경로가 설정대로인지 확인합니다.
