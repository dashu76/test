# K정밀웍스 구매 시스템

운송 요청(RFQ)을 만들어 거래 물류사들에 견적을 묻고, 비교해 발주하고, 배송을 추적합니다. 독립 시스템이며 이 폴더만 복사해 가도 설치·실행·테스트가 됩니다. 물류사가 꺼져 있어도 뜨고, 마감 전까지 다시 묻습니다.

## 설치·실행

```cmd
cd kpw-buyer
uv sync
copy .env.example .env      :: 필요하면 값 수정
uv run python -m kpw_buyer
```

- Agent Card: `http://127.0.0.1:5010/.well-known/agent-card.json` (물류사가 배송 알림을 보내는 곳)
- 내부 API: `http://127.0.0.1:5010/api/...` (우리 회사 화면·CLI 전용), 문서 `http://127.0.0.1:5010/docs`
- 상태 확인: `http://127.0.0.1:5010/healthz`

## CLI (화면 없이 업무 처리)

서버가 켜져 있어야 합니다. 다른 터미널에서:

```cmd
uv run python -m kpw_buyer.cli partners --check
uv run python -m kpw_buyer.cli rfq create --item "정밀 베어링 2팔레트" --weight 480 --origin 창원 --dest 평택 --need-by 2026-10-25
uv run python -m kpw_buyer.cli rfq list
uv run python -m kpw_buyer.cli rfq show RFQ-20261015-001
uv run python -m kpw_buyer.cli rfq collect RFQ-20261015-001        :: 수집기를 기다리지 않고 지금 다시 확인
uv run python -m kpw_buyer.cli rfq answer RFQ-20261015-001 klogistics "1100×1100 팔레트 2개, 2단 적재 불가"
uv run python -m kpw_buyer.cli rfq close RFQ-20261015-001          :: 마감 전이라도 받은 견적으로 진행
uv run python -m kpw_buyer.cli rfq extend RFQ-20261015-001 --minutes 30
uv run python -m kpw_buyer.cli rfq award RFQ-20261015-001 carrier-a [--allow-ineligible]
uv run python -m kpw_buyer.cli rfq track RFQ-20261015-001
uv run python -m kpw_buyer.cli rfq cancel RFQ-20261015-001 --reason "생산 일정 변경"
uv run python -m kpw_buyer.cli rfq receive RFQ-20261015-001 --note "2팔레트 이상 없음"     :: 배송 완료 후 입고 확인
uv run python -m kpw_buyer.cli rfq receive RFQ-20261015-001 --damaged --note "팔레트 1개 파손"  :: 이상 → 지급 보류
uv run python -m kpw_buyer.cli rfq pay RFQ-20261015-001                                   :: 지급 기록 (두 번 해도 1건)
```

## 설정 (`.env` 또는 환경변수, 환경변수가 우선)

| 이름 | 기본값 | 설명 |
|---|---|---|
| `APP_BUYER_NAME` | `K정밀웍스` | 견적 요청의 buyer, 업무키 앞부분 |
| `APP_BIND_HOST` / `APP_PORT` | `127.0.0.1` / `5010` | 듣는 주소 |
| `APP_PUBLIC_URL` | `http://{bind}:{port}` | Agent Card 주소 = 발주 요청에 넣는 알림 주소 |
| `APP_DB_PATH` | `data/kpw_buyer.sqlite3` | 업무 DB |
| `APP_PARTNERS_FILE` | `config/partners.toml` | 거래 물류사 (id, 주소)의 **처음 값**. 처음 뜰 때 DB로 옮기고 이후에는 DB가 원본 |
| `APP_REQUEST_TIMEOUT_S` | `10` | 물류사 HTTP 요청 하나의 응답 대기 |
| `APP_QUICK_WAIT_S` | `2` | 보낸 뒤 결과를 잠깐 기다려 보는 시간. 넘으면 `물류사 확인 중` |
| `APP_WORKER_INTERVAL_S` | `5` | 응답 없는 물류사에 다시 묻는 간격. `0`이면 수집기 끔 |
| `APP_DEFAULT_DEADLINE_MIN` | `30` | 기본 견적 마감 |
| `APP_TRACK_INTERVAL_S` | `300` | 배송 중인 발주를 직접 조회하는 간격 (알림 보조). `0`이면 끔 |
| `A2A_OBS_URL` | (비움) | 관제 허브(`obs-hub`) 주소. 비우면 관찰 이벤트를 보내지 않는다 |
| `APP_A2A_AUTH` | `true` | 회사 사이 파트너 키(`X-Partner-Key`) 요구. `false`면 지금까지처럼 열림 |
| `APP_STAFF_AUTH` | `true` | 화면·내부 API·CLI 로그인 요구 |
| `APP_SESSION_HOURS` | `12` | 로그인 세션 유효 시간 |
| `APP_LOGIN_HINT` | (비움) | 로그인 화면 시험 계정 안내(예: `admin3 / 1234`, 사용자 이름을 미리 넣음). 운영에서는 비운다 |
| `APP_UI_ENABLED` | `true` | 업무 화면(`/ui`). `false`면 화면만 끈다(A2A·내부 API·CLI는 그대로) |
| `APP_UI_ACCENT` | `#4338ca` | 화면 강조색(회사 색, `#rrggbb`) |

물류사가 서버를 옮기면 거래처 주소만 고칩니다(`cli partner set <id> --url …`, 아래 "인증과 권한"). `id`는 업무키·키 대상에 들어가므로 바꾸지 않습니다.

## 업무 규칙

| 단계 | 동작 | 시나리오 |
|---|---|---|
| 견적 수집 | 모든 거래처에 동시에 `quote`. 연결 실패는 마감까지 다시 보내고, 마감에 `응답 없음` | S-01, S-03, S-04 |
| 물류사 확인 중 | 보내고 기다리지 않는다(`return_immediately`). 금방 안 끝나면 `물류사 확인 중`으로 두고 수집기가 `tasks/get`으로 확인. 물류사 재시작으로 Task가 사라지면 같은 요청을 다시 보냄 | S-02, S-14, S-29 |
| 질문 받음 | 물류사가 되물으면(`input-required`) 질문을 보여 주고, `rfq answer`로 같은 Task에 답을 보냄 | S-07 |
| 견적 판정 | 계약 위반 응답 `검증 실패`, 거절 `견적 거절`, Task 실패·계약 비호환 `실패` | S-05, S-08 |
| 비교 | 납기·유효기간을 충족한 견적 중 최저가를 추천. 미충족은 표시만 하고 숨기지 않음 | S-06 |
| 마감 | 응답 0건이면 `유찰`. 마감 연장 시 응답 없던 곳에 다시 물음 | S-09 |
| 발주 | 업무키 `K정밀웍스:{RFQ}:book:{거래처id}:v1`. 못 보냈으면 `결과 확인 필요` → 다시 award하면 같은 내용으로 재전송. 물류사 담당자 수락 대기면 `물류사 수락 대기` → 수집기가 확인 | S-10, S-12, S-13, S-14 |
| 취소 | `cancel-booking`. 물류사가 거절하면(집하 후) 사유 표시 | S-15, S-16 |
| 배송 | 물류사 알림(`receive-shipment-event`)으로 갱신. 중복·늦게 온 옛 상태는 반영 안 함. 알림을 놓쳐도 수집기가 배송 중인 발주를 `APP_TRACK_INTERVAL_S`(기본 5분)마다 직접 조회(`track`) | S-17~S-20 |
| 납기 위험 | 통관 보류, 또는 도착 예정일(발주 수락 시 견적 소요일로 추정, 이후 물류사 조회값)이 희망 납기보다 늦으면 `[!] 납기 위험` | S-21 |
| 입고·지급 | 배송 완료 후에만 입고 확인. 이상 없음 → 지급 가능, 이상 있음 → 지급 보류. 지급은 업무키 `K정밀웍스:{RFQ}:pay:{예약번호}:v1`로 한 번만 기록 (Ch15) | S-23, S-24 |
| 재시작 | 수집 중인 요청은 DB에서 읽어 수집기가 이어서 처리 | S-29 |

## 업무 화면

브라우저로 `http://127.0.0.1:5010/` (→ `/ui`). 서버가 직접 내주는 화면이며 이 회사의 내부 API(`/api`)만 부릅니다. 설계: `systems/docs/p6-buyer-ui.md`.

- **운송 요청**: 왼쪽 목록에 요청마다 진행 요약과 **할 일**(질문 답 필요·발주 결정·물류사 수락 대기·납기 위험·입고 확인·지급·지급 보류). 오른쪽 상세에서 견적 비교(조건 충족 최저가 추천 ★), 물류사 질문에 답, 발주, 배송 추적·조회, 발주 취소, 입고 확인, 지급 기록.
- **새 요청**: 품목·중량·구간·희망 납기·마감·물류사를 골라 견적 요청.
- **거래처**: Agent Card로 연결 확인, (관리자) 추가·주소 변경·빼기.
- **설정 보기**, **관리**(관리자: 사용자·키·감사 기록).
- 로그인한 역할에 맞는 버튼만 보이고, 돈·약속이 걸린 발주·취소·지급은 두 번 눌러 확정합니다. 물류사 쪽에서 일어난 일(견적 도착·질문·수락·배송 알림)은 `/api/stream`(SSE)으로 바로 반영됩니다.

## 인증과 권한 (Part 4)

설계: `systems/docs/security-and-db.md`. 로컬에서 다섯 회사를 한 번에 준비하려면 `systems\dev-env\setup_dev_auth.ps1`.

**회사 사이 — 파트너 키 (Ch18).** 물류사를 부를 때 그 물류사가 우리에게 발급한 키를 `X-Partner-Key`로 냅니다(거래처 id로 찾으므로 주소가 바뀌어도 그대로). 물류사가 배송 알림을 보낼 때는 우리가 발급한 키를 내야 하고, **그 발주의 거래처가 보낸 알림만** 반영합니다. 상대가 우리 키를 거부하면(HTTP 401) 그 견적·발주는 "실패 — 파트너 키가 거부됐다"로 남습니다.

```cmd
uv run python -m kpw_buyer.admin outbound set carrier-a <물류사 A가 준 키>      :: 대상 = 거래처 id
uv run python -m kpw_buyer.admin key issue carrier-a --skills receive-shipment-event   :: 물류사 A에 줄 알림 키
```

**사내 — 로그인과 역할 (Ch19).** 돈이 걸린 실행(발주·취소·지급)은 승인권자만.

| 역할 | 할 수 있는 일 |
|---|---|
| `viewer` 조회 | 목록 보기 |
| `buyer` 구매 담당 | + 운송 요청·마감·연장·질문 답·추적, 입고 확인 |
| `approver` 승인권자 | + 발주·취소, 지급 기록 |
| `admin` 관리자 | + 거래처 추가·주소 변경, 사용자·키·감사 기록 |

```cmd
uv run python -m kpw_buyer.admin user add kim --role admin    :: 첫 관리자 (서버 밖, DB에 직접)
uv run python -m kpw_buyer.cli login kim                      :: CLI 로그인 (세션: data\.cli_session)
uv run python -m kpw_buyer.admin audit                        :: 감사 기록
```

**거래처는 DB에 있습니다.** `config/partners.toml`은 처음 뜰 때 한 번만 읽습니다. 이후 추가·주소 변경(S-32)은:

```cmd
uv run python -m kpw_buyer.cli partner add carrier-d http://127.0.0.1:5024
uv run python -m kpw_buyer.cli partner set carrier-c --url http://127.0.0.1:5033
uv run python -m kpw_buyer.cli partner set carrier-d --active no      :: 새 운송 요청에서 뺀다
```

## 관제 허브 (선택)

`A2A_OBS_URL`에 관제 허브(`obs-hub`, 기본 `http://127.0.0.1:5090`) 주소를 넣으면 이 시스템이 관찰 이벤트를 직접 보냅니다(`kpw_buyer/obs_hook.py`). 비워 두면 아무 일도 하지 않습니다. 보내기는 백그라운드 스레드가 하므로 허브가 꺼져 있거나 느려도 업무는 기다리지 않습니다(S-25). 허브에 닿지 않으면 5초 동안은 이벤트를 버립니다 — 관찰 기록은 업무 기록이 아닙니다.

| 이벤트 | 언제 |
|---|---|
| `agent.started` / `agent.stopped` | 서버 기동·종료 |
| `task.received` / `task.state` | A2A 요청을 받음 / Task 상태가 바뀔 때마다 (완료·실패·질문이면 결과 요약) |
| `card.fetched` / `card.failed` | 물류사 카드 조회 결과가 바뀔 때 |
| `request.sent` / `request.done` / `request.error` | 물류사에 견적·발주·취소·조회·답(`answer`)을 보낼 때. 처리 중이던 Task는 수집기가 `tasks/get`으로 확인해 결과가 바뀌면 같은 요청의 `request.done`을 다시 보낸다 |

## 테스트

```cmd
uv run pytest
```

`tests/fake_carrier.py`가 계약 패키지만으로 만든 가짜 물류사를 실제 HTTP로 띄워 위 시나리오를 확인합니다. 다른 회사 시스템 코드는 쓰지 않습니다. 관찰 이벤트는 `tests/fake_hub.py`(가짜 허브)로 확인합니다.

## 아직 없는 것

- TLS 없음 — 로컬·사내망 전제. 다른 머신과 주고받으려면 앞단에 HTTPS 프록시를 둔다
- 지급 보류 후 클레임 처리는 범위 밖 (plan_2 S-24)
