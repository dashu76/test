# 파일명: domain.py
"""K정밀웍스 구매 업무 규칙. 저장소·네트워크를 모르는 순수 함수만 둔다 (plan_2 6장 상태 모델)."""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from enum import StrEnum

from logistics_contract import Quote, ShipmentStatus

KST = timezone(timedelta(hours=9), "KST")


def now_kst() -> datetime:
    return datetime.now(KST)


class RfqState(StrEnum):
    COLLECTING = "collecting"   # 견적 수집 중
    COMPARED = "compared"       # 수집 끝, 비교 가능
    NO_BIDS = "no_bids"         # 유찰 (견적 0건)
    AWARDED = "awarded"         # 발주 완료 (배송 중)
    RECEIVED = "received"       # 입고 확인 (이상 없음) → 지급 가능
    ON_HOLD = "on_hold"         # 입고 시 이상 발견 → 지급 보류 (S-24)
    PAID = "paid"               # 지급 기록 완료
    CANCELLED = "cancelled"     # 발주 취소


class QuoteState(StrEnum):
    PENDING = "pending"         # 아직 못 보냄 (연결 실패면 마감 전까지 다시 보낸다)
    WAITING = "waiting"         # 물류사가 받았고 처리 중 (담당자 확인 등) → tasks/get으로 다시 확인
    QUESTION = "question"       # 물류사가 되물음 (input-required) → 우리 담당자가 답해야 함 (S-07)
    QUOTED = "quoted"
    DECLINED = "declined"       # 물류사가 견적 거절 (업무 결과)
    INVALID = "invalid"         # 응답이 계약과 다름 (Ch16)
    FAILED = "failed"           # 물류사 Task failed 또는 계약 비호환
    NO_RESPONSE = "no_response" # 마감까지 응답 없음


class BookingState(StrEnum):
    SENDING = "sending"         # 보내는 중
    UNKNOWN = "unknown"         # 보냈는데 결과를 못 받음 → 같은 업무키로 다시 보내야 함 (S-12)
    WAITING = "waiting"         # 물류사 담당자 수락 대기 (S-14) → tasks/get으로 다시 확인
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    FAILED = "failed"
    CANCELLED = "cancelled"


RFQ_LABEL = {
    RfqState.COLLECTING: "견적 수집 중", RfqState.COMPARED: "비교 가능", RfqState.NO_BIDS: "유찰",
    RfqState.AWARDED: "발주 완료", RfqState.RECEIVED: "입고 완료", RfqState.ON_HOLD: "지급 보류",
    RfqState.PAID: "지급 완료", RfqState.CANCELLED: "취소",
}
OPEN_QUOTE_STATES = (QuoteState.PENDING, QuoteState.WAITING, QuoteState.QUESTION)  # 아직 결론 없음

QUOTE_LABEL = {
    QuoteState.PENDING: "대기", QuoteState.WAITING: "물류사 확인 중", QuoteState.QUESTION: "질문 받음",
    QuoteState.QUOTED: "견적 수신", QuoteState.DECLINED: "견적 거절",
    QuoteState.INVALID: "검증 실패", QuoteState.FAILED: "실패", QuoteState.NO_RESPONSE: "응답 없음",
}
BOOKING_LABEL = {
    BookingState.SENDING: "발주 전송 중", BookingState.UNKNOWN: "결과 확인 필요(재전송)",
    BookingState.WAITING: "물류사 수락 대기",
    BookingState.ACCEPTED: "수락됨", BookingState.REJECTED: "거절됨", BookingState.FAILED: "실패",
    BookingState.CANCELLED: "취소됨",
}
SHIPMENT_LABEL = {
    ShipmentStatus.PENDING: "수락 대기", ShipmentStatus.ACCEPTED: "수락됨", ShipmentStatus.PICKED_UP: "집하",
    ShipmentStatus.IN_TRANSIT: "운송 중", ShipmentStatus.CUSTOMS_HOLD: "통관 대기",
    ShipmentStatus.DELIVERED: "배송 완료", ShipmentStatus.CANCELLED: "취소됨",
}


@dataclass
class Eligibility:
    eligible: bool
    expired: bool
    issues: list[str] = field(default_factory=list)


def check_quote(quote: Quote, need_by: date | None, now: datetime) -> Eligibility:
    """S-06 납기 조건, S-10 유효기간. 유효기간이 지난 견적은 어떤 경우에도 발주할 수 없다."""
    issues = []
    expired = quote.valid_until < now
    if expired:
        issues.append("견적 유효기간 지남")
    if need_by is not None:
        arrival = now.astimezone(KST).date() + timedelta(days=quote.eta_days)
        if arrival > need_by:
            issues.append(f"납기 초과 (도착 예상 {arrival}, 희망 {need_by})")
    return Eligibility(eligible=not issues, expired=expired, issues=issues)


def recommend(candidates: list[tuple[str, Quote, Eligibility]]) -> str | None:
    """조건을 모두 충족한 견적 중 최저가. 같은 값이면 빠른 납기."""
    ok = [(pid, q) for pid, q, e in candidates if e.eligible]
    if not ok:
        return None
    return min(ok, key=lambda x: (x[1].price_krw, x[1].eta_days))[0]


def booking_key(buyer: str, rfq_id: str, partner_id: str) -> str:
    return f"{buyer}:{rfq_id}:book:{partner_id}:v1"


def cancel_key(buyer: str, rfq_id: str, booking_id: str) -> str:
    return f"{buyer}:{rfq_id}:cancel:{booking_id}:v1"


def payment_key(buyer: str, rfq_id: str, booking_id: str) -> str:
    """Ch15 business_key_demo와 같은 모양의 지급 업무키."""
    return f"{buyer}:{rfq_id}:pay:{booking_id}:v1"


def delay_risk(shipment_status: str | None, eta: str | None, need_by: str | None) -> str:
    """S-21: 납기 위험 사유. 없으면 빈 문자열."""
    if shipment_status == ShipmentStatus.CUSTOMS_HOLD:
        return "통관 보류"
    if eta and need_by and date.fromisoformat(eta) > date.fromisoformat(need_by):
        return f"도착 예정 {eta}이 희망 납기 {need_by}보다 늦음"
    return ""
