# 파일명: card.py
"""Agent Card. 물류사는 이 카드의 주소로 배송 상태 알림을 보낸다. URL은 설정의 공개 주소에서 만든다."""

from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill
from logistics_contract import CONTRACT_TAG, SKILL_RECEIVE_SHIPMENT_EVENT

from . import __version__
from .a2a_auth import card_security
from .settings import Settings

JSON = "application/json"


def build_card(settings: Settings) -> AgentCard:
    return AgentCard(
        name=f"{settings.buyer_name} 구매 시스템",
        description=f"{settings.buyer_name}의 운송 발주 시스템. 물류사의 배송 상태 알림을 받는다",
        version=__version__,
        default_input_modes=[JSON],
        default_output_modes=[JSON],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[
            AgentInterface(url=f"{settings.public_url}/", protocol_binding="JSONRPC", protocol_version="1.0")
        ],
        skills=[
            AgentSkill(
                id=SKILL_RECEIVE_SHIPMENT_EVENT, name=SKILL_RECEIVE_SHIPMENT_EVENT,
                description="shipment-event를 받아 event-ack를 돌려준다. event_id로 중복을 거르고 seq가 작으면 반영하지 않는다",
                tags=[CONTRACT_TAG], input_modes=[JSON], output_modes=[JSON],
            )
        ],
        **(card_security() if settings.a2a_auth else {}),   # 알림을 보내려면 X-Partner-Key가 필요하다 (Ch18)
    )
