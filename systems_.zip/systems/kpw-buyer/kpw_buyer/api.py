# 파일명: api.py
"""내부 API (/api). 우리 회사 화면·CLI 전용이다. 다른 회사는 A2A로만 들어온다.

모든 경로는 로그인이 필요하고(APP_STAFF_AUTH), 경로마다 권한이 다르다(permissions.py, Part 4 Ch19):
돈이 걸린 실행(발주·취소·지급)은 승인권자만. 로그인·사용자·키·감사 기록 경로는 auth.py에 있다.
"""

import asyncio
import functools
import json
from datetime import date
from typing import Literal

import logistics_contract
from fastapi import APIRouter, Depends, HTTPException, Request
from sse_starlette.sse import EventSourceResponse
from pydantic import BaseModel, Field

from . import __version__
from .auth import StaffUser, require
from .service import BuyerError, BuyerService


class RfqCreate(BaseModel):
    item: str = Field(min_length=1)
    weight_kg: float = Field(gt=0)
    origin: str = Field(min_length=1)
    destination: str = Field(min_length=1)
    need_by: date | None = None
    deadline_min: int | None = Field(default=None, gt=0)
    partners: list[str] | None = None


class Award(BaseModel):
    partner_id: str
    allow_ineligible: bool = False


class Extend(BaseModel):
    minutes: int = Field(gt=0)


class Cancel(BaseModel):
    reason: str = ""


class Answer(BaseModel):
    partner_id: str
    text: str = Field(min_length=1)


class PartnerAdd(BaseModel):
    id: str = Field(min_length=1)
    url: str = Field(min_length=1)


class PartnerChange(BaseModel):
    url: str | None = None
    active: bool | None = None


class Receipt(BaseModel):
    condition: Literal["ok", "damaged"] = "ok"
    note: str = ""


router = APIRouter(prefix="/api", dependencies=[Depends(require("read"))])


def svc(request: Request) -> BuyerService:
    return request.app.state.service


def audit(request: Request, user: StaffUser, action: str, target: str, detail: str = "") -> None:
    request.app.state.auth.audit(user.username, action, target, detail)


def business(fn):
    """BuyerError → 409 (담당자가 읽을 사유를 그대로 돌려준다)."""
    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):
        try:
            return await fn(*args, **kwargs)
        except BuyerError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
    return wrapper


STREAM_CHECK_S = 0.5   # 화면 실시간 갱신: DB revision을 보는 간격


@router.get("/meta")
async def meta(request: Request):
    """화면이 이 회사에 맞게 그리는 데 필요한 것."""
    s = svc(request).settings
    return {
        "name": s.buyer_name, "public_url": s.public_url, "app_version": __version__,
        "contract_version": logistics_contract.__version__,
        "default_deadline_min": s.default_deadline_min, "request_timeout_s": s.request_timeout_s,
        "quick_wait_s": s.quick_wait_s, "worker_interval_s": s.worker_interval_s,
        "track_interval_s": s.track_interval_s, "obs_url": s.obs_url, "db_path": str(s.db_path),
        "ui_enabled": s.ui_enabled, "accent": s.ui_accent, "a2a_auth": s.a2a_auth, "staff_auth": s.staff_auth,
    }


@router.get("/board")
async def board(request: Request):
    return svc(request).board()


@router.get("/stream")
async def stream(request: Request):
    """SSE. DB가 바뀔 때마다 {"rev": n}을 보낸다(연결 직후 한 번). 화면은 받으면 다시 읽는다."""
    store = svc(request).store

    async def changes():
        last = None
        while not await request.is_disconnected():
            if store.revision != last:
                last = store.revision
                yield {"data": json.dumps({"rev": last})}
            await asyncio.sleep(STREAM_CHECK_S)

    return EventSourceResponse(changes(), ping=15)


@router.get("/partners")
async def partners(request: Request, check: bool = False):
    service = svc(request)
    out = []
    for p in service.partner_rows():
        item = dict(p)
        if check:
            try:
                card = await service.client.fetch_card(p["url"])
                item.update(reachable=True, name=card.name,
                            skills={s.id: list(s.tags) for s in card.skills})
            except Exception as exc:
                item.update(reachable=False, error=str(exc))
        out.append(item)
    return out


@router.post("/partners", status_code=201)
@business
async def add_partner(request: Request, body: PartnerAdd, user: StaffUser = Depends(require("partners.edit"))):
    row = svc(request).add_partner(body.id, body.url)
    audit(request, user, "partner.add", body.id, row["url"])
    return row


@router.patch("/partners/{partner_id}")
@business
async def change_partner(request: Request, partner_id: str, body: PartnerChange,
                         user: StaffUser = Depends(require("partners.edit"))):
    row = svc(request).update_partner(partner_id, body.url, body.active)
    audit(request, user, "partner.update", partner_id, f"url={row['url']} active={row['active']}")
    return row


@router.post("/rfqs", status_code=201)
@business
async def create_rfq(request: Request, body: RfqCreate, user: StaffUser = Depends(require("rfq.manage"))):
    service = svc(request)
    rfq_id = service.create_rfq(item=body.item, weight_kg=body.weight_kg, origin=body.origin,
                                destination=body.destination, need_by=body.need_by,
                                deadline_min=body.deadline_min, partner_ids=body.partners)
    audit(request, user, "rfq.create", rfq_id, f"{body.item} {body.weight_kg}kg {body.origin}→{body.destination}")
    await service.collect(rfq_id)  # 바로 한 번 묻는다. 나머지는 수집기가 마감까지 다시 묻는다
    return service.view(rfq_id)


@router.get("/rfqs")
async def list_rfqs(request: Request):
    return svc(request).list_view()


@router.get("/rfqs/{rfq_id}")
@business
async def get_rfq(request: Request, rfq_id: str):
    return svc(request).view(rfq_id)


@router.post("/rfqs/{rfq_id}/collect")
@business
async def collect(request: Request, rfq_id: str, _: StaffUser = Depends(require("rfq.manage"))):
    """지금 바로 다시 묻고·확인한다 (수집기를 기다리지 않고)."""
    service = svc(request)
    await service.refresh(rfq_id)
    return service.view(rfq_id)


@router.post("/rfqs/{rfq_id}/answer")
@business
async def answer(request: Request, rfq_id: str, body: Answer, user: StaffUser = Depends(require("rfq.manage"))):
    view = await svc(request).answer(rfq_id, body.partner_id, body.text)
    audit(request, user, "rfq.answer", rfq_id, f"{body.partner_id}: {body.text}")
    return view


@router.post("/rfqs/{rfq_id}/close")
@business
async def close(request: Request, rfq_id: str, _: StaffUser = Depends(require("rfq.manage"))):
    service = svc(request)
    service.close_now(rfq_id)
    return service.view(rfq_id)


@router.post("/rfqs/{rfq_id}/extend")
@business
async def extend(request: Request, rfq_id: str, body: Extend, _: StaffUser = Depends(require("rfq.manage"))):
    service = svc(request)
    service.extend(rfq_id, body.minutes)
    await service.collect(rfq_id)
    return service.view(rfq_id)


@router.post("/rfqs/{rfq_id}/award")
@business
async def award(request: Request, rfq_id: str, body: Award, user: StaffUser = Depends(require("award"))):
    view = await svc(request).award(rfq_id, body.partner_id, body.allow_ineligible)
    audit(request, user, "rfq.award", rfq_id, body.partner_id + (" (조건 미충족 허용)" if body.allow_ineligible else ""))
    return view


@router.post("/rfqs/{rfq_id}/cancel")
@business
async def cancel(request: Request, rfq_id: str, body: Cancel, user: StaffUser = Depends(require("award"))):
    view = await svc(request).cancel(rfq_id, body.reason)
    audit(request, user, "rfq.cancel", rfq_id, body.reason)
    return view


@router.post("/rfqs/{rfq_id}/track")
@business
async def track(request: Request, rfq_id: str, _: StaffUser = Depends(require("rfq.manage"))):
    return await svc(request).track(rfq_id)


@router.post("/rfqs/{rfq_id}/receive")
@business
async def receive(request: Request, rfq_id: str, body: Receipt, user: StaffUser = Depends(require("receive"))):
    view = svc(request).confirm_receipt(rfq_id, body.condition, body.note)
    audit(request, user, "rfq.receive", rfq_id, f"{body.condition} {body.note}".strip())
    return view


@router.post("/rfqs/{rfq_id}/pay")
@business
async def pay(request: Request, rfq_id: str, user: StaffUser = Depends(require("pay"))):
    view, created = svc(request).pay(rfq_id)
    if created:
        audit(request, user, "rfq.pay", rfq_id)
    return view | {"payment_result": "모의 지급 기록 1건 생성" if created else "이미 기록됨"}
