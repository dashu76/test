# 파일명: permissions.py
"""K정밀웍스 직원의 역할과 권한 (Part 4 Ch19 권한 경계). 조회는 누구나, 돈이 걸린 실행(발주·지급)은 승인권자만.
설계: systems/docs/security-and-db.md 3.1"""

from .auth import Role

PERMISSION_LABELS = {
    "read": "목록 보기",
    "rfq.manage": "운송 요청·마감·질문 답·추적",
    "receive": "입고 확인",
    "award": "발주·취소",
    "pay": "지급 기록",
    "partners.edit": "거래처 추가·주소 변경",
    "admin": "사용자·키·감사 기록 관리",
}

_VIEW = {"read"}
_BUY = _VIEW | {"rfq.manage", "receive"}
_APPROVE = _BUY | {"award", "pay"}

ROLES = {
    "viewer": Role("조회", frozenset(_VIEW)),
    "buyer": Role("구매 담당", frozenset(_BUY)),
    "approver": Role("승인권자", frozenset(_APPROVE)),
    "admin": Role("관리자", frozenset(_APPROVE | {"partners.edit", "admin"})),
}

# 물류사에 발급하는 키의 기본 허용 스킬 (배송 상태 알림만). 키의 회사 이름 = 우리 거래처 id
PARTNER_SKILLS = ["receive-shipment-event"]
