# 파일명: store.py
"""K정밀웍스 전용 SQLite 저장소. 업무 상태의 원본이다 (A2A Task는 전달 수단)."""

import json
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS rfqs (
    rfq_seq      INTEGER PRIMARY KEY AUTOINCREMENT,
    rfq_id       TEXT UNIQUE,
    request_json TEXT NOT NULL,           -- 물류사에 보내는 quote-request
    deadline     TEXT NOT NULL,
    state        TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    closed_at    TEXT
);
CREATE TABLE IF NOT EXISTS rfq_quotes (
    rfq_id       TEXT NOT NULL,
    partner_id   TEXT NOT NULL,
    carrier_name TEXT,
    state        TEXT NOT NULL,
    quote_json   TEXT,
    error        TEXT NOT NULL DEFAULT '',
    question     TEXT NOT NULL DEFAULT '',   -- 물류사가 되물은 내용 (state=question)
    attempts     INTEGER NOT NULL DEFAULT 0,
    task_id      TEXT NOT NULL DEFAULT '',   -- 물류사 쪽 A2A Task (waiting·question일 때 다시 확인·답장에 사용)
    updated_at   TEXT NOT NULL,
    PRIMARY KEY (rfq_id, partner_id)
);
CREATE TABLE IF NOT EXISTS bookings (
    business_key    TEXT PRIMARY KEY,
    rfq_id          TEXT NOT NULL,
    partner_id      TEXT NOT NULL,
    quote_id        TEXT NOT NULL,
    request_json    TEXT NOT NULL,        -- 재전송할 때 똑같이 보낸다
    state           TEXT NOT NULL,
    task_id         TEXT NOT NULL DEFAULT '',
    booking_id      TEXT,
    tracking_no     TEXT,
    reason          TEXT NOT NULL DEFAULT '',
    shipment_status TEXT,
    shipment_seq    INTEGER NOT NULL DEFAULT -1,
    shipment_note   TEXT NOT NULL DEFAULT '',
    eta             TEXT,
    tracked_at      TEXT,                 -- 마지막으로 check-delivery로 직접 조회한 시각
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS receipts (
    rfq_id       TEXT PRIMARY KEY,
    business_key TEXT NOT NULL,           -- 어느 발주의 입고인지
    condition    TEXT NOT NULL,           -- ok | damaged
    note         TEXT NOT NULL DEFAULT '',
    confirmed_at TEXT NOT NULL
);
-- 지급 기록 (모의). 업무키로 한 번만 기록한다 (Ch15 business_key_demo).
CREATE TABLE IF NOT EXISTS payments (
    business_key TEXT PRIMARY KEY,
    rfq_id       TEXT NOT NULL,
    payload      TEXT NOT NULL,
    created_at   TEXT NOT NULL
);
-- 거래처 (처음 뜰 때 config/partners.toml로 채운다. 이후에는 DB가 원본 — 주소가 바뀌면 여기만 고친다, S-32)
CREATE TABLE IF NOT EXISTS partners (
    id         TEXT PRIMARY KEY,
    url        TEXT NOT NULL,
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS shipment_events (
    event_id    TEXT PRIMARY KEY,
    tracking_no TEXT NOT NULL,
    seq         INTEGER NOT NULL,
    status      TEXT NOT NULL,
    at          TEXT NOT NULL,
    note        TEXT NOT NULL DEFAULT '',
    applied     INTEGER NOT NULL,         -- 0이면 순번이 늦어 상태에 반영하지 않음 (S-20)
    received_at TEXT NOT NULL
);
"""


def dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False)


class Store:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.revision = 0                   # 바뀐 행이 있는 쓰기마다 1씩 오른다 (화면 실시간 갱신용)
        self._revision_lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.read() as conn:
            conn.executescript(SCHEMA)

    # ---------- 거래처 ----------

    def seed_partners(self, partners, now: str) -> bool:
        """거래처가 하나도 없을 때만 설정 파일 값으로 채운다."""
        with self.transaction() as conn:
            if conn.execute("SELECT 1 FROM partners LIMIT 1").fetchone() is not None:
                return False
            conn.executemany("INSERT INTO partners (id, url, created_at, updated_at) VALUES (?, ?, ?, ?)",
                             [(p.id, p.url, now, now) for p in partners])
            return True

    def partners(self, active_only: bool = False) -> list[sqlite3.Row]:
        with self.read() as conn:
            sql = "SELECT * FROM partners" + (" WHERE active=1" if active_only else "") + " ORDER BY id"
            return conn.execute(sql).fetchall()

    def partner(self, partner_id: str) -> sqlite3.Row | None:
        with self.read() as conn:
            return conn.execute("SELECT * FROM partners WHERE id=?", (partner_id,)).fetchone()

    def partner_id_by_url(self, url: str) -> str | None:
        with self.read() as conn:
            row = conn.execute("SELECT id FROM partners WHERE url=?", (url.rstrip("/"),)).fetchone()
        return row["id"] if row else None

    def add_partner(self, partner_id: str, url: str, now: str) -> None:
        with self.transaction() as conn:
            conn.execute("INSERT INTO partners (id, url, created_at, updated_at) VALUES (?, ?, ?, ?)",
                         (partner_id, url, now, now))

    def update_partner(self, partner_id: str, now: str, **fields) -> bool:
        cols = ", ".join(f"{k}=?" for k in fields)
        with self.transaction() as conn:
            return conn.execute(f"UPDATE partners SET {cols}, updated_at=? WHERE id=?",
                                (*fields.values(), now, partner_id)).rowcount > 0

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.execute("COMMIT")
            if conn.total_changes:   # 읽기만 한 트랜잭션은 화면을 다시 그리게 하지 않는다
                with self._revision_lock:
                    self.revision += 1
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.close()

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            yield conn
        finally:
            conn.close()

    # ---------- 운송 요청(RFQ) ----------

    def create_rfq(self, make_request, partner_ids: list[str], deadline: str, now: str) -> str:
        """make_request(rfq_id) -> dict. 번호를 받은 뒤 요청을 만든다."""
        with self.transaction() as conn:
            cur = conn.execute(
                "INSERT INTO rfqs (request_json, deadline, state, created_at) VALUES ('{}', ?, 'collecting', ?)",
                (deadline, now),
            )
            seq = cur.lastrowid
            rfq_id = f"RFQ-{now[:10].replace('-', '')}-{seq:03d}"
            conn.execute("UPDATE rfqs SET rfq_id=?, request_json=? WHERE rfq_seq=?",
                         (rfq_id, dumps(make_request(rfq_id)), seq))
            for pid in partner_ids:
                conn.execute(
                    "INSERT INTO rfq_quotes (rfq_id, partner_id, state, updated_at) VALUES (?, ?, 'pending', ?)",
                    (rfq_id, pid, now),
                )
            return rfq_id

    def get_rfq(self, rfq_id: str) -> sqlite3.Row | None:
        with self.read() as conn:
            return conn.execute("SELECT * FROM rfqs WHERE rfq_id=?", (rfq_id,)).fetchone()

    def list_rfqs(self, state: str | None = None) -> list[sqlite3.Row]:
        with self.read() as conn:
            if state:
                return conn.execute("SELECT * FROM rfqs WHERE state=? ORDER BY rfq_seq DESC", (state,)).fetchall()
            return conn.execute("SELECT * FROM rfqs ORDER BY rfq_seq DESC").fetchall()

    def set_rfq(self, rfq_id: str, **fields: Any) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        with self.transaction() as conn:
            conn.execute(f"UPDATE rfqs SET {cols} WHERE rfq_id=?", (*fields.values(), rfq_id))

    # ---------- 업체별 견적 ----------

    def quotes(self, rfq_id: str) -> list[sqlite3.Row]:
        with self.read() as conn:
            return conn.execute("SELECT * FROM rfq_quotes WHERE rfq_id=? ORDER BY partner_id", (rfq_id,)).fetchall()

    def set_quote(self, rfq_id: str, partner_id: str, **fields: Any) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        with self.transaction() as conn:
            conn.execute(f"UPDATE rfq_quotes SET {cols} WHERE rfq_id=? AND partner_id=?",
                         (*fields.values(), rfq_id, partner_id))

    def open_to(self, rfq_id: str, state: str, now: str) -> None:
        """아직 결론 없는 견적(대기·확인 중·질문 받음)을 한꺼번에 정리한다 (마감·지금 진행·발주 완료)."""
        with self.transaction() as conn:
            conn.execute("UPDATE rfq_quotes SET state=?, updated_at=? WHERE rfq_id=?"
                         " AND state IN ('pending', 'waiting', 'question')", (state, now, rfq_id))

    def reopen_no_response(self, rfq_id: str, now: str) -> None:
        with self.transaction() as conn:
            conn.execute("UPDATE rfq_quotes SET state='pending', updated_at=? WHERE rfq_id=? AND state='no_response'",
                         (now, rfq_id))

    # ---------- 발주 ----------

    def booking(self, business_key: str) -> sqlite3.Row | None:
        with self.read() as conn:
            return conn.execute("SELECT * FROM bookings WHERE business_key=?", (business_key,)).fetchone()

    def waiting_bookings(self) -> list[sqlite3.Row]:
        with self.read() as conn:
            return conn.execute("SELECT * FROM bookings WHERE state='waiting' ORDER BY created_at").fetchall()

    def bookings_for(self, rfq_id: str) -> list[sqlite3.Row]:
        with self.read() as conn:
            return conn.execute("SELECT * FROM bookings WHERE rfq_id=? ORDER BY created_at", (rfq_id,)).fetchall()

    def booking_by_tracking(self, tracking_no: str) -> sqlite3.Row | None:
        with self.read() as conn:
            return conn.execute("SELECT * FROM bookings WHERE tracking_no=?", (tracking_no,)).fetchone()

    def insert_booking(self, business_key: str, rfq_id: str, partner_id: str, quote_id: str,
                       request: dict, now: str) -> None:
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO bookings (business_key, rfq_id, partner_id, quote_id, request_json, state,"
                " created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'sending', ?, ?)",
                (business_key, rfq_id, partner_id, quote_id, dumps(request), now, now),
            )

    def set_booking(self, business_key: str, **fields: Any) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        with self.transaction() as conn:
            conn.execute(f"UPDATE bookings SET {cols} WHERE business_key=?", (*fields.values(), business_key))

    def apply_shipment(self, tracking_no: str, status: str, seq: int, note: str, eta: str | None,
                       now: str) -> bool:
        """순번이 더 클 때만 반영한다 (S-20). 반영했으면 True."""
        with self.transaction() as conn:
            cur = conn.execute(
                "UPDATE bookings SET shipment_status=?, shipment_seq=?, shipment_note=?,"
                " eta=COALESCE(?, eta), updated_at=? WHERE tracking_no=? AND shipment_seq < ?",
                (status, seq, note, eta, now, tracking_no, seq),
            )
            return cur.rowcount == 1

    def bookings_to_track(self, older_than: str) -> list[sqlite3.Row]:
        """수락됐고 아직 배송이 끝나지 않았으며, 마지막 직접 조회가 오래된 발주 (S-18 보조 조회)."""
        with self.read() as conn:
            return conn.execute(
                "SELECT * FROM bookings WHERE state='accepted'"
                " AND COALESCE(shipment_status, '') NOT IN ('delivered', 'cancelled')"
                " AND (tracked_at IS NULL OR tracked_at < ?) ORDER BY created_at", (older_than,)).fetchall()

    # ---------- 입고·지급 ----------

    def receipt(self, rfq_id: str) -> sqlite3.Row | None:
        with self.read() as conn:
            return conn.execute("SELECT * FROM receipts WHERE rfq_id=?", (rfq_id,)).fetchone()

    def insert_receipt(self, rfq_id: str, business_key: str, condition: str, note: str, now: str) -> None:
        with self.transaction() as conn:
            conn.execute("INSERT INTO receipts VALUES (?, ?, ?, ?, ?)", (rfq_id, business_key, condition, note, now))

    def record_payment(self, business_key: str, rfq_id: str, payload: dict, now: str) -> bool:
        """처음 기록하면 True, 같은 내용이 이미 있으면 False, 같은 키에 다른 내용이면 ValueError."""
        text = dumps(payload)
        with self.transaction() as conn:
            row = conn.execute("SELECT payload FROM payments WHERE business_key=?", (business_key,)).fetchone()
            if row is not None:
                if row["payload"] != text:
                    raise ValueError("같은 업무키에 다른 지급 내용: 거부")
                return False
            conn.execute("INSERT INTO payments VALUES (?, ?, ?, ?)", (business_key, rfq_id, text, now))
            return True

    def payments_for(self, rfq_id: str) -> list[sqlite3.Row]:
        with self.read() as conn:
            return conn.execute("SELECT * FROM payments WHERE rfq_id=?", (rfq_id,)).fetchall()

    # ---------- 배송 알림 ----------

    def record_event(self, event: dict, applied: bool, now: str) -> bool:
        """처음 받은 알림이면 True, 이미 받은 event_id면 False (S-19)."""
        with self.transaction() as conn:
            if conn.execute("SELECT 1 FROM shipment_events WHERE event_id=?", (event["event_id"],)).fetchone():
                return False
            conn.execute(
                "INSERT INTO shipment_events (event_id, tracking_no, seq, status, at, note, applied, received_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (event["event_id"], event["tracking_no"], event["seq"], event["shipment_status"],
                 event["at"], event.get("note", ""), int(applied), now),
            )
            return True

    def has_event(self, event_id: str) -> bool:
        with self.read() as conn:
            return conn.execute("SELECT 1 FROM shipment_events WHERE event_id=?", (event_id,)).fetchone() is not None

    def events_for(self, tracking_no: str) -> list[sqlite3.Row]:
        with self.read() as conn:
            return conn.execute("SELECT * FROM shipment_events WHERE tracking_no=? ORDER BY seq",
                                (tracking_no,)).fetchall()
