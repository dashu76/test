# 파일명: app.py
"""FastAPI 조립: A2A(물류사용) + 내부 API(/api) + 견적 수집기. 업무 화면(/ui)은 APP_UI_ENABLED로 끈다.

- 인증(Part 4): 회사 사이는 파트너 키(APP_A2A_AUTH), 사내는 로그인·권한(APP_STAFF_AUTH). 설계: systems/docs/security-and-db.md
- 거래처 목록의 원본은 DB(partners). 처음 뜰 때 config/partners.toml로 채운다.
- A2A_OBS_URL이 있으면 관찰 이벤트를 관제 허브로 보낸다(obs_hook).
"""

import asyncio
import contextlib
import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
import logistics_contract

from . import __version__, a2a_auth, auth, obs_hook
from .api import router
from .card import build_card
from .executor import BuyerExecutor
from .permissions import PERMISSION_LABELS, ROLES
from .remote import CarrierClient
from .service import BuyerService
from .settings import Settings
from .store import Store

log = logging.getLogger("kpw_buyer")
UI_FILE = Path(__file__).resolve().parent / "ui" / "index.html"


def build_auth(settings: Settings) -> auth.AuthStore:
    return auth.AuthStore(settings.db_path, ROLES, settings.session_hours)


def build_service(settings: Settings, auth_store: auth.AuthStore | None = None) -> BuyerService:
    store = Store(settings.db_path)

    def headers_for(base_url: str) -> dict:
        """거래처 주소 → 그 물류사가 우리에게 발급한 키 (대상 = 거래처 id라 주소가 바뀌어도 그대로)."""
        partner_id = store.partner_id_by_url(base_url)
        return a2a_auth.key_headers(auth_store, partner_id) if partner_id else {}

    return BuyerService(settings, store,
                        CarrierClient(settings.request_timeout_s, settings.quick_wait_s, headers_for))


async def collector(service: BuyerService, interval_s: float) -> None:
    """수집 중인 운송 요청은 못 보낸 곳에 다시 보내고 처리 중인 곳은 결과를 확인한다.
    물류사 수락 대기 중인 발주도 결과를 확인하고, 배송 중인 발주는 가끔 직접 조회한다(알림 보조).
    재시작해도 DB에서 이어간다 (S-29)."""
    while True:
        for rfq_id in service.collecting_rfqs():
            try:
                await service.collect(rfq_id)
            except Exception:
                log.exception("%s 견적 수집 중 오류", rfq_id)
        for key in service.waiting_booking_keys():
            try:
                await service.refresh_booking(key)
            except Exception:
                log.exception("%s 발주 확인 중 오류", key)
        if service.settings.track_interval_s > 0:
            try:
                await service.track_due(service.settings.track_interval_s)
            except Exception:
                log.exception("배송 보조 조회 중 오류")
        await asyncio.sleep(interval_s)


def build_app(settings: Settings, service: BuyerService | None = None,
              auth_store: auth.AuthStore | None = None) -> FastAPI:
    auth_store = auth_store or build_auth(settings)
    service = service or build_service(settings, auth_store)
    card = build_card(settings)

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        obs_hook.start("kpw-buyer", settings.public_url, settings.obs_url, auth_store.outbound_key("obs") or "")
        obs_hook.emit("agent.started", "server", {"name": card.name, "skills": [s.id for s in card.skills],
                                                  "contract": logistics_contract.__version__,
                                                  "console": "/ui" if settings.ui_enabled else ""})
        if settings.staff_auth and not auth_store.has_users():
            log.warning("로그인이 켜져 있는데 사용자가 없다. 먼저 만든다: "
                        "uv run python -m kpw_buyer.admin user add <이름> --role admin")
        task = None
        if settings.worker_interval_s > 0:
            task = asyncio.create_task(collector(service, settings.worker_interval_s))
        yield
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
        obs_hook.emit("agent.stopped", "server")
        obs_hook.stop()

    app = FastAPI(title=f"{settings.buyer_name} 구매 시스템", version=__version__, lifespan=lifespan)
    app.state.service = service
    app.state.auth = auth_store
    app.state.staff_auth = settings.staff_auth
    app.state.login_hint = settings.login_hint
    app.state.session_cookie = f"session_{settings.port}"   # 한 PC에 여러 서버를 띄워도 로그인이 섞이지 않게
    app.state.permission_labels = PERMISSION_LABELS
    handler = DefaultRequestHandler(
        agent_executor=BuyerExecutor(service, auth_store, settings.a2a_auth),
        task_store=InMemoryTaskStore(), agent_card=card,
    )
    add_a2a_routes_to_fastapi(
        app,
        agent_card_routes=create_agent_card_routes(card),
        jsonrpc_routes=create_jsonrpc_routes(
            handler, rpc_url="/",
            context_builder=a2a_auth.PartnerContextBuilder(auth_store) if settings.a2a_auth else None),
    )
    if settings.a2a_auth:
        app.add_middleware(a2a_auth.JsonRpcKeyGuard, auth=auth_store)   # GetTask·ListTasks 등도 키 필요
    app.include_router(auth.router)
    app.include_router(router)

    if settings.ui_enabled:
        # 담당자 업무 화면. 내부 API(/api)만 부른다. A2A JSON-RPC는 POST /라 GET /와 겹치지 않는다.
        @app.get("/", include_in_schema=False)
        def root() -> RedirectResponse:
            return RedirectResponse("/ui")

        @app.get("/ui", include_in_schema=False)
        def ui() -> FileResponse:
            return FileResponse(UI_FILE, media_type="text/html; charset=utf-8")

    @app.get("/healthz")
    def healthz() -> dict:
        return {"status": "ok", "buyer": settings.buyer_name, "app_version": __version__,
                "contract_version": logistics_contract.__version__}

    return app
