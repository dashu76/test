# 파일명: remote.py
"""물류사 호출 (A2A 클라이언트). Ch12 a2a_result, Ch13 discovery_lib를 이 시스템 안으로 가져와 다듬었다.

- 보내고 기다리지 않는다(return_immediately). 잠깐(quick_wait_s) tasks/get으로 확인해 금방 끝나면 결과를 받고,
  아니면 working인 채로 돌려준다. 담당자가 확인하는 물류사(수동 견적)는 몇 분~몇 시간 걸릴 수 있기 때문이다.
- 나중에 get_task()로 다시 확인한다. 물류사가 재시작해 Task가 사라지면 RemoteTaskLost → 같은 요청을 다시 보낸다.
- 호출할 때마다 Agent Card를 다시 읽는다. 카드에 그 스킬이 없거나 계약 major 태그가 다르면 보내기 전에 멈춘다.
- A2A_OBS_URL이 있으면 카드 조회·요청·나중 확인 결과를 관제 허브에 알린다(obs_hook). 허브가 없어도 동작은 같다.
"""

import asyncio
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field

import httpx
from a2a.client import A2ACardResolver, ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import AgentCard, GetTaskRequest, Message, Part, Role, SendMessageRequest, Task, TaskState
from a2a.client.errors import A2AClientError
from a2a.utils.errors import TaskNotFoundError
from logistics_contract import CONTRACT_TAG

from . import obs_hook

TERMINAL = {TaskState.TASK_STATE_COMPLETED, TaskState.TASK_STATE_FAILED, TaskState.TASK_STATE_CANCELED,
            TaskState.TASK_STATE_REJECTED}
ASKING = {TaskState.TASK_STATE_INPUT_REQUIRED}


class RemoteUnavailable(Exception):
    """연결 실패·시간 초과. 상대가 요청을 받았는지 알 수 없다."""


class RemoteIncompatible(Exception):
    """상대 카드에 필요한 스킬·계약 버전이 없다."""


class RemoteRejected(RemoteIncompatible):
    """상대가 우리 파트너 키를 받지 않는다 (HTTP 401·403). 다시 보내도 소용없다 — 키를 확인해야 한다."""


class RemoteTaskLost(Exception):
    """상대가 그 Task를 모른다 (재시작 등). 같은 요청을 다시 보내면 상대 DB가 이어서 처리한다."""


@dataclass
class RemoteResult:
    state: int | None = None
    task_id: str = ""
    data: list = field(default_factory=list)
    status_text: str = ""

    @property
    def completed(self) -> bool:
        return self.state == TaskState.TASK_STATE_COMPLETED

    @property
    def asking(self) -> bool:
        return self.state in ASKING

    @property
    def waiting(self) -> bool:
        return self.state not in TERMINAL and self.state not in ASKING

    @property
    def state_name(self) -> str:
        return TaskState.Name(self.state) if self.state is not None else "NO_RESULT"


def _text(parts) -> str:
    return "".join(p.text for p in parts if p.HasField("text"))


def from_task(task: Task) -> RemoteResult:
    return RemoteResult(state=task.status.state, task_id=task.id, status_text=_text(task.status.message.parts),
                        data=[v for a in task.artifacts for v in get_data_parts(a.parts)])


def check_card(card: AgentCard, skill: str) -> None:
    for s in card.skills:
        if s.id == skill:
            if CONTRACT_TAG not in s.tags:
                raise RemoteIncompatible(f"{card.name}: {skill} 스킬의 계약 버전이 다르다 (필요: {CONTRACT_TAG}, 카드: {list(s.tags)})")
            return
    raise RemoteIncompatible(f"{card.name}: {skill} 스킬이 없다")


class CarrierClient:
    def __init__(self, timeout_s: float, quick_wait_s: float = 2.0,
                 headers_for: Callable[[str], dict] | None = None) -> None:
        self.timeout_s = timeout_s          # HTTP 요청 하나의 대기
        self.quick_wait_s = quick_wait_s    # 보낸 뒤 결과를 잠깐 기다려 보는 시간
        self.headers_for = headers_for or (lambda base_url: {})   # 거래처 주소 → 그 물류사가 발급한 키 헤더
        self._traces: dict[str, obs_hook.RequestTrace] = {}   # 상대가 처리 중인 Task → 그 요청 (관제 허브용)

    async def fetch_card(self, base_url: str) -> AgentCard:
        try:
            async with httpx.AsyncClient(timeout=self.timeout_s, headers=self.headers_for(base_url)) as http:
                card = await A2ACardResolver(http, base_url).get_agent_card()
        except Exception as exc:
            obs_hook.card_failed(base_url, exc)
            raise RemoteUnavailable(f"{base_url} 카드 조회 실패: {type(exc).__name__}") from exc
        obs_hook.card_fetched(base_url, card)
        return card

    async def call(self, base_url: str, skill: str, data: dict, context_id: str) -> tuple[AgentCard, RemoteResult]:
        """새 요청(data Part 하나)을 보낸다."""
        card = await self.fetch_card(base_url)
        check_card(card, skill)
        message = Message(message_id=str(uuid.uuid4()), context_id=context_id, role=Role.ROLE_USER,
                          parts=[new_data_part(data, media_type="application/json")])
        trace = obs_hook.RequestTrace(base_url, card.name, skill, obs_hook.summarize(data), context_id)
        return card, await self._traced(trace, self._guard(card, self._send(card, message, base_url=base_url)))

    async def reply_text(self, base_url: str, task_id: str, context_id: str, text: str,
                         answered_question: str = "") -> RemoteResult:
        """input-required였던 Task에 text 답을 보낸다.
        보낸 직후의 스냅샷은 아직 방금 답한 질문 상태일 수 있으므로, 그 상태가 바뀔 때까지 잠깐 더 확인한다."""
        card = await self.fetch_card(base_url)
        message = Message(message_id=str(uuid.uuid4()), task_id=task_id, context_id=context_id,
                          role=Role.ROLE_USER, parts=[Part(text=text)])
        trace = obs_hook.RequestTrace(base_url, card.name, "answer", text, context_id)
        trace.task_id = task_id
        return await self._traced(trace, self._guard(card, self._send(card, message, stale_question=answered_question,
                                                                      base_url=base_url)))

    async def get_task(self, base_url: str, task_id: str) -> RemoteResult:
        card = await self.fetch_card(base_url)
        trace = self._traces.get(task_id) or obs_hook.RequestTrace.resume(base_url, card.name, task_id)
        try:
            result = await self._guard(card, self._get(card, task_id, base_url))
        except RemoteTaskLost as exc:
            self._traces.pop(task_id, None)
            trace.error(exc)
            raise
        if result.state_name != trace.state:   # 결과가 바뀔 때만 알린다 (수집기는 몇 초마다 확인한다)
            trace.done(result.state_name, task_id)
        self._keep(trace, result)
        return result

    async def _traced(self, trace: obs_hook.RequestTrace, coro) -> RemoteResult:
        try:
            result = await coro
        except BaseException as exc:
            trace.error(exc)
            raise
        trace.done(result.state_name, result.task_id)
        self._keep(trace, result)
        return result

    def _keep(self, trace: obs_hook.RequestTrace, result: RemoteResult) -> None:
        if result.task_id and result.waiting:
            self._traces[result.task_id] = trace
        else:
            self._traces.pop(result.task_id, None)

    async def _guard(self, card: AgentCard, coro):
        try:
            return await asyncio.wait_for(coro, timeout=self.timeout_s + self.quick_wait_s)
        except TaskNotFoundError as exc:
            raise RemoteTaskLost(f"{card.name}: Task를 찾을 수 없다 (재시작 등)") from exc
        except TimeoutError as exc:
            raise RemoteUnavailable(f"{card.name}: 응답 없음") from exc
        except A2AClientError as exc:   # SDK가 HTTP 오류를 감싼다
            status = getattr(getattr(exc.__cause__, "response", None), "status_code", None)
            if status in (401, 403):
                raise RemoteRejected(f"{card.name}: 파트너 키가 거부됐다 (HTTP {status}) — 상대가 발급한 키를 확인하라") from exc
            raise RemoteUnavailable(f"{card.name}: {exc}") from exc
        except (httpx.HTTPError, OSError) as exc:
            raise RemoteUnavailable(f"{card.name}: 연결 실패 ({type(exc).__name__})") from exc

    def _client(self, card: AgentCard, http: httpx.AsyncClient):
        return create_client(card, client_config=ClientConfig(httpx_client=http, streaming=False, polling=True))

    async def _send(self, card: AgentCard, message: Message, stale_question: str | None = None,
                    base_url: str = "") -> RemoteResult:
        async with httpx.AsyncClient(timeout=self.timeout_s, headers=self.headers_for(base_url)) as http:
            client = await self._client(card, http)
            try:
                result = RemoteResult()
                async for response in client.send_message(SendMessageRequest(message=message)):
                    if response.HasField("task"):
                        result = from_task(response.task)
                    elif response.HasField("message"):  # Task 없이 바로 답한 경우
                        return RemoteResult(state=TaskState.TASK_STATE_COMPLETED,
                                            data=get_data_parts(response.message.parts))
                def unsettled(r: RemoteResult) -> bool:
                    return r.waiting or (stale_question is not None and r.asking and r.status_text == stale_question)

                deadline = time.monotonic() + self.quick_wait_s
                while unsettled(result) and result.task_id and time.monotonic() < deadline:
                    await asyncio.sleep(0.1)
                    result = from_task(await client.get_task(GetTaskRequest(id=result.task_id)))
                return result
            finally:
                await client.close()

    async def _get(self, card: AgentCard, task_id: str, base_url: str = "") -> RemoteResult:
        async with httpx.AsyncClient(timeout=self.timeout_s, headers=self.headers_for(base_url)) as http:
            client = await self._client(card, http)
            try:
                return from_task(await client.get_task(GetTaskRequest(id=task_id)))
            finally:
                await client.close()
