# 파일명: service.py
"""K정밀웍스 구매 업무. 화면·CLI·수집기·A2A 수신이 모두 이 클래스를 거친다.

흐름 (plan_2 2.1): 운송 요청 작성 → 견적 수집(마감까지) → 비교 → 업체 선정·발주 → 배송 추적.

물류사 응답은 바로 오지 않을 수 있다 (담당자 확인, 느린 산출). 보낸 요청이
- 금방 끝나면 결과를 바로 반영하고,
- 처리 중이면 '물류사 확인 중'(waiting)으로 두고 수집기가 tasks/get으로 다시 확인하며,
- 물류사가 되물으면(input-required) '질문 받음'으로 두고 우리 담당자의 답을 같은 Task로 보낸다.
물류사가 재시작해 Task가 사라지면 같은 요청을 다시 보낸다. 물류사는 rfq_id·업무키로 이어서 처리한다.
"""

import asyncio
import json
import re
import sqlite3
import logging
from collections.abc import Callable
from datetime import date, datetime, timedelta
from typing import Any
from urllib.parse import urlsplit

from logistics_contract import (
    SKILL_BOOK_SHIPMENT,
    SKILL_CANCEL_BOOKING,
    SKILL_CHECK_DELIVERY,
    SKILL_QUOTE,
    BookingRequest,
    CancelBookingRequest,
    ContractError,
    DeliveryQuery,
    EventAck,
    Quote,
    QuoteRequest,
    ShipmentEvent,
    parse_response,
    to_data,
)

from .domain import (
    BOOKING_LABEL,
    OPEN_QUOTE_STATES,
    QUOTE_LABEL,
    RFQ_LABEL,
    SHIPMENT_LABEL,
    BookingState,
    QuoteState,
    RfqState,
    booking_key,
    cancel_key,
    check_quote,
    delay_risk,
    now_kst,
    payment_key,
    recommend,
)
from .remote import CarrierClient, RemoteIncompatible, RemoteResult, RemoteTaskLost, RemoteUnavailable
from .settings import Partner, Settings
from .store import Store, dumps

log = logging.getLogger("kpw_buyer")


class BuyerError(ValueError):
    """담당자에게 그대로 보여 줄 업무 오류 (잘못된 순서, 없는 번호 등)."""


class PartnerMismatch(ValueError):
    """알림을 보낸 물류사(파트너 키)가 그 발주의 거래처가 아니다 → Task rejected."""


PARTNER_ID = re.compile(r"^[A-Za-z0-9._-]{1,32}$")


class BuyerService:
    def __init__(self, settings: Settings, store: Store, client: CarrierClient,
                 clock: Callable[[], datetime] = now_kst) -> None:
        self.settings = settings
        self.store = store
        self.client = client
        self.clock = clock
        self._lock = asyncio.Lock()
        store.seed_partners(settings.partners, self._now())   # 처음만: config/partners.toml → DB

    def _now(self) -> str:
        return self.clock().isoformat()

    # ---------- 거래처 (DB가 원본) ----------

    def partners(self, include_inactive: bool = False) -> list[Partner]:
        return [Partner(id=r["id"], url=r["url"]) for r in self.store.partners(active_only=not include_inactive)]

    def partner_rows(self) -> list[dict]:
        return [{"id": r["id"], "url": r["url"], "active": bool(r["active"]), "updated_at": r["updated_at"]}
                for r in self.store.partners()]

    def partner(self, partner_id: str) -> Partner:
        row = self.store.partner(partner_id)
        if row is None:
            raise BuyerError(f"등록되지 않은 거래처: {partner_id}")
        return Partner(id=row["id"], url=row["url"])

    @staticmethod
    def _check_url(url: str) -> str:
        url = url.strip().rstrip("/")
        if urlsplit(url).scheme not in ("http", "https") or not urlsplit(url).netloc:
            raise BuyerError(f"거래처 주소가 http(s) 주소가 아니다: {url}")
        return url

    def add_partner(self, partner_id: str, url: str) -> dict:
        if not PARTNER_ID.match(partner_id):
            raise BuyerError("거래처 id는 영문·숫자·._- 1~32자 (업무키에 들어가므로 바꾸지 않는다)")
        try:
            self.store.add_partner(partner_id, self._check_url(url), self._now())
        except sqlite3.IntegrityError as exc:
            raise BuyerError(f"이미 있는 거래처: {partner_id}") from exc
        return next(p for p in self.partner_rows() if p["id"] == partner_id)

    def update_partner(self, partner_id: str, url: str | None = None, active: bool | None = None) -> dict:
        fields = {}
        if url is not None:
            fields["url"] = self._check_url(url)
        if active is not None:
            fields["active"] = int(active)
        if fields and not self.store.update_partner(partner_id, self._now(), **fields):
            raise BuyerError(f"등록되지 않은 거래처: {partner_id}")
        return next(p for p in self.partner_rows() if p["id"] == partner_id)

    # ---------- 운송 요청 ----------

    def create_rfq(self, *, item: str, weight_kg: float, origin: str, destination: str,
                   need_by: date | None = None, deadline_min: int | None = None,
                   partner_ids: list[str] | None = None) -> str:
        known = [p.id for p in self.partners()]
        partner_ids = partner_ids or known
        unknown = set(partner_ids) - set(known)
        if unknown:
            raise BuyerError(f"등록되지 않은 거래처: {sorted(unknown)}")
        now = self.clock()
        deadline = now + timedelta(minutes=deadline_min or self.settings.default_deadline_min)

        def make_request(rfq_id: str) -> dict:
            try:
                return to_data(QuoteRequest(rfq_id=rfq_id, buyer=self.settings.buyer_name, item=item,
                                            weight_kg=weight_kg, origin=origin, destination=destination,
                                            need_by=need_by))
            except Exception as exc:  # pydantic 검증 오류를 업무 오류로
                raise BuyerError(f"운송 요청 내용 오류: {exc}") from exc

        return self.store.create_rfq(make_request, partner_ids, deadline.isoformat(), now.isoformat())

    def _rfq(self, rfq_id: str):
        row = self.store.get_rfq(rfq_id)
        if row is None:
            raise BuyerError(f"없는 운송 요청: {rfq_id}")
        return row

    def _quote_row(self, rfq_id: str, partner_id: str):
        row = next((q for q in self.store.quotes(rfq_id) if q["partner_id"] == partner_id), None)
        if row is None:
            raise BuyerError(f"{rfq_id}에 {partner_id} 거래처가 없다")
        return row

    # ---------- 견적 수집 ----------

    async def refresh(self, rfq_id: str) -> None:
        """수집 중이면 견적을 (다시) 묻고·확인하고, 수락 대기 중인 발주가 있으면 결과를 확인한다."""
        await self.collect(rfq_id)
        for b in self.store.bookings_for(rfq_id):
            if b["state"] == BookingState.WAITING:
                await self.refresh_booking(b["business_key"])

    async def collect(self, rfq_id: str) -> None:
        """아직 못 보낸 곳에 보내고, 처리 중인 곳은 결과를 확인한다. 마감·완료 여부를 판단한다."""
        async with self._lock:
            rfq = self._rfq(rfq_id)
            if rfq["state"] != RfqState.COLLECTING:
                return
            if self.clock() < datetime.fromisoformat(rfq["deadline"]):
                request = json.loads(rfq["request_json"])
                jobs = []
                for q in self.store.quotes(rfq_id):
                    if q["state"] == QuoteState.PENDING:
                        jobs.append(self._send_quote(rfq_id, q["partner_id"], request))
                    elif q["state"] == QuoteState.WAITING:
                        jobs.append(self._check_quote(rfq_id, q["partner_id"], q["task_id"], request))
                await asyncio.gather(*jobs)
            self._maybe_close(rfq_id)

    async def _send_quote(self, rfq_id: str, partner_id: str, request: dict) -> None:
        partner = self.partner(partner_id)
        attempts = self._quote_row(rfq_id, partner_id)["attempts"] + 1
        try:
            card, result = await self.client.call(partner.url, SKILL_QUOTE, request, context_id=rfq_id)
        except RemoteUnavailable as exc:
            # S-03·S-04: 마감 전까지 다시 보낸다. 같은 rfq_id라 물류사는 같은 견적을 돌려준다.
            self.store.set_quote(rfq_id, partner_id, error=str(exc), attempts=attempts, updated_at=self._now())
            return
        except RemoteIncompatible as exc:
            self.store.set_quote(rfq_id, partner_id, state=QuoteState.FAILED, error=str(exc),
                                 attempts=attempts, updated_at=self._now())
            return
        self._apply_quote(rfq_id, partner_id, result, carrier_name=card.name, attempts=attempts)

    async def _check_quote(self, rfq_id: str, partner_id: str, task_id: str, request: dict) -> None:
        partner = self.partner(partner_id)
        try:
            result = await self.client.get_task(partner.url, task_id)
        except RemoteTaskLost:
            await self._send_quote(rfq_id, partner_id, request)   # 물류사 재시작 → 같은 요청을 다시 보낸다
            return
        except RemoteUnavailable as exc:
            self.store.set_quote(rfq_id, partner_id, error=str(exc), updated_at=self._now())
            return
        except RemoteIncompatible as exc:          # 키 거부 등 — 다시 물어도 소용없다
            self.store.set_quote(rfq_id, partner_id, state=QuoteState.FAILED, error=str(exc), updated_at=self._now())
            return
        self._apply_quote(rfq_id, partner_id, result)

    def _apply_quote(self, rfq_id: str, partner_id: str, result: RemoteResult, **extra: Any) -> None:
        fields: dict[str, Any] = dict(task_id=result.task_id, updated_at=self._now(), **extra)
        if result.asking:
            self.store.set_quote(rfq_id, partner_id, state=QuoteState.QUESTION, question=result.status_text,
                                 error="", **fields)
            return
        if result.waiting:
            self.store.set_quote(rfq_id, partner_id, state=QuoteState.WAITING, error=result.status_text, **fields)
            return
        if not result.completed:
            self.store.set_quote(rfq_id, partner_id, state=QuoteState.FAILED,
                                 error=result.status_text or result.state_name, **fields)
            return
        try:
            if len(result.data) != 1:
                raise ContractError(f"견적 결과는 JSON 객체 하나여야 한다 (받은 개수 {len(result.data)})")
            quote = parse_response(result.data[0], "quote")
            if quote.rfq_id != rfq_id:
                raise ContractError(f"다른 운송 요청의 견적이다: {quote.rfq_id}")
        except ContractError as exc:
            # S-05: 원문을 남겨 두고 비교 대상에서 뺀다.
            self.store.set_quote(rfq_id, partner_id, state=QuoteState.INVALID, error=str(exc),
                                 quote_json=dumps(result.data), **fields)
            return
        state = QuoteState.QUOTED if isinstance(quote, Quote) else QuoteState.DECLINED
        self.store.set_quote(rfq_id, partner_id, state=state, question="",
                             error="" if state == QuoteState.QUOTED else quote.reason,
                             quote_json=dumps(to_data(quote)), **fields)

    async def answer(self, rfq_id: str, partner_id: str, text: str) -> dict:
        """S-07: 물류사 질문에 답한다. 같은 Task로 text를 보낸다."""
        if not text.strip():
            raise BuyerError("답 내용이 비었다")
        row = self._quote_row(rfq_id, partner_id)
        if row["state"] != QuoteState.QUESTION:
            raise BuyerError(f"{partner_id}의 질문이 없다 (상태: {QUOTE_LABEL[QuoteState(row['state'])]})")
        partner = self.partner(partner_id)
        async with self._lock:
            try:
                result = await self.client.reply_text(partner.url, row["task_id"], rfq_id, text,
                                                      answered_question=row["question"])
            except RemoteTaskLost:
                # 물류사가 재시작했다 → 견적 요청을 다시 보내면 물류사가 같은 질문을 새 Task로 다시 한다
                request = json.loads(self._rfq(rfq_id)["request_json"])
                await self._send_quote(rfq_id, partner_id, request)
                raise BuyerError("물류사 쪽 Task가 사라져 견적 요청을 다시 보냈다. 질문을 확인하고 다시 답하라")
            except RemoteUnavailable as exc:
                raise BuyerError(f"답을 보내지 못했다. 다시 시도하라: {exc}") from exc
            except RemoteIncompatible as exc:
                raise BuyerError(f"답을 보내지 못했다: {exc}") from exc
            self._apply_quote(rfq_id, partner_id, result)
        return self.view(rfq_id)

    def _maybe_close(self, rfq_id: str) -> None:
        rfq = self._rfq(rfq_id)
        if self.clock() >= datetime.fromisoformat(rfq["deadline"]):
            self.store.open_to(rfq_id, QuoteState.NO_RESPONSE, self._now())
        if any(q["state"] in OPEN_QUOTE_STATES for q in self.store.quotes(rfq_id)):
            return
        self._close(rfq_id)

    def _close(self, rfq_id: str) -> None:
        quoted = any(q["state"] == QuoteState.QUOTED for q in self.store.quotes(rfq_id))
        state = RfqState.COMPARED if quoted else RfqState.NO_BIDS
        self.store.set_rfq(rfq_id, state=state, closed_at=self._now())
        log.info("%s 견적 수집 종료: %s", rfq_id, RFQ_LABEL[state])

    def close_now(self, rfq_id: str) -> None:
        """S-02: 마감 전이라도 지금까지 받은 견적으로 진행한다."""
        rfq = self._rfq(rfq_id)
        if rfq["state"] != RfqState.COLLECTING:
            raise BuyerError(f"수집 중인 요청이 아니다: {RFQ_LABEL[RfqState(rfq['state'])]}")
        self.store.open_to(rfq_id, QuoteState.NO_RESPONSE, self._now())
        self._close(rfq_id)

    def extend(self, rfq_id: str, minutes: int) -> None:
        """S-09: 유찰·수집 중인 요청의 마감을 늘리고, 응답 없던 곳에 다시 묻는다."""
        rfq = self._rfq(rfq_id)
        if rfq["state"] not in (RfqState.COLLECTING, RfqState.NO_BIDS, RfqState.COMPARED):
            raise BuyerError("이미 발주했거나 취소된 요청은 마감을 늘릴 수 없다")
        now = self.clock()
        self.store.reopen_no_response(rfq_id, now.isoformat())
        self.store.set_rfq(rfq_id, state=RfqState.COLLECTING, closed_at=None,
                           deadline=(now + timedelta(minutes=minutes)).isoformat())

    def collecting_rfqs(self) -> list[str]:
        return [r["rfq_id"] for r in self.store.list_rfqs(RfqState.COLLECTING)]

    # ---------- 발주 ----------

    async def award(self, rfq_id: str, partner_id: str, allow_ineligible: bool = False) -> dict:
        """업체 선정 → book-shipment.
        결과를 모르면(UNKNOWN) 다시 부르면 같은 업무키로 재전송하고(S-12), 수락 대기(WAITING)면 결과를 확인한다(S-14)."""
        rfq = self._rfq(rfq_id)
        key = booking_key(self.settings.buyer_name, rfq_id, partner_id)
        existing = self.store.booking(key)

        if existing is None:
            if rfq["state"] not in (RfqState.COMPARED, RfqState.COLLECTING):
                raise BuyerError(f"발주할 수 없는 상태: {RFQ_LABEL[RfqState(rfq['state'])]}")
            busy = (BookingState.ACCEPTED, BookingState.SENDING, BookingState.UNKNOWN, BookingState.WAITING)
            if any(b["state"] in busy for b in self.store.bookings_for(rfq_id)):
                raise BuyerError("이미 진행 중이거나 수락된 발주가 있다")
            row = self._quote_row(rfq_id, partner_id)
            if row["state"] != QuoteState.QUOTED:
                raise BuyerError(f"{partner_id}의 유효한 견적이 없다")
            quote = parse_response(json.loads(row["quote_json"]), "quote")
            need_by = json.loads(rfq["request_json"]).get("need_by")
            check = check_quote(quote, date.fromisoformat(need_by) if need_by else None, self.clock())
            if check.expired:
                raise BuyerError("견적 유효기간이 지났다. 마감을 늘려 다시 견적을 받아야 한다")  # S-10
            if not check.eligible and not allow_ineligible:
                raise BuyerError(f"조건 미충족 견적: {', '.join(check.issues)} (예외로 진행하려면 allow_ineligible)")
            request = to_data(BookingRequest(business_key=key, rfq_id=rfq_id, quote_id=quote.quote_id,
                                             event_callback_url=self.settings.public_url))
            self.store.insert_booking(key, rfq_id, partner_id, quote.quote_id, request, self._now())
            await self._send_booking(key)
        elif existing["state"] in (BookingState.SENDING, BookingState.UNKNOWN):
            await self._send_booking(key)          # 똑같은 내용으로 재전송
        elif existing["state"] == BookingState.WAITING:
            await self.refresh_booking(key)
        return self.view(rfq_id)                   # 이미 결과가 나온 발주는 다시 보내지 않는다

    async def _send_booking(self, key: str) -> None:
        b = self.store.booking(key)
        partner = self.partner(b["partner_id"])
        try:
            _, result = await self.client.call(partner.url, SKILL_BOOK_SHIPMENT, json.loads(b["request_json"]),
                                               context_id=b["rfq_id"])
        except RemoteUnavailable as exc:
            # 상대가 받았는지 모른다 → 같은 업무키로 다시 보내면 된다
            self.store.set_booking(key, state=BookingState.UNKNOWN, reason=str(exc), updated_at=self._now())
            return
        except RemoteIncompatible as exc:
            # 보내기 전에 멈췄다 → 재전송해도 소용없음
            self.store.set_booking(key, state=BookingState.FAILED, reason=str(exc), updated_at=self._now())
            return
        self._apply_booking(key, result)

    async def refresh_booking(self, key: str) -> None:
        b = self.store.booking(key)
        if b is None or b["state"] != BookingState.WAITING:
            return
        partner = self.partner(b["partner_id"])
        try:
            result = await self.client.get_task(partner.url, b["task_id"])
        except RemoteTaskLost:
            await self._send_booking(key)          # 물류사 재시작 → 같은 업무키로 다시 보낸다
            return
        except RemoteUnavailable as exc:
            self.store.set_booking(key, reason=str(exc), updated_at=self._now())
            return
        except RemoteIncompatible as exc:          # 키 거부 등 — 담당자가 확인해야 한다
            self.store.set_booking(key, state=BookingState.FAILED, reason=str(exc), updated_at=self._now())
            return
        self._apply_booking(key, result)

    def _apply_booking(self, key: str, result: RemoteResult) -> None:
        b = self.store.booking(key)
        now = self._now()
        if result.waiting:
            self.store.set_booking(key, state=BookingState.WAITING, task_id=result.task_id,
                                   reason=result.status_text, updated_at=now)
            return
        if not result.completed:
            reason = result.status_text or result.state_name
            self.store.set_booking(key, state=BookingState.FAILED, task_id=result.task_id, reason=reason,
                                   updated_at=now)
            return
        try:
            booking = parse_response(result.data[0] if len(result.data) == 1 else None, "booking")
        except ContractError as exc:
            self.store.set_booking(key, state=BookingState.FAILED, reason=f"응답 계약 위반: {exc}", updated_at=now)
            return
        if booking.status == "rejected":
            # S-13: 거절. RFQ는 비교 가능 상태로 남아 차순위 업체를 고를 수 있다.
            self.store.set_booking(key, state=BookingState.REJECTED, reason=booking.reason, updated_at=now)
            return
        if booking.status == "pending":
            self.store.set_booking(key, state=BookingState.WAITING, task_id=result.task_id,
                                   booking_id=booking.booking_id, reason="물류사 수락 대기", updated_at=now)
            return
        # 도착 예정일: 물류사가 배송 조회로 알려 주기 전까지는 견적의 소요일로 추정한다 (납기 위험 판단에 사용)
        quote = parse_response(json.loads(self._quote_row(b["rfq_id"], b["partner_id"])["quote_json"]), "quote")
        eta = (self.clock().date() + timedelta(days=quote.eta_days)).isoformat()
        self.store.set_booking(key, state=BookingState.ACCEPTED, booking_id=booking.booking_id,
                               tracking_no=booking.tracking_no, reason="", eta=eta, updated_at=now)
        self.store.open_to(b["rfq_id"], QuoteState.NO_RESPONSE, now)  # 수집 중에 발주했으면 남은 대기 정리
        self.store.set_rfq(b["rfq_id"], state=RfqState.AWARDED, closed_at=now)

    def waiting_booking_keys(self) -> list[str]:
        return [b["business_key"] for b in self.store.waiting_bookings()]

    async def cancel(self, rfq_id: str, reason: str = "") -> dict:
        booking = self._accepted_booking(rfq_id)
        partner = self.partner(booking["partner_id"])
        request = to_data(CancelBookingRequest(
            business_key=cancel_key(self.settings.buyer_name, rfq_id, booking["booking_id"]),
            booking_id=booking["booking_id"], reason=reason))
        try:
            _, result = await self.client.call(partner.url, SKILL_CANCEL_BOOKING, request, context_id=rfq_id)
        except (RemoteUnavailable, RemoteIncompatible) as exc:
            raise BuyerError(f"취소 요청을 보내지 못했다. 다시 시도하라: {exc}") from exc
        if not result.completed:
            raise BuyerError(f"물류사가 취소 요청을 처리하지 못했다: {result.status_text or result.state_name}")
        answer = parse_response(result.data[0], "cancel-booking-result")
        if answer.status == "rejected":
            raise BuyerError(f"물류사가 취소를 거절했다: {answer.reason}")  # S-16
        self.store.set_booking(booking["business_key"], state=BookingState.CANCELLED, updated_at=self._now())
        self.store.set_rfq(rfq_id, state=RfqState.CANCELLED)
        return self.view(rfq_id)

    def _accepted_booking(self, rfq_id: str):
        self._rfq(rfq_id)
        booking = next((b for b in self.store.bookings_for(rfq_id) if b["state"] == BookingState.ACCEPTED), None)
        if booking is None:
            raise BuyerError("수락된 발주가 없다")
        return booking

    # ---------- 배송 추적 ----------

    async def track(self, rfq_id: str) -> dict:
        """check-delivery로 직접 조회한다. 물류사 알림을 못 받았을 때의 보조 수단 (S-18)."""
        booking = self._accepted_booking(rfq_id)
        partner = self.partner(booking["partner_id"])
        request = to_data(DeliveryQuery(tracking_no=booking["tracking_no"]))
        try:
            _, result = await self.client.call(partner.url, SKILL_CHECK_DELIVERY, request, context_id=rfq_id)
        except (RemoteUnavailable, RemoteIncompatible) as exc:
            raise BuyerError(f"배송 조회 실패: {exc}") from exc
        if not result.completed:
            raise BuyerError(f"배송 조회 실패: {result.status_text or result.state_name}")
        status = parse_response(result.data[0], "delivery-status")
        if status.status == "found":
            self.store.apply_shipment(status.tracking_no, status.shipment_status.value, status.seq, status.note,
                                      status.eta.isoformat() if status.eta else None, self._now())
        self.store.set_booking(booking["business_key"], tracked_at=self._now())
        return self.view(rfq_id)

    async def track_due(self, min_age_s: float) -> int:
        """S-18 보조: 배송 중인 발주 중 직접 조회한 지 오래된 것을 조회한다. 알림을 놓쳐도 결국 맞춰진다."""
        older_than = (self.clock() - timedelta(seconds=min_age_s)).isoformat()
        done = 0
        for b in self.store.bookings_to_track(older_than):
            try:
                await self.track(b["rfq_id"])
                done += 1
            except BuyerError as exc:
                log.info("%s 배송 조회 실패 (다음에 다시): %s", b["rfq_id"], exc)
                self.store.set_booking(b["business_key"], tracked_at=self._now())
        return done

    # ---------- 입고·지급 (S-23, S-24) ----------

    def confirm_receipt(self, rfq_id: str, condition: str = "ok", note: str = "") -> dict:
        """배송 완료된 화물의 입고를 확인한다. 이상이 있으면 지급을 보류한다."""
        if condition not in ("ok", "damaged"):
            raise BuyerError("condition은 ok 또는 damaged")
        rfq = self._rfq(rfq_id)
        existing = self.store.receipt(rfq_id)
        if existing is not None:
            if (existing["condition"], existing["note"]) == (condition, note):
                return self.view(rfq_id)          # 같은 입고 확인을 두 번 눌러도 한 번
            raise BuyerError("이미 다른 내용으로 입고 확인했다")
        if rfq["state"] != RfqState.AWARDED:
            raise BuyerError(f"입고 확인할 수 없는 상태: {RFQ_LABEL[RfqState(rfq['state'])]}")
        booking = self._accepted_booking(rfq_id)
        if booking["shipment_status"] != "delivered":
            label = SHIPMENT_LABEL.get(booking["shipment_status"], "확인 안 됨") if booking["shipment_status"] else "확인 안 됨"
            raise BuyerError(f"배송 완료 전에는 입고 확인할 수 없다 (현재: {label}). 필요하면 track으로 조회")
        self.store.insert_receipt(rfq_id, booking["business_key"], condition, note, self._now())
        self.store.set_rfq(rfq_id, state=RfqState.RECEIVED if condition == "ok" else RfqState.ON_HOLD)
        return self.view(rfq_id)

    def pay(self, rfq_id: str) -> tuple[dict, bool]:
        """지급 기록. 업무키로 한 번만 기록한다. (view, 이번에 새로 기록했는지)"""
        rfq = self._rfq(rfq_id)
        if rfq["state"] == RfqState.ON_HOLD:
            raise BuyerError("입고 시 이상이 있어 지급이 보류됐다")
        if rfq["state"] not in (RfqState.RECEIVED, RfqState.PAID):
            raise BuyerError(f"입고 확인 후에 지급할 수 있다 (현재: {RFQ_LABEL[RfqState(rfq['state'])]})")
        booking = self._accepted_booking(rfq_id)
        quote_row = self._quote_row(rfq_id, booking["partner_id"])
        quote = parse_response(json.loads(quote_row["quote_json"]), "quote")
        payload = {"rfq_id": rfq_id, "partner_id": booking["partner_id"], "carrier": quote.carrier,
                   "booking_id": booking["booking_id"], "quote_id": quote.quote_id, "amount_krw": quote.price_krw}
        key = payment_key(self.settings.buyer_name, rfq_id, booking["booking_id"])
        try:
            created = self.store.record_payment(key, rfq_id, payload, self._now())
        except ValueError as exc:
            raise BuyerError(str(exc)) from exc
        self.store.set_rfq(rfq_id, state=RfqState.PAID)
        return self.view(rfq_id), created

    async def learn_tracking(self, tracking_no: str, wait_s: float = 4.0, partner: str | None = None) -> bool:
        """모르는 운송장의 알림이 왔을 때, 물류사 수락을 기다리는 발주가 있으면 바로 확인한다.

        담당자가 수락하는 물류사(S-14)는 수락과 같은 트랜잭션에서 "수락됨" 알림을 쌓고 곧바로 보낸다.
        우리 수집기가 tasks/get으로 운송장을 알기 전에 알림이 먼저 올 수 있으므로, 거부하기 전에 잠깐 확인한다.
        물류사 Task가 수락을 반영하기까지 조금 걸릴 수 있어(K-Logistics poll_s) wait_s 동안 몇 번 다시 본다.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + wait_s
        while True:
            if self.store.booking_by_tracking(tracking_no) is not None:
                return True
            keys = [b["business_key"] for b in self.store.waiting_bookings()
                    if partner is None or b["partner_id"] == partner]   # 알림을 보낸 거래처의 발주만
            if not keys or loop.time() >= deadline:
                return False
            for key in keys:
                try:
                    await self.refresh_booking(key)
                except Exception:
                    log.exception("%s 발주 확인 중 오류", key)
            if self.store.booking_by_tracking(tracking_no) is not None:
                return True
            await asyncio.sleep(0.5)

    def receive_event(self, event: ShipmentEvent, partner: str | None = None) -> EventAck:
        """물류사가 보낸 배송 상태 알림 (receive-shipment-event). 중복·순서 뒤바뀜을 거른다 (S-19, S-20)."""
        if self.store.has_event(event.event_id):
            return EventAck(event_id=event.event_id, duplicate=True)
        booking = self.store.booking_by_tracking(event.tracking_no)
        if booking is None:
            raise ContractError(f"우리 회사 발주가 아닌 운송장: {event.tracking_no}")
        if partner is not None and booking["partner_id"] != partner:
            raise PartnerMismatch(f"{partner}의 키로 다른 거래처 발주({event.tracking_no})의 알림을 보낼 수 없다")
        now = self._now()
        applied = self.store.apply_shipment(event.tracking_no, event.shipment_status.value, event.seq,
                                            event.note, None, now)
        first = self.store.record_event(to_data(event), applied, now)
        return EventAck(event_id=event.event_id, duplicate=not first)

    # ---------- 보기 ----------

    def view(self, rfq_id: str) -> dict:
        rfq = self._rfq(rfq_id)
        request = json.loads(rfq["request_json"])
        need_by = date.fromisoformat(request["need_by"]) if request.get("need_by") else None
        now = self.clock()

        quotes, candidates = [], []
        for q in self.store.quotes(rfq_id):
            item: dict[str, Any] = {
                "partner_id": q["partner_id"], "carrier": q["carrier_name"] or q["partner_id"],
                "state": q["state"], "state_label": QUOTE_LABEL[QuoteState(q["state"])],
                "error": q["error"], "question": q["question"], "attempts": q["attempts"],
            }
            if q["state"] == QuoteState.QUOTED:
                quote = parse_response(json.loads(q["quote_json"]), "quote")
                check = check_quote(quote, need_by, now)
                candidates.append((q["partner_id"], quote, check))
                item.update(quote_id=quote.quote_id, price_krw=quote.price_krw, eta_days=quote.eta_days,
                            valid_until=quote.valid_until.isoformat(), eligible=check.eligible, issues=check.issues)
            quotes.append(item)
        quotes.sort(key=lambda x: (x.get("price_krw") is None, x.get("price_krw", 0)))

        bookings = []
        for b in self.store.bookings_for(rfq_id):
            bookings.append({
                "partner_id": b["partner_id"], "business_key": b["business_key"], "quote_id": b["quote_id"],
                "state": b["state"], "state_label": BOOKING_LABEL[BookingState(b["state"])],
                "booking_id": b["booking_id"], "tracking_no": b["tracking_no"], "reason": b["reason"],
                "shipment_status": b["shipment_status"],
                "shipment_label": SHIPMENT_LABEL.get(b["shipment_status"], "") if b["shipment_status"] else "",
                "shipment_seq": b["shipment_seq"], "shipment_note": b["shipment_note"], "eta": b["eta"],
                "delay_risk": delay_risk(b["shipment_status"], b["eta"], request.get("need_by"))
                if b["state"] == BookingState.ACCEPTED and b["shipment_status"] != "delivered" else "",
            })
        receipt = self.store.receipt(rfq_id)
        payments = [json.loads(p["payload"]) | {"business_key": p["business_key"], "recorded_at": p["created_at"]}
                    for p in self.store.payments_for(rfq_id)]

        return {
            "rfq_id": rfq_id, "state": rfq["state"], "state_label": RFQ_LABEL[RfqState(rfq["state"])],
            "item": request["item"], "weight_kg": request["weight_kg"], "origin": request["origin"],
            "destination": request["destination"], "need_by": request.get("need_by"),
            "deadline": rfq["deadline"], "created_at": rfq["created_at"], "closed_at": rfq["closed_at"],
            "quotes": quotes, "recommended": recommend(candidates), "bookings": bookings,
            "receipt": dict(condition=receipt["condition"], note=receipt["note"],
                            confirmed_at=receipt["confirmed_at"]) if receipt else None,
            "payments": payments,
        }

    def board(self, limit: int = 200) -> list[dict]:
        """화면 왼쪽 목록: 운송 요청마다 진행 요약과 '지금 할 일'. 최근 것부터."""
        out = []
        for r in self.store.list_rfqs()[:limit]:
            v = self.view(r["rfq_id"])
            quotes, bookings = v["quotes"], v["bookings"]
            active = next((b for b in bookings if b["state"] not in ("rejected", "failed", "cancelled")), None)
            todo = []
            if any(q["state"] == QuoteState.QUESTION for q in quotes):
                todo.append("질문 답 필요")
            if v["state"] in (RfqState.COLLECTING, RfqState.COMPARED) and active is None and \
                    any(q["state"] == QuoteState.QUOTED for q in quotes):
                todo.append("발주 결정")
            if active and active["state"] == BookingState.WAITING:
                todo.append("물류사 수락 대기")
            if active and active["state"] == BookingState.UNKNOWN:
                todo.append("발주 결과 확인")
            if active and active["delay_risk"]:
                todo.append("납기 위험")
            if v["state"] == RfqState.AWARDED and active and active["shipment_status"] == "delivered":
                todo.append("입고 확인")
            if v["state"] == RfqState.RECEIVED:
                todo.append("지급")
            if v["state"] == RfqState.ON_HOLD:
                todo.append("지급 보류")
            prices = [q["price_krw"] for q in quotes if q.get("price_krw") is not None]
            out.append({
                "rfq_id": v["rfq_id"], "state": v["state"], "state_label": v["state_label"], "item": v["item"],
                "weight_kg": v["weight_kg"], "origin": v["origin"], "destination": v["destination"],
                "need_by": v["need_by"], "deadline": v["deadline"], "created_at": v["created_at"],
                "quotes_total": len(quotes), "quotes_in": sum(q["state"] not in OPEN_QUOTE_STATES for q in quotes),
                "best_price": min(prices) if prices else None, "recommended": v["recommended"],
                "carrier": active["partner_id"] if active else None,
                "shipment_label": (active["shipment_label"] or active["state_label"]) if active else "", "todo": todo,
            })
        return out

    def list_view(self) -> list[dict]:
        return [{"rfq_id": r["rfq_id"], "state": r["state"], "state_label": RFQ_LABEL[RfqState(r["state"])],
                 "item": json.loads(r["request_json"])["item"], "deadline": r["deadline"],
                 "created_at": r["created_at"]} for r in self.store.list_rfqs()]
