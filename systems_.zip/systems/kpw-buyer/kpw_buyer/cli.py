# 파일명: cli.py
"""화면 없이 쓰는 CLI (plan_2 S-27). 우리 회사 내부 API만 부른다.

  uv run python -m kpw_buyer.cli partners --check
  uv run python -m kpw_buyer.cli login kim         (로그인 켜진 서버: 먼저 로그인, 세션은 data/.cli_session)
  uv run python -m kpw_buyer.cli partner add carrier-d http://127.0.0.1:5024   (관리자)
  uv run python -m kpw_buyer.cli partner set carrier-c --url http://127.0.0.1:5033
  uv run python -m kpw_buyer.cli rfq create --item "정밀 베어링 2팔레트" --weight 480 --origin 창원 --dest 평택 --need-by 2026-10-20
  uv run python -m kpw_buyer.cli rfq list
  uv run python -m kpw_buyer.cli rfq show RFQ-20261015-001
  uv run python -m kpw_buyer.cli rfq collect|close|track RFQ-...
  uv run python -m kpw_buyer.cli rfq answer RFQ-... klogistics "1100×1100 팔레트, 2단 적재 불가"
  uv run python -m kpw_buyer.cli rfq extend RFQ-... --minutes 30
  uv run python -m kpw_buyer.cli rfq award RFQ-... carrier-a [--allow-ineligible]
  uv run python -m kpw_buyer.cli rfq cancel RFQ-... --reason "생산 일정 변경"
  uv run python -m kpw_buyer.cli rfq receive RFQ-... [--damaged] [--note "팔레트 1개 파손"]
  uv run python -m kpw_buyer.cli rfq pay RFQ-...

API 주소: --api 또는 KPW_API_URL (기본: 설정의 공개 주소)
"""

import argparse
import getpass
import os
import sys

import httpx

from .auth import cli_headers, cli_session_file, save_cli_session
from .settings import APP_ROOT


def default_api() -> str:
    if os.getenv("KPW_API_URL"):
        return os.environ["KPW_API_URL"]
    from .settings import load_settings
    s = load_settings()
    return f"http://127.0.0.1:{s.port}" if s.bind_host in ("0.0.0.0", "::") else f"http://{s.bind_host}:{s.port}"


def won(v) -> str:
    return f"{v:,}원" if isinstance(v, int) else "-"


def print_rfq(v: dict) -> None:
    print(f"\n{v['rfq_id']}  [{v['state_label']}]  {v['item']} {v['weight_kg']:g}kg  {v['origin']} → {v['destination']}")
    print(f"  희망 납기 {v['need_by'] or '-'} · 견적 마감 {v['deadline'][:16].replace('T', ' ')}")
    print("  ── 견적 ──")
    for q in v["quotes"]:
        mark = "★" if q["partner_id"] == v["recommended"] else " "
        line = f"  {mark} {q['partner_id']:<12} {q['carrier']:<16} {q['state_label']:<8}"
        if q["state"] == "quoted":
            ok = "충족" if q["eligible"] else "조건 미충족: " + ", ".join(q["issues"])
            line += f" {won(q['price_krw']):>10} {q['eta_days']}일  {ok}"
        elif q["state"] == "question":
            line += f" 물류사 질문: {q['question']}  → rfq answer {v['rfq_id']} {q['partner_id']} \"답\""
        elif q["error"]:
            line += f" ({q['error']})"
        print(line)
    if v["recommended"]:
        print(f"  추천: {v['recommended']} (조건 충족 최저가)")
    for b in v["bookings"]:
        print("  ── 발주 ──")
        print(f"    {b['partner_id']} {b['state_label']} 예약 {b['booking_id'] or '-'} 운송장 {b['tracking_no'] or '-'}"
              + (f" 사유: {b['reason']}" if b["reason"] else ""))
        if b["shipment_status"]:
            print(f"    배송: {b['shipment_label']} (순번 {b['shipment_seq']}) {b['shipment_note']} 도착 예정 {b['eta'] or '-'}")
        if b.get("delay_risk"):
            print(f"    [!] 납기 위험: {b['delay_risk']}")
    if v.get("receipt"):
        r = v["receipt"]
        print("  ── 입고·지급 ──")
        print(f"    입고 {'이상 없음' if r['condition'] == 'ok' else '이상 있음'} {r['note']} ({r['confirmed_at'][:16].replace('T', ' ')})")
    for p in v.get("payments", []):
        print(f"    지급 기록: {p['carrier']} {won(p['amount_krw'])} (업무키 {p['business_key']})")
    if v.get("payment_result"):
        print(f"  → {v['payment_result']}")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="kpw_buyer.cli", description="K정밀웍스 구매 시스템 CLI")
    p.add_argument("--api", default=None)
    sub = p.add_subparsers(dest="cmd", required=True)

    pp = sub.add_parser("partners", help="거래처 목록")
    pp.add_argument("--check", action="store_true", help="Agent Card를 실제로 조회")

    pr = sub.add_parser("rfq", help="운송 요청")
    rs = pr.add_subparsers(dest="action", required=True)
    c = rs.add_parser("create")
    c.add_argument("--item", required=True)
    c.add_argument("--weight", type=float, required=True)
    c.add_argument("--origin", required=True)
    c.add_argument("--dest", required=True)
    c.add_argument("--need-by")
    c.add_argument("--deadline-min", type=int)
    c.add_argument("--partners", help="쉼표 구분 거래처 id (기본: 전체)")
    rs.add_parser("list")
    for name in ("show", "collect", "close", "track"):
        rs.add_parser(name).add_argument("rfq_id")
    e = rs.add_parser("extend")
    e.add_argument("rfq_id")
    e.add_argument("--minutes", type=int, required=True)
    a = rs.add_parser("award")
    a.add_argument("rfq_id")
    a.add_argument("partner_id")
    a.add_argument("--allow-ineligible", action="store_true")
    x = rs.add_parser("cancel")
    x.add_argument("rfq_id")
    x.add_argument("--reason", default="")
    w = rs.add_parser("answer", help="물류사 질문에 답")
    w.add_argument("rfq_id")
    w.add_argument("partner_id")
    w.add_argument("text")
    rc = rs.add_parser("receive", help="입고 확인")
    rc.add_argument("rfq_id")
    rc.add_argument("--damaged", action="store_true", help="이상 있음 (지급 보류)")
    rc.add_argument("--note", default="")
    rs.add_parser("pay", help="지급 기록").add_argument("rfq_id")
    lg = sub.add_parser("login", help="로그인 (세션을 이 폴더 data/.cli_session에 저장)")
    lg.add_argument("username")
    lg.add_argument("--password", help="스크립트용. 없으면 묻는다")
    sub.add_parser("logout")
    sub.add_parser("whoami", help="로그인한 사용자와 권한")
    pt = sub.add_parser("partner", help="거래처 추가·변경 (관리자)").add_subparsers(dest="action", required=True)
    pa = pt.add_parser("add")
    pa.add_argument("partner_id")
    pa.add_argument("url")
    ps = pt.add_parser("set")
    ps.add_argument("partner_id")
    ps.add_argument("--url")
    ps.add_argument("--active", choices=["yes", "no"])

    args = p.parse_args(argv)
    api = (args.api or default_api()).rstrip("/")
    try:
        with httpx.Client(base_url=api, timeout=60, headers=cli_headers(APP_ROOT)) as http:
            if args.cmd in ("login", "logout", "whoami"):
                return session_command(http, args)
            if args.cmd == "partner":
                if args.action == "add":
                    r = http.post("/api/partners", json={"id": args.partner_id, "url": args.url})
                else:
                    body = {"url": args.url, "active": None if args.active is None else args.active == "yes"}
                    r = http.patch(f"/api/partners/{args.partner_id}", json=body)
                if r.status_code >= 400:
                    print(f"거부: {r.json().get('detail', r.text)}", file=sys.stderr)
                    return 1
                x = r.json()
                print(f"{x['id']:<12} {x['url']}  {'사용' if x['active'] else '사용 안 함'}")
                return 0
            if args.cmd == "partners":
                r = http.get("/api/partners", params={"check": args.check})
                if r.status_code == 401:
                    print("로그인이 필요하다: uv run python -m kpw_buyer.cli login <이름>", file=sys.stderr)
                    return 1
                r.raise_for_status()
                for item in r.json():
                    state = "" if "reachable" not in item else (
                        f"  연결됨 · {item['name']} · 스킬 {', '.join(item['skills'])}" if item["reachable"]
                        else f"  연결 불가 ({item['error']})")
                    off = "" if item.get("active", True) else "  (사용 안 함)"
                    print(f"{item['id']:<12} {item['url']}{off}{state}")
                return 0

            if args.action == "list":
                r = http.get("/api/rfqs")
                r.raise_for_status()
                for v in r.json():
                    print(f"{v['rfq_id']}  {v['state_label']:<8} {v['item']}  (마감 {v['deadline'][:16].replace('T', ' ')})")
                return 0

            if args.action == "create":
                body = {"item": args.item, "weight_kg": args.weight, "origin": args.origin,
                        "destination": args.dest, "need_by": args.need_by, "deadline_min": args.deadline_min,
                        "partners": args.partners.split(",") if args.partners else None}
                r = http.post("/api/rfqs", json=body)
            elif args.action == "show":
                r = http.get(f"/api/rfqs/{args.rfq_id}")
            elif args.action == "extend":
                r = http.post(f"/api/rfqs/{args.rfq_id}/extend", json={"minutes": args.minutes})
            elif args.action == "award":
                r = http.post(f"/api/rfqs/{args.rfq_id}/award",
                              json={"partner_id": args.partner_id, "allow_ineligible": args.allow_ineligible})
            elif args.action == "cancel":
                r = http.post(f"/api/rfqs/{args.rfq_id}/cancel", json={"reason": args.reason})
            elif args.action == "answer":
                r = http.post(f"/api/rfqs/{args.rfq_id}/answer", json={"partner_id": args.partner_id, "text": args.text})
            elif args.action == "receive":
                r = http.post(f"/api/rfqs/{args.rfq_id}/receive",
                              json={"condition": "damaged" if args.damaged else "ok", "note": args.note})
            elif args.action == "pay":
                r = http.post(f"/api/rfqs/{args.rfq_id}/pay")
            else:
                r = http.post(f"/api/rfqs/{args.rfq_id}/{args.action}")
            if r.status_code == 401:
                print("로그인이 필요하다: uv run python -m kpw_buyer.cli login <이름>", file=sys.stderr)
                return 1
            if r.status_code >= 400:
                print(f"거부: {r.json().get('detail', r.text)}", file=sys.stderr)
                return 1
            print_rfq(r.json())
            return 0
    except httpx.ConnectError:
        print(f"구매 시스템({api})에 연결할 수 없다. 서버가 켜져 있는지 확인하라.", file=sys.stderr)
        return 2
    except httpx.HTTPStatusError as exc:   # 목록 조회 등 raise_for_status를 쓰는 명령
        if exc.response.status_code == 401:
            print("로그인이 필요하다: uv run python -m kpw_buyer.cli login <이름>", file=sys.stderr)
        else:
            print(f"거부: {exc.response.json().get('detail', exc.response.text)}", file=sys.stderr)
        return 1


def session_command(http: httpx.Client, args) -> int:
    if args.cmd == "login":
        r = http.post("/api/login", json={"username": args.username,
                                          "password": args.password or getpass.getpass("비밀번호: ")})
        if r.status_code >= 400:
            print(f"로그인 실패: {r.json().get('detail', r.text)}", file=sys.stderr)
            return 1
        body = r.json()
        if body["token"]:
            save_cli_session(APP_ROOT, body["token"])
        print(f"로그인: {body['user']['display_name']} ({body['user']['role_label']})")
        return 0
    if args.cmd == "logout":
        http.post("/api/logout")
        cli_session_file(APP_ROOT).unlink(missing_ok=True)
        print("로그아웃")
        return 0
    r = http.get("/api/me")
    if r.status_code == 401:
        print("로그인하지 않았다", file=sys.stderr)
        return 1
    body = r.json()
    labels = body["permission_labels"]
    print(f"{body['user']['display_name']} ({body['user']['role_label']})"
          + ("" if body["staff_auth"] else " — 이 서버는 로그인을 끈 상태"))
    print("권한: " + ", ".join(labels.get(p, p) for p in body["user"]["permissions"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
