"""구매 시스템을 실제 HTTP로 띄워 A2A 수신·내부 API·CLI·수집기를 확인한다."""

import asyncio
import time
import uuid
from datetime import datetime

import httpx
import pytest

from a2a.client import create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import Message, Role, SendMessageRequest, TaskState
from logistics_contract import CONTRACT_TAG, parse_response
from logistics_contract.examples import example

from conftest import make_settings
from fake_carrier import ThreadServer, free_port
from kpw_buyer import cli
from kpw_buyer.app import build_app
from kpw_buyer.domain import KST
from kpw_buyer.settings import Partner


@pytest.fixture
def buyer(market):
    """가짜 물류사 a(켜짐), late(꺼짐)를 거래처로 둔 구매 시스템. 수집기 0.2초 간격."""
    # 이 테스트들은 실제 시계를 쓰므로 견적 유효기간을 넉넉히 둔다
    far = datetime(2099, 1, 1, tzinfo=KST)
    market.carrier("a", price=174000, valid_until=far)
    market.carrier("late", start=False, valid_until=far)
    port = free_port()
    partners = [Partner(id=pid, url=f"http://127.0.0.1:{p}") for pid, p in market.ports.items()]
    settings = make_settings(market.tmp_path, partners, port=port, worker_interval_s=0.2)
    server = ThreadServer(build_app(settings), port).start()
    yield settings
    server.stop()


async def send(url, data):
    client = await create_client(url)
    req = SendMessageRequest(message=Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER,
                                             parts=[new_data_part(data)]))
    state, results, text = None, [], ""
    async for r in client.send_message(req):
        kind = r.WhichOneof("payload")
        if kind == "status_update":
            state = r.status_update.status.state
            text = "".join(p.text for p in r.status_update.status.message.parts)
        elif kind == "artifact_update":
            results += get_data_parts(r.artifact_update.artifact.parts)
    await client.close()
    return state, results, text


def test_card(buyer):
    card = httpx.get(f"{buyer.public_url}/.well-known/agent-card.json").json()
    assert card["supportedInterfaces"][0]["url"] == f"{buyer.public_url}/"
    assert card["skills"][0]["id"] == "receive-shipment-event"
    assert CONTRACT_TAG in card["skills"][0]["tags"]


def test_api_flow_and_shipment_event_over_a2a(buyer):
    api = httpx.Client(base_url=buyer.public_url, timeout=30)
    v = api.post("/api/rfqs", json={"item": "베어링", "weight_kg": 480, "origin": "창원", "destination": "평택",
                                    "need_by": "2026-12-31"}).json()
    rfq = v["rfq_id"]
    assert v["state"] == "collecting"           # late가 꺼져 있어 수집 중
    v = api.post(f"/api/rfqs/{rfq}/close").json()
    assert v["state"] == "compared"
    r = api.post(f"/api/rfqs/{rfq}/award", json={"partner_id": "late"})
    assert r.status_code == 409                 # 견적 없는 곳은 거부
    v = api.post(f"/api/rfqs/{rfq}/award", json={"partner_id": "a"}).json()
    tracking = v["bookings"][0]["tracking_no"]

    evt = {**example("shipment-event"), "tracking_no": tracking, "event_id": "x-1", "seq": 5}
    state, results, _ = asyncio.run(send(buyer.public_url, evt))
    assert state == TaskState.TASK_STATE_COMPLETED
    assert parse_response(results[0], "event-ack").duplicate is False
    assert api.get(f"/api/rfqs/{rfq}").json()["bookings"][0]["shipment_status"] == "in_transit"


def test_inbound_rejects_other_requests(buyer):
    state, results, text = asyncio.run(send(buyer.public_url, example("quote-request")))
    assert state == TaskState.TASK_STATE_FAILED and "받지 않는다" in text


def test_inbound_rejects_unknown_tracking(buyer):
    state, _, text = asyncio.run(send(buyer.public_url, example("shipment-event")))
    assert state == TaskState.TASK_STATE_FAILED and "운송장" in text


def test_collector_picks_up_partner_that_comes_back(buyer, market):
    api = httpx.Client(base_url=buyer.public_url, timeout=30)
    rfq = api.post("/api/rfqs", json={"item": "볼트", "weight_kg": 10, "origin": "창원",
                                      "destination": "인천"}).json()["rfq_id"]
    market.start("late")
    deadline = time.time() + 10
    while api.get(f"/api/rfqs/{rfq}").json()["state"] == "collecting":
        assert time.time() < deadline, "수집기가 다시 묻지 않았다"
        time.sleep(0.1)
    assert api.get(f"/api/rfqs/{rfq}").json()["state"] == "compared"


def test_cli(buyer, capsys):
    api = ["--api", buyer.public_url]
    assert cli.main(api + ["rfq", "create", "--item", "베어링", "--weight", "480", "--origin", "창원",
                           "--dest", "평택", "--partners", "a"]) == 0
    out = capsys.readouterr().out
    rfq = out.split()[0]
    assert "비교 가능" in out and "174,000원" in out and "추천: a" in out
    assert cli.main(api + ["rfq", "award", rfq, "a"]) == 0
    assert "수락됨" in capsys.readouterr().out
    assert cli.main(api + ["rfq", "award", rfq, "late"]) == 1   # 이미 발주 완료 → 거부
    assert "거부" in capsys.readouterr().err
