"""plan_2 시나리오를 가짜 물류사(실제 A2A HTTP)로 확인한다."""

import asyncio
from datetime import date, datetime

import pytest

from logistics_contract import CONTRACT_TAG, ShipmentEvent, ShipmentStatus

from kpw_buyer.domain import KST
from kpw_buyer.service import BuyerError

RFQ = dict(item="정밀 베어링", weight_kg=480, origin="창원", destination="평택", need_by=date(2026, 10, 20))


def run(coro):
    return asyncio.run(coro)


def quotes_by_partner(view):
    return {q["partner_id"]: q for q in view["quotes"]}


# ---------- 견적 단계 ----------

def test_s01_happy_path(market):
    market.carrier("a", price=174000)
    market.carrier("b", price=150000)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "compared"
    assert v["recommended"] == "b"

    v = run(svc.award(rfq, "b"))
    assert v["state"] == "awarded"
    booking = v["bookings"][0]
    assert booking["state"] == "accepted" and booking["tracking_no"]

    v = run(svc.track(rfq))
    assert v["bookings"][0]["shipment_status"] == "accepted"


def test_context_id_is_rfq_id_and_same_rfq_sent(market):
    b = market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    assert b.quote_calls == 1
    assert quotes_by_partner(svc.view(rfq))["a"]["quote_id"] == f"물류사 a-Q-{rfq}"


def test_s03_unreachable_partner_retried_until_deadline(market):
    market.carrier("a")
    market.carrier("down", start=False)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "collecting"
    assert quotes_by_partner(v)["down"]["state"] == "pending" and quotes_by_partner(v)["down"]["error"]

    market.clock.advance(minutes=31)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "compared"
    assert quotes_by_partner(v)["down"]["state"] == "no_response"


def test_s04_partner_comes_back_before_deadline(market):
    market.carrier("a")
    market.carrier("late", start=False, price=90000)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    market.start("late")
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "compared" and v["recommended"] == "late"
    assert quotes_by_partner(v)["late"]["attempts"] == 2


def test_s05_invalid_response_excluded(market):
    market.carrier("a", price=174000)
    market.carrier("bad", quote="invalid", price=1)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert quotes_by_partner(v)["bad"]["state"] == "invalid"
    assert v["recommended"] == "a"


def test_s06_eta_exceeds_need_by(market):
    market.carrier("slowship", eta_days=10)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    q = quotes_by_partner(v)["slowship"]
    assert q["state"] == "quoted" and not q["eligible"]
    assert v["recommended"] is None
    with pytest.raises(BuyerError, match="조건 미충족"):
        run(svc.award(rfq, "slowship"))
    v = run(svc.award(rfq, "slowship", allow_ineligible=True))
    assert v["state"] == "awarded"


def test_s08_declined_is_business_result(market):
    market.carrier("a")
    market.carrier("no", quote="decline")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    q = quotes_by_partner(svc.view(rfq))["no"]
    assert q["state"] == "declined" and q["error"] == "차량 없음"


def test_failed_task(market):
    market.carrier("boom", quote="fail")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert quotes_by_partner(v)["boom"]["state"] == "failed"
    assert v["state"] == "no_bids"


def test_incompatible_contract_not_called(market):
    b = market.carrier("v2", contract_tag="contract:logistics/2")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    q = quotes_by_partner(svc.view(rfq))["v2"]
    assert q["state"] == "failed" and CONTRACT_TAG in q["error"]
    assert b.quote_calls == 0


def test_s02_close_now_with_what_we_have(market):
    market.carrier("a")
    market.carrier("slow", quote="slow", slow_s=3)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))          # slow는 1초 타임아웃 → 대기
    assert svc.view(rfq)["state"] == "collecting"
    svc.close_now(rfq)
    v = svc.view(rfq)
    assert v["state"] == "compared" and quotes_by_partner(v)["slow"]["state"] == "no_response"


def test_s09_no_bids_then_extend(market):
    market.carrier("down", start=False)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    market.clock.advance(minutes=31)
    run(svc.collect(rfq))
    assert svc.view(rfq)["state"] == "no_bids"

    market.start("down")
    svc.extend(rfq, 30)
    run(svc.collect(rfq))
    assert svc.view(rfq)["state"] == "compared"


def test_s10_expired_quote_cannot_be_booked(market):
    market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    market.clock.advance(hours=25)
    with pytest.raises(BuyerError, match="유효기간"):
        run(svc.award(rfq, "a"))


def test_unknown_partner_rejected(market):
    market.carrier("a")
    with pytest.raises(BuyerError):
        market.service.create_rfq(**RFQ, partner_ids=["nope"])


# ---------- 발주 단계 ----------

def test_s14_booking_waits_for_carrier_staff(market):
    b = market.carrier("a", booking="hold")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = run(svc.award(rfq, "a"))
    assert v["bookings"][0]["state"] == "waiting" and v["state"] == "compared"
    assert svc.waiting_booking_keys() == [v["bookings"][0]["business_key"]]

    b.booking_release.set()                          # 물류사 담당자 수락
    run(svc.refresh(rfq))
    v = svc.view(rfq)
    assert v["bookings"][0]["state"] == "accepted" and v["state"] == "awarded"
    assert b.booking_calls == 1                      # 다시 보내지 않고 tasks/get으로 확인


def test_s14_accepted_event_before_collector_is_not_rejected(market):
    """물류사 담당자가 수락하자마자 보낸 '수락됨' 알림이 수집기보다 먼저 와도 거부하지 않는다."""
    b = market.carrier("a", booking="hold")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    run(svc.award(rfq, "a"))
    b.booking_release.set()                          # 담당자 수락 — 수집기는 아직 모른다
    tracking = next(iter(b.shipments))
    event = ShipmentEvent(event_id="a-1", carrier="물류사 a", booking_id="물류사 a-B-1", tracking_no=tracking,
                          seq=1, shipment_status=ShipmentStatus.ACCEPTED, at=datetime(2026, 10, 15, 9, 1, tzinfo=KST))
    assert run(svc.learn_tracking(tracking)) is True    # 받는 쪽(executor)이 거부 전에 하는 일
    ack = svc.receive_event(event)
    assert ack.duplicate is False
    v = svc.view(rfq)
    assert v["state"] == "awarded" and v["bookings"][0]["tracking_no"] == tracking


def test_unknown_tracking_without_waiting_booking_is_decided_at_once(market):
    import time
    market.carrier("a")
    svc = market.service
    started = time.monotonic()
    assert run(svc.learn_tracking("NOPE-1")) is False
    assert time.monotonic() - started < 0.5


def test_s12_task_lost_resend_same_business_key(market):
    """물류사가 발주를 받아 둔 채 재시작 → Task가 사라짐 → 같은 업무키로 재전송, 장부에는 1건."""
    b = market.carrier("a", booking="hold")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    run(svc.award(rfq, "a"))
    market.restart("a")
    b.booking_release.set()
    v = run(svc.award(rfq, "a"))
    assert v["bookings"][0]["state"] == "accepted"
    assert b.booking_calls == 2 and len(b.bookings) == 1


def test_unknown_booking_resent_when_carrier_back(market):
    market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    market.servers.pop("a").stop()                   # 발주 직전에 물류사가 꺼짐
    v = run(svc.award(rfq, "a"))
    assert v["bookings"][0]["state"] == "unknown"
    market.start("a")
    v = run(svc.award(rfq, "a"))                     # 같은 업무키로 재전송
    assert v["bookings"][0]["state"] == "accepted"


# ---------- 물류사 확인 중 / 질문 (S-02, S-07) ----------

def test_s02_manual_quote_waits_then_arrives(market):
    market.carrier("a", price=174000)
    k = market.carrier("k", quote="manual", price=150000)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "collecting" and quotes_by_partner(v)["k"]["state"] == "waiting"
    assert v["recommended"] == "a"                    # 받은 것 중에서는 a

    k.release.set()
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "compared" and v["recommended"] == "k"
    assert k.quote_calls == 1                         # 다시 보내지 않고 tasks/get으로 확인


def test_s07_question_and_answer(market):
    k = market.carrier("k", quote="manual", question="팔레트 규격은?")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    q = quotes_by_partner(svc.view(rfq))["k"]
    assert q["state"] == "question" and q["question"] == "팔레트 규격은?"

    v = run(svc.answer(rfq, "k", "1100×1100, 2단 적재 불가"))
    assert quotes_by_partner(v)["k"]["state"] == "waiting"
    assert k.answers == ["1100×1100, 2단 적재 불가"]

    k.release.set()
    run(svc.collect(rfq))
    assert quotes_by_partner(svc.view(rfq))["k"]["state"] == "quoted"


def test_answer_requires_question(market):
    market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    with pytest.raises(BuyerError, match="질문이 없다"):
        run(svc.answer(rfq, "a", "?"))


def test_waiting_quote_task_lost_after_carrier_restart(market):
    k = market.carrier("k", quote="manual")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    market.restart("k")
    k.release.set()
    run(svc.collect(rfq))                              # tasks/get → 없음 → 같은 rfq로 재전송
    assert quotes_by_partner(svc.view(rfq))["k"]["state"] == "quoted"
    assert k.quote_calls == 2


def test_deadline_closes_waiting_and_question(market):
    market.carrier("a")
    market.carrier("k", quote="manual")
    market.carrier("q", quote="manual", question="?")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    market.clock.advance(minutes=31)
    run(svc.collect(rfq))
    v = svc.view(rfq)
    assert v["state"] == "compared"
    assert quotes_by_partner(v)["k"]["state"] == quotes_by_partner(v)["q"]["state"] == "no_response"


def test_s13_rejected_then_next_best(market):
    market.carrier("cheap", price=100000, booking="reject")
    market.carrier("next", price=120000)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = run(svc.award(rfq, "cheap"))
    assert v["state"] == "compared" and v["bookings"][0]["state"] == "rejected"
    v = run(svc.award(rfq, "next"))
    assert v["state"] == "awarded"


def test_cannot_award_twice(market):
    market.carrier("a")
    market.carrier("b")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    run(svc.award(rfq, "a"))
    with pytest.raises(BuyerError):
        run(svc.award(rfq, "b"))


def test_s15_cancel_before_pickup(market):
    market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    run(svc.award(rfq, "a"))
    v = run(svc.cancel(rfq, "일정 변경"))
    assert v["state"] == "cancelled" and v["bookings"][0]["state"] == "cancelled"


def test_s16_cancel_after_pickup_rejected(market):
    b = market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = run(svc.award(rfq, "a"))
    b.shipments[v["bookings"][0]["tracking_no"]][0] = ShipmentStatus.PICKED_UP
    with pytest.raises(BuyerError, match="집하"):
        run(svc.cancel(rfq))


# ---------- 배송 알림 ----------

def event(tracking, seq, status, eid=None):
    return ShipmentEvent(event_id=eid or f"e-{seq}", carrier="물류사 a", booking_id="B", tracking_no=tracking,
                         seq=seq, shipment_status=status, at=datetime(2026, 10, 16, tzinfo=KST))


def test_s19_s20_events_dedup_and_order(market):
    market.carrier("a")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    tracking = run(svc.award(rfq, "a"))["bookings"][0]["tracking_no"]

    assert not svc.receive_event(event(tracking, 3, ShipmentStatus.IN_TRANSIT)).duplicate
    assert svc.receive_event(event(tracking, 3, ShipmentStatus.IN_TRANSIT)).duplicate      # S-19
    svc.receive_event(event(tracking, 2, ShipmentStatus.PICKED_UP))                           # S-20 늦게 온 옛 상태
    b = svc.view(rfq)["bookings"][0]
    assert (b["shipment_status"], b["shipment_seq"]) == ("in_transit", 3)


# ---------- 배송·입고·지급 (S-17~S-24) ----------

def awarded(market, **behavior):
    b = market.carrier("a", **behavior)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    tracking = run(svc.award(rfq, "a"))["bookings"][0]["tracking_no"]
    return svc, b, rfq, tracking


def test_s23_receive_and_pay_once(market):
    svc, b, rfq, tracking = awarded(market, price=174000)
    svc.receive_event(event(tracking, 4, ShipmentStatus.DELIVERED))     # 물류사 알림으로 배송 완료
    v = svc.confirm_receipt(rfq, "ok", "수량 이상 없음")
    assert v["state"] == "received" and v["receipt"]["condition"] == "ok"
    assert svc.confirm_receipt(rfq, "ok", "수량 이상 없음")["state"] == "received"   # 두 번 눌러도 한 번

    v, created = svc.pay(rfq)
    assert created and v["state"] == "paid" and v["payments"][0]["amount_krw"] == 174000
    v, created = svc.pay(rfq)                                             # 두 번 눌러도
    assert not created and len(v["payments"]) == 1                        # 장부에는 1건
    assert v["payments"][0]["business_key"].startswith("K정밀웍스:" + rfq + ":pay:")


def test_receive_requires_delivery(market):
    svc, _, rfq, _ = awarded(market)
    with pytest.raises(BuyerError, match="배송 완료 전"):
        svc.confirm_receipt(rfq)
    with pytest.raises(BuyerError, match="입고 확인 후"):
        svc.pay(rfq)


def test_s24_damaged_holds_payment(market):
    svc, _, rfq, tracking = awarded(market)
    svc.receive_event(event(tracking, 4, ShipmentStatus.DELIVERED))
    v = svc.confirm_receipt(rfq, "damaged", "팔레트 1개 파손")
    assert v["state"] == "on_hold"
    with pytest.raises(BuyerError, match="보류"):
        svc.pay(rfq)
    with pytest.raises(BuyerError, match="다른 내용"):
        svc.confirm_receipt(rfq, "ok")


def test_eta_estimated_from_quote_on_accept(market):
    svc, _, rfq, _ = awarded(market, eta_days=3)
    assert svc.view(rfq)["bookings"][0]["eta"] == "2026-10-18"


def test_s21_eta_after_need_by_is_risk(market):
    svc, _, rfq, _ = awarded(market, eta_days=3)
    svc.store.set_booking(svc.view(rfq)["bookings"][0]["business_key"], eta="2026-10-25")  # 납기 이후로 밀림
    assert "희망 납기" in svc.view(rfq)["bookings"][0]["delay_risk"]


def test_s21_delay_risk(market):
    svc, _, rfq, tracking = awarded(market)
    assert svc.view(rfq)["bookings"][0]["delay_risk"] == ""
    svc.receive_event(event(tracking, 3, ShipmentStatus.CUSTOMS_HOLD))
    assert svc.view(rfq)["bookings"][0]["delay_risk"] == "통관 보류"


def test_s18_track_due_when_events_missed(market):
    """알림이 오지 않아도 보조 조회로 배송 상태가 맞춰진다."""
    svc, b, rfq, tracking = awarded(market)
    b.shipments[tracking] = [ShipmentStatus.DELIVERED, 5]                  # 물류사에서는 이미 배송 완료
    assert run(svc.track_due(300)) == 1
    v = svc.view(rfq)["bookings"][0]
    assert (v["shipment_status"], v["shipment_seq"]) == ("delivered", 5)
    assert run(svc.track_due(300)) == 0                                    # 배송 완료 → 더 조회하지 않음


def test_track_due_respects_interval(market):
    svc, b, rfq, tracking = awarded(market)
    b.shipments[tracking] = [ShipmentStatus.IN_TRANSIT, 3]
    assert run(svc.track_due(300)) == 1
    assert run(svc.track_due(300)) == 0                                    # 방금 조회함
    market.clock.advance(minutes=6)
    assert run(svc.track_due(300)) == 1


# ---------- 재시작 ----------

def test_s29_restart_continues_from_db(market):
    market.carrier("a")
    market.carrier("late", start=False)
    rfq = market.service.create_rfq(**RFQ)
    run(market.service.collect(rfq))

    svc = market.restart_service()
    assert svc.collecting_rfqs() == [rfq]
    market.start("late")
    run(svc.collect(rfq))
    assert svc.view(rfq)["state"] == "compared"
