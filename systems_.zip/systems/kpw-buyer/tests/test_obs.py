"""관찰 이벤트 (S-25). 허브가 없으면 아무 일도 없고, 허브가 꺼져 있어도 업무는 그대로 된다."""

import asyncio
import dataclasses
import time
from datetime import date

import pytest

from a2a.types.a2a_pb2 import TaskState
from logistics_contract.examples import example

from conftest import make_settings
from fake_carrier import ThreadServer, free_port
from fake_hub import HubLog, build_fake_hub
from kpw_buyer import obs_hook
from kpw_buyer.app import build_app
from test_app import send

RFQ = dict(item="정밀 베어링", weight_kg=480, origin="창원", destination="평택", need_by=date(2026, 10, 20))
ME = "http://127.0.0.1:5010"


@pytest.fixture(autouse=True)
def reset_hook():
    yield
    obs_hook.stop(timeout_s=0.5)


@pytest.fixture
def hub():
    log = HubLog()
    port = free_port()
    server = ThreadServer(build_fake_hub(log), port).start()
    log.url = f"http://127.0.0.1:{port}"
    yield log
    server.stop()


def run(coro):
    return asyncio.run(coro)


def test_without_hub_nothing_is_sent():
    obs_hook.start("kpw-buyer", ME, "")
    obs_hook.emit("agent.started")
    assert not obs_hook.enabled() and obs_hook._queue.unfinished_tasks == 0


def test_quote_requests_reach_hub(market, hub):
    obs_hook.start("kpw-buyer", ME, hub.url)
    market.carrier("a", price=174000)
    k = market.carrier("k", quote="manual", price=150000)
    market.carrier("down", start=False)
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))                     # a 견적, k 처리 중, down 연결 실패
    run(svc.collect(rfq))                     # k 그대로 · down 다시 실패 → 알림 없음
    k.release.set()
    run(svc.collect(rfq))                     # k 견적 도착
    url = {pid: f"http://127.0.0.1:{port}" for pid, port in market.ports.items()}
    hub.wait_for(lambda h: len(h.of("request.done")) == 3)
    time.sleep(0.2)

    assert all(e["side"] == "client" and e["agentId"] == ME for e in hub.events)
    assert sorted(e["payload"]["url"] for e in hub.of("card.fetched")) == sorted([url["a"], url["k"]])
    assert [e["payload"]["url"] for e in hub.of("card.failed")] == [url["down"]]   # 바뀔 때만 알린다
    sent = {e["payload"]["to"]: e for e in hub.of("request.sent")}
    assert set(sent) == {url["a"], url["k"]}
    assert sent[url["a"]]["payload"]["skill"] == "quote"
    assert sent[url["a"]]["payload"]["text"].startswith(f"quote-request {rfq}")
    assert sent[url["a"]]["contextId"] == rfq

    done = {}
    for e in hub.of("request.done"):
        done.setdefault(e["payload"]["to"], []).append(e)
    assert [e["payload"]["state"] for e in done[url["a"]]] == ["TASK_STATE_COMPLETED"]
    # 처리 중 → (수집기가 tasks/get으로 확인) → 완료. 같은 요청(requestId)으로 이어진다
    assert [e["payload"]["state"] for e in done[url["k"]]] == ["TASK_STATE_WORKING", "TASK_STATE_COMPLETED"]
    assert {e["payload"]["requestId"] for e in done[url["k"]]} == {sent[url["k"]]["payload"]["requestId"]}
    assert done[url["k"]][0]["taskId"] == done[url["k"]][1]["taskId"] != ""


def test_answer_is_traced(market, hub):
    obs_hook.start("kpw-buyer", ME, hub.url)
    market.carrier("k", quote="manual", question="팔레트 규격은?")
    svc = market.service
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    run(svc.answer(rfq, "k", "1100×1100"))
    hub.wait_for(lambda h: len(h.of("request.done")) == 2)
    first, answer = hub.of("request.done")
    assert first["payload"]["state"] == "TASK_STATE_INPUT_REQUIRED"
    assert answer["payload"]["skill"] == "answer" and answer["taskId"] == first["taskId"]
    assert hub.of("request.sent")[1]["payload"]["text"] == "1100×1100"


def test_inbound_task_reaches_hub(tmp_path, hub):
    port = free_port()
    settings = dataclasses.replace(make_settings(tmp_path, [], port=port), obs_url=hub.url)
    server = ThreadServer(build_app(settings), port).start()
    try:
        state, _, _ = run(send(settings.public_url, example("quote-request")))
        assert state == TaskState.TASK_STATE_FAILED
        hub.wait_for(lambda h: any(e["payload"].get("to") == "TASK_STATE_FAILED" for e in h.of("task.state")))
    finally:
        server.stop()
    hub.wait_for(lambda h: "agent.stopped" in h.types())

    started = hub.of("agent.started")[0]
    assert started["agentId"] == settings.public_url and started["payload"]["name"] == "K정밀웍스 구매 시스템"
    assert started["payload"]["skills"] == ["receive-shipment-event"]
    assert hub.of("task.received")[0]["payload"]["text"].startswith("quote-request")
    failed = [e for e in hub.of("task.state") if e["payload"]["to"] == "TASK_STATE_FAILED"][0]
    assert "받지 않는다" in failed["payload"]["result"]


def test_s25_hub_down_business_continues(market):
    obs_hook.start("kpw-buyer", ME, f"http://127.0.0.1:{free_port()}")   # 아무도 듣지 않는 주소
    market.carrier("a", price=174000)
    market.carrier("b", price=150000)
    svc = market.service
    started = time.monotonic()
    rfq = svc.create_rfq(**RFQ)
    run(svc.collect(rfq))
    v = run(svc.award(rfq, "b"))
    assert v["state"] == "awarded" and v["bookings"][0]["state"] == "accepted"
    assert time.monotonic() - started < 10   # 허브를 기다리지 않는다
