from datetime import datetime, timedelta

import pytest

from fake_carrier import Behavior, ThreadServer, build_fake_app, free_port
from kpw_buyer.domain import KST
from kpw_buyer.remote import CarrierClient
from kpw_buyer.service import BuyerService
from kpw_buyer.settings import Partner, Settings
from kpw_buyer.store import Store


class FakeClock:
    def __init__(self) -> None:
        self.now = datetime(2026, 10, 15, 9, 0, tzinfo=KST)

    def __call__(self) -> datetime:
        return self.now

    def advance(self, **kwargs) -> None:
        self.now += timedelta(**kwargs)


def make_settings(tmp_path, partners, port: int = 5010, worker_interval_s: float = 0) -> Settings:
    return Settings(
        buyer_name="K정밀웍스", bind_host="127.0.0.1", port=port, public_url=f"http://127.0.0.1:{port}",
        db_path=tmp_path / "kpw_buyer.sqlite3", partners=tuple(partners),
        request_timeout_s=1.0, worker_interval_s=worker_interval_s, default_deadline_min=30,
        quick_wait_s=0.5, track_interval_s=0,
    )


class Market:
    """가짜 물류사 여러 곳 + 그들을 거래처로 둔 구매 서비스."""

    def __init__(self, tmp_path) -> None:
        self.tmp_path = tmp_path
        self.servers: dict[str, ThreadServer] = {}
        self.behaviors: dict[str, Behavior] = {}
        self.ports: dict[str, int] = {}
        self.clock = FakeClock()
        self._service = None

    def carrier(self, partner_id: str, start: bool = True, **behavior) -> Behavior:
        """거래처 하나 등록. start=False면 주소만 정해 두고 서버는 꺼진 상태 (S-03)."""
        b = Behavior(name=behavior.pop("name", f"물류사 {partner_id}"), **behavior)
        self.behaviors[partner_id] = b
        self.ports[partner_id] = free_port()
        if start:
            self.start(partner_id)
        return b

    def start(self, partner_id: str) -> None:
        port = self.ports[partner_id]
        self.servers[partner_id] = ThreadServer(build_fake_app(self.behaviors[partner_id], port), port).start()

    def restart(self, partner_id: str) -> None:
        """물류사 재시작: 장부(Behavior)는 남고 A2A Task(메모리)는 사라진다."""
        self.servers.pop(partner_id).stop()
        self.start(partner_id)

    def stop_all(self) -> None:
        for s in self.servers.values():
            s.stop()

    @property
    def settings(self) -> Settings:
        partners = [Partner(id=pid, url=f"http://127.0.0.1:{port}") for pid, port in self.ports.items()]
        return make_settings(self.tmp_path, partners)

    @property
    def service(self) -> BuyerService:
        if self._service is None:
            s = self.settings
            self._service = BuyerService(s, Store(s.db_path), CarrierClient(s.request_timeout_s, s.quick_wait_s),
                                         self.clock)
        return self._service

    def restart_service(self) -> BuyerService:
        self._service = None
        return self.service


@pytest.fixture
def market(tmp_path):
    m = Market(tmp_path)
    yield m
    m.stop_all()
