from datetime import date, datetime

from logistics_contract import Quote

from kpw_buyer.domain import KST, booking_key, check_quote, recommend

NOW = datetime(2026, 10, 15, 9, 0, tzinfo=KST)


def q(price, eta, valid=datetime(2026, 10, 16, 9, 0, tzinfo=KST)) -> Quote:
    return Quote(quote_id="Q", rfq_id="R", carrier="c", price_krw=price, eta_days=eta, valid_until=valid)


def test_eligible():
    assert check_quote(q(1, 3), date(2026, 10, 18), NOW).eligible


def test_eta_exceeds_need_by():
    e = check_quote(q(1, 4), date(2026, 10, 18), NOW)
    assert not e.eligible and not e.expired and "납기" in e.issues[0]


def test_expired():
    e = check_quote(q(1, 1, valid=datetime(2026, 10, 15, 8, 0, tzinfo=KST)), None, NOW)
    assert e.expired and not e.eligible


def test_recommend_cheapest_eligible_then_faster():
    a, b, c = q(100, 3), q(90, 9), q(100, 2)
    cands = [("a", a, check_quote(a, date(2026, 10, 18), NOW)),
             ("b", b, check_quote(b, date(2026, 10, 18), NOW)),   # 더 싸지만 납기 초과
             ("c", c, check_quote(c, date(2026, 10, 18), NOW))]
    assert recommend(cands) == "c"


def test_recommend_none():
    assert recommend([]) is None


def test_booking_key_stable():
    assert booking_key("K정밀웍스", "RFQ-1", "carrier-a") == "K정밀웍스:RFQ-1:book:carrier-a:v1"
