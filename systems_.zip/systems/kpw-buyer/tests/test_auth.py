"""인증·권한 (Part 4 Ch18 파트너 키, Ch19 권한 경계)과 거래처 DB. 설계: systems/docs/security-and-db.md"""

import asyncio
import dataclasses
import uuid
from datetime import datetime

import httpx
import pytest

from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import new_data_part
from a2a.types.a2a_pb2 import Message, Role, SendMessageRequest, TaskState
from logistics_contract.examples import example

from conftest import make_settings
from fake_carrier import ThreadServer, free_port
from kpw_buyer.app import build_app, build_auth, build_service
from kpw_buyer.domain import KST
from kpw_buyer.settings import Partner

PW = "pass-word-1"
FAR = datetime(2099, 1, 1, tzinfo=KST)
RFQ = {"item": "베어링", "weight_kg": 480, "origin": "창원", "destination": "평택", "need_by": "2026-12-31"}


class Buyer:
    def __init__(self, market, **changes) -> None:
        market.carrier("a", price=174000, valid_until=FAR)
        market.carrier("b", price=160000, valid_until=FAR)
        port = free_port()
        partners = [Partner(id=pid, url=f"http://127.0.0.1:{p}") for pid, p in market.ports.items()]
        self.settings = dataclasses.replace(make_settings(market.tmp_path, partners, port=port),
                                            a2a_auth=True, staff_auth=True, **changes)
        self.auth = build_auth(self.settings)
        self.service = build_service(self.settings, self.auth)
        self.server = ThreadServer(build_app(self.settings, self.service, self.auth), port).start()
        self.url = self.settings.public_url
        for name, role in (("boss", "admin"), ("appr", "approver"), ("buy", "buyer"), ("view", "viewer")):
            self.auth.add_user(name, PW, role)
        # 물류사 a·b가 우리에게 발급한 키 (대상 = 거래처 id), 우리가 a·b에 발급한 알림 키
        self.auth.set_outbound("a", "pk_from_carrier_a")
        self.auth.set_outbound("b", "pk_from_carrier_b")
        _, self.key_a = self.auth.issue_key("a", ["receive-shipment-event"])
        _, self.key_b = self.auth.issue_key("b", ["receive-shipment-event"])

    def login(self, name: str) -> httpx.Client:
        client = httpx.Client(base_url=self.url, timeout=30)
        assert client.post("/api/login", json={"username": name, "password": PW}).status_code == 200
        return client


@pytest.fixture
def buyer(market):
    b = Buyer(market)
    yield b
    b.server.stop()


async def notify(url: str, event: dict, key: str | None):
    async with httpx.AsyncClient(headers={"X-Partner-Key": key} if key else {}) as http:
        client = await create_client(url, client_config=ClientConfig(httpx_client=http, streaming=False))
        msg = Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[new_data_part(event)])
        task = [r async for r in client.send_message(SendMessageRequest(message=msg))][-1].task
        await client.close()
    return task.status.state, "".join(p.text for p in task.status.message.parts)


def awarded(buyer, partner_id="a") -> str:
    """운송 요청 → 발주(승인권자)까지 하고 운송장을 돌려준다."""
    appr = buyer.login("appr")
    rfq = appr.post("/api/rfqs", json=RFQ).json()["rfq_id"]
    appr.post(f"/api/rfqs/{rfq}/close")
    v = appr.post(f"/api/rfqs/{rfq}/award", json={"partner_id": partner_id}).json()
    return v["bookings"][0]["tracking_no"]


# ---------- 회사 사이 ----------

def test_card_declares_partner_key(buyer):
    card = httpx.get(f"{buyer.url}/.well-known/agent-card.json").json()
    assert card["securitySchemes"]["partnerKey"]["apiKeySecurityScheme"]["name"] == "X-Partner-Key"


def test_buyer_presents_carrier_issued_keys(buyer, market):
    awarded(buyer)
    assert set(market.behaviors["a"].partner_keys) == {"pk_from_carrier_a"}   # 견적·발주 모두 a가 준 키로
    assert set(market.behaviors["b"].partner_keys) == {"pk_from_carrier_b"}


def test_shipment_event_needs_owner_carrier_key(buyer):
    tracking = awarded(buyer, "a")
    event = {**example("shipment-event"), "tracking_no": tracking, "event_id": "a-evt-1", "seq": 5}
    state, text = asyncio.run(notify(buyer.url, event, None))
    assert state == TaskState.TASK_STATE_REJECTED and "파트너 키" in text
    state, text = asyncio.run(notify(buyer.url, event, buyer.key_b))           # 다른 물류사가 a의 운송장을
    assert state == TaskState.TASK_STATE_REJECTED and "다른 거래처" in text
    state, _ = asyncio.run(notify(buyer.url, event, buyer.key_a))
    assert state == TaskState.TASK_STATE_COMPLETED
    denied = [a for a in buyer.auth.audit_log() if a["action"] == "a2a.denied"]
    assert {a["actor"] for a in denied} == {"partner:?", "partner:b"}


def test_get_task_needs_key(buyer):
    body = {"jsonrpc": "2.0", "id": 1, "method": "ListTasks", "params": {}}
    assert httpx.post(f"{buyer.url}/", json=body, headers={"A2A-Version": "1.0"}).status_code == 401


# ---------- 사내: 돈이 걸린 일은 승인권자만 (Ch19) ----------

def test_roles(buyer):
    view, buy, appr = buyer.login("view"), buyer.login("buy"), buyer.login("appr")
    assert httpx.get(f"{buyer.url}/api/rfqs").status_code == 401
    assert view.get("/api/rfqs").status_code == 200
    assert view.post("/api/rfqs", json=RFQ).status_code == 403
    rfq = buy.post("/api/rfqs", json=RFQ).json()["rfq_id"]                    # 구매 담당: 요청은 된다
    buy.post(f"/api/rfqs/{rfq}/close")
    r = buy.post(f"/api/rfqs/{rfq}/award", json={"partner_id": "b"})
    assert r.status_code == 403 and "발주" in r.json()["detail"]             # 발주는 승인권자만
    assert appr.post(f"/api/rfqs/{rfq}/award", json={"partner_id": "b"}).status_code == 200
    # 권한 판정이 업무 판정보다 먼저다: 권한이 있으면 업무 규칙(배송 완료 전 입고 불가 = 409)까지 간다
    assert buy.post(f"/api/rfqs/{rfq}/receive", json={}).status_code == 409    # 입고 확인은 구매 담당도
    assert buy.post(f"/api/rfqs/{rfq}/pay").status_code == 403                 # 지급은 승인권자만
    assert appr.post(f"/api/rfqs/{rfq}/pay").status_code == 409
    actions = [(a["actor"], a["action"]) for a in buyer.auth.audit_log()]
    assert {("buy", "rfq.create"), ("appr", "rfq.award")} <= set(actions)
    assert ("buy", "denied") in actions


# ---------- 거래처 DB ----------

def test_partners_live_in_db(buyer):
    boss = buyer.login("boss")
    ids = [p["id"] for p in boss.get("/api/partners").json()]
    assert ids == ["a", "b"]                                                   # 설정 파일 값으로 처음 채움
    assert buyer.login("appr").post("/api/partners", json={"id": "c", "url": "http://127.0.0.1:1"}).status_code == 403
    r = boss.post("/api/partners", json={"id": "c", "url": "http://127.0.0.1:1/"})
    assert r.status_code == 201 and r.json()["url"] == "http://127.0.0.1:1"
    assert boss.post("/api/partners", json={"id": "c", "url": "http://x:1"}).status_code == 409
    assert boss.post("/api/partners", json={"id": "d", "url": "ftp://x"}).status_code == 409
    boss.patch("/api/partners/c", json={"active": False})
    v = boss.post("/api/rfqs", json=RFQ).json()
    assert {q["partner_id"] for q in v["quotes"]} == {"a", "b"}                 # 사용 안 하는 거래처는 빠진다

    again = build_service(buyer.settings, buyer.auth)                           # 다시 켜도 DB 값 (파일로 덮지 않음)
    assert [p["id"] for p in again.partner_rows()] == ["a", "b", "c"]


def test_partner_address_change_keeps_key(buyer, market):
    """S-32: 물류사가 주소를 옮기면 거래처 주소만 고친다. 키는 거래처 id로 찾으므로 그대로 쓰인다."""
    boss = buyer.login("boss")
    market.servers.pop("b").stop()
    port = free_port()
    market.ports["b"] = port
    market.start("b")
    assert boss.patch("/api/partners/b", json={"url": f"http://127.0.0.1:{port}"}).status_code == 200
    market.behaviors["b"].partner_keys.clear()
    rfq = boss.post("/api/rfqs", json=RFQ).json()
    assert next(q for q in rfq["quotes"] if q["partner_id"] == "b")["state"] == "quoted"
    assert set(market.behaviors["b"].partner_keys) == {"pk_from_carrier_b"}


def test_carrier_refusing_our_key_is_a_clear_failure(buyer, market):
    """물류사가 우리 키를 거부하면(폐기 등) 그 견적은 '실패 + 이유'로 남고 서버는 멀쩡하다."""
    from fastapi.responses import JSONResponse

    market.servers.pop("a").stop()
    app = __import__("fake_carrier").build_fake_app(market.behaviors["a"], market.ports["a"])

    @app.middleware("http")
    async def refuse(request, call_next):                  # 키를 확인하는 물류사가 우리 키를 받지 않는 상황
        if request.method == "POST":
            return JSONResponse({"jsonrpc": "2.0", "id": 1, "error": {"code": -32001, "message": "no key"}},
                                status_code=401)
        return await call_next(request)

    market.servers["a"] = ThreadServer(app, market.ports["a"]).start()
    r = buyer.login("buy").post("/api/rfqs", json=RFQ)
    assert r.status_code == 201
    a = next(q for q in r.json()["quotes"] if q["partner_id"] == "a")
    assert a["state"] == "failed" and "키" in a["error"]
