"""구매 업무 화면(/ui)과 화면이 쓰는 내부 API (설계: systems/docs/p6-buyer-ui.md)."""

import dataclasses
import json
import threading
from datetime import date, datetime

import httpx
import pytest

from conftest import make_settings
from fake_carrier import ThreadServer, free_port
from fake_hub import HubLog, build_fake_hub
from kpw_buyer import obs_hook
from kpw_buyer.app import build_app, build_service
from kpw_buyer.domain import KST
from kpw_buyer.settings import Partner

FAR = datetime(2099, 1, 1, tzinfo=KST)
RFQ = {"item": "베어링", "weight_kg": 480, "origin": "창원", "destination": "평택", "need_by": "2099-01-01"}


def start(market, **changes):
    port = free_port()
    partners = [Partner(id=pid, url=f"http://127.0.0.1:{p}") for pid, p in market.ports.items()]
    settings = dataclasses.replace(make_settings(market.tmp_path, partners, port=port), **changes)
    service = build_service(settings)
    return settings, service, ThreadServer(build_app(settings, service), port).start()


@pytest.fixture
def buyer(market):
    market.carrier("a", price=174000, valid_until=FAR)
    market.carrier("b", price=160000, valid_until=FAR)
    settings, service, server = start(market)
    yield settings, service, httpx.Client(base_url=settings.public_url, timeout=30)
    server.stop()


def test_ui_page_and_root_redirect(buyer):
    _, _, api = buyer
    page = api.get("/ui")
    assert page.status_code == 200 and "api('/board')" in page.text and "/api/stream" in page.text
    assert api.get("/", follow_redirects=False).headers["location"] == "/ui"


def test_ui_disabled_keeps_api(market):
    market.carrier("a", valid_until=FAR)
    settings, _, server = start(market, ui_enabled=False)
    try:
        api = httpx.Client(base_url=settings.public_url, timeout=10)
        assert api.get("/ui").status_code == 404
        assert api.get("/api/rfqs").status_code == 200
    finally:
        server.stop()


def test_meta(buyer):
    settings, _, api = buyer
    m = api.get("/api/meta").json()
    assert m["name"] == "K정밀웍스" and m["public_url"] == settings.public_url
    assert m["default_deadline_min"] == settings.default_deadline_min and m["ui_enabled"] is True


def test_board_tells_what_to_do_next(buyer, market):
    _, _, api = buyer
    rfq = api.post("/api/rfqs", json=RFQ).json()["rfq_id"]
    [row] = api.get("/api/board").json()
    assert row["rfq_id"] == rfq and row["quotes_in"] == 2 and row["quotes_total"] == 2
    assert row["best_price"] == 160000 and row["recommended"] == "b"
    assert row["todo"] == ["발주 결정"]

    v = api.post(f"/api/rfqs/{rfq}/award", json={"partner_id": "b"}).json()
    tracking = v["bookings"][0]["tracking_no"]
    row = api.get("/api/board").json()[0]
    assert row["carrier"] == "b" and row["todo"] == [] and row["shipment_label"] == "수락됨"

    service = buyer[1]
    from logistics_contract import ShipmentEvent, ShipmentStatus
    service.receive_event(ShipmentEvent(event_id="b-1", carrier="물류사 b", booking_id="b-B-1", tracking_no=tracking,
                                        seq=9, shipment_status=ShipmentStatus.DELIVERED,
                                        at=datetime(2026, 10, 15, 9, tzinfo=KST)))
    assert api.get("/api/board").json()[0]["todo"] == ["입고 확인"]
    api.post(f"/api/rfqs/{rfq}/receive", json={})
    assert api.get("/api/board").json()[0]["todo"] == ["지급"]
    api.post(f"/api/rfqs/{rfq}/pay")
    row = api.get("/api/board").json()[0]
    assert row["state"] == "paid" and row["todo"] == []


def test_board_shows_question(market):
    market.carrier("k", quote="manual", question="팔레트 규격은?", valid_until=FAR)
    settings, _, server = start(market)
    try:
        api = httpx.Client(base_url=settings.public_url, timeout=30)
        api.post("/api/rfqs", json=RFQ)
        assert "질문 답 필요" in api.get("/api/board").json()[0]["todo"]
    finally:
        server.stop()


def test_stream_sends_change(buyer):
    settings, service, api = buyer
    got, ready = [], threading.Event()

    def read():
        with httpx.stream("GET", f"{settings.public_url}/api/stream", timeout=30) as response:
            for line in response.iter_lines():
                if line.startswith("data:"):
                    got.append(json.loads(line[5:]))
                    ready.set()
                    if len(got) >= 2:
                        return

    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    assert ready.wait(5)
    api.get("/api/board")                                       # 읽기는 이벤트를 만들지 않는다
    service.create_rfq(item="볼트", weight_kg=10, origin="창원", destination="인천", need_by=date(2099, 1, 1))
    reader.join(5)
    assert len(got) == 2 and got[1]["rev"] > got[0]["rev"]


def test_started_event_links_console(market):
    market.carrier("a", valid_until=FAR)
    log = HubLog()
    hub_port = free_port()
    hub = ThreadServer(build_fake_hub(log), hub_port).start()
    try:
        _, _, server = start(market, obs_url=f"http://127.0.0.1:{hub_port}")
        server.stop()
        log.wait_for(lambda h: "agent.started" in h.types())
        assert log.of("agent.started")[0]["payload"]["console"] == "/ui"
    finally:
        obs_hook.stop(timeout_s=0.5)
        hub.stop()


def test_partner_check_reads_cards(buyer):
    """거래처 탭의 'Agent Card 확인' (CLI partners --check와 같은 API)."""
    _, _, api = buyer
    rows = {p["id"]: p for p in api.get("/api/partners", params={"check": True}).json()}
    assert rows["a"]["reachable"] is True and rows["a"]["name"] == "물류사 a"
    assert "quote" in rows["a"]["skills"]
