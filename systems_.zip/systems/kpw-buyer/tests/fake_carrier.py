"""테스트용 가짜 물류사 A2A 서버.

실제 물류사 코드(다른 시스템)를 import하지 않고, 계약 패키지만으로 물류사 역할을 흉내 낸다.
시나리오마다 Behavior로 응답 방식을 바꾼다. Behavior는 서버 밖에 있으므로 서버를 재시작해도
물류사의 "장부"(bookings 등)는 남고 A2A Task만 사라진다 — 실제 물류사의 DB와 같은 효과.
"""

import asyncio
import socket
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime

import uvicorn
from fastapi import FastAPI
from a2a.helpers.proto_helpers import get_data_parts, get_text_parts, new_data_part, new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill, Part, TaskState
from logistics_contract import (
    CONTRACT_TAG,
    Booking,
    BookingRejected,
    BookingRequest,
    CancelBookingRequest,
    CancelBookingResult,
    DeliveryNotFound,
    DeliveryQuery,
    DeliveryStatus,
    Quote,
    QuoteDeclined,
    QuoteRequest,
    ShipmentStatus,
    parse_request,
    to_data,
)

from kpw_buyer.domain import KST

FAKE_VALID_UNTIL = datetime(2026, 10, 16, 9, 0, tzinfo=KST)  # 테스트 시계(10-15 09:00) 기준 24시간 뒤
ASK = object()


@dataclass
class Behavior:
    name: str
    price: int = 100000
    eta_days: int = 3
    quote: str = "ok"            # ok | decline | invalid | fail | slow | manual(담당자 확인: release까지 대기)
    slow_s: float = 0.0
    booking: str = "accept"      # accept | reject | hold(booking_release까지 수락 대기)
    valid_until: datetime = FAKE_VALID_UNTIL
    contract_tag: str = CONTRACT_TAG
    question: str | None = None  # manual 견적 중 구매사에 되물을 질문
    release: threading.Event = field(default_factory=threading.Event)          # 담당자가 견적 확정
    booking_release: threading.Event = field(default_factory=threading.Event)  # 담당자가 발주 수락
    # 기록
    quote_calls: int = 0
    booking_calls: int = 0
    answers: list = field(default_factory=list)
    last_quote_request: QuoteRequest | None = None
    bookings: dict = field(default_factory=dict)    # business_key -> (request, response)
    shipments: dict = field(default_factory=dict)   # tracking_no -> [status, seq]
    partner_keys: list = field(default_factory=list)  # 받은 요청의 X-Partner-Key (구매사가 키를 내는지 확인용)


class FakeExecutor(AgentExecutor):
    def __init__(self, b: Behavior) -> None:
        self.b = b

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        resumed_from = context.current_task.status.state if context.current_task else None
        headers = (context.call_context.state or {}).get("headers", {}) if context.call_context else {}
        self.b.partner_keys.append(headers.get("x-partner-key"))
        task = context.current_task or new_task_from_user_message(context.message)
        if context.current_task is None:
            await event_queue.enqueue_event(task)
        up = TaskUpdater(event_queue, task.id, task.context_id)
        await up.update_status(TaskState.TASK_STATE_WORKING)
        if resumed_from == TaskState.TASK_STATE_INPUT_REQUIRED:
            self.b.answers.append("".join(get_text_parts(context.message.parts)))
            self.b.question = None
            msg = self.b.last_quote_request
        else:
            msg = parse_request(get_data_parts(context.message.parts)[0])
        result = await self.handle(msg)
        if result is ASK:
            await up.update_status(TaskState.TASK_STATE_INPUT_REQUIRED,
                                   message=up.new_agent_message(parts=[Part(text=self.b.question)]))
            return
        if result is None:
            await up.update_status(TaskState.TASK_STATE_FAILED,
                                   message=up.new_agent_message(parts=[Part(text="가짜 물류사 실패")]))
            return
        await up.add_artifact(parts=[new_data_part(result, media_type="application/json")], name="result")
        await up.update_status(TaskState.TASK_STATE_COMPLETED)

    async def handle(self, msg):
        b = self.b
        if isinstance(msg, QuoteRequest):
            b.quote_calls += 1
            b.last_quote_request = msg
            if b.quote == "manual":
                while not b.release.is_set():
                    if b.question:
                        return ASK
                    await asyncio.sleep(0.02)
            if b.quote == "slow":
                await asyncio.sleep(b.slow_s)
            if b.quote == "fail":
                return None
            if b.quote == "decline":
                return to_data(QuoteDeclined(rfq_id=msg.rfq_id, carrier=b.name, reason="차량 없음"))
            if b.quote == "invalid":
                return {"schema_version": "1.0", "kind": "quote", "status": "quoted", "업체": b.name, "가격": b.price}
            return to_data(Quote(quote_id=f"{b.name}-Q-{msg.rfq_id}", rfq_id=msg.rfq_id, carrier=b.name,
                                 price_krw=b.price, eta_days=b.eta_days, valid_until=b.valid_until))
        if isinstance(msg, BookingRequest):
            b.booking_calls += 1
            if msg.business_key not in b.bookings:
                if b.booking == "reject":
                    response = to_data(BookingRejected(business_key=msg.business_key, quote_id=msg.quote_id,
                                                       reason="배차 불가"))
                else:
                    n = len(b.bookings) + 1
                    tracking = f"{b.name}-T-{n}"
                    response = to_data(Booking(status="accepted", business_key=msg.business_key,
                                               booking_id=f"{b.name}-B-{n}", quote_id=msg.quote_id,
                                               tracking_no=tracking))
                    b.shipments[tracking] = [ShipmentStatus.ACCEPTED, 1]
                b.bookings[msg.business_key] = (to_data(msg), response)
            if b.booking == "hold":
                while not b.booking_release.is_set():
                    await asyncio.sleep(0.02)
            return b.bookings[msg.business_key][1]
        if isinstance(msg, CancelBookingRequest):
            for _, resp in b.bookings.values():
                if resp.get("booking_id") == msg.booking_id:
                    s = b.shipments[resp["tracking_no"]]
                    if s[0] != ShipmentStatus.ACCEPTED:
                        return to_data(CancelBookingResult(status="rejected", booking_id=msg.booking_id,
                                                           reason="이미 집하됨"))
                    s[0], s[1] = ShipmentStatus.CANCELLED, s[1] + 1
                    return to_data(CancelBookingResult(status="cancelled", booking_id=msg.booking_id))
            return to_data(CancelBookingResult(status="rejected", booking_id=msg.booking_id, reason="없는 예약"))
        if isinstance(msg, DeliveryQuery):
            if msg.tracking_no not in b.shipments:
                return to_data(DeliveryNotFound(tracking_no=msg.tracking_no))
            status, seq = b.shipments[msg.tracking_no]
            return to_data(DeliveryStatus(tracking_no=msg.tracking_no, shipment_status=status, seq=seq, note="가짜"))
        return None

    async def cancel(self, context, event_queue) -> None:
        raise NotImplementedError


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def build_fake_app(b: Behavior, port: int) -> FastAPI:
    card = AgentCard(
        name=b.name, description="가짜 물류사", version="0.0.0",
        default_input_modes=["application/json"], default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[AgentInterface(url=f"http://127.0.0.1:{port}/", protocol_binding="JSONRPC",
                                             protocol_version="1.0")],
        skills=[AgentSkill(id=s, name=s, description=s, tags=[b.contract_tag])
                for s in ("quote", "book-shipment", "cancel-booking", "check-delivery")],
    )
    handler = DefaultRequestHandler(agent_executor=FakeExecutor(b), task_store=InMemoryTaskStore(), agent_card=card)
    app = FastAPI()
    add_a2a_routes_to_fastapi(app, agent_card_routes=create_agent_card_routes(card),
                              jsonrpc_routes=create_jsonrpc_routes(handler, rpc_url="/"))
    return app


class ThreadServer:
    """uvicorn을 스레드에서 띄우고 내린다."""

    def __init__(self, app, port: int) -> None:
        self.port = port
        self.server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
        self.thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> "ThreadServer":
        self.thread.start()
        deadline = time.time() + 10
        while not self.server.started:
            if time.time() > deadline:
                raise RuntimeError("서버가 뜨지 않았다")
            time.sleep(0.02)
        return self

    def stop(self) -> None:
        self.server.should_exit = True
        self.thread.join(timeout=5)
