# plan — 관제 허브(obs-hub)를 「가상 사무공간」 화면으로 바꾸기

목표: `obs-hub`(:5090)의 첫 화면을 `vertualOfficeSource`의 사무공간 화면(`office/agentUI.html`, 첨부 `office.jpg` 형태)으로 바꾼다. 다섯 회사(구매사 5010, K-Logistics 5020, 물류사 A·B·C 5021~5023)가 구역별 책상에 앉고, 일을 주고받으면 말풍선·작업 표시·경보가 실시간으로 보이게 한다.

> **진행 상황 (2026-10-16):** 1~3단계, 6단계(테스트 11개 통과 · 독립성 검사 통과 · 문서) 완료. 4단계는 `office.html` 기본 설정(다섯 회사, hq)을 그대로 씀. 5단계(브라우저 확인)와 7단계(선택)는 남음.

> 참고: `office.jpg`에 보이는 「클라우드 CEO」, 「퀀트 딜러」 같은 16명은 agentUI.html 자체의 **모의 데이터**다. 바꾼 뒤에는 그 자리에 우리 다섯 회사가 앉는다.

---

## 0. 결론 먼저 — 어떤 방식으로 바꾸나

| 방식 | 내용 | 판단 |
|---|---|---|
| **A. 허브는 그대로, 화면만 교체** | obs-hub의 이벤트 수집·로그인·SQLite·heartbeat·`/stream`은 두고, `GET /`이 사무공간 화면을 내주게 한다 | **채택** |
| B. `vertualOfficeSource/office_hub.py`(:9900)로 교체 | 허브가 1초마다 각 서버의 Agent Card·**ListTasks**를 조회(당겨 오기) | 쓰지 않음 |

B를 쓰지 않는 이유:

- 우리 서버들은 키 없는 `ListTasks`를 401로 막는다. 키를 주면 다른 거래처의 Task까지 보이게 된다(`docs/security-and-db.md` P7-B S2).
- 각 서버는 이미 `obs_hook.py`로 이벤트를 허브에 **밀어 준다**(`task.received`·`task.state`·`request.sent`…).
- `office.html`(agentUI.html을 고친 것)은 이 obs-hub 이벤트 모양을 이미 알아듣는다. `bookToPublic()`이 obs-hub 이벤트를 사무공간 이벤트로 바꾼다.

그래서 **서버 다섯 개와 키·설정은 손대지 않는다.** 바뀌는 것은 obs-hub의 화면 파일 하나와 `app.py`의 라우트뿐이다.

기존 자료(이미 준비돼 있음):

| 파일 | 내용 |
|---|---|
| `docs/office-hub/office.html` | agentUI.html에 허브용 설정을 넣은 완성본(1.3MB, 그림 포함) |
| `docs/office-hub/관제허브_사무공간_변경방법.docx` / `.pdf` | 같은 작업의 안내서 |
| `docs/office-hub/a2a-bridge/` | (선택) 2_API활용 에이전트까지 같은 사무공간에 앉히는 도구 |

---

## 1단계 — 준비와 현재 상태 확인

1. obs-hub를 백업한다. 되돌릴 때 비교할 기준이 된다.
   ```powershell
   Copy-Item obs-hub\obs_hub\app.py obs-hub\obs_hub\app.py.bak
   ```
2. 인증 준비가 끝났는지 확인한다(처음이면 실행).
   ```powershell
   .\dev-env\setup_dev_auth.ps1
   ```
3. 다섯 서버의 `.env`에 `A2A_OBS_URL=http://127.0.0.1:5090`이 있는지 확인한다(현재 모두 있음).
4. 지금 화면이 정상인지 먼저 본다. 허브 → 서버 순서로 띄우고 `http://127.0.0.1:5090/`(`admin6` / `1234`)에서 이벤트가 들어오는지 확인한다.
   ```powershell
   cd obs-hub; uv run python -m obs_hub      # 창 1
   .\start_all.bat                            # systems 폴더에서, 서버 5개
   ```

**완료 기준:** 기존 관제 화면에 다섯 회사가 「켜짐」으로 보인다.

---

## 2단계 — 사무공간 화면 파일 넣기

1. 완성본을 obs-hub 화면 폴더에 복사한다.
   ```powershell
   Copy-Item docs\office-hub\office.html obs-hub\obs_hub\ui\office.html
   ```
2. (확인) `office.html`이 원본 `vertualOfficeSource/office/agentUI.html`과 다른 점은 아래 네 가지다. 원본이 새로 바뀌어 다시 만들어야 할 때는 이 네 가지를 똑같이 넣는다.

   | 고친 것 | 이유 |
   |---|---|
   | 맨 위 설정 블록 `window.OFFICE`(회사·주소·구역) | 책 예제 목록(99xx) 대신 우리 다섯 회사 |
   | 허브 주소 기본값 → `location.origin` | 9900 고정을 없앤다. 다른 PC·포트에서도 동작 |
   | 주소 인자 없이 바로 시작(`source=sse`, autostart, `preset=hq`) | 열자마자 `/stream`에 연결 |
   | 로그인 창, 사용자·로그아웃, 「기존 관제 화면」 링크 | `/stream`은 로그인해야 열린다(쿠키 `session_5090`) |

   원본에서 다시 만들 때는 두 파일을 비교 도구로 비교해 위 부분만 옮긴다(`code --diff vertualOfficeSource\office\agentUI.html docs\office-hub\office.html`).

**완료 기준:** `obs-hub\obs_hub\ui\`에 `index.html`과 `office.html`이 둘 다 있다.

---

## 3단계 — 허브 라우트 바꾸기 (`obs-hub/obs_hub/app.py`)

`@app.get("/")` 부분을 아래처럼 바꾼다. `office.html`이 없으면 예전 화면이 나오므로 안전하게 되돌릴 수 있다.

```python
    @app.get("/")
    async def page() -> FileResponse:
        office = UI.with_name("office.html")   # 사무 공간. 없으면 기존 화면
        return FileResponse(office if office.exists() else UI,
                            media_type="text/html; charset=utf-8")

    @app.get("/classic")                      # 기존 관제 화면
    async def classic() -> FileResponse:
        return FileResponse(UI, media_type="text/html; charset=utf-8")
```

같이 고칠 것:

- `app.py` 맨 위 docstring의 경로 목록에 `GET /classic`을 추가한다.
- `obs-hub/README.md`의 API 표: `GET /` → 사무공간, `GET /classic` → 기존 관제 화면.

**완료 기준:** 허브를 다시 켜면 `/`에서 사무공간, `/classic`에서 기존 화면이 나온다.

---

## 4단계 — 회사·구역 설정 맞추기 (`office.html` 맨 위 설정 블록)

```js
window.OFFICE = {
  preset: 'hq',                       // studio(2) · small(6) · dept(12) · hq(20칸)
  theme: 'day',                       // day · night · wood · mono
  zones: {exec: 'K정밀웍스', trading: 'K-Logistics', content: '물류사 A·B·C', ops: '관제'},
  agents: [
    {name: 'K정밀웍스 구매 시스템', url: 'http://127.0.0.1:5010', zone: 'exec',    org: 'K정밀웍스'},
    {name: 'K-Logistics',          url: 'http://127.0.0.1:5020', zone: 'trading', org: 'K-Logistics'},
    {name: '물류사 A',             url: 'http://127.0.0.1:5021', zone: 'content', org: '물류사 A'},
    {name: '물류사 B',             url: 'http://127.0.0.1:5022', zone: 'content', org: '물류사 B'},
    {name: '물류사 C',             url: 'http://127.0.0.1:5023', zone: 'content', org: '물류사 C'},
  ],
};
```

- `url`은 각 서버의 공개 주소(`APP_PUBLIC_URL`)와 **글자까지 같아야** 한다. `obs_hook.start(..., agent_url=...)`가 이 값을 이벤트의 `agentId`로 쓰고, 화면은 이 값으로 책상을 찾는다. 다르면 빈 칸 아무 데나 앉는다.
- `hq`는 exec 1칸 · trading 7칸 · content 7칸 · ops 5칸이다. 물류사가 7곳을 넘으면 구역을 나누거나 다른 구역에 둔다.
- 회사를 늘릴 때: 허브 `.env`의 `APP_WATCH_URLS`에 주소 추가 → 여기 `agents`에 한 줄 → 그 회사에 수집 키 발급(`uv run python -m obs_hub.admin key issue <이름> --skills ingest`).
- 잠깐 바꿔 볼 때는 주소 인자를 쓴다: `/?preset=dept&theme=night`. 배치는 브라우저에 저장되므로 꼬이면 「처음부터」를 누른다.

**완료 기준:** 다섯 회사가 의도한 구역에 앉는다.

---

## 5단계 — 실행과 확인

1. 허브를 다시 켠다(「관제 허브」 창에서 `Ctrl+C` → `uv run python -m obs_hub`). 서버 창은 그대로 둔다.
2. `http://127.0.0.1:5090/`을 열고 `admin6` / `1234`로 로그인한다.
3. 아래 시나리오로 화면을 확인한다.

| 해 볼 것 | 정상이면 |
|---|---|
| 그냥 열기 | 상단 「● 허브 연결됨」, 가동 5/5, 다섯 책상 |
| 서버 하나 끄기(`Ctrl+C`) | 몇 초 뒤 그 책상이 회색 「응답 없음」 |
| 구매사에서 `rfq create …` | 구매사 책상에 「→ 물류사 A」 등 작업 표시, 물류사 책상은 초록 「작업 중」 + 요청 말풍선 |
| A·B 견적 | 결과 말풍선 |
| K-Logistics(담당자 확인 대기) | 빨강 「승인 대기」 → `quote approve` 후 해제·결과 말풍선 |
| 물류사 C(20초) | 20초 동안 「작업 중」 유지 후 완료 |
| `/classic` | 기존 관제 화면이 그대로 동작 |

이벤트 → 화면 대응(참고):

| obs-hub 이벤트 | 사무공간 |
|---|---|
| `agent.online` / `agent.offline`(허브 heartbeat) | 자리에 앉음 / 회색 「응답 없음」 |
| `task.received` | 초록 「작업 중」 + 요청 말풍선 |
| `task.state` → `INPUT_REQUIRED` | 빨강 「승인 대기」 |
| `task.state` → `COMPLETED` / `FAILED`·`REJECTED`·`CANCELED` | 결과 말풍선 / 실패 누적 |
| `request.sent` / `request.done` | 맡긴 쪽 「→ 상대」 작업, 끝나면 사라짐 |
| `card.failed` | 경보 「카드 조회 실패」 |

---

## 6단계 — 테스트와 문서 정리

1. 기존 테스트가 그대로 통과하는지 확인한다: `cd obs-hub; uv run pytest`
2. `tests/test_hub.py`에 라우트 테스트 두 개를 추가한다.
   - `GET /`에 `office.html`이 있으면 사무공간(`window.OFFICE` 포함), 없으면 `index.html`.
   - `GET /classic`은 항상 `index.html`.
3. 독립성 검사: `.\dev-env\check_independence.ps1 -System obs-hub`. 폴더만 복사해도 `ui/office.html`이 함께 따라가는지 확인한다. 현재 `pyproject.toml`에 패키지 데이터 설정이 없으므로 wheel로 설치하는 경우에는 `ui/*.html` 포함 여부를 확인해야 한다.
4. 문서를 고친다.
   - `obs-hub/README.md`: 화면 설명, `/classic`, 설정 블록 위치
   - `systems/README.md`의 「관제 허브와 함께」: 첫 화면이 사무공간이라는 것
   - (선택) `start_all.bat`에 obs-hub 창 추가(허브 → 서버 순서)

---

## 7단계 — (선택) 더 해 볼 것

| 항목 | 방법 |
|---|---|
| 2_API활용 에이전트(9101·9102)도 같은 사무실에 | `docs/office-hub/a2a-bridge/` — `apply.py --apply` 후 `office_bridge.py` 실행 |
| 서버의 `agent.stopped`를 즉시 반영 | 지금 화면은 이 이벤트를 모르고 heartbeat로 몇 초 뒤 반영한다. `bookToPublic()`에 `case 'agent.stopped': mk('agent.offline', …)`을 추가 |
| 업무 화면 링크 | `agent.started`의 `payload.console`(예: `/ui`)을 책상 클릭 시 열리게 연결 |
| 오프라인 환경 | 글꼴을 Google Fonts에서 받으므로 인터넷이 막히면 기본 글꼴로 보인다(동작에는 지장 없음) |

---

## 되돌리기

1. `obs-hub\obs_hub\ui\office.html`을 지운다.
2. 허브를 다시 켠다. → 예전 화면이 나온다(3단계 코드는 그대로 둬도 된다).
3. 완전히 되돌리려면 `app.py.bak`으로 `app.py`를 복구한다.

## 알아둘 점

- 화면을 열면 허브가 최근 이벤트 2000건(`APP_REPLAY_EVENTS`)을 다시 보낸다. 처음에 말풍선이 몰리고 완료·실패 수에 과거 기록이 더해진다. 깔끔하게 보려면 값을 줄인다.
- 우리 시스템은 LLM을 쓰지 않으므로 「토큰 누적」은 0이다.
- 공간 모양·테마 그림을 새로 굽는 도구(Blender, `build_open.py`)는 이 저장소에 없다. `office.html`은 결과물이므로 바로 쓰는 데는 지장 없다.
