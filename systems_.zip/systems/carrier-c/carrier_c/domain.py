# 파일명: domain.py
"""물류사 C의 업무 규칙. 저장소·네트워크를 모르는 순수 함수만 둔다."""

import dataclasses
import math
import tomllib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from logistics_contract import ShipmentStatus

KST = timezone(timedelta(hours=9), "KST")


def now_kst() -> datetime:
    return datetime.now(KST)


@dataclass(frozen=True)
class Pricing:
    base_krw: int
    per_kg_krw: int
    round_to_krw: int
    eta_days: int
    max_weight_kg: float
    quote_valid_hours: int
    booking_mode: str


def load_pricing(path: Path) -> Pricing:
    with path.open("rb") as f:
        raw = tomllib.load(f)
    p, b = raw["pricing"], raw.get("booking", {})
    mode = b.get("mode", "auto")
    if mode != "auto":
        raise ValueError(f"지원하지 않는 발주 처리 방식: {mode} (현재는 auto만)")
    return Pricing(
        base_krw=int(p["base_krw"]),
        per_kg_krw=int(p["per_kg_krw"]),
        round_to_krw=int(p.get("round_to_krw", 1)),
        eta_days=int(p["eta_days"]),
        max_weight_kg=float(p["max_weight_kg"]),
        quote_valid_hours=int(p["quote_valid_hours"]),
        booking_mode=mode,
    )


EDITABLE = ("base_krw", "per_kg_krw", "round_to_krw", "eta_days", "max_weight_kg", "quote_valid_hours",
            "co2_kg_per_kg")   # 화면에서 고칠 수 있는 항목 (없는 항목은 이 회사에 없는 것)


def pricing_from_dict(values: dict) -> Pricing:
    """DB·화면에서 온 값으로 요금 규칙을 만든다. 모르는 항목은 무시하고, 잘못된 값은 ValueError."""
    kinds = {f.name: f.type for f in dataclasses.fields(Pricing)}
    clean = {}
    for name, kind in kinds.items():
        if name not in values:
            continue
        v = values[name]
        if v is None or v == "":
            clean[name] = None
        elif kind is int:
            if float(v) != int(float(v)):
                raise ValueError(f"{name}은(는) 정수여야 한다")
            clean[name] = int(float(v))
        elif kind is str:
            clean[name] = str(v)
        else:
            clean[name] = float(v)
    try:
        pricing = Pricing(**clean)
    except TypeError as exc:
        raise ValueError(f"요금 규칙 항목이 빠졌다: {exc}") from exc
    check_pricing(pricing)
    return pricing


def check_pricing(p: Pricing) -> None:
    if p.base_krw < 0 or p.per_kg_krw < 0 or p.round_to_krw < 1 or p.eta_days < 0:
        raise ValueError("운임은 0 이상, 올림 단위는 1 이상, 소요일은 0 이상이어야 한다")
    if p.max_weight_kg <= 0 or p.quote_valid_hours <= 0:
        raise ValueError("최대 중량·견적 유효시간은 0보다 커야 한다")
    if getattr(p, "co2_kg_per_kg", None) is not None and p.co2_kg_per_kg < 0:
        raise ValueError("CO₂ 계수는 0 이상이어야 한다")
    if p.booking_mode != "auto":
        raise ValueError("이 회사는 자동 수락(auto)만 지원한다")


def decide_quote(weight_kg: float, pricing: Pricing) -> tuple[int, int] | str:
    """(운임, 소요일) 또는 거절 사유."""
    if weight_kg > pricing.max_weight_kg:
        return f"최대 적재 중량 {pricing.max_weight_kg:g}kg 초과"
    raw = pricing.base_krw + pricing.per_kg_krw * weight_kg
    step = max(pricing.round_to_krw, 1)
    return math.ceil(raw / step) * step, pricing.eta_days


# 배송 상태 전이 (뒤로 가거나 건너뛰는 변경은 막는다)
TRANSITIONS: dict[ShipmentStatus, frozenset[ShipmentStatus]] = {
    ShipmentStatus.PENDING: frozenset({ShipmentStatus.ACCEPTED, ShipmentStatus.CANCELLED}),
    ShipmentStatus.ACCEPTED: frozenset({ShipmentStatus.PICKED_UP, ShipmentStatus.CANCELLED}),
    ShipmentStatus.PICKED_UP: frozenset({ShipmentStatus.IN_TRANSIT}),
    ShipmentStatus.IN_TRANSIT: frozenset({ShipmentStatus.CUSTOMS_HOLD, ShipmentStatus.DELIVERED}),
    ShipmentStatus.CUSTOMS_HOLD: frozenset({ShipmentStatus.IN_TRANSIT, ShipmentStatus.DELIVERED}),
    ShipmentStatus.DELIVERED: frozenset(),
    ShipmentStatus.CANCELLED: frozenset(),
}

STATUS_LABEL = {
    ShipmentStatus.PENDING: "수락 대기",
    ShipmentStatus.ACCEPTED: "수락됨",
    ShipmentStatus.PICKED_UP: "집하",
    ShipmentStatus.IN_TRANSIT: "운송 중",
    ShipmentStatus.CUSTOMS_HOLD: "통관 대기",
    ShipmentStatus.DELIVERED: "배송 완료",
    ShipmentStatus.CANCELLED: "취소됨",
}


class InvalidTransition(ValueError):
    pass


def check_transition(current: ShipmentStatus, new: ShipmentStatus) -> None:
    if new not in TRANSITIONS[current]:
        raise InvalidTransition(f"{STATUS_LABEL[current]} → {STATUS_LABEL[new]} 변경은 허용되지 않는다")


def can_cancel(current: ShipmentStatus) -> bool:
    return ShipmentStatus.CANCELLED in TRANSITIONS[current]
