# 파일명: __main__.py
"""실행: uv run python -m carrier_c  (이 폴더에서)"""

import logging

import uvicorn

from .app import build_app
from .settings import load_settings


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    settings = load_settings()
    app = build_app(settings)
    print(f"[{settings.carrier_name}] {settings.bind_host}:{settings.port} 에서 대기"
          f" · 공개 주소 {settings.public_url} · DB {settings.db_path}", flush=True)
    uvicorn.run(app, host=settings.bind_host, port=settings.port, log_level="warning")


if __name__ == "__main__":
    main()
