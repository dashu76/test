﻿# 파일명: check_independence.ps1
# 서버 폴더 하나하나가 "혼자 떼어 가도 동작하는지" 검사한다 (plan_3 4장).
#
#   .\check_independence.ps1                 # systems 아래 모든 서버
#   .\check_independence.ps1 -System carrier-a
#
# 검사
#   1 폴더 밖 참조 없음   2 단독 설치(uv sync)   3 단독 테스트(pytest)
#   4 단독 기동(거래처 없이)   5 카드 URL == APP_PUBLIC_URL   6 DB가 설정한 경로에 생김
#
# 서버 폴더의 파이썬 패키지 이름은 폴더 이름의 '-'를 '_'로 바꾼 것으로 본다 (carrier-a → carrier_a).
# 관제 허브(obs-hub)는 Agent Card가 없으므로 5는 /healthz의 public_url로 본다.
# 인증(Part 4)은 켜진 채로 기동한다 — 카드·/healthz는 공개라 사용자·키 없이도 검사된다.

param(
    [string[]]$System
)

$SystemsRoot = Split-Path -Parent $PSScriptRoot
$NotServers = @('interop-spec', 'dev-env')
# 업무 DB 대신 다른 파일을 설정한 경로에 만드는 시스템: 폴더 이름 → (환경변수, 파일 이름). 지금은 없음(관제 허브도 APP_DB_PATH)
$DataFile = @{}
$AllServers = Get-ChildItem $SystemsRoot -Directory |
    Where-Object { $NotServers -notcontains $_.Name -and (Test-Path (Join-Path $_.FullName 'pyproject.toml')) } |
    ForEach-Object { $_.Name }
if (-not $System) { $System = $AllServers }

$WorkRoot = Join-Path ([IO.Path]::GetTempPath()) 'a2a-independence'
New-Item -ItemType Directory -Force $WorkRoot | Out-Null
$Summary = @()

function Get-FreePort {
    $listener = New-Object System.Net.Sockets.TcpListener([Net.IPAddress]::Loopback, 0)
    $listener.Start(); $port = $listener.LocalEndpoint.Port; $listener.Stop()
    return $port
}

function Stop-Server($proc, $port) {
    Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
        ForEach-Object { try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction Stop } catch {} }
    if ($proc -and -not $proc.HasExited) { try { Stop-Process -Id $proc.Id -Force -ErrorAction Stop } catch {} }
}

function Test-Started($publicUrl, $port, $proc, $dbPath) {
    $health = $null
    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline -and -not $proc.HasExited) {
        try { $health = Invoke-RestMethod "http://127.0.0.1:$port/healthz" -TimeoutSec 2; break } catch { Start-Sleep -Milliseconds 300 }
    }
    if (-not $health) { return @{ started = $false; url_ok = $false; db_ok = $false } }
    try {
        $card = Invoke-RestMethod "http://127.0.0.1:$port/.well-known/agent-card.json" -TimeoutSec 2
        $url = $card.supportedInterfaces[0].url
    } catch {
        $url = "$($health.public_url)/"   # Agent Card가 없는 시스템(관제 허브)은 /healthz가 알려 주는 공개 주소
    }
    return @{
        started = $true
        url_ok  = ($url -eq "$publicUrl/")
        db_ok   = (Test-Path $dbPath)
        url     = $url
    }
}

foreach ($name in $System) {
    $src = Join-Path $SystemsRoot $name
    $pkg = $name -replace '-', '_'
    $result = [ordered]@{ System = $name }
    Write-Host "`n=== $name ===" -ForegroundColor Cyan

    # 1. 폴더 밖 참조 ------------------------------------------------------
    $others = $AllServers | Where-Object { $_ -ne $name } | ForEach-Object { $_ -replace '-', '_' }
    $files = Get-ChildItem $src -Recurse -File -Include *.py, pyproject.toml |
        Where-Object { $_.FullName -notmatch '\\(\.venv|__pycache__|data)\\' }
    $patterns = @('sys\.path', '\.\.[\\/]', 'path\s*=\s*"[A-Za-z]:') + ($others | ForEach-Object { "\b$_\b" })
    $hits = $files | Select-String -Pattern $patterns
    $result.Refs = if ($hits) { 'FAIL' } else { 'ok' }
    $hits | ForEach-Object { Write-Host "  [참조] $($_.Path):$($_.LineNumber): $($_.Line.Trim())" -ForegroundColor Yellow }

    # 2. 폴더만 따로 복사해 설치 -------------------------------------------
    $copy = Join-Path $WorkRoot $name
    if (Test-Path $copy) { Remove-Item -Recurse -Force $copy }
    robocopy $src $copy /E /XD .venv data __pycache__ .pytest_cache /XF .env /NFL /NDL /NJH /NJS /NP | Out-Null
    Push-Location $copy
    try {
        & uv sync --quiet
        $result.Install = if ($LASTEXITCODE -eq 0) { 'ok' } else { 'FAIL' }

        # 3. 단독 테스트 ----------------------------------------------------
        if ($result.Install -eq 'ok') {
            & uv run pytest -q -p no:cacheprovider | Select-Object -Last 1 | ForEach-Object { Write-Host "  [pytest] $_" }
            $result.Tests = if ($LASTEXITCODE -eq 0) { 'ok' } else { 'FAIL' }
        } else { $result.Tests = 'skip' }

        # 4~6. 거래처 없이 기동, 카드 주소·DB 경로 확인 (공개 주소를 bind 주소와 다르게 줘서 설정에서 오는지 확인)
        if ($result.Install -eq 'ok') {
            $port = Get-FreePort
            $publicUrl = "http://localhost:$port"
            $dataVar, $dataName = if ($DataFile.ContainsKey($name)) { $DataFile[$name] } else { @('APP_DB_PATH', 'independence-check.sqlite3') }
            $dbPath = Join-Path $copy "data\$dataName"
            $env:APP_BIND_HOST = '127.0.0.1'; $env:APP_PORT = "$port"
            $env:APP_PUBLIC_URL = $publicUrl
            Set-Item "env:$dataVar" $dbPath
            $proc = Start-Process uv -ArgumentList 'run', 'python', '-m', $pkg -WorkingDirectory $copy -PassThru `
                -WindowStyle Hidden -RedirectStandardOutput (Join-Path $copy 'server.out.log') -RedirectStandardError (Join-Path $copy 'server.err.log')
            try {
                $r = Test-Started $publicUrl $port $proc $dbPath
            } finally {
                Stop-Server $proc $port
                foreach ($v in 'APP_BIND_HOST', 'APP_PORT', 'APP_PUBLIC_URL', $dataVar) { Remove-Item "env:$v" -ErrorAction SilentlyContinue }
            }
            $result.Start = if ($r.started) { 'ok' } else { 'FAIL' }
            $result.CardUrl = if ($r.url_ok) { 'ok' } else { 'FAIL' }
            $result.Db = if ($r.db_ok) { 'ok' } else { 'FAIL' }
            if ($r.started -and -not $r.url_ok) { Write-Host "  [카드] 기대 $publicUrl/ , 실제 $($r.url)" -ForegroundColor Yellow }
            if (-not $r.started) { Get-Content (Join-Path $copy 'server.err.log') -Tail 20 | ForEach-Object { Write-Host "  [log] $_" } }
        } else { $result.Start = 'skip'; $result.CardUrl = 'skip'; $result.Db = 'skip' }
    } finally {
        Pop-Location
    }
    $Summary += [pscustomobject]$result
}

$Summary | Format-Table -AutoSize
$failed = $Summary | Where-Object { ($_.PSObject.Properties.Value) -contains 'FAIL' }
if ($failed) { Write-Host "분리 불가: $($failed.System -join ', ')" -ForegroundColor Red; exit 1 }
Write-Host "모든 시스템 독립성 검사 통과" -ForegroundColor Green
