# 파일명: demo_runner.py
"""관제 허브 시연용 업무 샘플 실행기 — samples.json의 견적→발주→배송→입고→지급 샘플을 5초마다 하나씩 실행한다.
같은 차례에 자재대응 Agent(A2A, :9102)에도 질문 하나를 보낸다(samples.json의 material, follow는 같은 대화로 이어 묻기).

각 회사의 업무 API(CLI가 부르는 것과 같은 /api/...)만 부르고, 서버 코드는 import하지 않는다.
관제 허브 화면(office.html)이 아래 문을 불러 시작·일시 정지를 정한다(127.0.0.1 전용, 시험용이라 인증 없음).

  GET  /status   진행 상태 {state, next, total, running, done, failed, log}
  POST /start    화면을 열거나 새로 고칠 때. 처음이거나 20개를 다 불렀으면 처음부터, 일시 정지면 재개
  POST /pause    새 샘플 불러오기를 멈춘다 (이미 진행 중인 샘플은 끝까지 간다)
  POST /resume   다시 불러온다
  POST /reset    처음부터 다시

실행 (systems 폴더에서, 다섯 서버와 관제 허브가 떠 있어야 함. 표준 라이브러리만 씀):
  python dev-env\\demo\\demo_runner.py                 # :5095, 화면을 열면 시작
  python dev-env\\demo\\demo_runner.py --autostart     # 화면 없이 바로 시작
  python dev-env\\demo\\demo_runner.py --interval 5 --step 3 --samples dev-env\\demo\\samples.json
"""

import argparse
import json
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
OPEN_QUOTES = {"pending", "waiting", "question"}       # kpw-buyer QuoteState 중 아직 결과가 없는 것
ALLOWED_ORIGINS = {"http://127.0.0.1:5090", "http://localhost:5090"}


class StepError(Exception):
    pass


class Api:
    """회사 하나의 업무 API. 처음 부를 때 로그인하고, 세션이 끝나면(401) 한 번 다시 로그인한다."""

    def __init__(self, name: str, url: str, user: str, password: str) -> None:
        self.name, self.url, self.user, self.password = name, url.rstrip("/"), user, password
        self.token = ""
        self.lock = threading.Lock()

    def _send(self, method: str, path: str, body) -> tuple[int, dict]:
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = urllib.request.Request(self.url + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read() or b"{}")
            except ValueError:
                return e.code, {}

    def login(self) -> None:
        with self.lock:
            status, body = self._send("POST", "/api/login", {"username": self.user, "password": self.password})
            if status >= 400:
                raise StepError(f"{self.name} 로그인 실패: {body.get('detail', status)}")
            self.token = body.get("token") or ""

    def call(self, method: str, path: str, body=None) -> dict:
        try:
            if not self.token:
                self.login()
            status, data = self._send(method, path, body)
            if status == 401:
                self.login()
                status, data = self._send(method, path, body)
        except urllib.error.URLError as e:
            raise StepError(f"{self.name}에 연결할 수 없다 ({e.reason})") from e
        if status >= 400:
            raise StepError(f"{self.name} 거부: {data.get('detail', status)}")
        return data


class Runner:
    def __init__(self, config: dict, interval: float, step: float) -> None:
        self.samples = config["samples"]
        material = config.get("material") or {}
        self.material_url = material.get("url", "").rstrip("/")
        self.material = material.get("samples", []) if self.material_url else []
        self.total = max(len(self.samples), len(self.material))
        self.apis = {name: Api(name, **s) for name, s in config["systems"].items()}
        self.interval, self.step = interval, step
        self.state = "idle"          # idle · running · paused · finished
        self.next = 0                # 다음에 불러올 샘플 번호 (0부터). 업무 샘플과 자재 질문을 같은 차례에 하나씩
        self.round = 0               # 처음부터 다시 시작한 횟수 — 지난 회차의 흐름은 끝까지 가되 기록만 구분
        self.running, self.done, self.failed = 0, 0, 0
        self.m_done, self.m_failed = 0, 0
        self.log: list[str] = []
        self.lock = threading.Lock()
        self.wake = threading.Event()

    # ---------- 제어 (화면이 부름) ----------

    def start(self) -> None:
        with self.lock:
            if self.state in ("idle", "finished"):
                self._reset_locked()
            elif self.state == "paused":
                self.state = "running"
        self.wake.set()

    def pause(self) -> None:
        with self.lock:
            if self.state == "running":
                self.state = "paused"
                self._log("일시 정지 — 새 샘플을 불러오지 않는다 (진행 중인 샘플은 끝까지)")

    def resume(self) -> None:
        with self.lock:
            if self.state == "paused":
                self.state = "running"
                self._log("재개")
        self.wake.set()

    def reset(self) -> None:
        with self.lock:
            self._reset_locked()
        self.wake.set()

    def _reset_locked(self) -> None:
        self.state, self.next, self.done, self.failed = "running", 0, 0, 0
        self.m_done = self.m_failed = 0
        self.round += 1
        self._log(f"{self.round}회차 시작 — 업무 샘플 {len(self.samples)}개 · 자재 질문 {len(self.material)}개를 "
                  f"{self.interval:g}초마다 하나씩")

    def status(self) -> dict:
        with self.lock:
            return {"state": self.state, "next": self.next, "total": self.total, "round": self.round,
                    "running": self.running, "done": self.done, "failed": self.failed,
                    "material": {"total": len(self.material), "done": self.m_done, "failed": self.m_failed},
                    "interval_s": self.interval, "log": self.log[-30:]}

    def _log(self, msg: str) -> None:
        line = f"{datetime.now():%H:%M:%S} {msg}"
        self.log = (self.log + [line])[-200:]
        print(line, flush=True)

    def say(self, msg: str) -> None:
        with self.lock:
            self._log(msg)

    # ---------- 5초마다 하나씩 ----------

    def loop(self) -> None:
        while True:
            with self.lock:
                due = self.state == "running" and self.next < self.total
                if due:
                    i, round_ = self.next, self.round
                    sample = self.samples[i] if i < len(self.samples) else None
                    question = self.material[i] if i < len(self.material) else None
                    self.next += 1
                    self.running += (sample is not None) + (question is not None)
                    if self.next == self.total:
                        self.state = "finished"
                        self._log(f"샘플 {self.total}차례를 모두 불러왔다 — 화면을 새로 고치면 처음부터 다시")
            if due:
                if sample is not None:
                    threading.Thread(target=self.flow, args=(i + 1, sample, round_), daemon=True).start()
                if question is not None:
                    threading.Thread(target=self.material_flow, args=(i + 1, question, round_), daemon=True).start()
                self.wake.wait(self.interval)
            else:
                self.wake.wait(1)
            self.wake.clear()

    def flow(self, n: int, s: dict, round_: int) -> None:
        tag = f"#{n:02d}"
        try:
            self._flow(tag, s)
            ok = True
        except StepError as e:
            self.say(f"{tag} 중단: {e}")
            ok = False
        except Exception as e:        # 예상하지 못한 오류도 실행기는 계속 돈다
            self.say(f"{tag} 오류: {type(e).__name__}: {e}")
            ok = False
        with self.lock:
            self.running -= 1
            if round_ == self.round:
                if ok:
                    self.done += 1
                else:
                    self.failed += 1

    # ---------- 샘플 하나: 견적 → 발주 → 배송 → 입고 → 지급 ----------

    def _flow(self, tag: str, s: dict) -> None:
        buyer, klog = self.apis["kpw-buyer"], self.apis["klogistics"]
        need_by = (date.today() + timedelta(days=s.get("need_by_days", 7))).isoformat()
        v = buyer.call("POST", "/api/rfqs", {
            "item": s["item"], "weight_kg": s["weight_kg"], "origin": s["origin"], "destination": s["destination"],
            "need_by": need_by, "deadline_min": 10, "partners": s["partners"]})
        rid = v["rfq_id"]
        self.say(f"{tag} {rid} 견적 요청 — {s['item']} {s['origin']}→{s['destination']} ({', '.join(s['partners'])})")

        if "klogistics" in s["partners"]:
            time.sleep(self.step)
            if s.get("klogistics") == "decline":
                klog.call("POST", f"/api/quotes/{rid}/decline", {"reason": "해당 일자 차량 부족"})
                self.say(f"{tag} {rid} K-Logistics 담당자 견적 거절")
            else:
                klog.call("POST", f"/api/quotes/{rid}/approve", {"price_krw": None, "eta_days": None})
                self.say(f"{tag} {rid} K-Logistics 담당자 견적 승인")

        v = self.wait_quotes(rid, 25 if "carrier-c" in s["partners"] else 10)
        if v["state"] == "collecting":
            v = buyer.call("POST", f"/api/rfqs/{rid}/close")
        quoted = {q["partner_id"]: q for q in v["quotes"] if q["state"] == "quoted"}
        quotes = ", ".join(f"{p} {q['price_krw']:,}원" for p, q in quoted.items())
        self.say(f"{tag} {rid} 견적 {len(quoted)}건 ({quotes or '없음'}) · 추천 {v['recommended'] or '-'}")

        partner = s.get("award", "recommended")
        if partner == "recommended" or not (quoted.get(partner) or {}).get("eligible"):
            partner = v["recommended"]
        if not partner:
            raise StepError(f"{rid} 발주할 견적이 없다 (유찰)")
        time.sleep(self.step)
        v = buyer.call("POST", f"/api/rfqs/{rid}/award", {"partner_id": partner, "allow_ineligible": False})
        self.say(f"{tag} {rid} 발주 → {partner}")

        if partner == "klogistics":
            time.sleep(self.step)
            booking = self.wait_for(lambda: next((b for b in klog.call("GET", "/api/inbox")["bookings"]
                                                  if b["rfq_id"] == rid), None), 15, "K-Logistics 발주 수락 대기 목록")
            klog.call("POST", f"/api/bookings/{booking['booking_id']}/accept")
            self.say(f"{tag} {rid} K-Logistics 담당자 발주 수락 ({booking['booking_id']})")

        b = self.wait_booking(rid, partner)
        self.say(f"{tag} {rid} 발주 완료 — 예약 {b['booking_id']} 운송장 {b['tracking_no']}")

        carrier = self.apis[partner]
        for status in s["route"]:
            time.sleep(self.step)
            carrier.call("POST", f"/api/shipments/{b['tracking_no']}/advance",
                         {"status": status, "note": f"시연 {s['origin']}→{s['destination']}"})
            self.say(f"{tag} {rid} {partner} 배송 상태 {status}")

        self.wait_for(lambda: self.booking(rid, partner).get("shipment_status") == "delivered" or None,
                      20, "구매사에 배송 완료 알림 도착")
        time.sleep(self.step)
        damaged = s.get("receive") == "damaged"
        buyer.call("POST", f"/api/rfqs/{rid}/receive",
                   {"condition": "damaged" if damaged else "ok", "note": "팔레트 1개 파손" if damaged else "이상 없음"})
        self.say(f"{tag} {rid} 입고 확인 ({'이상 있음' if damaged else '이상 없음'})")
        time.sleep(self.step)
        try:
            v = buyer.call("POST", f"/api/rfqs/{rid}/pay")
        except StepError as e:
            if not damaged:
                raise
            self.say(f"{tag} {rid} 지급 보류 — {e}")   # 이상 있음 입고는 지급이 막히는 것이 정상 (S-24)
            return
        self.say(f"{tag} {rid} 지급 완료 — {partner} {quoted[partner]['price_krw']:,}원 ({v.get('payment_result', '')})")

    # ---------- 자재대응 Agent 질문 (A2A JSON-RPC SendMessage, 같은 대화는 contextId로 이어 묻기) ----------

    def material_flow(self, n: int, q: dict, round_: int) -> None:
        tag, ok = f"자재#{n:02d}", True
        try:
            context = None
            for i, text in enumerate([q["ask"], *q.get("follow", [])]):
                if i:
                    time.sleep(self.step)
                state, context, answer = self.send_material(text, context)
                self.say(f"{tag} {'질문' if i == 0 else '이어서'}: {text} → {state} · {answer[:60]}")
                if state in ("FAILED", "REJECTED", "CANCELED"):
                    ok = False
                    break
        except StepError as e:
            self.say(f"{tag} 중단: {e}")
            ok = False
        except Exception as e:
            self.say(f"{tag} 오류: {type(e).__name__}: {e}")
            ok = False
        with self.lock:
            self.running -= 1
            if round_ == self.round:
                if ok:
                    self.m_done += 1
                else:
                    self.m_failed += 1

    def send_material(self, text: str, context: str | None) -> tuple[str, str | None, str]:
        message = {"messageId": uuid.uuid4().hex, "role": "ROLE_USER", "parts": [{"text": text}]}
        if context:
            message["contextId"] = context
        body = {"jsonrpc": "2.0", "id": uuid.uuid4().hex, "method": "SendMessage", "params": {"message": message}}
        req = urllib.request.Request(self.material_url + "/", data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                                     headers={"Content-Type": "application/json", "A2A-Version": "1.0"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                res = json.loads(r.read() or b"{}")
        except urllib.error.URLError as e:
            raise StepError(f"자재대응 Agent에 연결할 수 없다 ({getattr(e, 'reason', e)})") from e
        if "error" in res:
            raise StepError(f"자재대응 Agent 오류: {res['error'].get('message')}")
        result = res.get("result", {})
        task = result.get("task") or {}
        parts = [p for a in task.get("artifacts", []) for p in a.get("parts", [])] or \
                (result.get("message") or {}).get("parts", [])
        answer = " ".join(p["text"] for p in parts if p.get("text")).replace("\n", " ").strip()
        state = task.get("status", {}).get("state", "MESSAGE").replace("TASK_STATE_", "")
        return state, task.get("contextId") or (result.get("message") or {}).get("contextId") or context, answer

    # ---------- 기다리기 ----------

    def wait_for(self, check, seconds: float, what: str):
        deadline = time.time() + seconds
        while True:
            got = check()
            if got:
                return got
            if time.time() > deadline:
                raise StepError(f"{seconds:g}초 안에 확인하지 못했다: {what}")
            time.sleep(1)

    def wait_quotes(self, rid: str, seconds: float) -> dict:
        """견적이 다 들어오거나 시간이 다 될 때까지. 처리 중인 견적은 collect로 물류사 Task를 다시 확인한다."""
        buyer, deadline = self.apis["kpw-buyer"], time.time() + seconds
        while True:
            v = buyer.call("GET", f"/api/rfqs/{rid}")
            if not any(q["state"] in OPEN_QUOTES for q in v["quotes"]) or time.time() > deadline:
                return v
            time.sleep(1)
            if v["state"] == "collecting":
                buyer.call("POST", f"/api/rfqs/{rid}/collect")

    def booking(self, rid: str, partner: str) -> dict:
        v = self.apis["kpw-buyer"].call("GET", f"/api/rfqs/{rid}")
        return next((b for b in v["bookings"] if b["partner_id"] == partner), {})

    def wait_booking(self, rid: str, partner: str) -> dict:
        """물류사 수락까지. 수락 대기(waiting)면 award를 다시 불러 결과를 확인한다 (kpw-buyer S-14)."""
        def accepted():
            b = self.booking(rid, partner)
            if b.get("state") == "waiting":
                self.apis["kpw-buyer"].call("POST", f"/api/rfqs/{rid}/award",
                                            {"partner_id": partner, "allow_ineligible": False})
                b = self.booking(rid, partner)
            if b.get("state") in ("rejected", "failed", "cancelled"):
                raise StepError(f"{rid} 발주가 {b['state_label']}")
            return b if b.get("state") == "accepted" and b.get("tracking_no") else None
        return self.wait_for(accepted, 20, "물류사 발주 수락")


def make_handler(runner: Runner):
    class Handler(BaseHTTPRequestHandler):
        def _reply(self, status: int, body: dict) -> None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            origin = self.headers.get("Origin", "")
            if origin in ALLOWED_ORIGINS:      # 관제 허브 화면에서만 부를 수 있게
                self.send_header("Access-Control-Allow-Origin", origin)
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            if self.path.split("?")[0] == "/status":
                self._reply(200, runner.status())
            else:
                self._reply(404, {"detail": "없는 경로"})

        def do_POST(self) -> None:
            action = {"/start": runner.start, "/pause": runner.pause, "/resume": runner.resume,
                      "/reset": runner.reset}.get(self.path.split("?")[0])
            if action is None:
                self._reply(404, {"detail": "없는 경로"})
                return
            action()
            self._reply(200, runner.status())

        def log_message(self, *args) -> None:   # 2초마다 오는 /status 로 화면이 시끄럽지 않게
            pass

    return Handler


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="관제 허브 시연용 업무 샘플 실행기")
    ap.add_argument("--samples", type=Path, default=HERE / "samples.json")
    ap.add_argument("--port", type=int, default=5095)
    ap.add_argument("--interval", type=float, default=5, help="샘플을 불러오는 간격(초)")
    ap.add_argument("--step", type=float, default=3, help="샘플 안 단계 사이 간격(초) — 화면에서 진행이 보이게")
    ap.add_argument("--autostart", action="store_true", help="화면을 열지 않아도 바로 시작")
    a = ap.parse_args()

    runner = Runner(json.loads(a.samples.read_text(encoding="utf-8")), a.interval, a.step)
    threading.Thread(target=runner.loop, daemon=True).start()
    if a.autostart:
        runner.start()
    server = ThreadingHTTPServer(("127.0.0.1", a.port), make_handler(runner))
    print(f"샘플 실행기 http://127.0.0.1:{a.port}/status — 샘플 {len(runner.samples)}개 · "
          f"{'바로 시작' if a.autostart else '관제 허브 화면(http://127.0.0.1:5090/)을 열면 시작'}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
