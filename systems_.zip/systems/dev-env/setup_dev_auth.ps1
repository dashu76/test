﻿# 파일명: setup_dev_auth.ps1
# 로컬 개발용 인증 준비 (Part 4). 설계: systems/docs/security-and-db.md
# 각 시스템의 관리 도구(<패키지>.admin)만 불러서 — 다른 시스템 폴더를 건드리지 않는다 —
#   1 사용자 만들기 (구매사 admin1, K-Logistics admin2, 물류사 A~C admin3~5, 관제 허브 admin6 / 기본 비밀번호 1234)
#   2 회사 사이 키 교환 (받는 쪽이 발급 → 보내는 쪽이 outbound에 넣음)
#        물류사 4곳 → K정밀웍스에 키 발급  → 구매사 outbound <거래처 id>
#        K정밀웍스 → 물류사마다 알림 키 발급 → 물류사 outbound http://127.0.0.1:5010
#        관제 허브 → 시스템마다 수집 키 발급 → 그 시스템 outbound obs
#
#   .\setup_dev_auth.ps1                                  # 각 시스템 기본 DB (data\)
#   .\setup_dev_auth.ps1 -DbDir C:\temp\a2a -Password '다른비밀번호'
#
# 다시 실행하면 비밀번호를 다시 맞추고 새 키를 발급해 덮어쓴다(이전 키는 각 시스템에서 key revoke로 폐기).
# 운영에서는 쓰지 않는다. 회사 사이 키는 각 회사 관리자가 안전한 경로로 주고받는다.

param(
    [string]$DbDir,
    [string]$Password = '1234',
    [string]$BuyerUrl = 'http://127.0.0.1:5010'
)

$ErrorActionPreference = 'Stop'
$SystemsRoot = Split-Path -Parent $PSScriptRoot
$env:PYTHONIOENCODING = 'utf-8'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

# 폴더, 패키지, DB 파일 이름, 사용자(이름=역할)
# 시험 편의상 시스템마다 관리자 한 명. 이름은 시스템마다 다르게(admin1~admin6) — 어느 회사에 로그인했는지 헷갈리지 않게.
# 역할별 사용자는 화면 "관리" 탭이나 <패키지>.admin user add로. 로그인 화면 안내는 각 .env의 APP_LOGIN_HINT.
$Systems = [ordered]@{
    'kpw-buyer'          = @{ pkg = 'kpw_buyer';          db = 'kpw_buyer.sqlite3';  users = @('admin1=admin') }
    'klogistics-carrier' = @{ pkg = 'klogistics_carrier'; db = 'klogistics.sqlite3'; users = @('admin2=admin') }
    'carrier-a'          = @{ pkg = 'carrier_a';          db = 'carrier_a.sqlite3';  users = @('admin3=admin') }
    'carrier-b'          = @{ pkg = 'carrier_b';          db = 'carrier_b.sqlite3';  users = @('admin4=admin') }
    'carrier-c'          = @{ pkg = 'carrier_c';          db = 'carrier_c.sqlite3';  users = @('admin5=admin') }
    'obs-hub'            = @{ pkg = 'obs_hub';            db = 'obs_hub.sqlite3';    users = @('admin6=admin') }
}
# 구매사의 거래처 id (config/partners.toml과 같아야 한다) → 물류사 폴더
$Partners = [ordered]@{ 'klogistics' = 'klogistics-carrier'; 'carrier-a' = 'carrier-a'; 'carrier-b' = 'carrier-b'; 'carrier-c' = 'carrier-c' }
$BuyerName = 'K정밀웍스'

function Invoke-Admin([string]$system, [string[]]$arguments) {
    $s = $Systems[$system]
    if ($DbDir) { $env:APP_DB_PATH = Join-Path $DbDir $s.db } else { Remove-Item env:APP_DB_PATH -ErrorAction SilentlyContinue }
    Push-Location (Join-Path $SystemsRoot $system)
    $ErrorActionPreference = 'Continue'   # 5.1: 네이티브 명령의 stderr(예: "이미 있는 사용자")를 예외로 만들지 않는다
    try {
        $out = & uv run --quiet python -m "$($s.pkg).admin" @arguments 2>&1
        $code = $LASTEXITCODE
    } finally { Pop-Location }
    return @{ code = $code; out = ($out | ForEach-Object { "$_" }) }
}

function Issue-Key([string]$system, [string]$partner, [string]$skills) {
    $r = Invoke-Admin $system @('key', 'issue', $partner, '--skills', $skills, '--quiet')
    if ($r.code -ne 0) { throw "$system 키 발급 실패: $($r.out -join ' ')" }
    return ($r.out | Where-Object { $_ -like 'pk_*' } | Select-Object -Last 1).Trim()
}

function Set-Outbound([string]$system, [string]$target, [string]$key, [string]$note) {
    $r = Invoke-Admin $system @('outbound', 'set', $target, $key, '--note', $note)
    if ($r.code -ne 0) { throw "$system 키 저장 실패: $($r.out -join ' ')" }
}

Write-Host "`n[1] 사용자" -ForegroundColor Cyan
foreach ($system in $Systems.Keys) {
    foreach ($u in $Systems[$system].users) {
        $name, $role = $u -split '='
        $r = Invoke-Admin $system @('user', 'add', $name, '--role', $role, '--password', $Password)
        if ($r.code -ne 0) {   # 이미 있으면 역할·비밀번호만 다시 맞춘다
            $r = Invoke-Admin $system @('user', 'set', $name, '--role', $role, '--active', 'yes', '--password', $Password)
        }
        if ($r.code -ne 0) { throw "$system 사용자 $name 실패: $($r.out -join ' ')" }
    }
    Write-Host ("  {0,-20} {1}" -f $system, (($Systems[$system].users | ForEach-Object { $_ -replace '=', '(' }) -join ') ') + ')')
}

Write-Host "`n[2] 회사 사이 파트너 키 (Ch18)" -ForegroundColor Cyan
foreach ($pid_ in $Partners.Keys) {
    $carrier = $Partners[$pid_]
    $key = Issue-Key $carrier $BuyerName 'quote,book-shipment,cancel-booking,check-delivery'
    Set-Outbound 'kpw-buyer' $pid_ $key "$carrier 발급"
    $key = Issue-Key 'kpw-buyer' $pid_ 'receive-shipment-event'
    Set-Outbound $carrier $BuyerUrl $key "$BuyerName 발급 (배송 알림)"
    Write-Host "  $BuyerName <-> $carrier  (거래처 id $pid_)"
}

Write-Host "`n[3] 관제 허브 수집 키" -ForegroundColor Cyan
foreach ($system in @($Systems.Keys | Where-Object { $_ -ne 'obs-hub' })) {
    $key = Issue-Key 'obs-hub' $system 'ingest'
    Set-Outbound $system 'obs' $key '관제 허브 발급 (X-Obs-Key)'
    Write-Host "  obs-hub -> $system"
}
Remove-Item env:APP_DB_PATH -ErrorAction SilentlyContinue

Write-Host "`n완료. 로그인 (비밀번호 모두 $Password)" -ForegroundColor Green
foreach ($system in $Systems.Keys) { Write-Host ("  {0,-20} {1}" -f $system, (($Systems[$system].users[0] -split '=')[0])) }
Write-Host "로그인 화면에 안내를 띄우려면 각 시스템 .env에 APP_LOGIN_HINT=<이름> / $Password"
Write-Host "화면: 물류사 http://127.0.0.1:5020~5023/  관제 허브 http://127.0.0.1:5090/  ·  CLI: uv run python -m <패키지>.cli login <이름>"
