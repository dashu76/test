"""래퍼 공통 부품 — 명부 읽기, 기존 프로젝트 경로 연결, Agent Card 만들기, 서버 실행."""
import json
import sys
from pathlib import Path

import uvicorn
from fastapi import FastAPI

from a2a.server.agent_execution import AgentExecutor
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill

A2A_DIR = Path(__file__).resolve().parent.parent
ROSTER_FILE = A2A_DIR / "agents.json"
MOCK_DELAY_SEC = 3  # --mock 응답 지연. 사무공간 화면에서 '작업 중' 상태가 보이게 한다


def roster_entry(agent_id: str) -> dict:
    agents = json.loads(ROSTER_FILE.read_text(encoding="utf-8"))["agents"]
    for a in agents:
        if a["id"] == agent_id:
            return a
    raise SystemExit(f"agents.json 에 '{agent_id}' 항목이 없습니다.")


def attach_project(entry: dict) -> Path:
    """기존 프로젝트 폴더를 import 경로 맨 앞에 넣는다. 그 폴더의 파일은 고치지 않는다."""
    project = (A2A_DIR / entry["project"]).resolve()
    if not project.is_dir():
        raise SystemExit(f"프로젝트 폴더가 없습니다: {project}")
    sys.path.insert(0, str(project))
    sys.dont_write_bytecode = True  # 기존 폴더에 __pycache__ 를 새로 쓰지 않는다
    return project


def make_card(entry: dict, description: str, skills: list[AgentSkill]) -> AgentCard:
    return AgentCard(
        name=entry["name"],
        description=description,
        version="0.1.0",
        default_input_modes=["text/plain", "application/json"],
        default_output_modes=["text/plain", "application/json"],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[
            AgentInterface(url=f"http://127.0.0.1:{entry['port']}/", protocol_binding="JSONRPC", protocol_version="1.0")
        ],
        skills=skills,
    )


def serve(card: AgentCard, executor: AgentExecutor, port: int) -> None:
    handler = DefaultRequestHandler(agent_executor=executor, task_store=InMemoryTaskStore(), agent_card=card)
    app = FastAPI(title=card.name)
    add_a2a_routes_to_fastapi(
        app,
        agent_card_routes=create_agent_card_routes(card),
        jsonrpc_routes=create_jsonrpc_routes(handler, rpc_url="/"),
    )
    print(f"{card.name} — http://127.0.0.1:{port}/.well-known/agent-card.json", flush=True)
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
