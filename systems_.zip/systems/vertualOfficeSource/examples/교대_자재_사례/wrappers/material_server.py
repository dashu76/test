"""02_자재대응_Agent 를 A2A 서버로 감싼다.

    python wrappers/material_server.py                  실제 Claude 호출 (API 비용 발생)
    python wrappers/material_server.py --mock           API 호출 없이 고정 응답 (연결 확인용)
    python wrappers/material_server.py --fail-inbound   입고 조회 실패 모의 (Streamlit 토글과 같음)

입력: TextPart 에 생산 담당자의 질문.
출력: Artifact "material_answer" = TextPart(답변) + DataPart(도구 실행 내역).
같은 context_id 로 다시 보내면 이전 대화를 이어 간다 (Streamlit 의 대화 기록과 같은 역할).
"""
import argparse
import asyncio
import json
import sys
import time
from collections import defaultdict

from common import MOCK_DELAY_SEC, attach_project, make_card, roster_entry, serve

ENTRY = roster_entry("material")
attach_project(ENTRY)

from agent.agent import MaterialAgent, TurnResult  # noqa: E402  (02 프로젝트 코드)
from agent.config import load_api_key, load_settings  # noqa: E402
from agent.data_store import DataStore, find_data_dirs  # noqa: E402
from agent.tools import ToolRegistry  # noqa: E402

from a2a.helpers.proto_helpers import (  # noqa: E402
    new_data_part, new_task_from_user_message, new_text_message, new_text_part,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext  # noqa: E402
from a2a.server.events import EventQueue  # noqa: E402
from a2a.server.tasks.task_updater import TaskUpdater  # noqa: E402
from a2a.types.a2a_pb2 import AgentSkill, TaskState  # noqa: E402


def build_agent(fail_inbound: bool, mock: bool) -> tuple[MaterialAgent | None, object]:
    data_dir = find_data_dirs()[0]  # 기본 자료(참고/) — Streamlit 사이드바의 첫 항목
    settings = load_settings(data_dir)
    if mock:
        return None, settings
    api_key = load_api_key()
    if not api_key:
        raise SystemExit("API 키가 없습니다. ANTHROPIC_API_KEY 또는 02 폴더의 claudeapi.txt 를 확인하세요.")
    registry = ToolRegistry(DataStore.load(data_dir), settings, fail_inbound=fail_inbound)
    return MaterialAgent(api_key, settings, registry), settings


class MaterialExecutor(AgentExecutor):
    def __init__(self, agent: MaterialAgent | None, settings):
        self.agent = agent
        self.settings = settings
        self.histories: dict[str, list] = defaultdict(list)  # context_id → API 형식 대화 기록
        self.locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    def _run(self, messages: list, question: str) -> TurnResult:
        if self.agent is None:
            time.sleep(MOCK_DELAY_SEC)  # LLM 처리 시간 흉내
            messages += [{"role": "user", "content": question}, {"role": "assistant", "content": "(모의)"}]
            turn = len(messages) // 2
            return TurnResult(text=f"[모의 응답 · 대화 {turn}번째] 받은 질문: {question[:200]}",
                              max_tool_calls=self.settings.max_tool_calls)
        return self.agent.run_turn(messages, question)

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        await updater.update_status(TaskState.TASK_STATE_WORKING)

        question = context.get_user_input().strip()
        if not question:
            await updater.failed(new_text_message("질문이 비어 있습니다.", context_id=task.context_id, task_id=task.id))
            return

        async with self.locks[task.context_id]:  # 같은 대화의 발화는 차례로 처리
            r = await asyncio.to_thread(self._run, self.histories[task.context_id], question)

        if not r.text:  # API 오류 — run_turn 이 기록을 되돌려 두었다
            await updater.failed(new_text_message(r.warning or "응답이 비어 있습니다.",
                                                  context_id=task.context_id, task_id=task.id))
            return

        warning = r.warning or (f"도구 실행 한도({r.max_tool_calls}회)에 도달했습니다." if r.limit_hit else None)
        trace = {
            "mock": self.agent is None,
            "tool_calls": r.tool_calls,
            "max_tool_calls": r.max_tool_calls,
            "warning": warning,
            "tools": [{"name": l.name, "input": l.input, "is_error": l.is_error, "skipped": l.skipped} for l in r.logs],
        }
        trace = json.loads(json.dumps(trace, ensure_ascii=False, default=str))
        text = r.text + (f"\n\n⚠ {warning}" if warning else "")
        summary = r.text.strip().splitlines()[0].replace("**", "").strip()[:80]  # 결론 한 줄 — 사무공간 말풍선용
        await updater.add_artifact(parts=[new_text_part(text), new_data_part(trace)], name="material_answer",
                                   metadata={"summary": summary})
        await updater.complete()

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


SKILL = AgentSkill(
    id="material.check",
    name="자재 기준 생산 가능 여부 확인",
    description="제품코드·수량·생산 날짜(필요하면 시작 시각)를 받아 BOM·현재 재고·입고 예정을 조회하고 자재 기준 생산 가능 여부를 답한다. "
                "빠진 조건은 되묻는다. 설비·인력은 판단하지 않는다.",
    tags=["material", "inventory", "bom", "production", "자재"],
    examples=["내일 오전 9시에 P-100을 10개 생산할 수 있어?", "센서 B는 지금 몇 개 있어?"],
    input_modes=["text/plain"],
    output_modes=["text/plain", "application/json"],
)

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true", help="API 호출 없이 고정 응답")
    ap.add_argument("--fail-inbound", action="store_true", help="입고 조회 실패 모의")
    a = ap.parse_args()
    agent, settings = build_agent(a.fail_inbound, a.mock)
    card = make_card(ENTRY, "BOM·재고·입고 예정으로 생산 가능 여부를 답하는 에이전트 (02_자재대응_Agent 래퍼)", [SKILL])
    serve(card, MaterialExecutor(agent, settings), ENTRY["port"])
