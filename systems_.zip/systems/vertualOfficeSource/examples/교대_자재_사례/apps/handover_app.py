"""01_인수인계_보고서 의 원래 Tkinter 화면을 띄우되, 보고서 작성·수정을 사무공간에도 알린다.

    .venv\\Scripts\\python.exe apps\\handover_app.py

01 폴더의 파일은 고치지 않는다. app.py 가 import 하기 전에 core.client 의 두 함수를
알림을 끼운 함수로 바꿔 두고, 그다음 app.py 의 main() 을 그대로 실행한다.
"""
from office_notify import Notifier, attach_project, roster_entry

attach_project(roster_entry("handover"))

import core.client as client  # noqa: E402  (01 프로젝트 코드)

office = Notifier("handover", "Tkinter")
_make_report, _revise_report = client.make_report, client.revise_report


def _summary(report) -> str:
    return f"{report.category} · {report.resolution} · 확인할 일 {len(report.next_checks)}건"


def make_report(memo, shift="", writer="", target=""):
    tid = office.started(memo)
    try:
        report = _make_report(memo, shift, writer, target)
    except Exception as e:
        office.failed(tid, str(e))
        raise
    office.done(tid, _summary(report))
    return report


def revise_report(memo, report, feedback):
    tid = office.started("수정 요청: " + feedback)
    try:
        revised = _revise_report(memo, report, feedback)
    except Exception as e:
        office.failed(tid, str(e))
        raise
    office.done(tid, "수정본 · " + _summary(revised))
    return revised


client.make_report, client.revise_report = make_report, revise_report  # app.py 의 from-import 보다 먼저

import app  # noqa: E402  ← 01 의 app.py. 위에서 바꾼 함수를 가져간다

if __name__ == "__main__":
    assert app.make_report is make_report and app.revise_report is revise_report
    office.online()
    office.heartbeat_forever()
    app.main()
