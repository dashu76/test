# A2A 연결 — 기존 두 프로젝트를 그대로 둔 채 잇기

`01_인수인계_보고서`와 `02_자재대응_Agent`는 **고치지 않습니다.** 이 폴더의 래퍼가 두 폴더의 핵심 코드를 import 해서
각각 표준 A2A 서버(`a2a-sdk` 1.1.2, JSON-RPC, Agent Card)로 띄웁니다. 기존 Tkinter·Streamlit 화면도 그대로 쓸 수 있습니다.

```
a2a/
├─ agents.json               에이전트 명부 (id·이름·구역·포트·프로젝트 폴더·래퍼)
├─ wrappers/
│   ├─ common.py             명부 읽기, 프로젝트 경로 연결, Agent Card, 서버 실행
│   ├─ handover_server.py    :9101  skill handover.report  ← 01 의 make_report·validate·save
│   └─ material_server.py    :9102  skill material.check   ← 02 의 MaterialAgent.run_turn
├─ run_agents.py             명부의 에이전트를 각각 별도 프로세스로 띄움
└─ test_client.py            발견 → 인수인계 위임 → 자재대응 위임 → 이어서 묻기
```

## 설치 (처음 한 번)

```powershell
cd a2a
uv venv --python 3.12 .venv
uv pip install --python .venv\Scripts\python.exe "a2a-sdk[http-server]==1.1.2" fastapi anthropic pydantic uvicorn httpx
```

API 키는 각 프로젝트의 방식 그대로 읽습니다. `ANTHROPIC_API_KEY` 환경 변수가 먼저이고, 없으면 각 폴더의 `claudeapi.txt`를 읽습니다.

## 실행

터미널 1 — 서버

```powershell
.venv\Scripts\python.exe run_agents.py --mock   # API 호출 없음 (연결 확인용)
.venv\Scripts\python.exe run_agents.py          # 실제 Claude 호출 (비용 발생)
```

터미널 2 — 클라이언트

```powershell
.venv\Scripts\python.exe test_client.py --cards-only
.venv\Scripts\python.exe test_client.py --follow "오늘 오후 1시에 시작해"
.venv\Scripts\python.exe test_client.py --memo ..\01_인수인계_보고서\참고\작업메모_08_전산수량불일치.txt
```

## 시나리오 (기본값)

1. **발견** `agents.json`의 URL에서 `/.well-known/agent-card.json`을 읽어 skill을 확인합니다.
2. **위임 1** `작업메모_12_작업지시변경.txt`(P-100 수량 100→80개, 완성 60개)를 DataPart `{"memo", "shift"}`로 인수인계 에이전트에 보냅니다.
   보고서가 Artifact(DataPart JSON + TextPart)로 돌아옵니다.
3. **위임 2** 보고서의 대상·발생한 일·현재 상태·확인할 일만 골라 자재대응 에이전트에 질문합니다.
4. **이어서** `--follow`로 준 말을 같은 `context_id`로 보냅니다. 자재대응 에이전트는 context마다 대화 기록을 따로 보관합니다.

두 에이전트는 서로를 모릅니다. 둘을 잇는 것은 `test_client.py`(오케스트레이터)뿐입니다.

## 모드별 동작

| | 인수인계 | 자재대응 |
|---|---|---|
| `--mock` | 같은 메모로 `reports/`에 이미 저장된 보고서를 돌려줌. 없으면 `TASK_STATE_FAILED` | 받은 질문을 되돌려주는 고정 응답. 대화 차수는 context별로 셈 |
| 실제 | Claude로 보고서 생성 → 자동 검증 → `reports/`에 저장(`meta.source = "A2A"`). 기존 앱의 [보고서 보기]에도 나옴 | Claude tool use로 BOM·재고·입고 조회. 도구 실행 내역은 DataPart로 |
| 오류 | `HandoverError` 메시지를 담아 `TASK_STATE_FAILED` | API 오류는 `TASK_STATE_FAILED`, 대화 기록은 되돌림 |

`material_server.py --fail-inbound`로 Streamlit의 "입고 조회 실패 모의" 토글과 같은 상황을 만들 수 있습니다.

## 2단계 — 사무공간 연결

```
office/agentUI.html   v3 배포판 화면 (virtualCompany_v3/office_v3/build_open.py 로 만든 것, 원본 v3 는 수정하지 않음)
office/events.jsonl   허브가 보낸 이벤트 기록 (화면의 '기록 파일 재생' 소스로 다시 볼 수 있음)
office_hub.py         관찰 허브 :9900 — Agent Card·ListTasks 를 1초마다 조회해 이벤트(SSE)로 보냄
```

```powershell
.venv\Scripts\python.exe run_agents.py --mock --office   # 에이전트 + 허브
# 브라우저로 http://127.0.0.1:9900/ → 사무공간이 자동으로 열리고 에이전트가 자리에 앉는다
.venv\Scripts\python.exe test_client.py --follow "오늘 오후 1시에 시작해"   # 다른 터미널
```

화면 다시 만들기 (렌더 결과가 바뀌었을 때만, Pillow 필요):

```powershell
cd C:\WorkAI\wikiDocs_v2\virtualCompany\vertualCompany_v3\office_v3
$env:PYTHONDONTWRITEBYTECODE=1; python build_open.py --out "<이 폴더>\office\agentUI.html"
```

| A2A 에서 본 것 | 사무공간 이벤트 | 화면 |
|---|---|---|
| Agent Card 응답 시작 | `agent.online` (이름·구역·skills) | 자리에 앉음 |
| Agent Card 응답 계속 | `agent.heartbeat` (2초) | 대기(노랑) |
| Agent Card 2회 연속 실패 | `agent.offline` | 응답 없음(회색) |
| 새 Task (`SUBMITTED`/`WORKING`) | `task.started` + `agent.say` | 작업 중(초록) + 요청 말풍선 |
| `COMPLETED` | `task.done` (Artifact `metadata.summary`) | 결과 말풍선 |
| `FAILED`·`REJECTED`·`CANCELED` | `task.failed` | 실패 누적 → 경보(빨강) |
| `INPUT_REQUIRED`·`AUTH_REQUIRED` | `agent.alert` / 벗어나면 `agent.resolved` | 경보 |

오케스트레이터(`test_client.py`)는 서버가 아니라서 관찰할 수 없으므로 자기 활동을 `POST /events` 로 직접 알린다.

## 원래 화면도 사무공간에 — 런처 (`apps/`)

원래 방법(`python app.py`, `streamlit run app.py`)으로 띄운 화면은 A2A 를 거치지 않으므로 사무공간에 안 보인다.
런처로 띄우면 같은 화면이 그대로 뜨고, 작업 시작·완료가 같은 에이전트 자리에 `[Tkinter]`/`[Streamlit]` 표시로 나타난다.

```powershell
.venv\Scripts\python.exe apps\handover_app.py                                      # 01 Tkinter
.venv\Scripts\python.exe -m streamlit run apps\material_app.py --server.port 8501   # 02 Streamlit
```

런처는 핵심 함수(`make_report`·`revise_report`·`MaterialAgent.run_turn`) 앞뒤에 알림만 끼우고 원래 `app.py` 를 실행한다. 프로젝트 파일은 그대로.
matplotlib·streamlit 은 `a2a/.venv` 에만 설치했다.

## 에이전트 추가·삭제

- **추가** `wrappers/`에 래퍼를 하나 만들고(`common.py`의 `roster_entry`·`attach_project`·`make_card`·`serve` 사용) `agents.json`에 항목을 넣습니다.
- **삭제** `agents.json`에서 항목을 지웁니다. 프로젝트 폴더는 건드리지 않습니다.

## 알려진 한계

- 자재대응 에이전트가 되묻는 경우(시작 시각 등)도 Task는 `COMPLETED`로 끝나고, 답은 같은 `context_id`로 새 Task를 보내 이어 갑니다.
  `INPUT_REQUIRED` 상태로 표시하지는 않습니다(되묻기인지 판단하려면 02 프로젝트의 결과 구조를 바꿔야 해서 보류).
- Task 저장소는 메모리(`InMemoryTaskStore`)이고, 자재대응의 대화 기록도 서버를 다시 띄우면 사라집니다.
- 인증은 없습니다. `127.0.0.1`에서만 받습니다.
