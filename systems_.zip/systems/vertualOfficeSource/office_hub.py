"""사무공간 관찰 허브 — A2A 에이전트를 밖에서 관찰해 v3 사무공간(agentUI.html)에 이벤트로 흘린다.

    python office_hub.py            → http://127.0.0.1:9900  (브라우저로 열면 사무공간)

에이전트 쪽에는 보고 코드가 하나도 없다. 허브는 A2A 표준 두 가지만 쓴다.
  1. Agent Card  GET /.well-known/agent-card.json  → 출근(agent.online)·하트비트·퇴근(agent.offline)
  2. ListTasks   JSON-RPC ListTasks                → 작업 시작·완료·실패·입력 대기
그래서 다른 회사의 A2A 에이전트도 agents.json 에 URL 한 줄만 넣으면 자리에 앉는다.

허브가 여는 문
  GET  /              사무공간으로 이동 (SSE·자동 시작 인자를 붙여서)
  GET  /agentUI.html  v3 배포판 화면 (build_open.py 로 만든 것)
  GET  /catalog.json  agents.json → 화면의 에이전트 목록
  GET  /stream        이벤트 스트림 (SSE). 접속하면 지금까지의 이벤트부터 보낸다
  POST /events        클라이언트(오케스트레이터)가 자기 이벤트를 넣는 곳
  GET  /health
이벤트는 office/events.jsonl 에도 쌓인다 — 화면의 '기록 파일 재생' 소스로 다시 볼 수 있다.
"""
import asyncio
import json
import sys
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlencode

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response, StreamingResponse

from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, get_text_parts
from a2a.types.a2a_pb2 import ListTasksRequest, Role, TaskState

A2A_DIR = Path(__file__).resolve().parent
OFFICE_DIR = A2A_DIR / "office"
EVENT_LOG = OFFICE_DIR / "events.jsonl"
PORT = 9900
POLL_SEC = 1.0          # 카드·작업 조회 간격
HB_EVERY = 2            # 몇 번 조회마다 하트비트를 보낼지
OFFLINE_AFTER = 2       # 카드 조회가 연속 몇 번 실패하면 퇴근으로 볼지
BACKLOG_MAX = 2000

# 화면 설정의 기본값. agents.json 의 "office" 로 바꾼다.
#   preset  studio(2칸) · small(6칸: trading·ops) · dept(12칸: trading·content·ops) · hq(20칸: exec·trading·content·ops)
#   labels  구역 id → 화면에 보일 이름
#   clients 서버가 아니어서 관찰할 수 없고 POST /events 로 스스로 알리는 참여자 (오케스트레이터 등)
DEFAULT_OFFICE = {
    "preset": "small",
    "labels": {"trading": "작업", "ops": "운영", "exec": "조정", "content": "지원"},
    "clients": [{"key": "client:orchestrator", "name": "오케스트레이터", "zone": "exec", "role": "client"}],
}

BAD = {"FAILED", "REJECTED", "CANCELED"}
WAITING = {"INPUT_REQUIRED", "AUTH_REQUIRED"}


def _load() -> dict:
    return json.loads((A2A_DIR / "agents.json").read_text(encoding="utf-8"))


def office_cfg() -> dict:
    return {**DEFAULT_OFFICE, **_load().get("office", {})}


def agent_url(a: dict) -> str:
    """명부 항목의 A2A 주소. url 이 있으면 그대로(외부 에이전트), 없으면 127.0.0.1:port (래퍼)."""
    return (a.get("url") or f"http://127.0.0.1:{a['port']}").rstrip("/")


def roster() -> list[dict]:
    return [{**a, "url": agent_url(a)} for a in _load()["agents"]]


def snippet(text: str, n: int = 48) -> str:
    for line in (text or "").splitlines():
        line = line.replace("**", "").strip(" #│=-*\t")
        if line:
            return line if len(line) <= n else line[:n - 1] + "…"
    return ""


# ── 이벤트 버스 ─────────────────────────────────────────────────
class Bus:
    def __init__(self):
        self.backlog: list[dict] = []
        self.subs: set[asyncio.Queue] = set()
        OFFICE_DIR.mkdir(exist_ok=True)

    def publish(self, agent_id: str, type_: str, payload: dict | None = None, task_id: str = "") -> dict:
        ev = {"v": 1, "eventId": uuid.uuid4().hex[:12], "ts": int(time.time() * 1000),
              "agentId": agent_id, "type": type_, "taskId": task_id, "payload": payload or {}}
        return self.put(ev)

    def put(self, ev: dict) -> dict:
        ev.setdefault("v", 1)
        ev.setdefault("eventId", uuid.uuid4().hex[:12])
        ev.setdefault("ts", int(time.time() * 1000))
        self.backlog = (self.backlog + [ev])[-BACKLOG_MAX:]
        with EVENT_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")
        for q in list(self.subs):
            q.put_nowait(ev)
        if ev["type"] != "agent.heartbeat":
            p = ev.get("payload") or {}
            print(f"  {ev['type']:<15} {ev['agentId']:<24} {p.get('text') or p.get('name') or p.get('result') or p.get('reason') or ''}", flush=True)
        return ev


bus = Bus()


# ── 관찰자: 에이전트 하나 ───────────────────────────────────────
class Watcher:
    def __init__(self, entry: dict, http: httpx.AsyncClient):
        self.e, self.http = entry, http
        self.key = entry["url"]          # 화면에서 에이전트를 구분하는 키 = A2A 주소
        self.online = False
        self.misses = 0
        self.ticks = 0
        self.client = None
        self.states: dict[str, str] = {}  # taskId → 마지막으로 본 상태
        self.baseline = False             # 허브가 뜨기 전에 끝난 작업은 다시 알리지 않는다

    async def run(self):
        while True:
            try:
                await self.poll()
            except Exception as e:  # 관찰이 실패해도 허브는 계속 돈다
                print(f"  ! {self.e['id']} 관찰 오류: {type(e).__name__}: {e}", flush=True)
            await asyncio.sleep(POLL_SEC)

    async def poll(self):
        self.ticks += 1
        try:
            r = await self.http.get(f"{self.key}/.well-known/agent-card.json", timeout=2)
            r.raise_for_status()
            card = r.json()
        except (httpx.HTTPError, ValueError):
            self.misses += 1
            if self.online and self.misses >= OFFLINE_AFTER:
                self.online, self.client, self.baseline = False, None, False
                bus.publish(self.key, "agent.offline", {"reason": "Agent Card 응답 없음"})
            return

        self.misses = 0
        if not self.online:
            self.online = True
            bus.publish(self.key, "agent.online", {
                "name": card.get("name", self.e["name"]), "zone": self.e.get("zone"), "role": "server",
                "skills": [s.get("name") for s in card.get("skills", [])], "url": self.key})
            self.client = await create_client(self.key, client_config=ClientConfig(httpx_client=self.http))
        elif self.ticks % HB_EVERY == 0:
            bus.publish(self.key, "agent.heartbeat")

        resp = await self.client.list_tasks(ListTasksRequest(page_size=100, include_artifacts=True))
        # 목록은 최신순이다. 한 번의 조회에 여러 건이 잡혀도 일어난 순서대로 알리도록 상태 시각으로 정렬한다
        for t in sorted(resp.tasks, key=lambda t: t.status.timestamp.ToMilliseconds()):
            self.observe(t)
        self.baseline = True

    def observe(self, t):
        state = TaskState.Name(t.status.state).replace("TASK_STATE_", "")
        prev = self.states.get(t.id)
        if prev == state:
            return
        self.states[t.id] = state
        if not self.baseline and state in BAD | {"COMPLETED"}:
            return  # 허브 기동 전에 끝난 작업

        if prev is None or prev == "SUBMITTED":
            ask = request_text(t)
            bus.publish(self.key, "task.started", {"taskId": t.id, "name": snippet(ask, 28) or "작업"}, t.id)
            if ask:
                bus.publish(self.key, "agent.say", {"text": "← " + snippet(ask)})
        if prev in WAITING and state not in WAITING:
            bus.publish(self.key, "agent.resolved")

        if state == "COMPLETED":
            bus.publish(self.key, "task.done", {"taskId": t.id, "result": result_summary(t)}, t.id)
        elif state in BAD:
            reason = snippet(" ".join(get_text_parts(t.status.message.parts))) or state
            bus.publish(self.key, "task.failed", {"taskId": t.id, "reason": reason}, t.id)
        elif state in WAITING:
            bus.publish(self.key, "agent.alert", {"text": ("인증 필요" if state == "AUTH_REQUIRED" else "입력 대기")})


def request_text(t) -> str:
    """Task 기록에서 처음 받은 사용자 메시지의 내용."""
    for m in t.history:
        if m.role == Role.ROLE_USER:
            texts = get_text_parts(m.parts)
            if texts:
                return texts[0]
            for d in get_data_parts(m.parts):
                if isinstance(d, dict):
                    return str(d.get("memo") or d.get("text") or d.get("question") or "")
    return ""


def result_summary(t) -> str:
    """결과물의 metadata.summary 를 먼저 쓰고, 없으면 텍스트 첫 줄."""
    for a in t.artifacts:
        if "summary" in a.metadata:
            return snippet(str(a.metadata["summary"]), 60)
    for a in t.artifacts:
        s = snippet(" \n".join(get_text_parts(a.parts)), 60)
        if s:
            return s
    return "완료"


# ── HTTP ───────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(_app):
    """명부(agents.json)의 에이전트마다 관찰자를 하나씩 돌린다."""
    async with httpx.AsyncClient(timeout=httpx.Timeout(10, connect=2)) as http:
        tasks = [asyncio.create_task(Watcher(entry, http).run()) for entry in roster()]
        yield
        for t in tasks:
            t.cancel()


app = FastAPI(title="A2A office hub", lifespan=lifespan)


@app.get("/")
def index():
    cfg = office_cfg()
    q = {"source": "sse", "hub": f"http://127.0.0.1:{PORT}", "autostart": "1", "preset": cfg["preset"],
         "catalog": "/catalog.json", "labels": ",".join(f"{k}:{v}" for k, v in cfg["labels"].items())}
    return RedirectResponse("/agentUI.html?" + urlencode(q, safe=":/,"))


@app.get("/agentUI.html")
def page():
    f = OFFICE_DIR / "agentUI.html"
    if not f.exists():
        return JSONResponse({"error": "office/agentUI.html 이 없습니다. README 의 '화면 만들기'를 실행하세요."}, 404)
    return FileResponse(f, media_type="text/html; charset=utf-8")


@app.get("/catalog.json")
def catalog():
    items = [{"name": a["name"], "url": a["url"], "zone": a.get("zone", "ops"), "role": "server"} for a in roster()]
    return items + office_cfg()["clients"]


@app.get("/stream")
async def stream(request: Request):
    q: asyncio.Queue = asyncio.Queue()
    backlog = list(bus.backlog)
    bus.subs.add(q)

    async def gen():
        try:
            for ev in backlog:
                yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
            while not await request.is_disconnected():
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keep-alive\n\n"
        finally:
            bus.subs.discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "Access-Control-Allow-Origin": "*"})


@app.post("/events")
async def events(request: Request):
    body = await request.json()
    for ev in body if isinstance(body, list) else [body]:
        if isinstance(ev, dict) and ev.get("type") and ev.get("agentId"):
            bus.put(ev)
    return {"ok": True}


@app.get("/favicon.ico")
def favicon():
    return Response(status_code=204)  # 브라우저 콘솔의 404 를 없앤다


@app.get("/health")
def health():
    return {"ok": True, "agents": [a["id"] for a in roster()], "subscribers": len(bus.subs), "events": len(bus.backlog)}


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    print(f"사무공간 허브 — http://127.0.0.1:{PORT}/  (관찰 대상: {', '.join(a['id'] for a in roster())})", flush=True)
    uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="warning")
