@echo off
rem Start the five company servers, each in its own window.
rem Works from any directory (paths are relative to this file).
rem To send events to obs-hub, set A2A_OBS_URL before running; the windows inherit it.

start "klogistics-carrier" /D "%~dp0klogistics-carrier" cmd /k uv run python -m klogistics_carrier
start "carrier-a"          /D "%~dp0carrier-a"          cmd /k uv run python -m carrier_a
start "carrier-b"          /D "%~dp0carrier-b"          cmd /k uv run python -m carrier_b
start "carrier-c"          /D "%~dp0carrier-c"          cmd /k uv run python -m carrier_c
start "kpw-buyer"          /D "%~dp0kpw-buyer"          cmd /k uv run python -m kpw_buyer
