import pytest

from logistics_contract import (
    Booking,
    BookingRejected,
    BookingRequest,
    CancelBookingRequest,
    DeliveryNotFound,
    DeliveryQuery,
    DeliveryStatus,
    Quote,
    QuoteDeclined,
    QuoteRequest,
    ShipmentStatus,
)

from carrier_a.skills import BusinessKeyConflict

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")


def quote(service, **overrides) -> Quote:
    result = service.quote(QuoteRequest(**{**RFQ, **overrides}))
    assert isinstance(result, Quote)
    return result


def book(service, q: Quote, key="K정밀웍스:RFQ-1:book:물류사 A:v1", **overrides):
    return service.book(BookingRequest(business_key=key, rfq_id=q.rfq_id, quote_id=q.quote_id, **overrides))


# ---------- quote ----------

def test_quote(service):
    q = quote(service)
    assert (q.price_krw, q.eta_days, q.carrier) == (174000, 3, "물류사 A")
    assert q.quote_id == "A-Q-0001"


def test_same_rfq_returns_same_quote(service):
    assert quote(service) == quote(service)


def test_same_rfq_from_newer_minor_is_same_request(service):
    first = quote(service)
    again = service.quote(QuoteRequest(**RFQ, schema_version="1.1"))
    assert again == first


def test_same_rfq_with_different_content_conflicts(service):
    quote(service)
    with pytest.raises(BusinessKeyConflict):
        service.quote(QuoteRequest(**{**RFQ, "weight_kg": 500}))


def test_overweight_declined_and_remembered(service):
    req = QuoteRequest(**{**RFQ, "rfq_id": "RFQ-H", "weight_kg": 9000})
    first = service.quote(req)
    assert isinstance(first, QuoteDeclined)
    assert service.quote(req) == first


# ---------- book-shipment ----------

def test_book_accepted(service):
    b = book(service, quote(service))
    assert isinstance(b, Booking) and b.status == "accepted"
    assert b.tracking_no == "A-T-100001"


def test_book_resend_returns_same_booking(service):
    q = quote(service)
    assert book(service, q) == book(service, q)


def test_book_same_key_different_content_conflicts(service):
    q = quote(service)
    book(service, q)
    with pytest.raises(BusinessKeyConflict):
        book(service, q, event_callback_url="http://127.0.0.1:5010")


def test_book_expired_quote_rejected(service, clock):
    q = quote(service)
    clock.advance(hours=25)
    b = book(service, q)
    assert isinstance(b, BookingRejected) and "유효기간" in b.reason


def test_book_unknown_quote_rejected(service):
    q = quote(service)
    b = service.book(BookingRequest(business_key="k", rfq_id="RFQ-1", quote_id="A-Q-9999"))
    assert isinstance(b, BookingRejected)


def test_quote_cannot_be_booked_twice(service):
    q = quote(service)
    book(service, q)
    b = book(service, q, key="다른 업무키")
    assert isinstance(b, BookingRejected) and "이미" in b.reason


def test_callback_host_must_be_allowed(service):
    b = book(service, quote(service), event_callback_url="http://evil.example/")
    assert isinstance(b, BookingRejected) and "알림 주소" in b.reason


# ---------- cancel-booking / check-delivery ----------

def test_cancel_before_pickup(service):
    b = book(service, quote(service))
    r = service.cancel(CancelBookingRequest(business_key="c1", booking_id=b.booking_id))
    assert r.status == "cancelled"
    s = service.check_delivery(DeliveryQuery(tracking_no=b.tracking_no))
    assert s.shipment_status == ShipmentStatus.CANCELLED


def test_cancel_after_pickup_rejected(service):
    b = book(service, quote(service))
    service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP, "창원 집하")
    r = service.cancel(CancelBookingRequest(business_key="c1", booking_id=b.booking_id))
    assert r.status == "rejected" and "집하" in r.reason


def test_cancel_resend_returns_same_result(service):
    b = book(service, quote(service))
    req = CancelBookingRequest(business_key="c1", booking_id=b.booking_id)
    assert service.cancel(req) == service.cancel(req)


def test_check_delivery(service):
    b = book(service, quote(service))
    service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP, "창원 집하")
    service.advance_shipment(b.tracking_no, ShipmentStatus.IN_TRANSIT, "대전 허브 통과")
    s = service.check_delivery(DeliveryQuery(tracking_no=b.tracking_no))
    assert isinstance(s, DeliveryStatus)
    assert (s.shipment_status, s.seq, s.note) == (ShipmentStatus.IN_TRANSIT, 3, "대전 허브 통과")
    assert str(s.eta) == "2026-10-18"


def test_check_delivery_not_found(service):
    assert isinstance(service.check_delivery(DeliveryQuery(tracking_no="X")), DeliveryNotFound)


def test_state_survives_restart(settings, clock, service):
    """S-30: 재시작해도 DB에서 그대로 이어간다."""
    from carrier_a.domain import load_pricing
    from carrier_a.skills import CarrierService
    from carrier_a.store import Store

    q = quote(service)
    restarted = CarrierService(settings, Store(settings.db_path), load_pricing(settings.pricing_file), clock)
    assert restarted.quote(QuoteRequest(**RFQ)) == q
