"""테스트용 가짜 구매사 A2A 서버 (receive-shipment-event만). 실제 구매사 코드는 쓰지 않는다."""

import socket
import threading
import time
from dataclasses import dataclass, field

import uvicorn
from fastapi import FastAPI
from a2a.helpers.proto_helpers import get_data_parts, new_data_part, new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill, Part, TaskState
from logistics_contract import CONTRACT_TAG, EventAck, ShipmentEvent, parse_request, to_data


@dataclass
class BuyerBehavior:
    mode: str = "ok"                      # ok | reject
    events: list = field(default_factory=list)


class FakeBuyerExecutor(AgentExecutor):
    def __init__(self, b: BuyerBehavior) -> None:
        self.b = b

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        up = TaskUpdater(event_queue, task.id, task.context_id)
        event = parse_request(get_data_parts(context.message.parts)[0])
        assert isinstance(event, ShipmentEvent)
        if self.b.mode == "reject":
            await up.update_status(TaskState.TASK_STATE_FAILED,
                                   message=up.new_agent_message(parts=[Part(text="우리 회사 발주가 아닌 운송장")]))
            return
        duplicate = any(e.event_id == event.event_id for e in self.b.events)
        self.b.events.append(event)
        ack = EventAck(event_id=event.event_id, duplicate=duplicate)
        await up.add_artifact(parts=[new_data_part(to_data(ack))], name="event-ack")
        await up.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context, event_queue) -> None:
        raise NotImplementedError


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def build_fake_buyer(b: BuyerBehavior, port: int) -> FastAPI:
    card = AgentCard(
        name="가짜 구매사", description="테스트용", version="0.0.0",
        default_input_modes=["application/json"], default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[AgentInterface(url=f"http://127.0.0.1:{port}/", protocol_binding="JSONRPC",
                                             protocol_version="1.0")],
        skills=[AgentSkill(id="receive-shipment-event", name="receive-shipment-event", description="알림 수신",
                           tags=[CONTRACT_TAG])],
    )
    handler = DefaultRequestHandler(agent_executor=FakeBuyerExecutor(b), task_store=InMemoryTaskStore(),
                                    agent_card=card)
    app = FastAPI()
    add_a2a_routes_to_fastapi(app, agent_card_routes=create_agent_card_routes(card),
                              jsonrpc_routes=create_jsonrpc_routes(handler, rpc_url="/"))
    return app


class ThreadServer:
    def __init__(self, app, port: int) -> None:
        self.server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
        self.thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> "ThreadServer":
        self.thread.start()
        deadline = time.time() + 10
        while not self.server.started:
            if time.time() > deadline:
                raise RuntimeError("서버가 뜨지 않았다")
            time.sleep(0.02)
        return self

    def stop(self) -> None:
        self.server.should_exit = True
        self.thread.join(timeout=5)
