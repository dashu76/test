"""관찰 이벤트 (S-25). 허브가 없으면 아무 일도 없고, 허브가 꺼져 있어도 업무는 그대로 된다."""

import asyncio
import dataclasses
import time

import pytest

from a2a.types.a2a_pb2 import TaskState
from logistics_contract import BookingRequest, QuoteRequest, ShipmentStatus
from logistics_contract.examples import example

from carrier_a import obs_hook
from carrier_a.app import build_app
from carrier_a.outbox import Notifier, Outbox
from conftest import make_settings
from fake_buyer import BuyerBehavior, ThreadServer, build_fake_buyer, free_port
from fake_hub import HubLog, build_fake_hub
from test_a2a_roundtrip import send

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")


@pytest.fixture(autouse=True)
def reset_hook():
    yield
    obs_hook.stop(timeout_s=0.5)


@pytest.fixture
def hub():
    log = HubLog()
    port = free_port()
    server = ThreadServer(build_fake_hub(log), port).start()
    log.url = f"http://127.0.0.1:{port}"
    yield log
    server.stop()


def run_carrier(tmp_path, obs_url: str) -> tuple:
    port = free_port()
    settings = dataclasses.replace(make_settings(tmp_path, port=port), obs_url=obs_url, outbox_interval_s=0)
    return settings, ThreadServer(build_app(settings), port).start()


def test_without_hub_nothing_is_sent():
    obs_hook.start("carrier-a", "http://127.0.0.1:5021", "")
    obs_hook.emit("agent.started")
    assert not obs_hook.enabled() and obs_hook._queue.unfinished_tasks == 0


def test_server_events_reach_hub(tmp_path, hub):
    settings, server = run_carrier(tmp_path, hub.url)
    try:
        state, _, _ = asyncio.run(send(settings.public_url, example("quote-request")))
        assert state == TaskState.TASK_STATE_COMPLETED
        hub.wait_for(lambda h: any(e["payload"].get("to") == "TASK_STATE_COMPLETED" for e in h.of("task.state")))
    finally:
        server.stop()
    hub.wait_for(lambda h: "agent.stopped" in h.types())

    started = hub.of("agent.started")[0]
    assert started["agentId"] == settings.public_url and started["process"] == "carrier-a"
    assert started["payload"]["name"] == "물류사 A" and "quote" in started["payload"]["skills"]
    received = hub.of("task.received")[0]
    assert received["side"] == "server" and received["payload"]["text"].startswith("quote-request")
    states = [e for e in hub.of("task.state") if e["taskId"] == received["taskId"]]
    assert [e["payload"]["to"] for e in states] == ["TASK_STATE_WORKING", "TASK_STATE_COMPLETED"]
    assert states[-1]["payload"]["result"].startswith("quote quoted")
    assert len({e["eventId"] for e in hub.events}) == len(hub.events)


def test_failed_task_reports_reason(tmp_path, hub):
    settings, server = run_carrier(tmp_path, hub.url)
    try:
        bad = {**example("quote-request"), "schema_version": "2.0"}
        assert asyncio.run(send(settings.public_url, bad))[0] == TaskState.TASK_STATE_FAILED
        hub.wait_for(lambda h: any(e["payload"].get("to") == "TASK_STATE_FAILED" for e in h.of("task.state")))
    finally:
        server.stop()
    failed = [e for e in hub.of("task.state") if e["payload"]["to"] == "TASK_STATE_FAILED"][0]
    assert "계약 버전" in failed["payload"]["result"]


def test_s25_hub_down_business_continues(tmp_path):
    settings, server = run_carrier(tmp_path, f"http://127.0.0.1:{free_port()}")   # 아무도 듣지 않는 주소
    try:
        started = time.monotonic()
        for _ in range(3):
            state, results, _ = asyncio.run(send(settings.public_url, example("quote-request")))
            assert state == TaskState.TASK_STATE_COMPLETED and results
        assert time.monotonic() - started < 10   # 허브를 기다리지 않는다
    finally:
        server.stop()


def test_outbox_requests_reach_hub(service, clock, hub):
    obs_hook.start("carrier-a", "http://127.0.0.1:5021", hub.url)
    behavior = BuyerBehavior()
    buyer_port = free_port()
    buyer_url = f"http://127.0.0.1:{buyer_port}"
    outbox = Outbox(service.store, Notifier(timeout_s=1.0), clock, max_attempts=3)
    q = service.quote(QuoteRequest(**RFQ))
    b = service.book(BookingRequest(business_key="k1", rfq_id="RFQ-1", quote_id=q.quote_id,
                                    event_callback_url=buyer_url))

    assert asyncio.run(outbox.dispatch_once())["retry"] == 1      # 구매사 꺼짐
    buyer = ThreadServer(build_fake_buyer(behavior, buyer_port), buyer_port).start()
    try:
        service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP)
        clock.advance(seconds=5)
        assert asyncio.run(outbox.dispatch_once())["sent"] == 2
    finally:
        buyer.stop()
    hub.wait_for(lambda h: len(h.of("outbox.sent")) == 2)

    assert hub.of("card.failed")[0]["payload"]["url"] == buyer_url
    assert hub.of("outbox.retry")[0]["payload"]["status"] == "accepted"
    assert len(hub.of("card.fetched")) == 1                       # 카드 조회는 결과가 바뀔 때만 알린다
    sent = hub.of("request.sent")
    done = hub.of("request.done")
    assert [e["payload"]["skill"] for e in sent] == ["receive-shipment-event"] * 2
    assert all(e["side"] == "client" and e["payload"]["to"] == buyer_url for e in sent)
    assert [e["payload"]["state"] for e in done] == ["TASK_STATE_COMPLETED"] * 2
    assert all(e["taskId"] for e in done)
    assert [e["payload"]["status"] for e in hub.of("outbox.sent")] == ["accepted", "picked_up"]
