"""인증·권한 (Part 4 Ch18 파트너 키, Ch19 권한 경계)과 설정 DB. 설계: systems/docs/security-and-db.md"""

import asyncio
import dataclasses
import uuid
from datetime import timedelta

import httpx
import pytest

from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import GetTaskRequest, Message, Role, SendMessageRequest, TaskState
from logistics_contract import BookingRequest, QuoteRequest, parse_response
from logistics_contract.examples import example

from carrier_a import admin, cli
from carrier_a.app import build_app, build_auth, build_outbox, build_service
from carrier_a.auth import LOCK_FAILS, utcnow
from conftest import make_settings
from fake_buyer import ThreadServer, free_port

PW = "pass-word-1"


class Carrier:
    def __init__(self, tmp_path, **changes) -> None:
        port = free_port()
        self.settings = dataclasses.replace(make_settings(tmp_path, port=port), outbox_interval_s=0,
                                            a2a_auth=True, staff_auth=True, **changes)
        self.service = build_service(self.settings)
        self.auth = build_auth(self.settings)
        self.server = ThreadServer(build_app(self.settings, self.service, auth_store=self.auth), port).start()
        self.url = self.settings.public_url
        for name, role in (("boss", "admin"), ("mgr", "manager"), ("op", "operator"), ("view", "viewer")):
            self.auth.add_user(name, PW, role)
        _, self.key = self.auth.issue_key("K정밀웍스", ["quote", "book-shipment", "cancel-booking", "check-delivery"])

    def login(self, name: str) -> httpx.Client:
        client = httpx.Client(base_url=self.url, timeout=10)
        r = client.post("/api/login", json={"username": name, "password": PW})
        assert r.status_code == 200, r.text
        return client


@pytest.fixture
def carrier(tmp_path):
    c = Carrier(tmp_path)
    yield c
    c.server.stop()


async def a2a(url: str, data: dict, key: str | None):
    """(최종 상태, data 결과, 상태 메시지)"""
    async with httpx.AsyncClient(headers={"X-Partner-Key": key} if key else {}) as http:
        client = await create_client(url, client_config=ClientConfig(httpx_client=http, streaming=False))
        msg = Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[new_data_part(data)])
        task = [r async for r in client.send_message(SendMessageRequest(message=msg))][-1].task
        await client.close()
    data = [v for a in task.artifacts for v in get_data_parts(a.parts)]
    return task.status.state, data, "".join(p.text for p in task.status.message.parts), task.id


# ---------- 회사 사이: 파트너 키 (Ch18) ----------

def test_card_declares_partner_key(carrier):
    card = httpx.get(f"{carrier.url}/.well-known/agent-card.json").json()   # 카드는 공개 (발견용)
    scheme = card["securitySchemes"]["partnerKey"]["apiKeySecurityScheme"]
    assert scheme["name"] == "X-Partner-Key" and scheme["location"] == "header"
    assert card["securityRequirements"] == [{"schemes": {"partnerKey": {}}}]


def test_no_key_or_wrong_key_is_rejected(carrier):
    for key in (None, "pk_wrong"):
        state, data, text, _ = asyncio.run(a2a(carrier.url, example("quote-request"), key))
        assert state == TaskState.TASK_STATE_REJECTED and data == [] and "파트너 키" in text
    assert carrier.service.quotes() == []                              # 업무는 아무것도 일어나지 않았다
    denied = [a for a in carrier.auth.audit_log() if a["action"] == "a2a.denied"]
    assert len(denied) == 2 and not denied[0]["ok"]


def test_valid_key_quote_book_and_ownership(carrier):
    state, data, _, _ = asyncio.run(a2a(carrier.url, example("quote-request"), carrier.key))
    assert state == TaskState.TASK_STATE_COMPLETED
    quote = parse_response(data[0], "quote")

    # 다른 회사 키로는 이 견적으로 발주할 수 없고, 남의 운송장은 조회되지 않는다
    _, other = carrier.auth.issue_key("다른상사", ["quote", "book-shipment", "check-delivery"])
    booking_req = {**example("booking-request"), "quote_id": quote.quote_id}
    state, data, _, _ = asyncio.run(a2a(carrier.url, {**booking_req, "business_key": "x:1"}, other))
    assert parse_response(data[0], "booking").status == "rejected"
    assert parse_response(data[0], "booking").reason == "존재하지 않는 견적"

    state, data, _, _ = asyncio.run(a2a(carrier.url, booking_req, carrier.key))
    booking = parse_response(data[0], "booking")
    assert booking.status == "accepted"
    query = {"schema_version": "1.0", "kind": "delivery-query", "tracking_no": booking.tracking_no}
    _, data, _, _ = asyncio.run(a2a(carrier.url, query, other))
    assert data[0]["status"] == "not_found"                             # 있다는 것도 알려 주지 않는다
    _, data, _, _ = asyncio.run(a2a(carrier.url, query, carrier.key))
    assert data[0]["status"] == "found"


def test_other_company_name_is_rejected(carrier):
    req = {**example("quote-request"), "buyer": "다른상사"}
    state, _, text, _ = asyncio.run(a2a(carrier.url, req, carrier.key))
    assert state == TaskState.TASK_STATE_REJECTED and "다른 회사" in text


def test_skill_outside_key_is_rejected(carrier):
    _, query_only = carrier.auth.issue_key("K정밀웍스", ["check-delivery"])
    state, _, text, _ = asyncio.run(a2a(carrier.url, example("quote-request"), query_only))
    assert state == TaskState.TASK_STATE_REJECTED and "quote" in text


def test_revoked_key_is_rejected(carrier):
    key_id = carrier.auth.partner_keys()[0]["key_id"]
    carrier.auth.revoke_key(key_id)
    state, _, _, _ = asyncio.run(a2a(carrier.url, example("quote-request"), carrier.key))
    assert state == TaskState.TASK_STATE_REJECTED


def test_get_task_needs_key(carrier):
    _, _, _, task_id = asyncio.run(a2a(carrier.url, example("quote-request"), carrier.key))
    body = {"jsonrpc": "2.0", "id": 1, "method": "GetTask", "params": {"id": task_id}}
    r = httpx.post(f"{carrier.url}/", json=body, headers={"A2A-Version": "1.0"})
    assert r.status_code == 401 and "파트너 키" in r.json()["error"]["message"]

    async def get():
        async with httpx.AsyncClient(headers={"X-Partner-Key": carrier.key}) as http:
            client = await create_client(carrier.url, client_config=ClientConfig(httpx_client=http, streaming=False))
            task = await client.get_task(GetTaskRequest(id=task_id))
            await client.close()
            return task
    assert asyncio.run(get()).status.state == TaskState.TASK_STATE_COMPLETED


def test_outbox_presents_buyer_issued_key(tmp_path):
    settings = make_settings(tmp_path)
    service, store = build_service(settings), build_auth(settings)
    store.set_outbound("http://127.0.0.1:5010", "pk_from_buyer")
    notifier = build_outbox(settings, service, store).notifier
    assert notifier.headers_for("http://127.0.0.1:5010") == {"X-Partner-Key": "pk_from_buyer"}
    assert notifier.headers_for("http://127.0.0.1:9999") == {}


# ---------- 사내: 로그인과 권한 (Ch19) ----------

def test_api_needs_login(carrier):
    assert httpx.get(f"{carrier.url}/api/quotes").status_code == 401
    assert httpx.get(f"{carrier.url}/api/stream").status_code == 401
    assert httpx.get(f"{carrier.url}/ui").status_code == 200              # 화면(로그인 폼)은 열린다
    r = httpx.post(f"{carrier.url}/api/login", json={"username": "view", "password": "틀림"})
    assert r.status_code == 401


def test_cookie_and_bearer_sessions(carrier):
    web = carrier.login("view")
    assert f"session_{carrier.settings.port}" in web.cookies and web.get("/api/quotes").status_code == 200
    me = web.get("/api/me").json()
    assert me["user"]["role"] == "viewer" and me["user"]["permissions"] == ["read"]

    token = httpx.post(f"{carrier.url}/api/login", json={"username": "op", "password": PW}).json()["token"]
    bearer = httpx.Client(base_url=carrier.url, headers={"Authorization": f"Bearer {token}"})
    assert bearer.get("/api/me").json()["user"]["username"] == "op"
    bearer.post("/api/logout")
    assert bearer.get("/api/me").status_code == 401


def test_roles_limit_actions(carrier):
    q = carrier.service.quote(QuoteRequest(rfq_id="RFQ-1", buyer="K정밀웍스", item="볼트", weight_kg=10,
                                           origin="창원", destination="평택"))
    b = carrier.service.book(BookingRequest(business_key="k1", rfq_id="RFQ-1", quote_id=q.quote_id))
    advance = {"status": "picked_up", "note": "집하"}
    viewer = carrier.login("view")
    r = viewer.post(f"/api/shipments/{b.tracking_no}/advance", json=advance)
    assert r.status_code == 403 and "배송 상태 변경" in r.json()["detail"]
    assert viewer.post("/api/outbox/dispatch").status_code == 403
    assert viewer.get("/api/users").status_code == 403
    assert carrier.login("op").post(f"/api/shipments/{b.tracking_no}/advance", json=advance).status_code == 200
    assert carrier.login("mgr").put("/api/pricing", json={"base_krw": 1}).status_code == 403

    log = carrier.auth.audit_log()
    assert any(a["action"] == "denied" and a["actor"] == "view" for a in log)
    assert any(a["action"] == "shipment.advance" and a["actor"] == "op" for a in log)


def test_login_lock_after_failures(carrier):
    for _ in range(LOCK_FAILS):
        httpx.post(f"{carrier.url}/api/login", json={"username": "op", "password": "wrong-pass"})
    r = httpx.post(f"{carrier.url}/api/login", json={"username": "op", "password": PW})
    assert r.status_code == 401 and "잠겼다" in r.json()["detail"]


def test_session_expires_and_disabled_user(carrier):
    web = carrier.login("op")
    carrier.auth.clock = lambda: utcnow() + timedelta(hours=carrier.auth.session_hours + 1)
    assert web.get("/api/me").status_code == 401
    carrier.auth.clock = utcnow

    web = carrier.login("op")
    boss = carrier.login("boss")
    assert boss.patch("/api/users/op", json={"active": False}).status_code == 200
    assert web.get("/api/me").status_code == 401                           # 사용 중지 → 세션도 끝
    assert httpx.post(f"{carrier.url}/api/login", json={"username": "op", "password": PW}).status_code == 401
    assert boss.patch("/api/users/boss", json={"active": False}).status_code == 409   # 자기 자신은 못 멈춘다


def test_admin_manages_users_and_keys_over_api(carrier):
    boss = carrier.login("boss")
    r = boss.post("/api/users", json={"username": "lee", "password": PW, "role": "operator"})
    assert r.status_code == 201 and r.json()["role_label"] == "운영"
    assert boss.post("/api/users", json={"username": "x", "password": "abc", "role": "viewer"}).status_code == 409
    issued = boss.post("/api/keys", json={"partner": "새상사", "skills": ["quote"]}).json()
    assert issued["key"].startswith("pk_")
    assert all("key" not in k for k in boss.get("/api/keys").json())          # 평문은 다시 볼 수 없다
    assert boss.delete(f"/api/keys/{issued['key_id']}").status_code == 200
    boss.put("/api/outbound", json={"target": "http://127.0.0.1:5010/", "key": "pk_abcdefghijklmnop"})
    [o] = boss.get("/api/outbound").json()
    assert o["target"] == "http://127.0.0.1:5010" and "abcdefghij" not in o["key"]   # 가려서 보여 준다
    actions = [a["action"] for a in boss.get("/api/audit").json()]
    assert {"user.add", "key.issue", "key.revoke", "outbound.set"} <= set(actions)


# ---------- 설정 DB ----------

def test_pricing_lives_in_db(carrier):
    boss = carrier.login("boss")
    r = boss.put("/api/pricing", json={"base_krw": 50000, "eta_days": 5})
    assert r.status_code == 200 and r.json()["base_krw"] == 50000
    assert boss.get("/api/meta").json()["pricing"]["eta_days"] == 5
    assert boss.put("/api/pricing", json={"round_to_krw": 0}).status_code == 409
    assert boss.put("/api/pricing", json={"eta_days": 1.5}).status_code == 409

    q = carrier.service.quote(QuoteRequest(rfq_id="RFQ-9", buyer="K정밀웍스", item="볼트", weight_kg=10,
                                           origin="창원", destination="평택"))
    assert q.eta_days == 5 and q.price_krw >= 50000
    again = build_service(carrier.settings)                                   # 다시 켜도 DB 값
    assert again.pricing.base_krw == 50000


# ---------- CLI·관리 도구 ----------

def test_cli_login_whoami_logout(carrier, tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(cli, "APP_ROOT", tmp_path)                            # 세션 파일을 프로젝트 폴더에 만들지 않는다
    api = ["--api", carrier.url]
    assert cli.main(api + ["shipment", "list"]) == 1
    assert "login" in capsys.readouterr().err
    assert cli.main(api + ["login", "op", "--password", PW]) == 0
    assert (tmp_path / "data" / ".cli_session").exists()
    assert cli.main(api + ["shipment", "list"]) == 0
    assert cli.main(api + ["whoami"]) == 0
    assert "배송 상태 변경" in capsys.readouterr().out
    assert cli.main(api + ["logout"]) == 0
    assert not (tmp_path / "data" / ".cli_session").exists()


def test_admin_tool(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("APP_DB_PATH", str(tmp_path / "admin.sqlite3"))
    assert admin.main(["user", "add", "kim", "--role", "admin", "--password", PW]) == 0
    assert admin.main(["user", "add", "kim", "--role", "admin", "--password", PW]) == 1   # 이미 있음
    assert admin.main(["key", "issue", "K정밀웍스", "--quiet"]) == 0
    key = capsys.readouterr().out.strip().splitlines()[-1]
    assert key.startswith("pk_")
    assert admin.main(["outbound", "set", "obs", "pk_hub_key_123456"]) == 0
    assert admin.main(["key", "list"]) == 0 and "K정밀웍스" in capsys.readouterr().out
    assert admin.main(["audit"]) == 0
    assert "user.add" in capsys.readouterr().out


def test_two_servers_on_one_pc_keep_separate_logins(carrier, tmp_path):
    """브라우저(쿠키 저장소 하나)로 같은 PC의 두 서버에 로그인해도 서로 로그아웃되지 않는다.
    쿠키는 호스트로만 나뉘고 포트로는 나뉘지 않으므로, 쿠키 이름에 포트를 붙였다."""
    folder = tmp_path / "second"
    folder.mkdir()
    other = Carrier(folder)
    try:
        browser = httpx.Client(timeout=10)                       # 쿠키 저장소 하나 = 브라우저 하나
        for c in (carrier, other):
            assert browser.post(f"{c.url}/api/login", json={"username": "op", "password": PW}).status_code == 200
        assert browser.get(f"{carrier.url}/api/me").status_code == 200
        assert browser.get(f"{other.url}/api/me").status_code == 200
    finally:
        other.server.stop()


def test_login_hint_only_when_set(carrier, tmp_path):
    """로그인 화면 시험 계정 안내(APP_LOGIN_HINT). 기본은 비어 있어 안 보인다."""
    assert httpx.get(f"{carrier.url}/api/login-hint").status_code == 404
    folder = tmp_path / "hint"
    folder.mkdir()
    hinted = Carrier(folder, login_hint="admin3 / 1234")
    try:
        assert httpx.get(f"{hinted.url}/api/login-hint").json() == {"hint": "admin3 / 1234", "username": "admin3"}
    finally:
        hinted.server.stop()
