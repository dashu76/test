"""실제 HTTP로 서버를 띄워 A2A 클라이언트로 왕복한다 (다른 회사 서버 없이)."""

import asyncio
import socket
import threading
import time
import uuid

import httpx
import pytest
import uvicorn

from a2a.client import create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import Message, Role, SendMessageRequest, TaskState
from logistics_contract import CONTRACT_TAG, parse_response
from logistics_contract.examples import example

from carrier_a.app import build_app
from conftest import make_settings


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def server(tmp_path):
    port = free_port()
    settings = make_settings(tmp_path, port=port)
    srv = uvicorn.Server(uvicorn.Config(build_app(settings), host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=srv.run, daemon=True)
    thread.start()
    deadline = time.time() + 10
    while not srv.started:
        assert time.time() < deadline, "서버가 뜨지 않았다"
        time.sleep(0.05)
    yield settings
    srv.should_exit = True
    thread.join(timeout=5)


async def send(url: str, data: dict) -> tuple[int, list, str]:
    """(최종 Task 상태, data 결과 목록, 상태 메시지 텍스트)"""
    client = await create_client(url)
    request = SendMessageRequest(message=Message(
        message_id=str(uuid.uuid4()), context_id=data.get("rfq_id", ""), role=Role.ROLE_USER,
        parts=[new_data_part(data, media_type="application/json")]))
    state, results, text = None, [], ""
    async for response in client.send_message(request):
        kind = response.WhichOneof("payload")
        if kind == "task":
            state = response.task.status.state
        elif kind == "status_update":
            state = response.status_update.status.state
            text = "".join(p.text for p in response.status_update.status.message.parts)
        elif kind == "artifact_update":
            results.extend(get_data_parts(response.artifact_update.artifact.parts))
    return state, results, text


def test_agent_card_url_matches_public_url(server):
    card = httpx.get(f"{server.public_url}/.well-known/agent-card.json").json()
    assert card["supportedInterfaces"][0]["url"] == f"{server.public_url}/"
    assert {s["id"] for s in card["skills"]} == {"quote", "book-shipment", "cancel-booking", "check-delivery"}
    assert all(CONTRACT_TAG in s["tags"] for s in card["skills"])


def test_healthz(server):
    body = httpx.get(f"{server.public_url}/healthz").json()
    assert body["status"] == "ok" and body["contract_version"] == "1.0.0"


def test_quote_and_book_over_a2a(server):
    state, results, _ = asyncio.run(send(server.public_url, example("quote-request")))
    assert state == TaskState.TASK_STATE_COMPLETED
    quote = parse_response(results[0], "quote")   # A2A를 거친 float 숫자도 계약대로 받는다
    assert quote.price_krw == 174000

    booking_req = {**example("booking-request"), "quote_id": quote.quote_id}
    state, results, _ = asyncio.run(send(server.public_url, booking_req))
    assert state == TaskState.TASK_STATE_COMPLETED
    assert parse_response(results[0], "booking").status == "accepted"


def test_contract_violation_fails_task_with_reason(server):
    bad = {**example("quote-request"), "schema_version": "2.0"}
    state, results, text = asyncio.run(send(server.public_url, bad))
    assert state == TaskState.TASK_STATE_FAILED
    assert results == [] and "계약 버전" in text
