"""테스트용 가짜 관제 허브 (POST /events만). 실제 관제 허브 코드는 쓰지 않는다."""

import time

from fastapi import FastAPI


class HubLog:
    def __init__(self) -> None:
        self.events: list[dict] = []

    def types(self) -> list[str]:
        return [e["type"] for e in self.events]

    def of(self, type_: str) -> list[dict]:
        return [e for e in self.events if e["type"] == type_]

    def wait_for(self, predicate, timeout_s: float = 5.0) -> None:
        deadline = time.time() + timeout_s
        while not predicate(self):
            if time.time() > deadline:
                raise AssertionError(f"허브가 기대한 이벤트를 받지 못했다: {self.types()}")
            time.sleep(0.05)


def build_fake_hub(log: HubLog) -> FastAPI:
    app = FastAPI()

    @app.post("/events")
    def receive(event: dict) -> dict:
        log.events.append(event)
        return {"ok": True}

    return app
