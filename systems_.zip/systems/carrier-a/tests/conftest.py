from datetime import datetime, timedelta

import pytest

from carrier_a.domain import KST, load_pricing
from carrier_a.settings import APP_ROOT, Settings
from carrier_a.skills import CarrierService
from carrier_a.store import Store


class FakeClock:
    def __init__(self) -> None:
        self.now = datetime(2026, 10, 15, 9, 0, tzinfo=KST)

    def __call__(self) -> datetime:
        return self.now

    def advance(self, **kwargs) -> None:
        self.now += timedelta(**kwargs)


def make_settings(tmp_path, port: int = 5021, public_url: str | None = None) -> Settings:
    return Settings(
        carrier_name="물류사 A",
        id_prefix="A",
        bind_host="127.0.0.1",
        port=port,
        public_url=public_url or f"http://127.0.0.1:{port}",
        db_path=tmp_path / "carrier_a.sqlite3",
        pricing_file=APP_ROOT / "config" / "pricing.toml",
        allowed_callback_hosts=frozenset({"127.0.0.1", "localhost"}),
    )


@pytest.fixture
def clock() -> FakeClock:
    return FakeClock()


@pytest.fixture
def settings(tmp_path) -> Settings:
    return make_settings(tmp_path)


@pytest.fixture
def service(settings, clock) -> CarrierService:
    return CarrierService(settings, Store(settings.db_path), load_pricing(settings.pricing_file), clock)
