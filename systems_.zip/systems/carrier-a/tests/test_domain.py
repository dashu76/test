import pytest

from logistics_contract import ShipmentStatus as S

from carrier_a.domain import InvalidTransition, Pricing, can_cancel, check_transition, decide_quote

PRICING = Pricing(base_krw=30000, per_kg_krw=300, round_to_krw=1000, eta_days=3,
                  max_weight_kg=5000, quote_valid_hours=24, booking_mode="auto")


def test_price_rounds_up():
    assert decide_quote(480, PRICING) == (174000, 3)
    assert decide_quote(12.5, PRICING) == (34000, 3)   # 33,750 → 34,000


def test_overweight_is_declined():
    assert isinstance(decide_quote(5000.1, PRICING), str)


def test_transitions():
    check_transition(S.ACCEPTED, S.PICKED_UP)
    check_transition(S.CUSTOMS_HOLD, S.IN_TRANSIT)
    with pytest.raises(InvalidTransition):
        check_transition(S.DELIVERED, S.IN_TRANSIT)
    with pytest.raises(InvalidTransition):
        check_transition(S.ACCEPTED, S.DELIVERED)


def test_cancel_only_before_pickup():
    assert can_cancel(S.ACCEPTED)
    assert not can_cancel(S.PICKED_UP)
