# 물류사 A — 운송 견적·예약·배송 조회 A2A 서버

독립 시스템입니다. 이 폴더만 복사해 다른 머신에 두어도 설치·실행·테스트가 됩니다. 다른 회사 서버나 관제 허브가 없어도 뜹니다.

## 설치·실행

```cmd
cd carrier-a
uv sync
copy .env.example .env      :: 필요하면 값 수정
uv run python -m carrier_a
```

- Agent Card: `http://127.0.0.1:5021/.well-known/agent-card.json`
- 상태 확인: `http://127.0.0.1:5021/healthz`

## 설정 (`.env` 또는 환경변수, 환경변수가 우선)

| 이름 | 기본값 | 설명 |
|---|---|---|
| `APP_CARRIER_NAME` | `물류사 A` | Agent Card 이름, 견적의 carrier |
| `APP_ID_PREFIX` | `A` | 견적·예약·운송장 번호 앞자리 |
| `APP_BIND_HOST` / `APP_PORT` | `127.0.0.1` / `5021` | 듣는 주소 |
| `APP_PUBLIC_URL` | `http://{bind}:{port}` | Agent Card에 실리는 주소. `0.0.0.0`으로 들을 때는 반드시 지정 |
| `APP_DB_PATH` | `data/carrier_a.sqlite3` | 업무 DB (상대 경로는 이 폴더 기준) |
| `APP_PRICING_FILE` | `config/pricing.toml` | 요금 규칙 |
| `APP_ALLOWED_CALLBACK_HOSTS` | `127.0.0.1,localhost` | 발주 요청의 알림 주소로 허용할 호스트 |
| `A2A_OBS_URL` | (비움) | 관제 허브(`obs-hub`) 주소. 비우면 관찰 이벤트를 보내지 않는다 |
| `APP_UI_ENABLED` | `true` | 담당자 업무 화면(`/ui`). `false`면 화면만 끈다(A2A·내부 API·CLI는 그대로) |
| `APP_UI_ACCENT` | `#1d4ed8` | 화면 강조색(회사 색, `#rrggbb`) |
| `APP_A2A_AUTH` | `true` | 회사 사이 파트너 키(`X-Partner-Key`) 요구. `false`면 지금까지처럼 열림 |
| `APP_STAFF_AUTH` | `true` | 화면·내부 API·CLI 로그인 요구 |
| `APP_SESSION_HOURS` | `12` | 로그인 세션 유효 시간 |
| `APP_LOGIN_HINT` | (비움) | 로그인 화면 시험 계정 안내(예: `admin3 / 1234`, 사용자 이름을 미리 넣음). 운영에서는 비운다 |

## 스킬 (계약: `logistics-contract==1.0.0`)

| 스킬 | 요청 → 응답 | 비고 |
|---|---|---|
| `quote` | `quote-request` → `quote` (quoted / declined) | 같은 `rfq_id`로 다시 오면 같은 견적. 내용이 다르면 Task failed |
| `book-shipment` | `booking-request` → `booking` (accepted / rejected) | `business_key`로 중복 방지. 지금은 자동 수락만 |
| `cancel-booking` | `cancel-booking-request` → `cancel-booking-result` | 집하 전까지만 취소 |
| `check-delivery` | `delivery-query` → `delivery-status` (found / not_found) | |

계약 위반(버전·종류·형식), 같은 업무키에 다른 내용 → Task `failed` + 이유 메시지.

## 계약 버전 올리기

`interop-spec`에서 빌드한 wheel을 `vendor\`에 넣고 `pyproject.toml`의 `logistics-contract==` 버전과 `[tool.uv.sources]` 경로를 함께 바꾼 뒤 `uv sync` → `uv run pytest`.

## 담당자 CLI — 배송 처리와 구매사 알림

서버가 켜져 있어야 합니다. 다른 터미널에서:

```cmd
uv run python -m carrier_a.cli shipment list
uv run python -m carrier_a.cli shipment advance A-T-100001 picked_up --note "창원 집하"
uv run python -m carrier_a.cli outbox list [--state pending|sent|failed]
uv run python -m carrier_a.cli outbox retry "<event_id>"
uv run python -m carrier_a.cli outbox dispatch
```

- 배송 상태(`picked_up` → `in_transit` → (`customs_hold`) → `delivered`)를 바꾸면, 발주 때 받은 구매사 알림 주소(`event_callback_url`)로 보낼 `shipment-event`가 **같은 DB 트랜잭션에서** outbox에 쌓입니다.
- 발송기(`APP_OUTBOX_INTERVAL_S`, 기본 2초)가 쌓인 순서대로 보냅니다. 구매사가 꺼져 있으면 2·4·8…초(최대 5분) 간격으로 다시 보내고, 앞 알림이 안 끝나면 뒤 알림은 기다립니다(순서 유지).
- 구매사가 거부(Task failed)하거나 `APP_OUTBOX_MAX_ATTEMPTS`(기본 20)회 실패하면 `failed` → 담당자가 확인 후 `outbox retry`.

## 업무 화면 (담당자용)

브라우저로 `http://127.0.0.1:5021/` (→ `/ui`). 서버가 직접 내주는 화면이며 이 회사의 내부 API(`/api`)만 부릅니다. 설계: `systems/docs/p6-carrier-ui.md`.

- **견적 요청함 · 발주 수신함**: 자동 처리 회사라 조회 전용. 어떤 요청이 들어와 어떻게 답했는지(거절 사유 포함) 본다.
- **배송 관리**: 다음으로 갈 수 있는 상태만 버튼으로(메모 선택). 상태를 바꾸면 구매사 알림이 같은 트랜잭션에서 쌓인다. 상태 이력 펼치기.
- **알림 발송 현황**: 대기·보냄·실패 필터, **지금 발송**, 실패 건 **재시도**.
- **설정 보기**: 요금 규칙·처리 방식·스킬·발송 설정·관제 허브 주소. 관리자는 요금 규칙·처리 방식을 여기서 고친다.
- **관리** (관리자만): 사용자·역할, 발급한 파트너 키·받은 키, 감사 기록.
- 로그인해야 열리고, 역할에 없는 버튼은 보이지 않는다(판정은 서버).

DB가 바뀌면(A2A 요청·CLI·다른 담당자·발송기) `/api/stream`(SSE)으로 화면이 바로 갱신됩니다. 입력 중인 칸은 지워지지 않습니다.

## 인증과 권한 (Part 4)

설계: `systems/docs/security-and-db.md`. 로컬에서 다섯 회사를 한 번에 준비하려면 `systems\dev-env\setup_dev_auth.ps1`.

**회사 사이 — 파트너 키 (Ch18).** 구매사는 우리가 발급한 키를 `X-Partner-Key` 헤더로 냅니다(Agent Card의 `securitySchemes`에 적혀 있음). 키가 없거나 틀리거나 폐기됐거나 허용 스킬 밖이면 Task `rejected` + 이유, `GetTask` 등 그 밖의 호출은 401. 키가 맞아도 **다른 회사 이름의 견적 요청은 거부**하고, 남의 견적·예약·운송장은 "없는 것"으로 답합니다.

```cmd
uv run python -m carrier_a.admin key issue "K정밀웍스"                  :: 구매사에 줄 키 (한 번만 보임)
uv run python -m carrier_a.admin outbound set http://127.0.0.1:5010 <키>  :: 구매사가 준 키 (배송 알림을 보낼 때 냄)
uv run python -m carrier_a.admin key list | key revoke <key_id>
```

**사내 — 로그인과 역할 (Ch19).**

| 역할 | 할 수 있는 일 |
|---|---|
| `viewer` 조회 | 목록·설정 보기 |
| `operator` 운영 | + 배송 상태 변경, 알림 지금 발송·재시도 |
| `manager` 승인 | + 견적 승인·거절·질문, 발주 수락·거절 |
| `admin` 관리자 | + 요금·처리 방식 변경, 사용자·키·감사 기록 (화면 "관리" 탭) |

```cmd
uv run python -m carrier_a.admin user add kim --role admin     :: 첫 관리자 (서버 밖, DB에 직접)
uv run python -m carrier_a.cli login kim                       :: CLI 로그인 (세션: data\.cli_session)
uv run python -m carrier_a.admin audit                         :: 감사 기록
```

비밀번호는 PBKDF2 해시, 세션·발급 키는 SHA-256 해시로만 저장합니다. 로그인 5회 실패하면 5분 잠금. 요금 규칙(`config/pricing.toml`)은 처음 뜰 때 DB로 옮겨지고, 이후에는 화면 "설정 보기"(관리자)에서 고칩니다(`admin config reset pricing`으로 파일 값으로 되돌림).

## 관제 허브 (선택)

`A2A_OBS_URL`에 관제 허브(`obs-hub`, 기본 `http://127.0.0.1:5090`) 주소를 넣으면 이 시스템이 관찰 이벤트를 직접 보냅니다(`carrier_a/obs_hook.py`). 비워 두면 아무 일도 하지 않습니다. 보내기는 백그라운드 스레드가 하므로 허브가 꺼져 있거나 느려도 업무는 기다리지 않습니다(S-25). 허브에 닿지 않으면 5초 동안은 이벤트를 버립니다 — 관찰 기록은 업무 기록이 아닙니다.

| 이벤트 | 언제 |
|---|---|
| `agent.started` / `agent.stopped` | 서버 기동·종료 |
| `task.received` / `task.state` | A2A 요청을 받음 / Task 상태가 바뀔 때마다 (완료·실패·질문이면 결과 요약) |
| `card.fetched` / `card.failed` | 구매사 카드 조회 결과가 바뀔 때 |
| `request.sent` / `request.done` / `request.error` | 구매사에 배송 알림(`receive-shipment-event`)을 보낼 때 |
| `outbox.sent` / `outbox.retry` / `outbox.failed` | 배송 알림 발송 결과 (상태·예약·시도 횟수·오류) |

## 테스트

```cmd
uv run pytest
```

단위(요금·상태 전이), 업무(업무키·거절 사유·재시작), 계약 예시, 실제 HTTP A2A 왕복을 확인합니다. 관찰 이벤트는 `tests/fake_hub.py`(가짜 허브)로 확인합니다. 다른 서버는 필요 없습니다.

## 아직 없는 것 (plan_3 진행 순서)

- TLS 없음 — 로컬·사내망 전제. 다른 머신과 주고받으려면 앞단에 HTTPS 프록시를 둔다 (키·세션이 평문 HTTP로 오간다)
- 물류사 A는 자동 견적·자동 수락 회사다. 담당자 확인 흐름은 `klogistics-carrier`에 있다
