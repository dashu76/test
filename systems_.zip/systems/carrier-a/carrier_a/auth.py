# 파일명: auth.py
"""사내 로그인·권한, 회사 사이 파트너 키, 감사 기록 (Part 4 Ch18·Ch19). 설계: systems/docs/security-and-db.md

- 이 시스템의 DB 파일(APP_DB_PATH) 안의 테이블만 쓴다. 비밀번호·세션 토큰·발급한 파트너 키는 해시만 저장한다.
- 여섯 시스템이 같은 파일을 각자 복사해 쓴다. 회사마다 다른 것은 역할 표(permissions.py)뿐이다.
- 상대 회사가 우리에게 발급한 키(outbound_keys)는 상대에게 내밀어야 하므로 평문으로 둔다(DB 파일 접근 = 서버 관리자).
"""

import hashlib
import hmac
import json
import re
import secrets
import sqlite3
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username      TEXT PRIMARY KEY,
    display_name  TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL,
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    username   TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);
-- 우리가 다른 회사(또는 관제 허브에 보내는 시스템)에 발급한 키. 해시만 둔다.
CREATE TABLE IF NOT EXISTS partner_keys (
    key_id       TEXT PRIMARY KEY,
    partner      TEXT NOT NULL,
    key_hash     TEXT NOT NULL UNIQUE,
    skills_json  TEXT NOT NULL,
    active       INTEGER NOT NULL DEFAULT 1,
    created_at   TEXT NOT NULL,
    last_used_at TEXT,
    revoked_at   TEXT
);
-- 다른 회사가 우리에게 발급한 키 (대상 → 키). 요청을 보낼 때 X-Partner-Key로 내민다.
CREATE TABLE IF NOT EXISTS outbound_keys (
    target     TEXT PRIMARY KEY,
    key        TEXT NOT NULL,
    note       TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    at     TEXT NOT NULL,
    actor  TEXT NOT NULL,
    action TEXT NOT NULL,
    target TEXT NOT NULL DEFAULT '',
    detail TEXT NOT NULL DEFAULT '',
    ok     INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS audit_log_action ON audit_log (action, target, at);
"""

PBKDF2_ROUNDS = 200_000
LOCK_FAILS, LOCK_MINUTES = 5, 5          # 로그인 5회 실패 → 5분 잠금
SESSION_COOKIE = "session"   # 실제 쿠키 이름은 cookie_name() — 포트를 붙인다
USERNAME = re.compile(r"^[A-Za-z0-9._-]{2,32}$")
MIN_PASSWORD = 4                         # 개발·시험 편의(admin/1234). 운영 비밀번호 정책은 P7-B S5


class AuthError(ValueError):
    """사용자에게 그대로 보여 줄 수 있는 인증·관리 오류."""


@dataclass(frozen=True)
class Role:
    label: str
    permissions: frozenset[str]


@dataclass(frozen=True)
class StaffUser:
    username: str
    display_name: str
    role: str
    permissions: frozenset[str] = field(default_factory=frozenset)

    def as_dict(self, roles: dict[str, Role]) -> dict:
        return {"username": self.username, "display_name": self.display_name or self.username, "role": self.role,
                "role_label": roles[self.role].label if self.role in roles else self.role,
                "permissions": sorted(self.permissions)}


@dataclass(frozen=True)
class Partner:
    """파트너 키로 확인된 상대 회사."""
    name: str
    skills: frozenset[str]
    key_id: str


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def hash_password(password: str, salt: bytes | None = None, rounds: int = PBKDF2_ROUNDS) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
    return f"pbkdf2_sha256${rounds}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, rounds, salt, digest = stored.split("$")
    except ValueError:
        return False
    check = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(rounds))
    return hmac.compare_digest(check.hex(), digest)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def mask(secret: str) -> str:
    return secret[:6] + "…" + secret[-4:] if len(secret) > 12 else "…"


class AuthStore:
    def __init__(self, db_path: Path, roles: dict[str, Role], session_hours: float = 12,
                 clock: Callable[[], datetime] = utcnow) -> None:
        self.path = db_path
        self.roles = roles
        self.session_hours = session_hours
        self.clock = clock
        db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._read() as conn:
            conn.executescript(SCHEMA)

    # ---------- DB ----------

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def _read(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def _write(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.close()

    def _now(self) -> str:
        return self.clock().isoformat()

    # ---------- 감사 기록 ----------

    def audit(self, actor: str, action: str, target: str = "", detail: str = "", ok: bool = True) -> None:
        with self._write() as conn:
            conn.execute("INSERT INTO audit_log (at, actor, action, target, detail, ok) VALUES (?, ?, ?, ?, ?, ?)",
                         (self._now(), actor, action, target, detail[:500], int(ok)))

    def audit_log(self, limit: int = 200) -> list[dict]:
        with self._read() as conn:
            rows = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) | {"ok": bool(r["ok"])} for r in rows]

    # ---------- 사용자 ----------

    def _check_role(self, role: str) -> None:
        if role not in self.roles:
            raise AuthError(f"없는 역할: {role} (가능: {', '.join(self.roles)})")

    @staticmethod
    def _check_password(password: str) -> None:
        if len(password) < MIN_PASSWORD:
            raise AuthError(f"비밀번호는 {MIN_PASSWORD}자 이상이어야 한다")

    def add_user(self, username: str, password: str, role: str, display_name: str = "", actor: str = "admin") -> dict:
        if not USERNAME.match(username):
            raise AuthError("사용자 이름은 영문·숫자·._- 2~32자")
        self._check_role(role)
        self._check_password(password)
        now = self._now()
        try:
            with self._write() as conn:
                conn.execute("INSERT INTO users (username, display_name, password_hash, role, created_at, updated_at)"
                             " VALUES (?, ?, ?, ?, ?, ?)", (username, display_name, hash_password(password), role, now, now))
        except sqlite3.IntegrityError as exc:
            raise AuthError(f"이미 있는 사용자: {username}") from exc
        self.audit(actor, "user.add", username, f"role={role}")
        return self.user(username)

    def update_user(self, username: str, *, role: str | None = None, active: bool | None = None,
                    password: str | None = None, display_name: str | None = None, actor: str = "admin") -> dict:
        fields: dict = {}
        if role is not None:
            self._check_role(role)
            fields["role"] = role
        if active is not None:
            fields["active"] = int(active)
        if password is not None:
            self._check_password(password)
            fields["password_hash"] = hash_password(password)
        if display_name is not None:
            fields["display_name"] = display_name
        if not fields:
            return self.user(username)
        with self._write() as conn:
            if conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone() is None:
                raise AuthError(f"없는 사용자: {username}")
            cols = ", ".join(f"{k}=?" for k in fields)
            conn.execute(f"UPDATE users SET {cols}, updated_at=? WHERE username=?",
                         (*fields.values(), self._now(), username))
            if active is False or password is not None:   # 끊거나 비밀번호를 바꾸면 기존 세션은 끝낸다
                conn.execute("DELETE FROM sessions WHERE username=?", (username,))
        changed = ", ".join(("password=***" if k == "password_hash" else f"{k}={v}") for k, v in fields.items())
        self.audit(actor, "user.update", username, changed)
        return self.user(username)

    def user(self, username: str) -> dict:
        with self._read() as conn:
            r = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if r is None:
            raise AuthError(f"없는 사용자: {username}")
        return self._user_view(r)

    def _user_view(self, r) -> dict:
        role = self.roles.get(r["role"])
        return {"username": r["username"], "display_name": r["display_name"], "role": r["role"],
                "role_label": role.label if role else r["role"], "active": bool(r["active"]),
                "created_at": r["created_at"], "updated_at": r["updated_at"]}

    def users(self) -> list[dict]:
        with self._read() as conn:
            return [self._user_view(r) for r in conn.execute("SELECT * FROM users ORDER BY username").fetchall()]

    def has_users(self) -> bool:
        with self._read() as conn:
            return conn.execute("SELECT 1 FROM users LIMIT 1").fetchone() is not None

    def _staff(self, r) -> StaffUser:
        role = self.roles.get(r["role"])
        return StaffUser(r["username"], r["display_name"], r["role"], role.permissions if role else frozenset())

    def system_user(self) -> StaffUser:
        """로그인을 끈 경우(APP_STAFF_AUTH=false)의 사용자: 모든 권한."""
        every = frozenset().union(*(r.permissions for r in self.roles.values()))
        return StaffUser("local", "로그인 꺼짐", "admin" if "admin" in self.roles else "", every)

    # ---------- 로그인·세션 ----------

    def _locked(self, conn, username: str) -> bool:
        since = (self.clock() - timedelta(minutes=LOCK_MINUTES)).isoformat()
        last_ok = conn.execute("SELECT MAX(at) AS at FROM audit_log WHERE action='login' AND target=? AND ok=1",
                               (username,)).fetchone()["at"] or ""
        fails = conn.execute("SELECT COUNT(*) AS n FROM audit_log WHERE action='login' AND target=? AND ok=0"
                             " AND at > ? AND at > ?", (username, since, last_ok)).fetchone()["n"]
        return fails >= LOCK_FAILS

    def login(self, username: str, password: str) -> tuple[str, StaffUser]:
        with self._read() as conn:
            if self._locked(conn, username):
                self.audit(username, "login", username, "잠김", ok=False)
                raise AuthError(f"로그인 실패가 많아 {LOCK_MINUTES}분 동안 잠겼다")
            r = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if r is None or not r["active"] or not verify_password(password, r["password_hash"]):
            self.audit(username, "login", username, "이름·비밀번호 불일치 또는 사용 중지", ok=False)
            raise AuthError("사용자 이름 또는 비밀번호가 맞지 않는다")
        token = secrets.token_urlsafe(32)
        now = self.clock()
        with self._write() as conn:
            conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now.isoformat(),))
            conn.execute("INSERT INTO sessions (token_hash, username, created_at, expires_at) VALUES (?, ?, ?, ?)",
                         (token_hash(token), username, now.isoformat(),
                          (now + timedelta(hours=self.session_hours)).isoformat()))
        self.audit(username, "login", username)
        return token, self._staff(r)

    def user_for_token(self, token: str) -> StaffUser | None:
        with self._read() as conn:
            r = conn.execute("SELECT u.* FROM sessions s JOIN users u ON u.username = s.username"
                             " WHERE s.token_hash=? AND s.expires_at > ? AND u.active=1",
                             (token_hash(token), self._now())).fetchone()
        return self._staff(r) if r else None

    def logout(self, token: str) -> None:
        with self._write() as conn:
            conn.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(token),))

    # ---------- 우리가 발급한 파트너 키 ----------

    def issue_key(self, partner: str, skills: list[str], actor: str = "admin") -> tuple[str, str]:
        """새 키를 만들어 (key_id, 키 평문)을 돌려준다. 평문은 이때 한 번만 볼 수 있다."""
        partner, skills = partner.strip(), sorted({s.strip() for s in skills if s.strip()})
        if not partner or not skills:
            raise AuthError("회사 이름과 허용 스킬이 필요하다")
        key, key_id = "pk_" + secrets.token_urlsafe(24), "k_" + secrets.token_hex(4)
        with self._write() as conn:
            conn.execute("INSERT INTO partner_keys (key_id, partner, key_hash, skills_json, created_at)"
                         " VALUES (?, ?, ?, ?, ?)", (key_id, partner, token_hash(key), json.dumps(skills), self._now()))
        self.audit(actor, "key.issue", key_id, f"{partner}: {', '.join(skills)}")
        return key_id, key

    def revoke_key(self, key_id: str, actor: str = "admin") -> None:
        with self._write() as conn:
            cur = conn.execute("UPDATE partner_keys SET active=0, revoked_at=? WHERE key_id=? AND active=1",
                               (self._now(), key_id))
            if cur.rowcount == 0:
                raise AuthError(f"없거나 이미 폐기된 키: {key_id}")
        self.audit(actor, "key.revoke", key_id)

    def partner_keys(self) -> list[dict]:
        with self._read() as conn:
            rows = conn.execute("SELECT * FROM partner_keys ORDER BY created_at DESC").fetchall()
        return [{"key_id": r["key_id"], "partner": r["partner"], "skills": json.loads(r["skills_json"]),
                 "active": bool(r["active"]), "created_at": r["created_at"], "last_used_at": r["last_used_at"],
                 "revoked_at": r["revoked_at"]} for r in rows]

    def partner_for_key(self, key: str | None) -> Partner | None:
        if not key:
            return None
        with self._read() as conn:
            r = conn.execute("SELECT * FROM partner_keys WHERE key_hash=? AND active=1", (token_hash(key),)).fetchone()
        if r is None:
            return None
        with self._write() as conn:
            conn.execute("UPDATE partner_keys SET last_used_at=? WHERE key_id=?", (self._now(), r["key_id"]))
        return Partner(r["partner"], frozenset(json.loads(r["skills_json"])), r["key_id"])

    # ---------- 상대 회사가 우리에게 발급한 키 ----------

    def set_outbound(self, target: str, key: str, note: str = "", actor: str = "admin") -> None:
        target, key = target.strip().rstrip("/"), key.strip()
        if not target or not key:
            raise AuthError("대상과 키가 필요하다")
        with self._write() as conn:
            conn.execute("INSERT INTO outbound_keys (target, key, note, updated_at) VALUES (?, ?, ?, ?)"
                         " ON CONFLICT(target) DO UPDATE SET key=excluded.key, note=excluded.note,"
                         " updated_at=excluded.updated_at", (target, key, note, self._now()))
        self.audit(actor, "outbound.set", target, note)

    def delete_outbound(self, target: str, actor: str = "admin") -> None:
        with self._write() as conn:
            if conn.execute("DELETE FROM outbound_keys WHERE target=?", (target.rstrip("/"),)).rowcount == 0:
                raise AuthError(f"없는 대상: {target}")
        self.audit(actor, "outbound.delete", target)

    def outbound_key(self, target: str) -> str | None:
        with self._read() as conn:
            r = conn.execute("SELECT key FROM outbound_keys WHERE target=?", (target.rstrip("/"),)).fetchone()
        return r["key"] if r else None

    def outbound_keys(self) -> list[dict]:
        with self._read() as conn:
            rows = conn.execute("SELECT * FROM outbound_keys ORDER BY target").fetchall()
        return [{"target": r["target"], "key": mask(r["key"]), "note": r["note"], "updated_at": r["updated_at"]}
                for r in rows]


# ---------- FastAPI: 로그인 확인과 권한 ----------

def cookie_name(request: Request) -> str:
    """세션 쿠키 이름. 브라우저는 쿠키를 호스트로만 나누고 포트로는 나누지 않으므로(RFC 6265),
    한 PC(127.0.0.1)에 여러 회사 서버를 띄우면 같은 이름의 쿠키를 서로 덮어쓴다. 그래서 서버 포트를 붙인다."""
    return getattr(request.app.state, "session_cookie", SESSION_COOKIE)


def _token(request: Request) -> str | None:
    header = request.headers.get("authorization", "")
    if header.lower().startswith("bearer "):
        return header[7:].strip()
    return request.cookies.get(cookie_name(request))


def current_user(request: Request) -> StaffUser:
    state = request.app.state
    if not state.staff_auth:
        return state.auth.system_user()
    token = _token(request)
    user = state.auth.user_for_token(token) if token else None
    if user is None:
        raise HTTPException(status_code=401, detail="로그인이 필요하다")
    return user


def require(permission: str):
    """권한이 없으면 403. 판정은 언제나 서버가 한다(화면은 버튼을 숨길 뿐)."""
    def check(request: Request, user: StaffUser = Depends(current_user)) -> StaffUser:
        if permission not in user.permissions:
            request.app.state.auth.audit(user.username, "denied", request.url.path, permission, ok=False)
            label = request.app.state.permission_labels.get(permission, permission)
            raise HTTPException(status_code=403, detail=f"권한이 없다: {label}")
        return user
    return check


class Login(BaseModel):
    username: str
    password: str


class NewUser(BaseModel):
    username: str
    password: str
    role: str
    display_name: str = ""


class UserChange(BaseModel):
    role: str | None = None
    active: bool | None = None
    password: str | None = None
    display_name: str | None = None


class NewKey(BaseModel):
    partner: str = Field(min_length=1)
    skills: list[str] = Field(min_length=1)


class Outbound(BaseModel):
    target: str = Field(min_length=1)
    key: str = Field(min_length=1)
    note: str = ""


router = APIRouter(prefix="/api")


def _auth(request: Request) -> AuthStore:
    return request.app.state.auth


def _guard(fn):
    try:
        return fn()
    except AuthError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/login")
def login(request: Request, response: Response, body: Login):
    if not request.app.state.staff_auth:
        return {"user": _auth(request).system_user().as_dict(_auth(request).roles), "token": ""}
    try:
        token, user = _auth(request).login(body.username, body.password)
    except AuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    return _start_session(request, response, token, user)


def _start_session(request: Request, response: Response, token: str, user: StaffUser) -> dict:
    response.set_cookie(cookie_name(request), token, httponly=True, samesite="strict",
                        secure=request.url.scheme == "https", max_age=int(_auth(request).session_hours * 3600))
    return {"user": user.as_dict(_auth(request).roles), "token": token}   # token은 CLI용 (화면은 쿠키)


@router.get("/login-hint")
def login_hint(request: Request):
    """로그인 화면에 보여 줄 시험 계정 안내(APP_LOGIN_HINT, 예: "admin3 / 1234"). 비어 있으면 404 → 화면에 안 나온다.
    시험·시연용. 운영에서는 비워 둔다."""
    hint = getattr(request.app.state, "login_hint", "")
    if not hint:
        raise HTTPException(status_code=404, detail="로그인 안내 없음")
    return {"hint": hint, "username": hint.split("/")[0].strip()}


@router.post("/logout")
def logout(request: Request, response: Response):
    token = _token(request)
    if token:
        _auth(request).logout(token)
    response.delete_cookie(cookie_name(request))
    return {"ok": True}


@router.get("/me")
def me(request: Request, user: StaffUser = Depends(current_user)):
    roles = _auth(request).roles
    return {"user": user.as_dict(roles), "staff_auth": request.app.state.staff_auth,
            "roles": {k: {"label": r.label, "permissions": sorted(r.permissions)} for k, r in roles.items()},
            "permission_labels": request.app.state.permission_labels}


@router.get("/users")
def users(request: Request, _: StaffUser = Depends(require("admin"))):
    return _auth(request).users()


@router.post("/users", status_code=201)
def add_user(request: Request, body: NewUser, user: StaffUser = Depends(require("admin"))):
    return _guard(lambda: _auth(request).add_user(body.username, body.password, body.role, body.display_name,
                                                  actor=user.username))


@router.patch("/users/{username}")
def change_user(request: Request, username: str, body: UserChange, user: StaffUser = Depends(require("admin"))):
    if username == user.username and (body.active is False or (body.role and body.role != user.role)):
        raise HTTPException(status_code=409, detail="자기 자신의 역할을 바꾸거나 사용을 멈출 수 없다")
    return _guard(lambda: _auth(request).update_user(username, role=body.role, active=body.active,
                                                     password=body.password, display_name=body.display_name,
                                                     actor=user.username))


@router.get("/keys")
def keys(request: Request, _: StaffUser = Depends(require("admin"))):
    return _auth(request).partner_keys()


@router.post("/keys", status_code=201)
def issue_key(request: Request, body: NewKey, user: StaffUser = Depends(require("admin"))):
    key_id, key = _guard(lambda: _auth(request).issue_key(body.partner, body.skills, actor=user.username))
    return {"key_id": key_id, "key": key, "partner": body.partner, "skills": sorted(set(body.skills))}


@router.delete("/keys/{key_id}")
def revoke_key(request: Request, key_id: str, user: StaffUser = Depends(require("admin"))):
    _guard(lambda: _auth(request).revoke_key(key_id, actor=user.username))
    return {"key_id": key_id, "active": False}


@router.get("/outbound")
def outbound(request: Request, _: StaffUser = Depends(require("admin"))):
    return _auth(request).outbound_keys()


@router.put("/outbound")
def set_outbound(request: Request, body: Outbound, user: StaffUser = Depends(require("admin"))):
    _guard(lambda: _auth(request).set_outbound(body.target, body.key, body.note, actor=user.username))
    return {"target": body.target.rstrip("/"), "key": mask(body.key)}


@router.delete("/outbound")
def delete_outbound(request: Request, target: str, user: StaffUser = Depends(require("admin"))):
    _guard(lambda: _auth(request).delete_outbound(target, actor=user.username))
    return {"target": target, "deleted": True}


@router.get("/audit")
def audit(request: Request, limit: int = 200, _: StaffUser = Depends(require("admin"))):
    return _auth(request).audit_log(min(max(limit, 1), 1000))


# ---------- CLI 세션 (이 시스템 폴더의 data/.cli_session) ----------

def cli_session_file(root: Path) -> Path:
    return root / "data" / ".cli_session"


def cli_headers(root: Path) -> dict[str, str]:
    path = cli_session_file(root)
    if path.exists():
        token = path.read_text(encoding="utf-8").strip()
        if token:
            return {"Authorization": f"Bearer {token}"}
    return {}


def save_cli_session(root: Path, token: str) -> Path:
    path = cli_session_file(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(token, encoding="utf-8")
    return path
