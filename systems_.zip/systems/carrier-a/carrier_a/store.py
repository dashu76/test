# 파일명: store.py
"""물류사 A 전용 SQLite 저장소. 다른 회사와 공유하지 않는다.

업무키 처리는 Ch15 business_key_demo와 같은 방식이다: BEGIN IMMEDIATE로 잠그고,
같은 키가 있으면 저장해 둔 첫 응답을 돌려주며, 같은 키에 다른 내용이면 거부한다.
"""

import json
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS quotes (
    quote_seq     INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_id      TEXT UNIQUE,                 -- 거절된 견적은 NULL
    rfq_id        TEXT NOT NULL UNIQUE,
    request_key   TEXT NOT NULL,
    status        TEXT NOT NULL,               -- quoted | declined
    valid_until   TEXT,
    response_json TEXT NOT NULL,
    created_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bookings (
    booking_seq   INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id    TEXT UNIQUE,                 -- 거절된 발주는 NULL
    business_key  TEXT NOT NULL UNIQUE,
    request_key   TEXT NOT NULL,
    quote_id      TEXT NOT NULL,
    tracking_no   TEXT UNIQUE,
    status        TEXT NOT NULL,               -- rejected 또는 ShipmentStatus 값
    seq           INTEGER NOT NULL DEFAULT 0,  -- 상태 변경 순번
    eta           TEXT,
    callback_url  TEXT,
    response_json TEXT NOT NULL,               -- 첫 응답 (재전송 시 그대로 돌려줌)
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS shipment_history (
    booking_id TEXT NOT NULL,
    seq        INTEGER NOT NULL,
    status     TEXT NOT NULL,
    note       TEXT NOT NULL DEFAULT '',
    at         TEXT NOT NULL,
    PRIMARY KEY (booking_id, seq)
);
CREATE TABLE IF NOT EXISTS cancel_requests (
    business_key  TEXT PRIMARY KEY,
    request_key   TEXT NOT NULL,
    response_json TEXT NOT NULL,
    created_at    TEXT NOT NULL
);
-- 화면·API로 고치는 설정 (pricing 한 줄). 처음 뜰 때 config/pricing.toml로 채운다.
CREATE TABLE IF NOT EXISTS config (
    key        TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    updated_by TEXT NOT NULL
);
-- 구매사에 보낼 배송 상태 알림. 상태 변경과 같은 트랜잭션에서 쌓는다(transactional outbox).
CREATE TABLE IF NOT EXISTS outbox (
    event_id        TEXT PRIMARY KEY,
    booking_id      TEXT NOT NULL,
    target_url      TEXT NOT NULL,
    payload_json    TEXT NOT NULL,
    state           TEXT NOT NULL,             -- pending | sent | failed
    attempts        INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TEXT NOT NULL,
    last_error      TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL,
    sent_at         TEXT
);
"""


def canonical(data: dict[str, Any]) -> str:
    """같은 요청인지 비교하는 키. schema_version 차이(1.0 vs 1.1)는 같은 요청으로 본다."""
    body = {k: v for k, v in data.items() if k != "schema_version"}
    return json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class Store:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.revision = 0                   # 바뀐 행이 있는 쓰기마다 1씩 오른다 (화면 실시간 갱신용)
        self._revision_lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(SCHEMA)
            columns = {r["name"] for r in conn.execute("PRAGMA table_info(bookings)").fetchall()}
            if "partner" not in columns:   # 인증 도입 전 DB: 발주한 회사(파트너 키의 회사) 열을 더한다
                conn.execute("ALTER TABLE bookings ADD COLUMN partner TEXT")

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.execute("COMMIT")
            if conn.total_changes:   # 읽기만 한 트랜잭션은 화면을 다시 그리게 하지 않는다
                with self._revision_lock:
                    self.revision += 1
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.close()

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            yield conn
        finally:
            conn.close()

    # ---------- 견적 ----------

    @staticmethod
    def find_quote_by_rfq(conn, rfq_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM quotes WHERE rfq_id=?", (rfq_id,)).fetchone()

    @staticmethod
    def find_quote(conn, quote_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM quotes WHERE quote_id=?", (quote_id,)).fetchone()

    @staticmethod
    def insert_quote(conn, rfq_id: str, request_key: str, created_at: str) -> int:
        cur = conn.execute(
            "INSERT INTO quotes (rfq_id, request_key, status, response_json, created_at)"
            " VALUES (?, ?, 'pending', '{}', ?)",
            (rfq_id, request_key, created_at),
        )
        return cur.lastrowid

    @staticmethod
    def finish_quote(conn, quote_seq: int, quote_id: str | None, status: str,
                     valid_until: str | None, response: dict) -> None:
        conn.execute(
            "UPDATE quotes SET quote_id=?, status=?, valid_until=?, response_json=? WHERE quote_seq=?",
            (quote_id, status, valid_until, json.dumps(response, ensure_ascii=False), quote_seq),
        )

    # ---------- 발주 ----------

    @staticmethod
    def find_booking_by_key(conn, business_key: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM bookings WHERE business_key=?", (business_key,)).fetchone()

    @staticmethod
    def find_booking(conn, booking_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM bookings WHERE booking_id=?", (booking_id,)).fetchone()

    @staticmethod
    def find_booking_by_tracking(conn, tracking_no: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM bookings WHERE tracking_no=?", (tracking_no,)).fetchone()

    @staticmethod
    def find_active_booking_for_quote(conn, quote_id: str) -> sqlite3.Row | None:
        return conn.execute(
            "SELECT * FROM bookings WHERE quote_id=? AND status NOT IN ('rejected', 'cancelled')",
            (quote_id,),
        ).fetchone()

    @staticmethod
    def insert_booking(conn, business_key: str, request_key: str, quote_id: str,
                       callback_url: str | None, now: str, partner: str | None = None) -> int:
        cur = conn.execute(
            "INSERT INTO bookings (business_key, request_key, quote_id, status, callback_url,"
            " response_json, created_at, updated_at, partner) VALUES (?, ?, ?, 'pending', ?, '{}', ?, ?, ?)",
            (business_key, request_key, quote_id, callback_url, now, now, partner),
        )
        return cur.lastrowid

    @staticmethod
    def finish_booking(conn, booking_seq: int, booking_id: str | None, tracking_no: str | None,
                       status: str, eta: str | None, response: dict) -> None:
        conn.execute(
            "UPDATE bookings SET booking_id=?, tracking_no=?, status=?, eta=?, response_json=?"
            " WHERE booking_seq=?",
            (booking_id, tracking_no, status, eta, json.dumps(response, ensure_ascii=False), booking_seq),
        )

    @staticmethod
    def set_booking_status(conn, booking_id: str, status: str, note: str, at: str) -> int:
        row = conn.execute("SELECT seq FROM bookings WHERE booking_id=?", (booking_id,)).fetchone()
        seq = row["seq"] + 1
        conn.execute(
            "UPDATE bookings SET status=?, seq=?, updated_at=? WHERE booking_id=?",
            (status, seq, at, booking_id),
        )
        conn.execute(
            "INSERT INTO shipment_history (booking_id, seq, status, note, at) VALUES (?, ?, ?, ?, ?)",
            (booking_id, seq, status, note, at),
        )
        return seq

    @staticmethod
    def all_quotes(conn) -> list[sqlite3.Row]:
        return conn.execute("SELECT * FROM quotes ORDER BY quote_seq DESC").fetchall()

    @staticmethod
    def all_bookings(conn) -> list[sqlite3.Row]:
        return conn.execute("SELECT * FROM bookings ORDER BY booking_seq DESC").fetchall()

    @staticmethod
    def shipments(conn) -> list[sqlite3.Row]:
        return conn.execute(
            "SELECT * FROM bookings WHERE tracking_no IS NOT NULL ORDER BY booking_seq DESC").fetchall()

    @staticmethod
    def last_note(conn, booking_id: str) -> str:
        row = conn.execute(
            "SELECT note FROM shipment_history WHERE booking_id=? ORDER BY seq DESC LIMIT 1",
            (booking_id,),
        ).fetchone()
        return row["note"] if row else ""

    @staticmethod
    def history(conn, booking_id: str) -> list[sqlite3.Row]:
        return conn.execute(
            "SELECT * FROM shipment_history WHERE booking_id=? ORDER BY seq", (booking_id,)
        ).fetchall()

    # ---------- 취소 ----------

    @staticmethod
    def find_cancel(conn, business_key: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM cancel_requests WHERE business_key=?", (business_key,)).fetchone()

    @staticmethod
    def insert_cancel(conn, business_key: str, request_key: str, response: dict, now: str) -> None:
        conn.execute(
            "INSERT INTO cancel_requests (business_key, request_key, response_json, created_at)"
            " VALUES (?, ?, ?, ?)",
            (business_key, request_key, json.dumps(response, ensure_ascii=False), now),
        )

    # ---------- 설정 ----------

    def get_config(self, key: str) -> dict | None:
        with self.read() as conn:
            row = conn.execute("SELECT value_json FROM config WHERE key=?", (key,)).fetchone()
        return json.loads(row["value_json"]) if row else None

    def set_config(self, key: str, value: dict, by: str, now: str) -> None:
        with self.transaction() as conn:
            conn.execute("INSERT INTO config (key, value_json, updated_at, updated_by) VALUES (?, ?, ?, ?)"
                         " ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,"
                         " updated_at=excluded.updated_at, updated_by=excluded.updated_by",
                         (key, json.dumps(value, ensure_ascii=False), now, by))

    def reset_config(self, key: str) -> bool:
        with self.transaction() as conn:
            return conn.execute("DELETE FROM config WHERE key=?", (key,)).rowcount > 0

    # ---------- 알림 outbox ----------

    @staticmethod
    def enqueue_event(conn, event_id: str, booking_id: str, target_url: str, payload: dict, now: str) -> None:
        conn.execute(
            "INSERT OR IGNORE INTO outbox (event_id, booking_id, target_url, payload_json, state,"
            " next_attempt_at, created_at) VALUES (?, ?, ?, ?, 'pending', ?, ?)",
            (event_id, booking_id, target_url, json.dumps(payload, ensure_ascii=False), now, now),
        )

    @staticmethod
    def pending_events(conn) -> list[sqlite3.Row]:
        """쌓인 순서대로 (같은 트랜잭션 안의 순번까지 지키도록 rowid로 정렬)."""
        return conn.execute("SELECT * FROM outbox WHERE state='pending' ORDER BY rowid").fetchall()

    @staticmethod
    def outbox(conn, state: str | None = None) -> list[sqlite3.Row]:
        if state:
            return conn.execute("SELECT * FROM outbox WHERE state=? ORDER BY created_at DESC", (state,)).fetchall()
        return conn.execute("SELECT * FROM outbox ORDER BY created_at DESC").fetchall()

    @staticmethod
    def set_event(conn, event_id: str, **fields) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE outbox SET {cols} WHERE event_id=?", (*fields.values(), event_id))
