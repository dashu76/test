# 파일명: permissions.py
"""물류사 직원의 역할과 권한 (Part 4 Ch19 권한 경계). 조회는 누구나, 약속이 걸린 결정은 승인 역할만.
설계: systems/docs/security-and-db.md 3.1"""

from .auth import Role

PERMISSION_LABELS = {
    "read": "목록·설정 보기",
    "shipment.update": "배송 상태 변경",
    "outbox.manage": "알림 발송·재시도",
    "quote.decide": "견적 승인·거절·질문",
    "booking.decide": "발주 수락·거절",
    "settings.edit": "요금·처리 방식 변경",
    "admin": "사용자·키·감사 기록 관리",
}

_VIEW = {"read"}
_OPERATE = _VIEW | {"shipment.update", "outbox.manage"}
_DECIDE = _OPERATE | {"quote.decide", "booking.decide"}

ROLES = {
    "viewer": Role("조회", frozenset(_VIEW)),
    "operator": Role("운영", frozenset(_OPERATE)),
    "manager": Role("승인", frozenset(_DECIDE)),
    "admin": Role("관리자", frozenset(_DECIDE | {"settings.edit", "admin"})),
}

# 구매사에 발급하는 키의 기본 허용 스킬
PARTNER_SKILLS = ["quote", "book-shipment", "cancel-booking", "check-delivery"]
