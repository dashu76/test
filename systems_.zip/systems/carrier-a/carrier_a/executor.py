# 파일명: executor.py
"""A2A 어댑터: data Part 하나를 계약 모델로 바꿔 skills에 넘기고, 결과를 data Artifact로 돌려준다."""

import logging

from a2a.helpers.proto_helpers import get_data_parts, new_data_part, new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import Part, TaskState
from logistics_contract import ContractError, parse_request, to_data

from . import a2a_auth, obs_hook
from .auth import AuthStore
from .skills import BusinessKeyConflict, CarrierService, PartnerMismatch

log = logging.getLogger("carrier_a")


class CarrierExecutor(AgentExecutor):
    def __init__(self, service: CarrierService, auth: AuthStore | None = None, a2a_auth_on: bool = False) -> None:
        self.service = service
        self.auth = auth
        self.a2a_auth_on = a2a_auth_on   # 켜면 파트너 키를 확인한다 (Part 4 Ch18)

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        obs_hook.task_received(task.id, task.context_id, context.message)
        updater = obs_hook.ObservedUpdater(event_queue, task.id, task.context_id, task.status.state)
        partner = None
        if self.a2a_auth_on:
            data = get_data_parts(context.message.parts)
            kind = data[0].get("kind") if len(data) == 1 and isinstance(data[0], dict) else None
            who, reason = a2a_auth.check(context.call_context, kind)
            if reason:
                await self._reject(updater, who.name if who else "?", reason, kind)
                return
            partner = who.name
        await updater.update_status(TaskState.TASK_STATE_WORKING)

        try:
            data = get_data_parts(context.message.parts)
            if len(data) != 1:
                raise ContractError("요청에는 data Part(JSON 객체)가 정확히 하나 있어야 한다")
            result = self.service.handle(parse_request(data[0]), partner)
        except PartnerMismatch as exc:
            await self._reject(updater, partner or "?", str(exc), "")
            return
        except (ContractError, BusinessKeyConflict) as exc:
            await self._fail(updater, str(exc))
            return
        except Exception:
            log.exception("요청 처리 중 내부 오류 (task=%s)", task.id)
            await self._fail(updater, "물류사 내부 오류")
            return

        await updater.add_artifact(
            parts=[new_data_part(to_data(result), media_type="application/json")],
            name=result.kind,
        )
        await updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def _reject(self, updater: TaskUpdater, who: str, reason: str, kind: str | None) -> None:
        """인증·권한 거부: Task rejected + 이유 (Ch18). 감사 기록에도 남긴다."""
        if self.auth:
            self.auth.audit(f"partner:{who}", "a2a.denied", kind or "", reason, ok=False)
        await updater.update_status(TaskState.TASK_STATE_REJECTED,
                                    message=updater.new_agent_message(parts=[Part(text=reason)]))

    @staticmethod
    async def _fail(updater: TaskUpdater, reason: str) -> None:
        await updater.update_status(
            TaskState.TASK_STATE_FAILED,
            message=updater.new_agent_message(parts=[Part(text=reason)]),
        )

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("A2A Task 취소는 지원하지 않는다. 예약 취소는 cancel-booking 스킬을 쓴다")
