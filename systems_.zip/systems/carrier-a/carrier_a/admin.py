# 파일명: admin.py
"""서버 관리 도구 — 서버를 거치지 않고 이 시스템의 DB를 직접 고친다(서버 PC의 관리자용).
첫 관리자 만들기, 다른 회사에 줄 파트너 키 발급, 다른 회사가 준 키 넣기, 감사 기록 보기.
설계: systems/docs/security-and-db.md. 여섯 시스템이 같은 파일을 각자 복사해 쓴다.

  uv run python -m <패키지>.admin user add kim --role admin            (비밀번호를 묻는다)
  uv run python -m <패키지>.admin user list
  uv run python -m <패키지>.admin user set kim --role manager --active no
  uv run python -m <패키지>.admin key issue "K정밀웍스" [--skills quote,book-shipment] [--quiet]
  uv run python -m <패키지>.admin key list | key revoke k_1a2b3c4d
  uv run python -m <패키지>.admin outbound set <대상> <키> [--note …]   (대상: 거래처 id·상대 기준 URL·obs)
  uv run python -m <패키지>.admin outbound list | outbound delete <대상>
  uv run python -m <패키지>.admin config show | config reset pricing
  uv run python -m <패키지>.admin audit [--limit 50]

DB 위치는 서버와 같은 설정(APP_DB_PATH, .env)을 따른다.
"""

import argparse
import getpass
import json
import sqlite3
import sys

from .auth import AuthError, AuthStore
from .permissions import PARTNER_SKILLS, ROLES
from .settings import load_settings


def ask_password() -> str:
    first = getpass.getpass("비밀번호: ")
    if first != getpass.getpass("비밀번호 확인: "):
        raise AuthError("두 비밀번호가 다르다")
    return first


def yes_no(value: str | None) -> bool | None:
    return None if value is None else value.lower() in ("y", "yes", "true", "1")


def main(argv: list[str] | None = None) -> int:
    prog = f"{__package__}.admin"
    p = argparse.ArgumentParser(prog=prog, description="서버 관리 도구 (DB 직접)")
    sub = p.add_subparsers(dest="cmd", required=True)

    u = sub.add_parser("user").add_subparsers(dest="action", required=True)
    ua = u.add_parser("add")
    ua.add_argument("username")
    ua.add_argument("--role", required=True, choices=list(ROLES))
    ua.add_argument("--display", default="")
    ua.add_argument("--password", help="스크립트용. 없으면 묻는다")
    u.add_parser("list")
    us = u.add_parser("set")
    us.add_argument("username")
    us.add_argument("--role", choices=list(ROLES))
    us.add_argument("--active", choices=["yes", "no"])
    us.add_argument("--display")
    us.add_argument("--password", help="스크립트용")
    us.add_argument("--ask-password", action="store_true", help="새 비밀번호를 묻는다")

    k = sub.add_parser("key").add_subparsers(dest="action", required=True)
    ki = k.add_parser("issue", help="다른 회사(또는 시스템)에 줄 키를 발급한다")
    ki.add_argument("partner", help="키를 받을 회사 이름 (상대가 요청에 쓰는 이름과 같아야 한다)")
    ki.add_argument("--skills", default=",".join(PARTNER_SKILLS))
    ki.add_argument("--quiet", action="store_true", help="키만 출력 (스크립트용)")
    k.add_parser("list")
    k.add_parser("revoke").add_argument("key_id")

    o = sub.add_parser("outbound").add_subparsers(dest="action", required=True)
    os_ = o.add_parser("set", help="다른 회사가 우리에게 발급한 키를 넣는다")
    os_.add_argument("target")
    os_.add_argument("key")
    os_.add_argument("--note", default="")
    o.add_parser("list")
    o.add_parser("delete").add_argument("target")

    c = sub.add_parser("config").add_subparsers(dest="action", required=True)
    c.add_parser("show")
    c.add_parser("reset", help="DB의 설정을 지워 다음 기동 때 파일 값으로 다시 채운다").add_argument("key")

    sub.add_parser("audit").add_argument("--limit", type=int, default=50)

    args = p.parse_args(argv)
    settings = load_settings()
    store = AuthStore(settings.db_path, ROLES, settings.session_hours)
    try:
        if args.cmd == "user":
            if args.action == "add":
                user = store.add_user(args.username, args.password or ask_password(), args.role, args.display,
                                      actor="admin-tool")
                print(f"사용자 추가: {user['username']} ({user['role_label']})")
            elif args.action == "list":
                for x in store.users():
                    print(f"{x['username']:<16} {x['role_label']:<6} {'사용' if x['active'] else '중지':<4} {x['display_name']}")
            else:
                password = args.password or (ask_password() if args.ask_password else None)
                user = store.update_user(args.username, role=args.role, active=yes_no(args.active),
                                         password=password, display_name=args.display, actor="admin-tool")
                print(f"변경: {user['username']} {user['role_label']} {'사용' if user['active'] else '중지'}")
        elif args.cmd == "key":
            if args.action == "issue":
                key_id, key = store.issue_key(args.partner, args.skills.split(","), actor="admin-tool")
                if args.quiet:
                    print(key)
                else:
                    print(f"발급: {key_id} → {args.partner} ({args.skills})")
                    print(f"키: {key}")
                    print("[!] 키는 지금 한 번만 보인다. 상대 회사에 안전하게 전달한다.")
            elif args.action == "list":
                for x in store.partner_keys():
                    state = "사용" if x["active"] else f"폐기 {x['revoked_at'][:16]}"
                    print(f"{x['key_id']}  {x['partner']:<14} {state:<20} {','.join(x['skills'])}"
                          f"  마지막 사용 {(x['last_used_at'] or '-')[:16]}")
            else:
                store.revoke_key(args.key_id, actor="admin-tool")
                print(f"폐기: {args.key_id}")
        elif args.cmd == "outbound":
            if args.action == "set":
                store.set_outbound(args.target, args.key, args.note, actor="admin-tool")
                print(f"저장: {args.target.rstrip('/')}")
            elif args.action == "list":
                for x in store.outbound_keys():
                    print(f"{x['target']:<32} {x['key']:<14} {x['note']}")
            else:
                store.delete_outbound(args.target, actor="admin-tool")
                print(f"삭제: {args.target}")
        elif args.cmd == "config":
            with sqlite3.connect(settings.db_path) as conn:
                try:
                    rows = conn.execute("SELECT key, value_json, updated_at, updated_by FROM config").fetchall()
                except sqlite3.OperationalError:
                    print("이 시스템에는 DB 설정(config)이 없다", file=sys.stderr)
                    return 1
                if args.action == "show":
                    for key, value, at, by in rows:
                        print(f"[{key}] {at[:16]} by {by}\n  {json.dumps(json.loads(value), ensure_ascii=False)}")
                else:
                    gone = conn.execute("DELETE FROM config WHERE key=?", (args.key,)).rowcount
                    print("지웠다 — 다음 기동 때 파일 값으로 채운다" if gone else f"없는 설정: {args.key}")
                    store.audit("admin-tool", "config.reset", args.key)
        else:
            for x in reversed(store.audit_log(args.limit)):
                mark = "" if x["ok"] else " [거부]"
                print(f"{x['at'][:19]} {x['actor']:<18} {x['action']:<16} {x['target']:<22} {x['detail']}{mark}")
    except AuthError as exc:
        print(f"[!] {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
