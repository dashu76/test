# 파일명: skills.py
"""스킬별 업무 처리. A2A를 모르고, 계약 모델을 받아 계약 모델을 돌려준다.

- 업무상 "안 됨"(견적 거절, 발주 거절, 취소 거절, 조회 결과 없음)은 정상 응답으로 돌려준다.
- 같은 업무키에 다른 내용, 이 서버가 받지 않는 요청은 예외로 올려 Task failed가 되게 한다.
"""

import dataclasses
import json
from collections.abc import Callable
from datetime import datetime, timedelta
from urllib.parse import urlsplit

from logistics_contract import (
    Booking,
    BookingRejected,
    BookingRequest,
    CancelBookingRequest,
    CancelBookingResult,
    ContractError,
    ContractMessage,
    DeliveryNotFound,
    DeliveryQuery,
    DeliveryStatus,
    Quote,
    QuoteDeclined,
    QuoteRequest,
    ShipmentEvent,
    ShipmentStatus,
    parse_response,
    to_data,
)

from .domain import can_cancel, check_transition, decide_quote, EDITABLE, now_kst, Pricing, pricing_from_dict, STATUS_LABEL
from .settings import Settings
from .store import Store, canonical


class BusinessKeyConflict(ValueError):
    """같은 업무키(또는 rfq_id)로 다른 내용이 왔다."""


class StaffError(ValueError):
    """담당자 작업 오류 (없는 운송장, 허용되지 않는 상태 변경 등)."""


class PartnerMismatch(ValueError):
    """파트너 키의 회사와 요청 속 회사가 다르다 (예: 다른 회사 이름으로 견적 요청) → Task rejected."""


class CarrierService:
    def __init__(self, settings: Settings, store: Store, pricing: Pricing,
                 clock: Callable[[], datetime] = now_kst) -> None:
        self.settings = settings
        self.store = store
        self.pricing = pricing
        self.clock = clock

    @property
    def name(self) -> str:
        return self.settings.carrier_name

    def _id(self, kind: str, seq: int) -> str:
        return f"{self.settings.id_prefix}-{kind}-{seq:04d}"

    def handle(self, message: ContractMessage, partner: str | None = None) -> ContractMessage:
        """partner: 파트너 키로 확인된 회사 (인증을 끄면 None → 회사 확인을 하지 않는다)."""
        match message:
            case QuoteRequest():
                return self.quote(message, partner)
            case BookingRequest():
                return self.book(message, partner)
            case CancelBookingRequest():
                return self.cancel(message, partner)
            case DeliveryQuery():
                return self.check_delivery(message, partner)
            case _:
                raise ContractError(f"{self.name}는 {message.kind} 요청을 받지 않는다")

    # ---------- quote ----------

    def quote(self, req: QuoteRequest, partner: str | None = None) -> Quote | QuoteDeclined:
        if partner is not None and req.buyer != partner:
            raise PartnerMismatch(f"{partner}의 키로 다른 회사({req.buyer}) 이름의 견적을 요청할 수 없다")
        key = canonical(to_data(req))
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_quote_by_rfq(conn, req.rfq_id)
            if row is not None:
                if row["request_key"] != key:
                    raise BusinessKeyConflict(f"같은 rfq_id({req.rfq_id})로 다른 견적 요청이 왔다")
                return parse_response(json.loads(row["response_json"]), "quote")

            seq = Store.insert_quote(conn, req.rfq_id, key, now.isoformat())
            decision = decide_quote(req.weight_kg, self.pricing)
            if isinstance(decision, str):
                result = QuoteDeclined(rfq_id=req.rfq_id, carrier=self.name, reason=decision)
                Store.finish_quote(conn, seq, None, "declined", None, to_data(result))
                return result

            price, eta_days = decision
            result = Quote(
                quote_id=self._id("Q", seq), rfq_id=req.rfq_id, carrier=self.name,
                price_krw=price, eta_days=eta_days,
                valid_until=now + timedelta(hours=self.pricing.quote_valid_hours),
            )
            Store.finish_quote(conn, seq, result.quote_id, "quoted",
                               result.valid_until.isoformat(), to_data(result))
            return result

    # ---------- book-shipment ----------

    def _booking_rejection(self, conn, req: BookingRequest, now: datetime, partner: str | None) -> str | None:
        quote = Store.find_quote(conn, req.quote_id)
        if quote is None or quote["status"] != "quoted":
            return "존재하지 않는 견적"
        if partner is not None and json.loads(quote["request_key"]).get("buyer") != partner:
            return "존재하지 않는 견적"   # 다른 회사가 받은 견적 — 있다는 것도 알려 주지 않는다
        if quote["rfq_id"] != req.rfq_id:
            return "견적의 운송 요청 번호가 다르다"
        if datetime.fromisoformat(quote["valid_until"]) < now:
            return "견적 유효기간이 지났다"
        if Store.find_active_booking_for_quote(conn, req.quote_id) is not None:
            return "이미 다른 발주에 사용된 견적"
        if req.event_callback_url is not None:
            host = urlsplit(req.event_callback_url).hostname
            if host not in self.settings.allowed_callback_hosts:
                return f"허용되지 않은 알림 주소: {host}"
        return None

    def book(self, req: BookingRequest, partner: str | None = None) -> Booking | BookingRejected:
        key = canonical(to_data(req))
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_booking_by_key(conn, req.business_key)
            if row is not None:
                if row["request_key"] != key or (partner is not None and row["partner"] not in (None, partner)):
                    raise BusinessKeyConflict("같은 업무키에 다른 발주 내용: 거부")
                return parse_response(json.loads(row["response_json"]), "booking")

            reason = self._booking_rejection(conn, req, now, partner)
            seq = Store.insert_booking(conn, req.business_key, key, req.quote_id,
                                       req.event_callback_url, now.isoformat(), partner)
            if reason is not None:
                result = BookingRejected(business_key=req.business_key, quote_id=req.quote_id, reason=reason)
                Store.finish_booking(conn, seq, None, None, "rejected", None, to_data(result))
                return result

            # 자동 수락 (수동 수락은 P3에서 pending으로 시작)
            quote = Store.find_quote(conn, req.quote_id)
            booking_id = self._id("B", seq)
            tracking_no = f"{self.settings.id_prefix}-T-{100000 + seq}"
            eta = (now + timedelta(days=int(json.loads(quote["response_json"])["eta_days"]))).date()
            result = Booking(status="accepted", business_key=req.business_key, booking_id=booking_id,
                             quote_id=req.quote_id, tracking_no=tracking_no)
            Store.finish_booking(conn, seq, booking_id, tracking_no, ShipmentStatus.PENDING.value,
                                 eta.isoformat(), to_data(result))
            self._status_changed(conn, booking_id, ShipmentStatus.ACCEPTED, "자동 수락", now)
            return result

    def _status_changed(self, conn, booking_id: str, status: ShipmentStatus, note: str, now: datetime) -> int:
        """배송 상태를 바꾸고, 알림 주소가 있으면 같은 트랜잭션에서 구매사 알림을 outbox에 쌓는다."""
        seq = Store.set_booking_status(conn, booking_id, status.value, note, now.isoformat())
        row = Store.find_booking(conn, booking_id)
        if row["callback_url"]:
            event = ShipmentEvent(event_id=f"{self.name}:{booking_id}:{seq}", carrier=self.name,
                                  booking_id=booking_id, tracking_no=row["tracking_no"], seq=seq,
                                  shipment_status=status, at=now, note=note)
            Store.enqueue_event(conn, event.event_id, booking_id, row["callback_url"], to_data(event),
                                now.isoformat())
        return seq

    # ---------- cancel-booking ----------

    @staticmethod
    def _owned(booking, partner: str | None) -> bool:
        """그 회사의 발주인가. 인증 전·기존 데이터(partner 없음)는 막지 않는다."""
        return booking is not None and (partner is None or booking["partner"] in (None, partner))

    def cancel(self, req: CancelBookingRequest, partner: str | None = None) -> CancelBookingResult:
        key = canonical(to_data(req))
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_cancel(conn, req.business_key)
            if row is not None:
                if row["request_key"] != key:
                    raise BusinessKeyConflict("같은 업무키에 다른 취소 내용: 거부")
                return parse_response(json.loads(row["response_json"]), "cancel-booking-result")

            booking = Store.find_booking(conn, req.booking_id)
            if not self._owned(booking, partner):
                result = CancelBookingResult(status="rejected", booking_id=req.booking_id, reason="존재하지 않는 예약")
            else:
                current = ShipmentStatus(booking["status"])
                if can_cancel(current):
                    self._status_changed(conn, req.booking_id, ShipmentStatus.CANCELLED,
                                         req.reason or "구매사 요청 취소", now)
                    result = CancelBookingResult(status="cancelled", booking_id=req.booking_id)
                else:
                    result = CancelBookingResult(status="rejected", booking_id=req.booking_id,
                                                 reason=f"취소할 수 없는 상태: {STATUS_LABEL[current]}")
            Store.insert_cancel(conn, req.business_key, key, to_data(result), now.isoformat())
            return result

    # ---------- check-delivery ----------

    def check_delivery(self, req: DeliveryQuery, partner: str | None = None) -> DeliveryStatus | DeliveryNotFound:
        with self.store.read() as conn:
            row = Store.find_booking_by_tracking(conn, req.tracking_no)
            if not self._owned(row, partner):
                return DeliveryNotFound(tracking_no=req.tracking_no)
            return DeliveryStatus(
                tracking_no=req.tracking_no,
                shipment_status=ShipmentStatus(row["status"]),
                seq=row["seq"],
                eta=row["eta"],
                note=Store.last_note(conn, row["booking_id"]),
            )

    # ---------- 물류사 내부 작업 (담당자 API·CLI) ----------

    def shipments(self) -> list[dict]:
        with self.store.read() as conn:
            return [dict(tracking_no=r["tracking_no"], booking_id=r["booking_id"], status=r["status"],
                         status_label=STATUS_LABEL[ShipmentStatus(r["status"])], seq=r["seq"], eta=r["eta"],
                         note=Store.last_note(conn, r["booking_id"]), notify=bool(r["callback_url"]))
                    for r in Store.shipments(conn)]

    def update_pricing(self, changes: dict, actor: str) -> Pricing:
        """요금 규칙을 고친다 (화면 설정 보기 · admin 권한). DB가 원본이 되고 다음 견적부터 반영된다."""
        current = dataclasses.asdict(self.pricing)
        merged = {**current, **{k: v for k, v in changes.items() if k in EDITABLE and k in current}}
        pricing = pricing_from_dict(merged)
        self.store.set_config("pricing", dataclasses.asdict(pricing), actor, self.clock().isoformat())
        self.pricing = pricing
        return pricing

    def quotes(self) -> list[dict]:
        """견적 요청함 (화면). 요청 내용은 request_key(요청의 정규형 JSON)에서 읽는다."""
        with self.store.read() as conn:
            rows = Store.all_quotes(conn)
        views = []
        for r in rows:
            req, res = json.loads(r["request_key"]), json.loads(r["response_json"] or "{}")
            views.append(dict(
                rfq_id=r["rfq_id"], quote_id=r["quote_id"], status=r["status"], buyer=req.get("buyer"),
                item=req.get("item"), weight_kg=req.get("weight_kg"), origin=req.get("origin"),
                destination=req.get("destination"), need_by=req.get("need_by"), price_krw=res.get("price_krw"),
                eta_days=res.get("eta_days"), co2_kg=res.get("co2_kg"), valid_until=r["valid_until"],
                reason=res.get("reason"), decided_by="auto", created_at=r["created_at"]))
        return views

    def bookings(self) -> list[dict]:
        """발주 수신함 (화면). 거절된 발주도 남는다."""
        with self.store.read() as conn:
            rows = Store.all_bookings(conn)
        views = []
        for r in rows:
            req, res = json.loads(r["request_key"]), json.loads(r["response_json"] or "{}")
            views.append(dict(
                booking_id=r["booking_id"], business_key=r["business_key"], rfq_id=req.get("rfq_id"),
                quote_id=r["quote_id"], status=r["status"], tracking_no=r["tracking_no"], seq=r["seq"],
                eta=r["eta"], callback_url=r["callback_url"], reason=res.get("reason"), decided_by="auto",
                created_at=r["created_at"], updated_at=r["updated_at"]))
        return views

    def history(self, tracking_no: str) -> list[dict]:
        with self.store.read() as conn:
            row = Store.find_booking_by_tracking(conn, tracking_no)
            if row is None:
                raise StaffError(f"없는 운송장: {tracking_no}")
            return [dict(seq=h["seq"], status=h["status"], note=h["note"], at=h["at"])
                    for h in Store.history(conn, row["booking_id"])]

    def advance_shipment(self, tracking_no: str, new_status: ShipmentStatus, note: str = "") -> int:
        """S-17: 집하·운송·통관·배송 완료. 구매사 알림이 outbox에 함께 쌓인다."""
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_booking_by_tracking(conn, tracking_no)
            if row is None:
                raise StaffError(f"없는 운송장: {tracking_no}")
            try:
                check_transition(ShipmentStatus(row["status"]), new_status)
            except ValueError as exc:
                raise StaffError(str(exc)) from exc
            return self._status_changed(conn, row["booking_id"], new_status, note, now)
