# 파일명: a2a_auth.py
"""회사 사이 A2A 인증 — 파트너 키 (Part 4 Ch18). 설계: systems/docs/security-and-db.md 2장

- 상대는 우리가 발급한 키를 X-Partner-Key 헤더로 내민다. Agent Card의 securitySchemes에 그렇게 적는다.
- SendMessage·SendStreamingMessage: 실행기가 판정한다(키 없음·틀림·허용되지 않은 스킬 → Task rejected + 이유).
- 그 밖의 JSON-RPC(GetTask·ListTasks·CancelTask …): JsonRpcKeyGuard가 키를 확인하고 없으면 401.
- 다섯 업무 시스템이 같은 파일을 각자 복사해 쓴다.
"""

import json

from a2a.auth.user import UnauthenticatedUser, User
from a2a.server.context import ServerCallContext
from a2a.server.routes.common import DefaultServerCallContextBuilder
from a2a.types.a2a_pb2 import APIKeySecurityScheme, SecurityRequirement, SecurityScheme, StringList
from logistics_contract import (
    SKILL_BOOK_SHIPMENT,
    SKILL_CANCEL_BOOKING,
    SKILL_CHECK_DELIVERY,
    SKILL_QUOTE,
    SKILL_RECEIVE_SHIPMENT_EVENT,
)

from .auth import AuthStore, Partner

HEADER = "X-Partner-Key"
SCHEME = "partnerKey"
SEND_METHODS = {"SendMessage", "SendStreamingMessage"}   # 실행기가 판정한다 (Ch18처럼 rejected + 이유)
SKILL_OF_KIND = {
    "quote-request": SKILL_QUOTE,
    "booking-request": SKILL_BOOK_SHIPMENT,
    "cancel-booking-request": SKILL_CANCEL_BOOKING,
    "delivery-query": SKILL_CHECK_DELIVERY,
    "shipment-event": SKILL_RECEIVE_SHIPMENT_EVENT,
}
NO_KEY = f"파트너 키가 없거나 맞지 않는다 ({HEADER} 헤더에 발급받은 키를 넣어 보낸다)"


class PartnerUser(User):
    def __init__(self, partner: Partner) -> None:
        self.partner = partner

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def user_name(self) -> str:
        return self.partner.name


class PartnerContextBuilder(DefaultServerCallContextBuilder):
    """요청 헤더의 파트너 키로 ServerCallContext.user를 채운다 (Ch18 ApiKeyContextBuilder와 같은 자리)."""

    def __init__(self, auth: AuthStore) -> None:
        self.auth = auth

    def build_user(self, request) -> User:
        partner = self.auth.partner_for_key(request.headers.get(HEADER))
        return PartnerUser(partner) if partner else UnauthenticatedUser()


def card_security() -> dict:
    """Agent Card에 실을 보안 항목: '이 에이전트를 부르려면 X-Partner-Key 헤더가 필요하다'."""
    return {
        "security_schemes": {SCHEME: SecurityScheme(api_key_security_scheme=APIKeySecurityScheme(
            name=HEADER, location="header", description="계약할 때 발급받은 파트너 키를 헤더에 담아 보낸다"))},
        "security_requirements": [SecurityRequirement(schemes={SCHEME: StringList(list=[])})],
    }


def partner_of(call_context: ServerCallContext | None) -> Partner | None:
    user = call_context.user if call_context else None
    return user.partner if isinstance(user, PartnerUser) else None


def check(call_context: ServerCallContext | None, kind: str | None) -> tuple[Partner | None, str | None]:
    """(확인된 상대, 거부 이유). kind가 None이면 키만 본다."""
    partner = partner_of(call_context)
    if partner is None:
        return None, NO_KEY
    skill = SKILL_OF_KIND.get(kind or "")
    if kind is not None and skill not in partner.skills:
        return partner, f"{partner.name}의 키로는 {skill or kind} 스킬을 쓸 수 없다"
    return partner, None


class JsonRpcKeyGuard:
    """SendMessage 말고는 실행기를 거치지 않으므로(GetTask·ListTasks …), 여기서 키를 확인한다(ASGI 미들웨어)."""

    def __init__(self, app, auth: AuthStore, path: str = "/") -> None:
        self.app, self.auth, self.path = app, auth, path

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] != "POST" or scope["path"] != self.path:
            return await self.app(scope, receive, send)
        chunks, more = [], True
        while more:
            message = await receive()
            chunks.append(message.get("body", b""))
            more = message.get("more_body", False)
        body = b"".join(chunks)
        try:
            payload = json.loads(body or b"{}")
            method, rpc_id = (payload.get("method"), payload.get("id")) if isinstance(payload, dict) else (None, None)
        except ValueError:
            method, rpc_id = None, None
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope["headers"]}
        if method not in SEND_METHODS and self.auth.partner_for_key(headers.get(HEADER.lower())) is None:
            self.auth.audit("partner:?", "a2a.denied", str(method), "키 없음·틀림", ok=False)
            error = json.dumps({"jsonrpc": "2.0", "id": rpc_id,
                                "error": {"code": -32001, "message": NO_KEY}}, ensure_ascii=False).encode()
            await send({"type": "http.response.start", "status": 401,
                        "headers": [(b"content-type", b"application/json; charset=utf-8"),
                                    (b"www-authenticate", f'ApiKey header="{HEADER}"'.encode())]})
            await send({"type": "http.response.body", "body": error})
            return

        sent = False

        async def replay():
            nonlocal sent
            if not sent:
                sent = True
                return {"type": "http.request", "body": body, "more_body": False}
            return await receive()

        await self.app(scope, replay, send)


def key_headers(auth: AuthStore | None, target: str) -> dict[str, str]:
    """상대가 우리에게 발급한 키(outbound_keys)로 요청 헤더를 만든다. 없으면 빈 헤더(상대가 거부하면 그 이유가 남는다)."""
    key = auth.outbound_key(target) if auth else None
    return {HEADER: key} if key else {}
