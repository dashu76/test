# 파일명: obs_hook.py
"""관제 허브(선택)에 관찰 이벤트를 보낸다. A2A_OBS_URL이 비어 있으면 아무 일도 하지 않는다 (S-25).

- 업무 코드는 emit()만 부르고 기다리지 않는다. 보내기는 백그라운드 스레드가 한다.
- 허브가 꺼져 있거나 느려도 업무는 그대로 진행한다. 허브에 닿지 않으면 잠시 이벤트를 버린다
  (관찰 기록은 업무 기록이 아니다. 업무 상태의 원본은 DB).
- 이벤트 모양: {v, eventId, ts, agentId, side(server|client), type, taskId, contextId, process, payload}
  server: 일을 받은 쪽(task.*), client: 일을 맡긴 쪽(request.*, card.*)
"""

import atexit
import itertools
import os
import queue
import threading
import time

import httpx
from a2a.helpers.proto_helpers import get_data_parts, get_text_parts
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import AgentCard, Message, TaskState

RETRY_AFTER_S = 5.0   # 허브에 닿지 않으면 이 시간 동안은 보내지 않고 버린다
SUMMARY_KEYS = ("kind", "status", "shipment_status", "rfq_id", "booking_id", "tracking_no", "seq",
                "price_krw", "eta_days", "reason")
REPORTED = {TaskState.TASK_STATE_COMPLETED, TaskState.TASK_STATE_FAILED, TaskState.TASK_STATE_CANCELED,
            TaskState.TASK_STATE_REJECTED, TaskState.TASK_STATE_INPUT_REQUIRED}

_queue: queue.Queue = queue.Queue(maxsize=10000)
_numbers = itertools.count(1)
_state = {"url": "", "name": "", "agent": "", "down_until": 0.0, "key": ""}
_thread: threading.Thread | None = None
_cards: dict[str, bool] = {}   # 주소 → 마지막 카드 조회 성공 여부 (바뀔 때만 알린다)


def start(name: str, agent_url: str, obs_url: str, obs_key: str = "") -> None:
    """name: 이 시스템 이름(process), agent_url: 자기 공개 주소(agentId), obs_url: 허브 주소(비면 끔),
    obs_key: 허브가 발급한 수집 키(X-Obs-Key)."""
    global _thread
    _state.update(url=(obs_url or "").rstrip("/"), name=name, agent=agent_url.rstrip("/"), down_until=0.0,
                  key=obs_key or "")
    _cards.clear()
    if _state["url"] and (_thread is None or not _thread.is_alive()):
        _thread = threading.Thread(target=_send_loop, name="obs-hook", daemon=True)
        _thread.start()
        atexit.register(flush)


def stop(timeout_s: float = 2.0) -> None:
    flush(timeout_s)
    _state["url"] = ""


def enabled() -> bool:
    return bool(_state["url"])


def emit(type_: str, side: str = "server", payload: dict | None = None, task_id: str = "",
         context_id: str = "") -> None:
    url = _state["url"]
    if not url:
        return
    event = {
        "v": 1,
        "eventId": f"{_state['name']}-{os.getpid()}-{next(_numbers)}",
        "ts": int(time.time() * 1000),
        "agentId": _state["agent"],
        "side": side,
        "type": type_,
        "taskId": task_id,
        "contextId": context_id,
        "process": _state["name"],
        "payload": payload or {},
    }
    try:
        _queue.put_nowait((url, event))
    except queue.Full:
        pass


def flush(timeout_s: float = 2.0) -> None:
    """쌓인 이벤트를 보낼 때까지 최대 timeout_s 기다린다 (종료 직전·테스트용)."""
    deadline = time.monotonic() + timeout_s
    while _queue.unfinished_tasks and time.monotonic() < deadline:
        time.sleep(0.02)


def _send_loop() -> None:
    with httpx.Client(timeout=2) as http:
        while True:
            url, event = _queue.get()
            try:
                if time.monotonic() >= _state["down_until"]:
                    http.post(url + "/events", json=event,
                              headers={"X-Obs-Key": _state["key"]} if _state["key"] else None)
            except httpx.TransportError:
                _state["down_until"] = time.monotonic() + RETRY_AFTER_S
            except Exception:
                pass
            finally:
                _queue.task_done()


# 요약 ------------------------------------------------------------------------

def short(text: str, size: int = 160) -> str:
    text = " ".join(str(text).split())
    return text if len(text) <= size else text[:size] + "…"


def _value(v):
    return int(v) if isinstance(v, float) and v.is_integer() else v   # A2A data Part의 174000.0 → 174000


def summarize(data: dict) -> str:
    """계약 메시지 한 줄 요약: 'quote quoted RFQ-… 174000'."""
    return short(" ".join(str(_value(data[k])) for k in SUMMARY_KEYS if data.get(k) not in (None, "")))


def describe(message: Message | None) -> str:
    if message is None:
        return ""
    data = get_data_parts(message.parts)
    if data and isinstance(data[0], dict):
        return summarize(data[0])
    return short("".join(get_text_parts(message.parts)))


def state_name(state) -> str:
    return TaskState.Name(state) if state is not None else ""


# 서버 쪽: Task 상태 ---------------------------------------------------------------

def task_received(task_id: str, context_id: str, message: Message) -> None:
    emit("task.received", "server", {"text": describe(message)}, task_id, context_id)


class ObservedUpdater(TaskUpdater):
    """TaskUpdater와 같고, 상태를 바꿀 때마다 허브에 task.state를 알린다."""

    def __init__(self, event_queue, task_id: str, context_id: str, state=None) -> None:
        super().__init__(event_queue, task_id, context_id)
        self._state = state
        self._result = ""

    async def add_artifact(self, parts, *args, **kwargs) -> None:
        await super().add_artifact(parts, *args, **kwargs)
        data = get_data_parts(parts)
        if data and isinstance(data[0], dict):
            self._result = summarize(data[0])

    async def update_status(self, state, message: Message | None = None, *args, **kwargs) -> None:
        await super().update_status(state, message, *args, **kwargs)
        if enabled():
            payload = {"from": state_name(self._state) or None, "to": state_name(state)}
            if state in REPORTED:
                payload["result"] = self._result or describe(message)
            elif message is not None:
                payload["note"] = describe(message)
            emit("task.state", "server", payload, self.task_id, self.context_id)
        self._state = state


# 클라이언트 쪽: 카드 조회·요청 ----------------------------------------------------------

def card_fetched(url: str, card: AgentCard) -> None:
    url = url.rstrip("/")
    if _cards.get(url) is True:
        return
    _cards[url] = True
    emit("card.fetched", "client", {"url": url, "name": card.name, "skills": [s.id for s in card.skills]})


def card_failed(url: str, error: BaseException) -> None:
    url = url.rstrip("/")
    if _cards.get(url) is False:
        return
    _cards[url] = False
    emit("card.failed", "client", {"url": url, "error": type(error).__name__})


class RequestTrace:
    """다른 회사에 보낸 요청 하나: request.sent → request.done(상태가 바뀔 때마다) → … | request.error.
    상대가 아직 처리 중(working)이면 끝난 것이 아니다. 나중에 결과를 확인하면 같은 요청의 request.done을 다시 보낸다."""

    RUNNING = {"TASK_STATE_SUBMITTED", "TASK_STATE_WORKING"}

    def __init__(self, to: str, to_name: str, skill: str, text: str = "", context_id: str = "",
                 announce: bool = True) -> None:
        self.base = {"requestId": f"{_state['name']}-{os.getpid()}-r{next(_numbers)}", "to": to.rstrip("/"),
                     "toName": to_name, "skill": skill}
        self.task_id = ""
        self.context_id = context_id
        self.state = ""
        self.finished = False
        if announce:
            emit("request.sent", "client", {**self.base, "text": short(text)}, "", context_id)

    @classmethod
    def resume(cls, to: str, to_name: str, task_id: str) -> "RequestTrace":
        """보낸 기록이 없는 Task(재시작 등)를 나중에 확인할 때. 허브 화면은 taskId로 원래 요청을 찾는다."""
        trace = cls(to, to_name, "", announce=False)
        trace.task_id = task_id
        return trace

    def done(self, state, task_id: str = "", context_id: str = "", **extra) -> None:
        self.task_id = task_id or self.task_id
        self.context_id = context_id or self.context_id
        self.state = _name(state)
        self.finished = self.state not in self.RUNNING
        emit("request.done", "client", {**self.base, "state": self.state, **extra}, self.task_id, self.context_id)

    def error(self, error: BaseException) -> None:
        if self.finished:
            return
        self.finished = True
        emit("request.error", "client", {**self.base, "error": type(error).__name__, "detail": short(str(error))},
             self.task_id, self.context_id)


def _name(state) -> str:
    return state if isinstance(state, str) else state_name(state)
