# 파일명: apply.py
"""2_API활용/a2a 의 두 에이전트(인수인계 9101 · 자재대응 9102)에 사무 공간 책상을 주는 설정을 관제 허브에 넣는다.
둘에게 일을 맡기는 오케스트레이터(test_client.py)도 같은 ops 구역에 자리를 정해 둔다 (중계 --no-clients 면 안 나옴).

  python apply.py            # 미리 보기만 (아무것도 바꾸지 않음)
  python apply.py --apply    # 적용: ① obs-hub/.env 감시 주소  ② office.html 자리  ③ 중계용 수집 키(.obs_key)
  python apply.py --undo     # 되돌리기: ①② 원래대로, 키 파일 삭제 (허브의 키 폐기는 안내만)

여러 번 실행해도 같은 결과다. 적용·되돌리기 뒤에는 관제 허브를 다시 켠다.
전제: 사무 공간 화면이 허브에 들어가 있다 (obs-hub/obs_hub/ui/office.html — 안내서 2장).
"""

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SYSTEMS = HERE.parents[2]
HUB_DIR = SYSTEMS / "obs-hub"
ENV = HUB_DIR / ".env"
OFFICE = HUB_DIR / "obs_hub" / "ui" / "office.html"
KEY_FILE = HERE / ".obs_key"
PROCESS = "a2a-office"   # 수집 키 이름 = 중계가 붙이는 process

DEFAULT_WATCH = [f"http://127.0.0.1:{p}" for p in (5010, 5020, 5021, 5022, 5023)]   # obs_hub/settings.py 기본값
NEW_WATCH = ["http://127.0.0.1:9101", "http://127.0.0.1:9102"]

ANCHOR = "    {name: '물류사 C',             url: 'http://127.0.0.1:5023', zone: 'content', org: '물류사 C'},\n"
AGENT_LINES = (
    "    {name: '교대 인수인계 에이전트', url: 'http://127.0.0.1:9101', zone: 'ops', org: '사내 생산'},   // a2a-bridge\n"
    "    {name: '자재대응 에이전트',     url: 'http://127.0.0.1:9102', zone: 'ops', org: '사내 생산'},   // a2a-bridge\n"
    "    {name: '오케스트레이터(test_client)', url: 'client:orchestrator', role: 'client', zone: 'ops', org: '사내 생산'},   // a2a-bridge\n"
)
OPS_OLD, OPS_NEW = "ops: '관제'}", "ops: '사내 생산(교대·자재)'}"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8") if p.exists() else ""


def write(p: Path, s: str, do: bool, what: str) -> None:
    print(("  변경  " if do else "  (미리 보기) ") + what)
    if do:
        p.write_text(s, encoding="utf-8", newline="\n")


def env_step(undo: bool, do: bool) -> None:
    lines = read(ENV).split("\n") if ENV.exists() else ["# 로컬 시험용 (git 제외)", ""]
    idx = next((i for i, l in enumerate(lines) if l.startswith("APP_WATCH_URLS=")), None)
    urls = [u.strip() for u in lines[idx].split("=", 1)[1].split(",") if u.strip()] if idx is not None else list(DEFAULT_WATCH)
    want = [u for u in urls if u not in NEW_WATCH] if undo else urls + [u for u in NEW_WATCH if u not in urls]
    if want == urls and (idx is not None or undo):
        print(f"  그대로 {ENV.name}: APP_WATCH_URLS 이미 {'원래대로' if undo else '적용됨'}")
        return
    if undo and want == DEFAULT_WATCH and idx is not None:
        lines.pop(idx)                       # 이 스크립트가 넣은 줄이면 지워서 기본값으로
    elif idx is None:
        lines.insert(len(lines) - 1 if lines[-1] == "" else len(lines), "APP_WATCH_URLS=" + ",".join(want))
    else:
        lines[idx] = "APP_WATCH_URLS=" + ",".join(want)
    write(ENV, "\n".join(lines), do, f"{ENV.relative_to(SYSTEMS)}: 감시 주소 {'에서 9101·9102 뺌' if undo else '에 9101·9102 추가'}")


def office_step(undo: bool, do: bool) -> None:
    s = read(OFFICE)
    if not s:
        print(f"  건너뜀 {OFFICE.relative_to(SYSTEMS)} 없음 — 먼저 사무 공간 화면을 허브에 적용하세요 (안내서 2장)")
        return
    has = "url: 'http://127.0.0.1:9101'" in s
    if undo:
        if not has and OPS_NEW not in s:
            print("  그대로 office.html: 이미 원래대로"); return
        s = s.replace(AGENT_LINES, "").replace(OPS_NEW, OPS_OLD)
    else:
        if has:
            print("  그대로 office.html: 이미 적용됨"); return
        if s.count(ANCHOR) != 1:
            sys.exit("office.html 설정 블록에서 '물류사 C' 줄을 찾지 못했습니다. 손으로 고쳤다면 README의 두 줄을 직접 넣으세요.")
        s = s.replace(ANCHOR, ANCHOR + AGENT_LINES).replace(OPS_OLD, OPS_NEW)
    write(OFFICE, s, do, f"{OFFICE.relative_to(SYSTEMS)}: ops 구역 {'원래대로' if undo else '에 두 에이전트 자리'}")


def key_step(undo: bool, do: bool) -> None:
    if undo:
        if KEY_FILE.exists():
            print(("  삭제  " if do else "  (미리 보기) 삭제 ") + KEY_FILE.name)
            if do:
                KEY_FILE.unlink()
        print(f"  안내  허브의 키 폐기: cd obs-hub; uv run python -m obs_hub.admin key list → key revoke <id>  ({PROCESS})")
        return
    if KEY_FILE.exists():
        print(f"  그대로 {KEY_FILE.name}: 이미 있음 (새로 받으려면 지우고 다시 실행)"); return
    cmd = ["uv", "run", "--quiet", "python", "-m", "obs_hub.admin", "key", "issue", PROCESS, "--skills", "ingest", "--quiet"]
    print(("  발급  " if do else "  (미리 보기) 발급 ") + f"관제 허브 수집 키 '{PROCESS}' → {KEY_FILE.name}")
    if do:
        r = subprocess.run(cmd, cwd=HUB_DIR, capture_output=True, text=True, encoding="utf-8")
        key = next((l.strip() for l in reversed(r.stdout.splitlines()) if l.strip().startswith("pk_")), "")
        if r.returncode or not key:
            sys.exit(f"키 발급 실패: {r.stderr or r.stdout}")
        KEY_FILE.write_text(key + "\n", encoding="utf-8", newline="\n")


def main() -> None:
    ap = argparse.ArgumentParser(description="a2a 두 에이전트 → 관제 허브 사무 공간 책상")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--apply", action="store_true")
    g.add_argument("--undo", action="store_true")
    a = ap.parse_args()
    do = a.apply or a.undo
    print(f"[{'되돌리기' if a.undo else '적용' if a.apply else '미리 보기'}] {SYSTEMS}")
    env_step(a.undo, do)
    office_step(a.undo, do)
    key_step(a.undo, do)
    if do:
        print("완료. 관제 허브를 다시 켜세요 (obs-hub 창에서 Ctrl+C → uv run python -m obs_hub).")
    else:
        print("바꾼 것 없음. 적용하려면 --apply")


if __name__ == "__main__":
    main()
