# 파일명: material_analysis.py
"""자재대응 Agent가 끝낸 Task에서 사무 공간 차트용 「간략 분석」을 만든다. 표준 라이브러리만 쓴다.

재료는 Task 결과물(material_check)의 DataPart — 에이전트가 실제로 부른 도구 기록(tool_log)이다.
  get_bom               → 부품과 제품 1개당 소요량
  get_inventory         → 현재 재고
  get_inbound_schedule  → 생산 시작 전 입고 예정 수량
  calculate_shortage    → 생산 수량 (production_qty)
mock 모드처럼 에이전트가 재고·입고를 조회하지 않았으면 --material-data 폴더의 자료 파일(현재재고.csv·입고예정.csv)로
채우고 source="data"로 표시한다(화면은 「자료 기준 참고값」으로 구분). 자료 폴더를 주지 않으면 비워 둔다.

분석 모양:
  {"product": "P-100", "qty": 20, "source": "agent"|"data"|"none", "tools": 4, "verdict": "부족 1종",
   "parts": [{"name": "베어링 A", "need": 40, "stock": 30, "inbound": 20, "short": 0}, ...]}
  등록되지 않은 제품: {"product": "P-999", "notFound": true}
"""

import csv
import json
import re
import urllib.request
from pathlib import Path

QTY = re.compile(r"(-?\d+)\s*개")
PRODUCT = re.compile(r"P-\d+")


def get_task(agent_url: str, task_id: str) -> dict | None:
    body = {"jsonrpc": "2.0", "id": "bridge", "method": "GetTask", "params": {"id": task_id}}
    req = urllib.request.Request(agent_url.rstrip("/") + "/", data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json", "A2A-Version": "1.0"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return json.loads(r.read() or b"{}").get("result")
    except (OSError, ValueError):
        return None


def material_data(task: dict) -> dict | None:
    for art in task.get("artifacts", []):
        if art.get("name") == "material_check":
            for part in art.get("parts", []):
                if isinstance(part.get("data"), dict):
                    return part["data"]
    return None


def read_rows(folder: Path | None, name: str) -> list[dict]:
    if not folder or not (folder / name).exists():
        return []
    with open(folder / name, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


class Analyzer:
    def __init__(self, data_dir: Path | None = None) -> None:
        self.data_dir = data_dir
        self.memory: dict[str, dict] = {}   # contextId → 지난 질문의 제품·수량 (「30개로 늘리면?」처럼 이어 묻기)

    def analyze(self, task: dict) -> dict | None:
        data = material_data(task)
        if not data:
            return None
        log = data.get("tool_log") or []
        ctx = task.get("contextId", "")
        last = self.memory.get(ctx, {})
        question = str(data.get("question") or "")

        boms = [t for t in log if t.get("tool") == "get_bom"]
        if not boms:
            return None                                   # 되물음 등 — 도구를 안 썼으면 차트 없음
        bom = boms[-1].get("result") or {}
        product = bom.get("product_code") or (boms[-1].get("input") or {}).get("product_code", "")
        if not bom.get("found"):
            return {"product": product, "notFound": True, "tools": int(data.get("tool_count") or len(log))}

        qtys = [t["input"].get("production_qty") for t in log
                if t.get("tool") == "calculate_shortage" and isinstance(t.get("input"), dict)]
        qty = next((int(q) for q in qtys if isinstance(q, (int, float))), None)
        if qty is None:
            asked = [int(q) for q in QTY.findall(question)]
            same = PRODUCT.findall(question) in ([], [product])   # 다른 제품 수량을 가져오지 않게
            qty = asked[0] if asked and same else last.get("qty") if last.get("product") == product else None
        if not qty or qty <= 0:
            return None
        self.memory[ctx] = {"product": product, "qty": qty}

        stock_of = {t["result"].get("부품코드"): t["result"].get("현재재고") for t in log
                    if t.get("tool") == "get_inventory" and (t.get("result") or {}).get("found")}
        inbound_of = {t["result"].get("부품코드"): t["result"].get("시작전입고예정수량") for t in log
                      if t.get("tool") == "get_inbound_schedule" and isinstance(t.get("result"), dict)
                      and "시작전입고예정수량" in t["result"]}
        source = "agent" if stock_of else "none"
        if not stock_of and self.data_dir:
            stock_of = {r["부품코드"]: int(r["현재재고"]) for r in read_rows(self.data_dir, "현재재고.csv")}
            inbound_of = {}
            for r in read_rows(self.data_dir, "입고예정.csv"):
                inbound_of[r["부품코드"]] = inbound_of.get(r["부품코드"], 0) + int(r["입고예정수량"])
            source = "data" if stock_of else "none"

        parts = []
        for p in bom.get("parts", []):
            code, need = p.get("부품코드"), int(p.get("제품1개당소요량") or 0) * qty
            stock = stock_of.get(code)
            inbound = inbound_of.get(code, 0) if stock is not None else None
            short = max(0, need - stock - (inbound or 0)) if stock is not None else None
            parts.append({"name": p.get("부품명") or code, "need": need, "stock": stock, "inbound": inbound, "short": short})

        if source == "none":
            verdict = "재고·입고 미조회"
        elif any(p["short"] for p in parts):
            verdict = f"부족 {sum(1 for p in parts if p['short'])}종"
        elif any(p["need"] > p["stock"] for p in parts):
            verdict = "입고 반영 시 가능"
        else:
            verdict = "재고로 가능"
        return {"product": product, "qty": qty, "source": source, "verdict": verdict,
                "tools": int(data.get("tool_count") or len(log)), "parts": parts}
