# 파일명: office_bridge.py
"""a2a 사무공간 허브(:9900)의 이벤트를 관제 허브(:5090)로 넘겨 주는 중계.

2_API활용/a2a 쪽 코드는 고치지 않는다. 9900의 /stream(SSE)을 읽어
  - agent.heartbeat 는 버린다 (2초마다 와서 허브 DB만 채운다. 출근 여부는 관제 허브의 Agent Card 감시가 맡는다)
  - "process" 를 붙인다 (관제 허브는 수집 키 이름 == process 인 이벤트만 받는다)
  - "side" 는 넣지 않는다 (사무 공간 형식 그대로. side 가 있으면 화면이 책 형식으로 보고 다시 바꾼다)
  - payload 의 "zone" 은 뺀다 (자리는 관제 허브 office.html 설정이 정한다. a2a agents.json 구역과 섞이지 않게)
그리고 관제 허브 POST /events 로 보낸다 (헤더 X-Obs-Key).

9900은 접속할 때마다 지난 이벤트부터 다시 보내지만 관제 허브가 eventId로 중복을 거른다.
어느 쪽이 꺼져도 몇 초 뒤 다시 붙는다. 표준 라이브러리만 쓴다(어느 파이썬으로도 실행).

a2a office_hub 는 두 가지 판이 있어 둘 다 받는다 (스트림 주소는 /events/stream → 없으면 /stream 순으로 찾는다):
  - 사무 공간 형식  {eventId, ts(ms), agentId, type, taskId, payload{...}}          → 그대로
  - 간이 형식       {seq, ts(ISO), agentId("…/"), type, text, taskId, contextId}  → 사무 공간 형식으로 바꾼다
    (eventId = <process>-<ts>-<seq>, ts 는 ms, agentId 끝 '/' 제거, text 는 type 에 맞는 payload 키로)

  python office_bridge.py                          # 기본: 9900 → 5090, 키는 같은 폴더 .obs_key
  python office_bridge.py --source http://127.0.0.1:9900 --hub http://127.0.0.1:5090 --key-file .obs_key
  python office_bridge.py --once                   # 지금까지 쌓인 것만 넘기고 끝 (점검용)
  python office_bridge.py --no-clients             # 오케스트레이터(test_client) 책상은 빼고 두 에이전트만
  python office_bridge.py --only http://127.0.0.1:9102   # 이 에이전트 이벤트만 (여러 번 가능)
  python office_bridge.py --only http://127.0.0.1:9102 --material-data "C:\\1_a2a_lab\\API활용\\02_자재대응_Agent\\참고"

task.done 이면 그 Task를 GetTask 로 다시 읽어, 자재대응 결과물(material_check)이 있으면 차트용 간략 분석을
payload.analysis 로 붙인다 (material_analysis.py). 사무 공간 화면이 말풍선 옆에 분석 창으로 그린다.
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

from material_analysis import Analyzer, get_task

HERE = Path(__file__).resolve().parent
SKIP = {"agent.heartbeat"}
STREAM_PATHS = ("/events/stream", "/stream")
TEXT_KEY = {"agent.online": "name", "task.started": "name", "task.done": "result",   # 간이 형식 text → payload 키
            "task.failed": "reason", "agent.offline": "reason"}                      # 나머지(agent.say·alert)는 text


def load_key(path: Path) -> str:
    key = os.environ.get("A2A_BRIDGE_OBS_KEY", "").strip()
    if not key and path.exists():
        key = path.read_text(encoding="utf-8").strip()
    if not key:
        sys.exit(f"수집 키가 없습니다: {path} (README 2단계-①) 또는 환경 변수 A2A_BRIDGE_OBS_KEY")
    return key


def from_simple(event: dict) -> dict:
    """간이 형식(seq·text·ISO ts) → 사무 공간 형식. eventId 는 convert 가 process 를 붙인다."""
    ts = event.get("ts")
    if isinstance(ts, str):
        try:
            ts = int(datetime.fromisoformat(ts).timestamp() * 1000)
        except ValueError:
            ts = int(time.time() * 1000)
    text, type_ = str(event.get("text") or ""), event["type"]
    payload = {TEXT_KEY.get(type_, "text"): text} if text else {}
    if type_ == "task.started" and not text:
        payload = {"name": "작업"}
    return {"v": 1, "eventId": f"{ts}-{event.get('seq', '')}", "ts": ts, "agentId": event.get("agentId", ""),
            "type": type_, "taskId": event.get("taskId", ""), "contextId": event.get("contextId", ""),
            "payload": payload}


def convert(event: dict, process: str, clients: bool = True, only: frozenset = frozenset()) -> dict | None:
    if not isinstance(event, dict) or event.get("type") in SKIP or not event.get("type"):
        return None
    if "eventId" not in event:
        event = from_simple(event)
    if isinstance(event.get("agentId"), str) and event["agentId"].startswith("http"):
        event["agentId"] = event["agentId"].rstrip("/")   # 관제 허브 감시 주소·office.html url 과 같게
    if only and event.get("agentId") not in only:
        return None
    if not clients and not str(event.get("agentId", "")).startswith("http"):
        return None                          # client:orchestrator 같은 A2A 서버가 아닌 쪽
    out = {k: v for k, v in event.items() if k != "side"}
    if isinstance(out.get("payload"), dict) and "zone" in out["payload"]:
        # a2a 명부(agents.json)의 구역은 버린다. 자리는 관제 허브 office.html 설정이 정한다
        out["payload"] = {k: v for k, v in out["payload"].items() if k != "zone"}
    out["eventId"] = f"{process}-{event.get('eventId', '')}"   # 다른 시스템 번호와 겹치지 않게
    out["process"] = process
    out.setdefault("org", "사내 생산")
    return out


def post(hub: str, key: str, event: dict) -> str:
    req = urllib.request.Request(hub + "/events", data=json.dumps(event, ensure_ascii=False).encode("utf-8"),
                                 headers={"Content-Type": "application/json", "X-Obs-Key": key}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return "중복" if json.loads(r.read() or b"{}").get("duplicate") else "보냄"
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:200]
        if e.code in (401, 403):
            sys.exit(f"관제 허브가 거부했습니다 ({e.code}): {detail}\n키와 --process 이름(키 발급 이름)을 확인하세요.")
        return f"실패 {e.code} {detail}"


def open_stream(source: str, once: bool):
    """판에 따라 /events/stream 또는 /stream. 404면 다음 주소를 시도한다."""
    for path in STREAM_PATHS:
        try:
            # 평소에는 시간 제한 없이 기다린다(9900이 꺼지면 연결이 닫혀 빈 줄 → 다시 붙는다)
            return urllib.request.urlopen(source + path, timeout=1.5 if once else None)
        except urllib.error.HTTPError as e:
            if e.code != 404 or path == STREAM_PATHS[-1]:
                raise


def stream(source: str, once: bool):
    """SSE 'data:' 줄을 JSON으로 하나씩 낸다. once면 1초 동안 새 줄이 없을 때 끝낸다."""
    with open_stream(source, once) as r:
        while True:
            try:
                line = r.readline()
            except TimeoutError:
                return
            if not line:
                return
            line = line.decode("utf-8").strip()
            if line.startswith("data:"):
                try:
                    yield json.loads(line[5:].strip())
                except json.JSONDecodeError:
                    pass


def main() -> None:
    ap = argparse.ArgumentParser(description="a2a 사무공간 허브 → 관제 허브 중계")
    ap.add_argument("--source", default="http://127.0.0.1:9900", help="a2a office_hub 주소")
    ap.add_argument("--hub", default="http://127.0.0.1:5090", help="관제 허브 주소")
    ap.add_argument("--process", default="a2a-office", help="수집 키를 발급한 이름 (key issue <이름>)")
    ap.add_argument("--key-file", type=Path, default=HERE / ".obs_key")
    ap.add_argument("--once", action="store_true", help="쌓인 이벤트만 넘기고 끝")
    ap.add_argument("--no-clients", action="store_true", help="오케스트레이터(client:…) 이벤트는 넘기지 않음 — 두 에이전트 책상만")
    ap.add_argument("--only", action="append", default=[], help="이 에이전트 주소의 이벤트만 넘김 (여러 번 가능)")
    ap.add_argument("--material-data", type=Path, default=None,
                    help="자재대응 자료 폴더(현재재고.csv·입고예정.csv). 에이전트가 재고·입고를 조회하지 않았을 때(mock) 차트를 채울 참고값")
    a = ap.parse_args()
    source, hub, key = a.source.rstrip("/"), a.hub.rstrip("/"), load_key(a.key_file)
    only = frozenset(u.rstrip("/") for u in a.only)
    analyzer = Analyzer(a.material_data)
    sent: set[str] = set()                 # 9900이 다시 보내는 지난 이벤트는 Task를 다시 조회하지 않는다
    print(f"중계 시작: {source} → {hub}/events (process={a.process}, heartbeat 제외"
          + (f", 대상 {', '.join(sorted(only))}" if only else "")
          + (f", 자재 자료 {a.material_data}" if a.material_data else "") + ")", flush=True)
    while True:
        try:
            for ev in stream(source, a.once):
                out = convert(ev, a.process, not a.no_clients, only)
                if not out or out["eventId"] in sent:
                    continue
                sent.add(out["eventId"])
                if out["type"] == "task.done" and out.get("taskId") and str(out.get("agentId", "")).startswith("http"):
                    task = get_task(out["agentId"], out["taskId"])   # 자재대응 결과물 → 차트용 간략 분석
                    analysis = analyzer.analyze(task) if task else None
                    if analysis:
                        out["payload"] = {**out.get("payload", {}), "analysis": analysis}
                if out:
                    result = post(hub, key, out)
                    if result != "중복":
                        print(f"  {result}  {out['type']:<16} {out.get('agentId', '')}", flush=True)
            if a.once:
                return
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            if a.once:
                sys.exit(f"연결 실패: {e}")
            print(f"  연결 끊김 ({type(e).__name__}) — 3초 뒤 다시", flush=True)
        time.sleep(3)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
