# a2a-bridge — 2_API활용 두 에이전트에게 사무 공간 책상 주기

`2_API활용/a2a`로 A2A가 된 두 에이전트(교대 인수인계 :9101, 자재대응 :9102)를 관제 허브(:5090) 사무 공간의 `ops` 구역에 한 자리씩 앉힌다.
**2_API활용 쪽 코드와 업무 서버 5개는 고치지 않는다.** 바뀌는 것은 관제 허브의 설정 두 곳과 수집 키 하나뿐이다.

| 파일 | 하는 일 |
|---|---|
| `apply.py` | 1단계 설정 적용·되돌리기. 기본은 미리 보기 |
| `office_bridge.py` | 2단계 중계. a2a 사무공간 허브(:9900) 이벤트 → 관제 허브(:5090). 표준 라이브러리만 사용 |
| `.obs_key` | `apply.py --apply`가 만드는 수집 키 (외부에 두지 않는다. `.gitignore`) |

전제: 사무 공간 화면이 허브에 들어가 있다(`obs-hub/obs_hub/ui/office.html`, 안내서 `관제허브_사무공간_변경방법.docx` 2장).

## 1단계 — 책상 (출근·자리 비움)

```powershell
cd C:\Users\yyson\OneDrive\Desktop\A2A\systems\docs\office-hub\a2a-bridge
python apply.py            # 무엇이 바뀌는지 미리 보기
python apply.py --apply    # 적용
```

`apply.py --apply`가 하는 일:

1. `obs-hub/.env`의 `APP_WATCH_URLS`에 `http://127.0.0.1:9101`, `http://127.0.0.1:9102`를 더한다(기존 5개는 그대로).
2. `obs-hub/obs_hub/ui/office.html` 설정 블록에 두 에이전트와 오케스트레이터(`test_client.py`, 2단계에서만 나타남) 자리를 `ops`로 넣고, 구역 이름을 「사내 생산(교대·자재)」로 바꾼다.
3. 관제 허브에 수집 키 `a2a-office`(권한 `ingest`)를 발급해 `.obs_key`에 저장한다(2단계에서 씀).

그다음 관제 허브를 다시 켜고(「관제 허브 :5090」 창에서 `Ctrl+C` → `uv run python -m obs_hub`), a2a 두 에이전트를 띄운다.

```powershell
cd C:\Users\yyson\OneDrive\Desktop\A2A\2_API활용\a2a
.venv\Scripts\python.exe run_agents.py --mock          # 1단계만이면 --office 없이
```

`http://127.0.0.1:5090/`의 `ops` 구역에 두 에이전트가 앉는다. 끄면 회색 「응답 없음」. 작업 상태는 아직 안 보인다.

## 2단계 — 작업 상태까지 (중계)

```
래퍼 9101·9102 ←(1초마다 조회)─ a2a office_hub :9900 ─/stream→ office_bridge.py ─POST /events + X-Obs-Key→ 관제 허브 :5090
```

```powershell
# 터미널 1 — 에이전트 + a2a 사무공간 허브(:9900)
cd C:\Users\yyson\OneDrive\Desktop\A2A\2_API활용\a2a
.venv\Scripts\python.exe run_agents.py --mock --office

# 터미널 2 — 중계
cd C:\Users\yyson\OneDrive\Desktop\A2A\systems\docs\office-hub\a2a-bridge
python office_bridge.py

# 터미널 3 — 일 시키기 (a2a 쪽 시나리오 그대로)
cd C:\Users\yyson\OneDrive\Desktop\A2A\2_API활용\a2a
.venv\Scripts\python.exe test_client.py --follow "오늘 오후 1시에 시작해"
```

같은 책상에 「작업 중」·결과 말풍선·실패 경보가 나온다. 두 허브 모두 A2A 주소(`http://127.0.0.1:9101`)를 에이전트 id로 쓰므로 자리가 하나로 합쳐진다.

중계가 하는 일: `agent.heartbeat`는 버림(출근은 1단계 감시가 맡음) · `process: "a2a-office"`를 붙임(허브는 키 이름과 같은 process만 받음) ·
`eventId` 앞에 `a2a-office-` · `side`는 넣지 않음(사무 공간 형식 그대로) · a2a 명부의 `zone`은 뺌(자리는 `office.html`이 정함). 9900이 다시 보내는 지난 이벤트는 관제 허브가 eventId로 거른다.
어느 쪽이 꺼져도 3초마다 다시 붙는다. 점검만 하려면 `python office_bridge.py --once`.

a2a `office_hub.py`가 간이판(스트림 `/events/stream`, 이벤트 `{seq, type, agentId: "…/", text, ts: ISO}`)이어도 그대로 받는다. 중계가 스트림 주소를 찾아 붙고, 사무 공간 형식(`eventId = a2a-office-<ts>-<seq>`, `ts` ms, `agentId` 끝 `/` 제거, `text` → `payload.name·text·result·reason`)으로 바꿔 보낸다.
**자재 분석 창.** 중계가 `task.done`을 받으면 그 Task를 `GetTask`로 다시 읽어 자재대응 결과물(`material_check`의 도구 기록)로 간략 분석(부품별 필요·재고·입고 예정·부족)을 만들어 `payload.analysis`로 붙입니다(`material_analysis.py`). 사무 공간은 말풍선 오른쪽에 막대 차트 창으로 14초 동안 보여 줍니다. mock 모드는 에이전트가 재고·입고를 조회하지 않으므로 `--material-data "C:\1_a2a_lab\API활용\02_자재대응_Agent\참고"`를 주면 자료 파일 값으로 채우고 「자료 파일 기준 참고값」으로 표시합니다(입고 예정은 시각 구분 없는 전체). 실제 모드에서는 에이전트의 조회 결과를 그대로 씁니다.

한 에이전트만 앉히려면 `--only`(여러 번 가능): `python office_bridge.py --only http://127.0.0.1:9102`. 이때 1단계도 그 에이전트만 넣는다(`APP_WATCH_URLS`에 9102, `office.html` `agents`에 자재대응 한 줄).

둘에게 일을 맡기는 오케스트레이터(`test_client.py`)도 자기 활동을 9900에 알리므로 `ops`에 세 번째 책상이 생긴다(누가 일을 넘겼는지 보임). 두 에이전트 책상만 원하면 `python office_bridge.py --no-clients`.

## 되돌리기

```powershell
python apply.py --undo      # .env·office.html 원래대로, .obs_key 삭제
cd ..\..\..\obs-hub; uv run python -m obs_hub.admin key list    # a2a-office 키 id 확인 → key revoke <id>
```

관제 허브를 다시 켜면 끝. 허브 DB에 남은 지난 이벤트는 기록으로 남는다(화면에는 최근 2000건만 다시 보냄).

## 알아둘 점

- `office.html`을 손으로 고쳐 「물류사 C」 줄이 달라졌으면 `apply.py`가 멈춘다. 그때는 아래 줄들을 설정 블록 `agents`에 직접 넣는다.
  ```js
  {name: '교대 인수인계 에이전트', url: 'http://127.0.0.1:9101', zone: 'ops', org: '사내 생산'},
  {name: '자재대응 에이전트',     url: 'http://127.0.0.1:9102', zone: 'ops', org: '사내 생산'},
  {name: '오케스트레이터(test_client)', url: 'client:orchestrator', role: 'client', zone: 'ops', org: '사내 생산'},
  ```
- 실제 모드(`--mock` 없이)는 Claude API 호출 비용이 든다. 화면 확인은 `--mock`으로 충분하다.
- a2a 쪽은 인증이 없다(127.0.0.1에서만). 관제 허브로 들어가는 길만 수집 키로 막는다.
