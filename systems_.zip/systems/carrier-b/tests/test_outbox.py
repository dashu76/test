"""구매사 배송 알림 outbox (S-17·S-18). 가짜 구매사를 실제 HTTP로 띄워 보낸다."""

import asyncio

import pytest

from logistics_contract import BookingRequest, QuoteRequest, ShipmentStatus

from fake_buyer import BuyerBehavior, ThreadServer, build_fake_buyer, free_port
from carrier_b.outbox import Notifier, Outbox
from carrier_b.skills import StaffError

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")


class Buyer:
    def __init__(self) -> None:
        self.behavior = BuyerBehavior()
        self.port = free_port()
        self.url = f"http://127.0.0.1:{self.port}"
        self.server = None

    def start(self):
        self.server = ThreadServer(build_fake_buyer(self.behavior, self.port), self.port).start()

    def stop(self):
        if self.server:
            self.server.stop()
            self.server = None


@pytest.fixture
def buyer():
    b = Buyer()
    yield b
    b.stop()


@pytest.fixture
def outbox(service, clock):
    return Outbox(service.store, Notifier(timeout_s=1.0), clock, max_attempts=3)


def booked(service, callback_url: str | None):
    q = service.quote(QuoteRequest(**RFQ))
    return service.book(BookingRequest(business_key="k1", rfq_id="RFQ-1", quote_id=q.quote_id,
                                       event_callback_url=callback_url))


def run(coro):
    return asyncio.run(coro)


def test_events_queued_with_status_changes(service, outbox, buyer):
    b = booked(service, buyer.url)
    service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP, "창원 집하")
    events = sorted(outbox.list(), key=lambda e: e["event_id"])
    assert [e["shipment_status"] for e in events] == ["accepted", "picked_up"]
    assert all(e["state"] == "pending" and e["target_url"] == buyer.url for e in events)
    assert events[0]["event_id"] == "물류사 B:B-B-0001:1"


def test_no_callback_no_events(service, outbox):
    b = booked(service, None)
    service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP)
    assert outbox.list() == []


def test_s17_dispatch_in_order(service, outbox, buyer):
    buyer.start()
    b = booked(service, buyer.url)
    for status in (ShipmentStatus.PICKED_UP, ShipmentStatus.IN_TRANSIT, ShipmentStatus.DELIVERED):
        service.advance_shipment(b.tracking_no, status)
    assert run(outbox.dispatch_once()) == {"sent": 4, "retry": 0, "failed": 0}
    assert [e.seq for e in buyer.behavior.events] == [1, 2, 3, 4]
    assert buyer.behavior.events[-1].shipment_status == ShipmentStatus.DELIVERED
    assert run(outbox.dispatch_once())["sent"] == 0       # 이미 보낸 것은 다시 보내지 않는다


def test_s18_buyer_down_then_back(service, outbox, buyer, clock):
    b = booked(service, buyer.url)
    service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP)
    assert run(outbox.dispatch_once()) == {"sent": 0, "retry": 1, "failed": 0}   # 첫 알림 실패 → 뒤 알림은 대기
    first = next(e for e in outbox.list() if e["shipment_status"] == "accepted")
    assert first["attempts"] == 1 and first["last_error"]

    buyer.start()
    assert run(outbox.dispatch_once())["sent"] == 0        # 첫 알림이 재시도 시각 전 → 뒤 알림도 기다린다
    clock.advance(seconds=5)
    assert run(outbox.dispatch_once())["sent"] == 2
    assert [e.seq for e in buyer.behavior.events] == [1, 2]   # 순서 그대로


def test_rejected_marked_failed_then_staff_retry(service, outbox, buyer):
    buyer.behavior.mode = "reject"
    buyer.start()
    booked(service, buyer.url)
    assert run(outbox.dispatch_once()) == {"sent": 0, "retry": 0, "failed": 1}
    failed = outbox.list("failed")[0]
    assert "구매사 거부" in failed["last_error"]

    buyer.behavior.mode = "ok"
    outbox.retry(failed["event_id"])
    assert run(outbox.dispatch_once())["sent"] == 1


def test_max_attempts(service, outbox, buyer, clock):
    booked(service, buyer.url)                           # 구매사는 계속 꺼져 있다
    for _ in range(3):
        run(outbox.dispatch_once())
        clock.advance(minutes=10)
    assert outbox.list()[0]["state"] == "failed"


def test_backoff_grows_and_caps(outbox):
    assert [outbox.backoff(n) for n in (1, 2, 3)] == [2, 4, 8]
    assert outbox.backoff(30) == 300


def test_advance_errors(service):
    with pytest.raises(StaffError):
        service.advance_shipment("없음", ShipmentStatus.PICKED_UP)
    b = booked(service, None)
    with pytest.raises(StaffError):
        service.advance_shipment(b.tracking_no, ShipmentStatus.DELIVERED)
