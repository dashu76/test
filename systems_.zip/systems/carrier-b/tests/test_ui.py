"""담당자 업무 화면(/ui)과 화면이 쓰는 내부 API (설계: systems/docs/p6-carrier-ui.md)."""

import dataclasses
import json
import threading

import httpx
import pytest

from logistics_contract import BookingRequest, QuoteRequest

from carrier_b import obs_hook
from carrier_b.app import build_app, build_service
from carrier_b.domain import decide_quote
from conftest import make_settings
from fake_buyer import ThreadServer, free_port
from fake_hub import HubLog, build_fake_hub

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")


def start(tmp_path, **changes):
    port = free_port()
    settings = dataclasses.replace(make_settings(tmp_path, port=port), outbox_interval_s=0, **changes)
    service = build_service(settings)
    server = ThreadServer(build_app(settings, service), port).start()
    return settings, service, server


@pytest.fixture
def carrier(tmp_path):
    settings, service, server = start(tmp_path)
    yield settings, service, httpx.Client(base_url=settings.public_url, timeout=10)
    server.stop()


def booked(service):
    q = service.quote(QuoteRequest(**RFQ))
    return service.book(BookingRequest(business_key="K정밀웍스:RFQ-1:book:a:v1", rfq_id="RFQ-1",
                                       quote_id=q.quote_id, event_callback_url="http://127.0.0.1:5010"))


def test_ui_page_and_root_redirect(carrier):
    _, _, api = carrier
    page = api.get("/ui")
    assert page.status_code == 200 and page.headers["content-type"].startswith("text/html")
    assert "/api/stream" in page.text and "/api/meta" in page.text
    root = api.get("/", follow_redirects=False)
    assert root.status_code == 307 and root.headers["location"] == "/ui"


def test_ui_disabled_keeps_api(tmp_path):
    settings, _, server = start(tmp_path, ui_enabled=False)
    try:
        api = httpx.Client(base_url=settings.public_url, timeout=10)
        assert api.get("/ui").status_code == 404
        assert api.get("/", follow_redirects=False).status_code in (404, 405)
        assert api.get("/api/shipments").status_code == 200        # CLI가 쓰는 API는 그대로
        assert api.get("/.well-known/agent-card.json").status_code == 200
    finally:
        server.stop()


def test_meta(carrier):
    settings, service, api = carrier
    m = api.get("/api/meta").json()
    assert m["name"] == "물류사 B" and m["public_url"] == settings.public_url
    assert m["modes"] == {"quote": "auto", "booking": "auto"}
    assert m["pricing"]["base_krw"] == service.pricing.base_krw and m["pricing"]["eta_days"] == service.pricing.eta_days
    assert set(m["transitions"]["accepted"]) == {"picked_up", "cancelled"} and m["transitions"]["delivered"] == []
    assert m["statuses"]["in_transit"] == "운송 중"
    assert {s["id"] for s in m["skills"]} == {"quote", "book-shipment", "cancel-booking", "check-delivery"}
    assert m["obs_url"] == "" and m["ui_enabled"] is True


def test_quote_and_booking_lists(carrier):
    _, service, api = carrier
    b = booked(service)
    service.quote(QuoteRequest(**{**RFQ, "rfq_id": "RFQ-2", "weight_kg": 9999}))   # 최대 중량 초과 → 거절

    quotes = {q["rfq_id"]: q for q in api.get("/api/quotes").json()}
    assert quotes["RFQ-1"]["status"] == "quoted"
    assert (quotes["RFQ-1"]["price_krw"], quotes["RFQ-1"]["eta_days"]) == decide_quote(480, service.pricing)
    assert quotes["RFQ-1"]["item"] == "베어링" and quotes["RFQ-1"]["origin"] == "창원"
    assert quotes["RFQ-2"]["status"] == "declined" and "초과" in quotes["RFQ-2"]["reason"]
    assert list(quotes) == ["RFQ-2", "RFQ-1"]                       # 최근 것이 위

    [bk] = api.get("/api/bookings").json()
    assert bk["booking_id"] == b.booking_id and bk["tracking_no"] == b.tracking_no
    assert bk["rfq_id"] == "RFQ-1" and bk["status"] == "accepted" and bk["callback_url"] == "http://127.0.0.1:5010"


def test_shipment_history(carrier):
    _, service, api = carrier
    b = booked(service)
    r = api.post(f"/api/shipments/{b.tracking_no}/advance", json={"status": "picked_up", "note": "창원 집하"})
    assert r.status_code == 200
    history = api.get(f"/api/shipments/{b.tracking_no}/history").json()
    assert [(h["seq"], h["status"], h["note"]) for h in history] == [(1, "accepted", "자동 수락"), (2, "picked_up", "창원 집하")]
    assert api.get("/api/shipments/없음/history").status_code == 404
    assert api.post(f"/api/shipments/{b.tracking_no}/advance", json={"status": "delivered"}).status_code == 409


def test_revision_moves_only_on_real_changes(carrier):
    _, service, _ = carrier
    store = service.store
    before = store.revision
    with store.transaction() as conn:                                # 읽기만 한 쓰기 트랜잭션
        conn.execute("SELECT COUNT(*) FROM quotes").fetchone()
    assert store.revision == before
    service.quote(QuoteRequest(**RFQ))
    assert store.revision == before + 1
    service.quote(QuoteRequest(**RFQ))                               # 같은 요청 재전송 → 바뀐 것 없음
    assert store.revision == before + 1


def read_events(url: str, count: int, out: list, ready: threading.Event) -> None:
    with httpx.stream("GET", url, timeout=10) as response:
        for line in response.iter_lines():
            if line.startswith("data:"):
                out.append(json.loads(line[5:]))
                ready.set()
                if len(out) >= count:
                    return


def test_stream_sends_change(carrier):
    settings, service, api = carrier
    got, ready = [], threading.Event()
    reader = threading.Thread(target=read_events, args=(f"{settings.public_url}/api/stream", 2, got, ready), daemon=True)
    reader.start()
    assert ready.wait(5)                                             # 연결 직후 한 번
    api.get("/api/quotes")                                           # 읽기는 이벤트를 만들지 않는다
    service.quote(QuoteRequest(**RFQ))                               # A2A로 들어온 견적과 같은 길
    reader.join(5)
    assert len(got) == 2 and got[1]["rev"] == got[0]["rev"] + 1


def test_started_event_links_console(tmp_path):
    log = HubLog()
    hub_port = free_port()
    hub = ThreadServer(build_fake_hub(log), hub_port).start()
    try:
        _, _, server = start(tmp_path, obs_url=f"http://127.0.0.1:{hub_port}")
        server.stop()
        log.wait_for(lambda h: "agent.started" in h.types())
        assert log.of("agent.started")[0]["payload"]["console"] == "/ui"
    finally:
        obs_hook.stop(timeout_s=0.5)
        hub.stop()
