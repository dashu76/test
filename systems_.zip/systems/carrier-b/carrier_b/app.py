# 파일명: app.py
"""FastAPI 조립: A2A(구매사용) + 내부 API(/api, 담당자용) + 구매사 알림 발송기 + 상태 확인 + 업무 화면(/ui).

- 인증(Part 4): 회사 사이는 파트너 키(APP_A2A_AUTH), 사내는 로그인·권한(APP_STAFF_AUTH). 설계: systems/docs/security-and-db.md
- 요금 규칙의 원본은 DB(config). 처음 뜰 때 config/pricing.toml로 채운다.
- A2A_OBS_URL이 있으면 관찰 이벤트를 관제 허브로 보낸다(obs_hook).
"""

import asyncio
import contextlib
import dataclasses
import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
import logistics_contract

from . import __version__, a2a_auth, auth, obs_hook
from .api import router
from .card import build_card
from .domain import load_pricing, now_kst, pricing_from_dict
from .executor import CarrierExecutor
from .outbox import Notifier, Outbox, run_dispatcher
from .permissions import PERMISSION_LABELS, ROLES
from .settings import Settings
from .skills import CarrierService
from .store import Store

UI_FILE = Path(__file__).resolve().parent / "ui" / "index.html"
log = logging.getLogger("carrier_b")


def saved_pricing(settings: Settings, store: Store):
    """DB의 요금 규칙. 없으면(처음) 파일 값으로 채운다 — 이후에는 DB가 원본이다."""
    saved = store.get_config("pricing")
    if saved is not None:
        return pricing_from_dict(saved)
    pricing = load_pricing(settings.pricing_file)
    store.set_config("pricing", dataclasses.asdict(pricing), f"file:{settings.pricing_file.name}", now_kst().isoformat())
    return pricing


def build_service(settings: Settings) -> CarrierService:
    store = Store(settings.db_path)
    return CarrierService(settings, store, saved_pricing(settings, store))


def build_auth(settings: Settings) -> auth.AuthStore:
    return auth.AuthStore(settings.db_path, ROLES, settings.session_hours)


def build_outbox(settings: Settings, service: CarrierService, auth_store: auth.AuthStore | None = None) -> Outbox:
    notifier = Notifier(headers_for=lambda target: a2a_auth.key_headers(auth_store, target))
    return Outbox(service.store, notifier, service.clock, max_attempts=settings.outbox_max_attempts)


def build_app(settings: Settings, service: CarrierService | None = None, outbox: Outbox | None = None,
              auth_store: auth.AuthStore | None = None) -> FastAPI:
    service = service or build_service(settings)
    auth_store = auth_store or build_auth(settings)
    outbox = outbox or build_outbox(settings, service, auth_store)
    card = build_card(settings)
    # A2A Task는 전달 수단이라 메모리에 둔다. 업무 상태의 원본은 Store(SQLite)다.
    handler = DefaultRequestHandler(
        agent_executor=CarrierExecutor(service, auth_store, settings.a2a_auth),
        task_store=InMemoryTaskStore(), agent_card=card,
    )

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        obs_hook.start("carrier-b", settings.public_url, settings.obs_url, auth_store.outbound_key("obs") or "")
        obs_hook.emit("agent.started", "server", {"name": card.name, "skills": [s.id for s in card.skills],
                                                  "contract": logistics_contract.__version__,
                                                  "console": "/ui" if settings.ui_enabled else ""})
        if settings.staff_auth and not auth_store.has_users():
            log.warning("로그인이 켜져 있는데 사용자가 없다. 먼저 만든다: "
                        "uv run python -m carrier_b.admin user add <이름> --role admin")
        task = None
        if settings.outbox_interval_s > 0:
            task = asyncio.create_task(run_dispatcher(outbox, settings.outbox_interval_s))
        yield
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
        obs_hook.emit("agent.stopped", "server")
        obs_hook.stop()

    app = FastAPI(title=settings.carrier_name, version=__version__, lifespan=lifespan)
    app.state.service = service
    app.state.outbox = outbox
    app.state.card = card
    app.state.auth = auth_store
    app.state.staff_auth = settings.staff_auth
    app.state.login_hint = settings.login_hint
    app.state.session_cookie = f"session_{settings.port}"   # 한 PC에 여러 서버를 띄워도 로그인이 섞이지 않게
    app.state.permission_labels = PERMISSION_LABELS
    add_a2a_routes_to_fastapi(
        app,
        agent_card_routes=create_agent_card_routes(card),
        jsonrpc_routes=create_jsonrpc_routes(
            handler, rpc_url="/",
            context_builder=a2a_auth.PartnerContextBuilder(auth_store) if settings.a2a_auth else None),
    )
    if settings.a2a_auth:
        app.add_middleware(a2a_auth.JsonRpcKeyGuard, auth=auth_store)   # GetTask·ListTasks 등도 키 필요
    app.include_router(auth.router)
    app.include_router(router)

    if settings.ui_enabled:
        # 담당자 업무 화면. 내부 API(/api)만 부른다. A2A JSON-RPC는 POST /라 GET /와 겹치지 않는다.
        @app.get("/", include_in_schema=False)
        def root() -> RedirectResponse:
            return RedirectResponse("/ui")

        @app.get("/ui", include_in_schema=False)
        def ui() -> FileResponse:
            return FileResponse(UI_FILE, media_type="text/html; charset=utf-8")

    @app.get("/healthz")
    def healthz() -> dict:
        return {
            "status": "ok",
            "carrier": settings.carrier_name,
            "app_version": __version__,
            "contract_version": logistics_contract.__version__,
        }

    return app
