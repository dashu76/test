# 파일명: outbox.py
"""구매사에 배송 상태 알림(shipment-event)을 보내는 outbox (plan_2 S-17·S-18).

- 상태가 바뀌면 skills가 같은 DB 트랜잭션에서 outbox에 알림을 쌓는다. 상태는 바뀌었는데 알림이 빠지는 일이 없다.
- 이 모듈의 발송기가 주기적으로 쌓인 알림을 구매사의 event_callback_url로 보낸다.
  - 구매사가 꺼져 있으면(연결 실패·시간 초과) 늘어나는 간격으로 다시 보낸다. 같은 구매사의 뒤 알림은 이번 회차에 보내지 않는다.
  - 구매사가 Task failed로 거부하면(계약 비호환·우리 발주 아님 등) 다시 보내도 소용없으므로 failed로 두고 담당자가 확인한다.
  - 최대 시도 횟수를 넘겨도 failed. 담당자가 retry로 다시 대기열에 넣을 수 있다.
- 같은 알림을 두 번 받아도 구매사는 event_id로 걸러낸다. 순서가 바뀌어도 seq로 걸러낸다.
"""

import asyncio
import json
import logging
import uuid
from urllib.parse import urlsplit
from collections.abc import Callable
from datetime import datetime, timedelta

import httpx
from a2a.client import A2ACardResolver, ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import Message, Role, SendMessageRequest, TaskState
from logistics_contract import CONTRACT_TAG, SKILL_RECEIVE_SHIPMENT_EVENT, ContractError, EventAck, parse_response

from . import obs_hook
from .store import Store

log = logging.getLogger("carrier_b.outbox")


class DeliveryUnavailable(Exception):
    """구매사에 닿지 않았다 → 나중에 다시 보낸다."""


class DeliveryRejected(Exception):
    """구매사가 거부했다 → 다시 보내도 소용없다."""


class Notifier:
    """구매사의 receive-shipment-event 스킬을 부르는 A2A 클라이언트."""

    def __init__(self, timeout_s: float = 10.0, headers_for: Callable[[str], dict] | None = None) -> None:
        self.timeout_s = timeout_s
        self.headers_for = headers_for or (lambda target: {})   # 알림 주소 → 그 구매사가 발급한 키 헤더

    async def send(self, target_url: str, payload: dict) -> EventAck:
        traces: list[obs_hook.RequestTrace] = []   # 요청을 보내기 시작하면 _send가 넣는다 (관제 허브용)
        try:
            return await self._deliver(target_url, payload, traces)
        except BaseException as exc:
            if traces:
                traces[0].error(exc)
            raise

    async def _deliver(self, target_url: str, payload: dict, traces: list) -> EventAck:
        try:
            return await asyncio.wait_for(self._send(target_url, payload, traces), timeout=self.timeout_s * 2)
        except (DeliveryUnavailable, DeliveryRejected):
            raise
        except ContractError as exc:   # 응답(event-ack)이 계약과 다름
            raise DeliveryRejected(f"응답 계약 위반: {exc}") from exc
        except TimeoutError as exc:
            raise DeliveryUnavailable(f"{target_url}: 응답 없음") from exc
        except Exception as exc:  # 카드 조회·연결 실패
            raise DeliveryUnavailable(f"{target_url}: {type(exc).__name__}") from exc

    async def _send(self, target_url: str, payload: dict, traces: list) -> EventAck:
        async with httpx.AsyncClient(timeout=self.timeout_s, headers=self.headers_for(base_url(target_url))) as http:
            try:
                card = await A2ACardResolver(http, target_url).get_agent_card()
            except Exception as exc:
                obs_hook.card_failed(target_url, exc)
                raise
            obs_hook.card_fetched(target_url, card)
            skill = next((s for s in card.skills if s.id == SKILL_RECEIVE_SHIPMENT_EVENT), None)
            if skill is None or CONTRACT_TAG not in skill.tags:
                raise DeliveryRejected(f"{card.name}: {SKILL_RECEIVE_SHIPMENT_EVENT}({CONTRACT_TAG}) 스킬이 없다")
            client = await create_client(card, client_config=ClientConfig(httpx_client=http, streaming=False))
            try:
                request = SendMessageRequest(message=Message(
                    message_id=str(uuid.uuid4()), role=Role.ROLE_USER,
                    parts=[new_data_part(payload, media_type="application/json")]))
                traces.append(obs_hook.RequestTrace(target_url, card.name, SKILL_RECEIVE_SHIPMENT_EVENT,
                                                    obs_hook.summarize(payload)))
                responses = [r async for r in client.send_message(request)]
            finally:
                await client.close()
        last = responses[-1]
        if last.HasField("message"):
            traces[0].done("MESSAGE")
            return parse_response(get_data_parts(last.message.parts)[0], "event-ack")
        task = last.task
        traces[0].done(task.status.state, task.id, task.context_id)
        if task.status.state == TaskState.TASK_STATE_COMPLETED:
            data = [v for a in task.artifacts for v in get_data_parts(a.parts)]
            return parse_response(data[0] if data else None, "event-ack")
        reason = "".join(p.text for p in task.status.message.parts) or TaskState.Name(task.status.state)
        if task.status.state in (TaskState.TASK_STATE_FAILED, TaskState.TASK_STATE_REJECTED):
            raise DeliveryRejected(reason)
        raise DeliveryUnavailable(f"처리가 끝나지 않음: {reason}")


def base_url(url: str) -> str:
    """알림 주소의 기준 URL(scheme://host:port). 구매사가 발급한 키는 이 값으로 찾는다."""
    parts = urlsplit(url)
    return f"{parts.scheme}://{parts.netloc}"


class Outbox:
    def __init__(self, store: Store, notifier: Notifier, clock: Callable[[], datetime],
                 max_attempts: int = 20, base_backoff_s: float = 2.0, max_backoff_s: float = 300.0) -> None:
        self.store = store
        self.notifier = notifier
        self.clock = clock
        self.max_attempts = max_attempts
        self.base_backoff_s = base_backoff_s
        self.max_backoff_s = max_backoff_s
        self._lock = asyncio.Lock()

    def backoff(self, attempts: int) -> float:
        return min(self.base_backoff_s * 2 ** (attempts - 1), self.max_backoff_s)

    async def dispatch_once(self) -> dict:
        """쌓인 순서대로 보낸다. 구매사마다 앞 알림이 끝나기 전에는 뒤 알림을 보내지 않는다(순서 유지)."""
        async with self._lock:
            counts = {"sent": 0, "retry": 0, "failed": 0}
            now = self.clock()
            with self.store.read() as conn:
                rows = Store.pending_events(conn)
            blocked: set[str] = set()   # 앞 알림이 아직 안 끝난 구매사
            for row in rows:
                if row["target_url"] in blocked:
                    continue
                if datetime.fromisoformat(row["next_attempt_at"]) > now:   # 재시도 시각 전
                    blocked.add(row["target_url"])
                    continue
                attempts = row["attempts"] + 1
                payload = json.loads(row["payload_json"])
                try:
                    await self.notifier.send(row["target_url"], payload)
                except DeliveryUnavailable as exc:
                    blocked.add(row["target_url"])
                    if attempts >= self.max_attempts:
                        self._update(row["event_id"], state="failed", attempts=attempts, last_error=str(exc))
                        counts["failed"] += 1
                        self._observe("outbox.failed", row, payload, attempts, str(exc))
                    else:
                        retry_at = self.clock() + timedelta(seconds=self.backoff(attempts))
                        self._update(row["event_id"], attempts=attempts, last_error=str(exc),
                                     next_attempt_at=retry_at.isoformat())
                        counts["retry"] += 1
                        self._observe("outbox.retry", row, payload, attempts, str(exc))
                    continue
                except DeliveryRejected as exc:
                    self._update(row["event_id"], state="failed", attempts=attempts, last_error=f"구매사 거부: {exc}")
                    counts["failed"] += 1
                    self._observe("outbox.failed", row, payload, attempts, f"구매사 거부: {exc}")
                    log.warning("알림 %s 거부됨: %s", row["event_id"], exc)
                    continue
                self._update(row["event_id"], state="sent", attempts=attempts, last_error="",
                             sent_at=self.clock().isoformat())
                counts["sent"] += 1
                self._observe("outbox.sent", row, payload, attempts)
            return counts

    @staticmethod
    def _observe(type_: str, row, payload: dict, attempts: int, error: str = "") -> None:
        """관제 허브용 업무 이벤트 (허브가 없으면 아무 일도 없다)."""
        obs_hook.emit(type_, "server", {"event": row["event_id"], "booking": row["booking_id"],
                                        "status": payload.get("shipment_status"), "to": row["target_url"],
                                        "attempts": attempts, "error": error})

    def _update(self, event_id: str, **fields) -> None:
        with self.store.transaction() as conn:
            Store.set_event(conn, event_id, **fields)

    def retry(self, event_id: str) -> None:
        """담당자가 실패한 알림을 다시 대기열에 넣는다."""
        with self.store.transaction() as conn:
            row = conn.execute("SELECT state FROM outbox WHERE event_id=?", (event_id,)).fetchone()
            if row is None:
                raise KeyError(event_id)
            Store.set_event(conn, event_id, state="pending", attempts=0, next_attempt_at=self.clock().isoformat())

    def list(self, state: str | None = None) -> list[dict]:
        with self.store.read() as conn:
            return [dict(event_id=r["event_id"], booking_id=r["booking_id"], target_url=r["target_url"],
                         state=r["state"], attempts=r["attempts"], next_attempt_at=r["next_attempt_at"],
                         last_error=r["last_error"], created_at=r["created_at"], sent_at=r["sent_at"],
                         shipment_status=json.loads(r["payload_json"])["shipment_status"])
                    for r in Store.outbox(conn, state)]


async def run_dispatcher(outbox: Outbox, interval_s: float) -> None:
    while True:
        try:
            counts = await outbox.dispatch_once()
            if counts["sent"] or counts["failed"]:
                log.info("알림 발송: %s", counts)
        except Exception:
            log.exception("알림 발송 중 오류")
        await asyncio.sleep(interval_s)
