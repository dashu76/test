# 파일명: cli.py
"""물류사 담당자 CLI (화면 없이 업무 처리). 우리 회사 내부 API만 부른다.

  uv run python -m carrier_b.cli login kim          (로그인 켜진 서버: 먼저 로그인, 세션은 data/.cli_session)
  uv run python -m carrier_b.cli shipment list
  uv run python -m carrier_b.cli shipment advance B-T-100001 picked_up --note "창원 집하"
  uv run python -m carrier_b.cli outbox list [--state pending|sent|failed]
  uv run python -m carrier_b.cli outbox retry "물류사 B:B-B-0001:2"
  uv run python -m carrier_b.cli outbox dispatch

API 주소: --api 또는 CARRIER_API_URL (기본: 설정의 주소)
"""

import argparse
import getpass
import os
import sys

import httpx

from .auth import cli_headers, cli_session_file, save_cli_session
from .settings import APP_ROOT

STATUSES = ["picked_up", "in_transit", "customs_hold", "delivered"]
OUTBOX_LABEL = {"pending": "발송 대기", "sent": "보냄", "failed": "실패(확인 필요)"}


def default_api() -> str:
    if os.getenv("CARRIER_API_URL"):
        return os.environ["CARRIER_API_URL"]
    from .settings import load_settings
    return load_settings().local_api


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="carrier_b.cli", description="물류사 담당자 CLI")
    p.add_argument("--api", default=None)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("shipment").add_subparsers(dest="action", required=True)
    s.add_parser("list")
    v = s.add_parser("advance")
    v.add_argument("tracking_no")
    v.add_argument("status", choices=STATUSES)
    v.add_argument("--note", default="")
    o = sub.add_parser("outbox").add_subparsers(dest="action", required=True)
    o.add_parser("list").add_argument("--state", choices=list(OUTBOX_LABEL))
    o.add_parser("retry").add_argument("event_id")
    o.add_parser("dispatch")
    lg = sub.add_parser("login", help="로그인 (세션을 이 폴더 data/.cli_session에 저장)")
    lg.add_argument("username")
    lg.add_argument("--password", help="스크립트용. 없으면 묻는다")
    sub.add_parser("logout")
    sub.add_parser("whoami", help="로그인한 사용자와 권한")

    args = p.parse_args(argv)
    api = (args.api or default_api()).rstrip("/")
    try:
        with httpx.Client(base_url=api, timeout=60, headers=cli_headers(APP_ROOT)) as http:
            if args.cmd in ("login", "logout", "whoami"):
                return session_command(http, args)
            if args.cmd == "shipment" and args.action == "list":
                r = http.get("/api/shipments")
            elif args.cmd == "shipment":
                r = http.post(f"/api/shipments/{args.tracking_no}/advance", json={"status": args.status, "note": args.note})
            elif args.action == "list":
                r = http.get("/api/outbox", params={"state": args.state} if args.state else None)
            elif args.action == "retry":
                r = http.post(f"/api/outbox/{args.event_id}/retry")
            else:
                r = http.post("/api/outbox/dispatch")
            if r.status_code == 401:
                print("로그인이 필요하다: uv run python -m carrier_b.cli login <이름>", file=sys.stderr)
                return 1
            if r.status_code >= 400:
                print(f"거부: {r.json().get('detail', r.text)}", file=sys.stderr)
                return 1
            body = r.json()
            if args.cmd == "shipment" and args.action == "list":
                for x in body:
                    notify = "알림 대상" if x["notify"] else ""
                    print(f"{x['tracking_no']:<14} {x['status_label']:<6} 순번 {x['seq']} 도착 예정 {x['eta'] or '-'}  {x['note']}  {notify}")
            elif args.cmd == "shipment":
                print(f"{body['tracking_no']}: {body['status']} (순번 {body['seq']}) — 구매사 알림 대기열에 추가")
            elif args.action == "list":
                for x in body:
                    err = f"  오류: {x['last_error']}" if x["last_error"] else ""
                    print(f"{x['event_id']:<28} {x['shipment_status']:<12} {OUTBOX_LABEL[x['state']]:<10} 시도 {x['attempts']}{err}")
            elif args.action == "retry":
                print(f"{body['event_id']}: 다시 발송 대기")
            else:
                print(f"보냄 {body['sent']} · 재시도 예정 {body['retry']} · 실패 {body['failed']}")
            return 0
    except httpx.ConnectError:
        print(f"물류사 시스템({api})에 연결할 수 없다. 서버가 켜져 있는지 확인하라.", file=sys.stderr)
        return 2


def session_command(http: httpx.Client, args) -> int:
    if args.cmd == "login":
        r = http.post("/api/login", json={"username": args.username,
                                          "password": args.password or getpass.getpass("비밀번호: ")})
        if r.status_code >= 400:
            print(f"로그인 실패: {r.json().get('detail', r.text)}", file=sys.stderr)
            return 1
        body = r.json()
        if body["token"]:
            save_cli_session(APP_ROOT, body["token"])
        print(f"로그인: {body['user']['display_name']} ({body['user']['role_label']})")
        return 0
    if args.cmd == "logout":
        http.post("/api/logout")
        cli_session_file(APP_ROOT).unlink(missing_ok=True)
        print("로그아웃")
        return 0
    r = http.get("/api/me")
    if r.status_code == 401:
        print("로그인하지 않았다", file=sys.stderr)
        return 1
    body = r.json()
    labels = body["permission_labels"]
    print(f"{body['user']['display_name']} ({body['user']['role_label']})"
          + ("" if body["staff_auth"] else " — 이 서버는 로그인을 끈 상태"))
    print("권한: " + ", ".join(labels.get(p, p) for p in body["user"]["permissions"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
