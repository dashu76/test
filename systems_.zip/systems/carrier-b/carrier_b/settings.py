# 파일명: settings.py
"""설정 읽기. 우선순위: 환경변수 > 이 폴더의 .env > 기본값. 상대 경로는 이 폴더(carrier-b) 기준."""

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

APP_ROOT = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "APP_CARRIER_NAME": "물류사 B",
    "APP_ID_PREFIX": "B",
    "APP_BIND_HOST": "127.0.0.1",
    "APP_PORT": "5022",
    "APP_PUBLIC_URL": "",
    "APP_DB_PATH": "data/carrier_b.sqlite3",
    "APP_PRICING_FILE": "config/pricing.toml",
    "APP_ALLOWED_CALLBACK_HOSTS": "127.0.0.1,localhost",
    "APP_OUTBOX_INTERVAL_S": "2",
    "APP_OUTBOX_MAX_ATTEMPTS": "20",
    "A2A_OBS_URL": "",
    "APP_UI_ENABLED": "true",
    "APP_A2A_AUTH": "true",
    "APP_STAFF_AUTH": "true",
    "APP_SESSION_HOURS": "12",
    "APP_LOGIN_HINT": "",
    "APP_UI_ACCENT": "#15803d",
}


@dataclass(frozen=True)
class Settings:
    carrier_name: str
    id_prefix: str
    bind_host: str
    port: int
    public_url: str
    db_path: Path
    pricing_file: Path
    allowed_callback_hosts: frozenset[str]
    outbox_interval_s: float = 2.0    # 구매사 알림 발송 주기. 0이면 발송기를 켜지 않는다
    outbox_max_attempts: int = 20     # 이만큼 실패하면 failed (담당자 확인)
    obs_url: str = ""                 # 관제 허브 주소. 비면 관찰 이벤트를 보내지 않는다
    ui_enabled: bool = True           # 담당자 업무 화면(/ui). 꺼도 A2A·내부 API·CLI는 그대로
    ui_accent: str = ""               # 화면 강조색(#rrggbb, 회사 색). 비면 회사 이름으로 정한다
    # 인증 (Part 4). 코드 기본값은 꺼짐(테스트가 Settings를 직접 만든다). 실제 실행(load_settings)은 켜짐이 기본
    a2a_auth: bool = False            # 회사 사이 파트너 키(X-Partner-Key) 요구
    staff_auth: bool = False          # 화면·내부 API·CLI 로그인 요구
    session_hours: float = 12.0
    login_hint: str = ""              # 로그인 화면 시험 계정 안내 (예: "admin3 / 1234"). 운영에서는 비운다

    @property
    def local_api(self) -> str:
        host = "127.0.0.1" if self.bind_host in ("0.0.0.0", "::") else self.bind_host
        return f"http://{host}:{self.port}"


def read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _flag(value: str) -> bool:
    return value.strip().lower() in ("1", "true", "yes", "on")


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def load_settings(root: Path = APP_ROOT, environ: Mapping[str, str] | None = None) -> Settings:
    environ = os.environ if environ is None else environ
    values = {**DEFAULTS, **read_env_file(root / ".env")}
    values.update({k: v for k, v in environ.items() if k in DEFAULTS})

    bind_host = values["APP_BIND_HOST"]
    port = int(values["APP_PORT"])
    public_url = values["APP_PUBLIC_URL"].rstrip("/")
    if not public_url:
        if bind_host in ("0.0.0.0", "::"):
            raise ValueError("APP_BIND_HOST가 모든 주소일 때는 APP_PUBLIC_URL을 반드시 지정해야 한다")
        public_url = f"http://{bind_host}:{port}"
    if urlsplit(public_url).scheme not in ("http", "https"):
        raise ValueError(f"APP_PUBLIC_URL이 http(s) 주소가 아니다: {public_url}")

    return Settings(
        carrier_name=values["APP_CARRIER_NAME"],
        id_prefix=values["APP_ID_PREFIX"],
        bind_host=bind_host,
        port=port,
        public_url=public_url,
        db_path=_resolve(root, values["APP_DB_PATH"]),
        pricing_file=_resolve(root, values["APP_PRICING_FILE"]),
        allowed_callback_hosts=frozenset(
            h.strip() for h in values["APP_ALLOWED_CALLBACK_HOSTS"].split(",") if h.strip()
        ),
        outbox_interval_s=float(values["APP_OUTBOX_INTERVAL_S"]),
        outbox_max_attempts=int(values["APP_OUTBOX_MAX_ATTEMPTS"]),
        obs_url=values["A2A_OBS_URL"].rstrip("/"),
        ui_enabled=_flag(values["APP_UI_ENABLED"]),
        ui_accent=values["APP_UI_ACCENT"].strip(),
        a2a_auth=_flag(values["APP_A2A_AUTH"]),
        staff_auth=_flag(values["APP_STAFF_AUTH"]),
        session_hours=float(values["APP_SESSION_HOURS"]),
        login_hint=values["APP_LOGIN_HINT"].strip(),
    )
