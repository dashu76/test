# 파일명: export_schemas.py
"""모델 → JSON Schema 파일 생성. 파이썬이 아닌 언어로 구현하는 회사도 같은 계약을 쓸 수 있게 한다.

실행: uv run python tools/export_schemas.py          (src/logistics_contract/schemas/ 갱신)
      uv run python tools/export_schemas.py --check  (파일이 모델과 다르면 실패 — 테스트에서 사용)
"""

import json
import sys
from pathlib import Path

from logistics_contract import ALL_MODELS, SCHEMA_VERSION

OUT = Path(__file__).resolve().parent.parent / "src" / "logistics_contract" / "schemas"


def render() -> dict[str, str]:
    major = SCHEMA_VERSION.split(".")[0]
    files = {}
    for name, model in ALL_MODELS.items():
        schema = model.model_json_schema()
        schema["$id"] = f"urn:logistics-contract:{name}:v{major}"
        files[f"{name}.v{major}.json"] = json.dumps(schema, ensure_ascii=False, indent=2) + "\n"
    return files


def main(check: bool) -> int:
    files = render()
    stale = [n for n, text in files.items()
             if not (OUT / n).exists() or (OUT / n).read_text(encoding="utf-8") != text]
    if check:
        if stale:
            print("스키마 파일이 모델과 다르다. tools/export_schemas.py를 실행하라:", stale)
            return 1
        print("스키마 최신")
        return 0
    OUT.mkdir(parents=True, exist_ok=True)
    for name, text in files.items():
        (OUT / name).write_text(text, encoding="utf-8", newline="\n")
    print(f"{len(files)}개 스키마 → {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main("--check" in sys.argv))
