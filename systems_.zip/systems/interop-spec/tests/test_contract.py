import os
import subprocess
import sys
from pathlib import Path

import pytest

from logistics_contract import (
    CONTRACT_TAG,
    ContractError,
    Quote,
    QuoteRequest,
    ShipmentStatus,
    parse_request,
    to_data,
)
from logistics_contract.examples import load_examples, parse_example

EXAMPLES = load_examples()


@pytest.mark.parametrize("item", EXAMPLES, ids=[e["name"] for e in EXAMPLES])
def test_examples(item):
    if item["expect"] == "ok":
        parse_example(item)
    else:
        with pytest.raises(ContractError):
            parse_example(item)


def test_every_model_has_an_ok_example():
    from logistics_contract import ALL_MODELS

    covered = {type(parse_example(e)).__name__ for e in EXAMPLES if e["expect"] == "ok"}
    assert {m.__name__ for m in ALL_MODELS.values()} <= covered


def test_round_trip_through_json_dict():
    req = parse_request(next(e for e in EXAMPLES if e["name"] == "quote-request")["message"])
    assert isinstance(req, QuoteRequest)
    again = parse_request(to_data(req))
    assert again == req


def test_float_numbers_become_int():
    quote = parse_example(next(e for e in EXAMPLES if e["name"] == "quote-numbers-as-a2a-floats"))
    assert isinstance(quote, Quote)
    assert quote.price_krw == 174000 and type(quote.price_krw) is int


def test_unknown_fields_are_ignored():
    req = parse_example(next(e for e in EXAMPLES if e["name"] == "quote-request-from-newer-minor"))
    assert not hasattr(req, "hazmat")


def test_constants():
    assert CONTRACT_TAG == "contract:logistics/1"
    assert ShipmentStatus("in_transit") is ShipmentStatus.IN_TRANSIT


def test_json_schemas_are_up_to_date():
    tool = Path(__file__).resolve().parent.parent / "tools" / "export_schemas.py"
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    result = subprocess.run([sys.executable, str(tool), "--check"],
                            capture_output=True, encoding="utf-8", env=env)
    assert result.returncode == 0, result.stdout + result.stderr
