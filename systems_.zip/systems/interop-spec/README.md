# logistics-contract — K정밀웍스 ↔ 물류사 A2A 계약 (logistics/1)

회사 간에 오가는 메시지의 모양을 정한 **버전이 붙은 패키지**입니다. 각 회사 서버는 이 폴더를 경로로 참조하지 않고, 빌드된 wheel을 자기 `vendor/`에 받아 **버전을 고정해** 설치합니다 (`VERSIONING.md`).

## 스킬

| 스킬 ID | 방향 | 요청 `kind` | 응답 `kind` / `status` |
|---|---|---|---|
| `quote` | 구매사 → 물류사 | `quote-request` | `quote` / `quoted` · `declined` |
| `book-shipment` | 구매사 → 물류사 | `booking-request` | `booking` / `pending` · `accepted` · `rejected` |
| `cancel-booking` | 구매사 → 물류사 | `cancel-booking-request` | `cancel-booking-result` / `cancelled` · `rejected` |
| `check-delivery` | 구매사 → 물류사 | `delivery-query` | `delivery-status` / `found` · `not_found` |
| `receive-shipment-event` | 물류사 → 구매사 | `shipment-event` | `event-ack` |

- 요청·응답 모두 A2A **data Part 하나**(JSON 객체)입니다. 응답은 Task의 Artifact로 돌려줍니다.
- 받는 쪽은 `kind`로 처리할 스킬을 고릅니다 (A2A 메시지에는 스킬 ID가 없음).
- Agent Card의 각 스킬 `tags`에 `contract:logistics/1`(지원 major)을 넣습니다.
- 한 운송 요청(RFQ)에서 생기는 Task는 모두 `contextId = rfq_id`로 묶습니다.

## Task 상태와 업무 결과

| 상황 | A2A Task 상태 | 업무 결과 |
|---|---|---|
| 정상 처리 | `completed` | 응답 메시지 |
| 견적 거절, 발주 거절, 취소 거절, 조회 결과 없음 | `completed` | `status: declined / rejected / not_found` |
| 담당자 처리 대기 (수동 모드) | `working` 유지 | — |
| 정보 부족 | `input-required` + 질문 | — |
| 계약 위반(버전·종류·형식), 같은 업무키에 다른 내용, 내부 오류 | `failed` + 이유 메시지 | — |

## 업무키

- `booking-request`, `cancel-booking-request`에는 구매사가 정한 `business_key`를 넣습니다. 예: `K정밀웍스:{rfq_id}:book:{물류사}:v1`.
- 받는 쪽은 같은 키·같은 내용이면 처음 결과를 그대로 돌려주고, 같은 키·다른 내용이면 `failed`로 거부합니다.
- `quote-request`는 `rfq_id`가 업무키 역할을 합니다. 같은 물류사에 같은 `rfq_id`로 다시 보내면 같은 견적을 돌려받습니다.
- `shipment-event`는 `event_id`로 중복을 거르고, `seq`가 이미 받은 것보다 작으면 무시합니다.

## 숫자

A2A data Part는 숫자를 float으로 돌려줍니다(`174000` → `174000.0`). 정수 필드는 소수부가 0인 float을 받아 주고, `174000.5`처럼 소수부가 있으면 거부합니다.

## 사용 (파이썬)

```python
from logistics_contract import QuoteRequest, parse_request, parse_response, to_data, ContractError

data = to_data(QuoteRequest(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480,
                            origin="창원", destination="평택"))
msg = parse_request(data)                    # 받는 쪽: kind로 모델 선택 + 버전 확인
quote = parse_response(raw, "quote")         # 보낸 쪽: 응답 확인
```

파이썬이 아닌 구현은 `src/logistics_contract/schemas/*.json`(JSON Schema)과 `src/logistics_contract/examples/catalog.json`(예시)을 기준으로 합니다.

## 개발

```cmd
uv sync
uv run python tools/export_schemas.py   :: 모델을 고쳤으면 스키마 다시 생성
uv run pytest
uv build                                :: dist\logistics_contract-<버전>-py3-none-any.whl
```
