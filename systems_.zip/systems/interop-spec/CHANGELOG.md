# CHANGELOG

## 1.1.0 — 2026-10-15

- `schema_version` 1.1.
- `quote`(quoted)에 선택 필드 `co2_kg`(운송 탄소 배출 추정치, kg) 추가. 1.0 수신자는 무시하므로 호환.
- 예시 `quote-with-co2-v1.1` 추가.

## 1.0.0 — 2026-10-15

- 첫 버전 (`schema_version` 1.0).
- 메시지: quote-request / quote(quoted·declined), booking-request / booking(pending·accepted·rejected),
  cancel-booking-request / cancel-booking-result, delivery-query / delivery-status(found·not_found),
  shipment-event / event-ack.
- `parse_request`, `parse_response`, `to_data`, `ContractError`, 예시 메시지 카탈로그, JSON Schema.
