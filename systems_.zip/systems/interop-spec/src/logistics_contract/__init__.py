"""logistics-contract: K정밀웍스와 물류사 사이의 A2A 메시지 계약."""

from importlib.metadata import PackageNotFoundError, version

from .models import (
    ALL_MODELS,
    CONTRACT_MAJOR,
    CONTRACT_NAME,
    CONTRACT_TAG,
    REQUEST_MODELS,
    RESPONSE_MODELS,
    SCHEMA_VERSION,
    SKILL_BOOK_SHIPMENT,
    SKILL_CANCEL_BOOKING,
    SKILL_CHECK_DELIVERY,
    SKILL_QUOTE,
    SKILL_RECEIVE_SHIPMENT_EVENT,
    Booking,
    BookingRejected,
    BookingRequest,
    CancelBookingRequest,
    CancelBookingResult,
    ContractMessage,
    DeliveryNotFound,
    DeliveryQuery,
    DeliveryStatus,
    EventAck,
    Quote,
    QuoteDeclined,
    QuoteRequest,
    ShipmentEvent,
    ShipmentStatus,
)
from .parsing import ContractError, ensure_compatible, major_of, parse_request, parse_response, to_data

try:
    __version__ = version("logistics-contract")
except PackageNotFoundError:  # 설치하지 않고 소스 트리에서 바로 import한 경우
    __version__ = "0.0.0"

__all__ = [
    "ALL_MODELS", "CONTRACT_MAJOR", "CONTRACT_NAME", "CONTRACT_TAG", "REQUEST_MODELS",
    "RESPONSE_MODELS", "SCHEMA_VERSION",
    "SKILL_BOOK_SHIPMENT", "SKILL_CANCEL_BOOKING", "SKILL_CHECK_DELIVERY", "SKILL_QUOTE",
    "SKILL_RECEIVE_SHIPMENT_EVENT",
    "Booking", "BookingRejected", "BookingRequest", "CancelBookingRequest", "CancelBookingResult",
    "ContractMessage", "DeliveryNotFound", "DeliveryQuery", "DeliveryStatus", "EventAck",
    "Quote", "QuoteDeclined", "QuoteRequest", "ShipmentEvent", "ShipmentStatus",
    "ContractError", "ensure_compatible", "major_of", "parse_request", "parse_response", "to_data",
    "__version__",
]
