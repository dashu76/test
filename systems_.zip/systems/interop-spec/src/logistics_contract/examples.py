# 파일명: examples.py
"""패키지에 들어 있는 예시 메시지. 각 회사 서버의 계약 테스트가 같은 예시를 쓰게 한다."""

import json
from importlib.resources import files
from typing import Any

from .parsing import parse_request, parse_response
from .models import ContractMessage


def load_examples() -> list[dict[str, Any]]:
    text = files("logistics_contract").joinpath("examples/catalog.json").read_text(encoding="utf-8")
    return json.loads(text)["examples"]


def example(name: str) -> dict[str, Any]:
    """이름으로 예시 메시지 하나(dict 사본)를 꺼낸다."""
    for item in load_examples():
        if item["name"] == name:
            return dict(item["message"])
    raise KeyError(name)


def parse_example(item: dict[str, Any]) -> ContractMessage:
    if item["role"] == "request":
        return parse_request(item["message"])
    return parse_response(item["message"], item["expected_kind"])
