# 파일명: models.py
"""logistics/1 계약의 메시지 모델.

- 모든 메시지는 A2A data Part 하나(JSON 객체)로 오간다.
- `kind`로 메시지 종류를 구분한다. A2A 메시지에는 "어느 스킬을 부르는지" 필드가 없기 때문이다.
- `schema_version`의 major가 같으면 호환이다. 받는 쪽은 모르는 필드를 무시한다(extra="ignore").
- 금액·일수는 정수다. A2A data Part는 숫자를 float(42000.0)로 돌려주므로, 소수부가 0인 float은
  pydantic이 정수로 받아 준다. 42000.5처럼 소수부가 있으면 거부한다(Ch16 float_check).
"""

from datetime import date, datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

CONTRACT_NAME = "logistics"
CONTRACT_MAJOR = 1
SCHEMA_VERSION = "1.1"
CONTRACT_TAG = f"contract:{CONTRACT_NAME}/{CONTRACT_MAJOR}"

# 스킬 ID (Agent Card의 AgentSkill.id)
SKILL_QUOTE = "quote"
SKILL_BOOK_SHIPMENT = "book-shipment"
SKILL_CANCEL_BOOKING = "cancel-booking"
SKILL_CHECK_DELIVERY = "check-delivery"
SKILL_RECEIVE_SHIPMENT_EVENT = "receive-shipment-event"


class ShipmentStatus(StrEnum):
    PENDING = "pending"            # 발주 수락 대기
    ACCEPTED = "accepted"          # 수락, 집하 전
    PICKED_UP = "picked_up"
    IN_TRANSIT = "in_transit"
    CUSTOMS_HOLD = "customs_hold"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


class ContractMessage(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    schema_version: str = SCHEMA_VERSION


# ---------- quote (구매사 → 물류사) ----------

class QuoteRequest(ContractMessage):
    kind: Literal["quote-request"] = "quote-request"
    rfq_id: str = Field(min_length=1, description="구매사의 운송 요청 번호. 같은 물류사에 다시 보내면 같은 견적을 돌려받는다")
    buyer: str = Field(min_length=1)
    item: str = Field(min_length=1)
    weight_kg: float = Field(gt=0)
    origin: str = Field(min_length=1)
    destination: str = Field(min_length=1)
    need_by: date | None = None


class Quote(ContractMessage):
    kind: Literal["quote"] = "quote"
    status: Literal["quoted"] = "quoted"
    quote_id: str
    rfq_id: str
    carrier: str
    price_krw: int = Field(ge=0)
    eta_days: int = Field(ge=0)
    valid_until: datetime
    co2_kg: float | None = Field(default=None, ge=0, description="(1.1) 운송 탄소 배출 추정치. 1.0 수신자는 무시한다")


class QuoteDeclined(ContractMessage):
    kind: Literal["quote"] = "quote"
    status: Literal["declined"] = "declined"
    rfq_id: str
    carrier: str
    reason: str


# ---------- book-shipment (구매사 → 물류사) ----------

class BookingRequest(ContractMessage):
    kind: Literal["booking-request"] = "booking-request"
    business_key: str = Field(min_length=1, description="재전송해도 한 번만 처리되도록 구매사가 정하는 업무키")
    rfq_id: str
    quote_id: str
    event_callback_url: str | None = Field(default=None, description="배송 상태 알림을 받을 구매사 A2A 주소")


class Booking(ContractMessage):
    kind: Literal["booking"] = "booking"
    status: Literal["pending", "accepted"]
    business_key: str
    booking_id: str
    quote_id: str
    tracking_no: str | None = None


class BookingRejected(ContractMessage):
    kind: Literal["booking"] = "booking"
    status: Literal["rejected"] = "rejected"
    business_key: str
    quote_id: str
    reason: str


# ---------- cancel-booking (구매사 → 물류사) ----------

class CancelBookingRequest(ContractMessage):
    kind: Literal["cancel-booking-request"] = "cancel-booking-request"
    business_key: str = Field(min_length=1)
    booking_id: str
    reason: str = ""


class CancelBookingResult(ContractMessage):
    kind: Literal["cancel-booking-result"] = "cancel-booking-result"
    status: Literal["cancelled", "rejected"]
    booking_id: str
    reason: str = ""


# ---------- check-delivery (구매사 → 물류사) ----------

class DeliveryQuery(ContractMessage):
    kind: Literal["delivery-query"] = "delivery-query"
    tracking_no: str = Field(min_length=1)


class DeliveryStatus(ContractMessage):
    kind: Literal["delivery-status"] = "delivery-status"
    status: Literal["found"] = "found"
    tracking_no: str
    shipment_status: ShipmentStatus
    seq: int = Field(ge=0, description="물류사 측 상태 변경 순번. 뒤로 가는 변경은 무시한다")
    eta: date | None = None
    note: str = ""


class DeliveryNotFound(ContractMessage):
    kind: Literal["delivery-status"] = "delivery-status"
    status: Literal["not_found"] = "not_found"
    tracking_no: str


# ---------- receive-shipment-event (물류사 → 구매사) ----------

class ShipmentEvent(ContractMessage):
    kind: Literal["shipment-event"] = "shipment-event"
    event_id: str = Field(min_length=1, description="중복 수신을 걸러내는 키")
    carrier: str
    booking_id: str
    tracking_no: str
    seq: int = Field(ge=0)
    shipment_status: ShipmentStatus
    at: datetime
    note: str = ""


class EventAck(ContractMessage):
    kind: Literal["event-ack"] = "event-ack"
    event_id: str
    duplicate: bool = False


# 받는 쪽이 kind로 요청 모델을 고를 때 쓴다.
REQUEST_MODELS: dict[str, type[ContractMessage]] = {
    "quote-request": QuoteRequest,
    "booking-request": BookingRequest,
    "cancel-booking-request": CancelBookingRequest,
    "delivery-query": DeliveryQuery,
    "shipment-event": ShipmentEvent,
}

# 응답은 같은 kind 안에서 status로 갈린다.
RESPONSE_MODELS: dict[tuple[str, str], type[ContractMessage]] = {
    ("quote", "quoted"): Quote,
    ("quote", "declined"): QuoteDeclined,
    ("booking", "pending"): Booking,
    ("booking", "accepted"): Booking,
    ("booking", "rejected"): BookingRejected,
    ("cancel-booking-result", "cancelled"): CancelBookingResult,
    ("cancel-booking-result", "rejected"): CancelBookingResult,
    ("delivery-status", "found"): DeliveryStatus,
    ("delivery-status", "not_found"): DeliveryNotFound,
    ("event-ack", ""): EventAck,  # status 필드가 없는 응답
}

# JSON Schema로 내보낼 모델 (파일 이름 → 모델)
ALL_MODELS: dict[str, type[ContractMessage]] = {
    "quote-request": QuoteRequest,
    "quote": Quote,
    "quote-declined": QuoteDeclined,
    "booking-request": BookingRequest,
    "booking": Booking,
    "booking-rejected": BookingRejected,
    "cancel-booking-request": CancelBookingRequest,
    "cancel-booking-result": CancelBookingResult,
    "delivery-query": DeliveryQuery,
    "delivery-status": DeliveryStatus,
    "delivery-not-found": DeliveryNotFound,
    "shipment-event": ShipmentEvent,
    "event-ack": EventAck,
}
