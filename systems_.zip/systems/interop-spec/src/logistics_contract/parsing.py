# 파일명: parsing.py
"""받은 data Part(dict)를 계약 모델로 바꾸는 함수. 버전·종류·형식 오류를 ContractError 하나로 모은다."""

from typing import Any

from pydantic import ValidationError

from .models import CONTRACT_MAJOR, REQUEST_MODELS, RESPONSE_MODELS, ContractMessage


class ContractError(ValueError):
    """계약 위반. 받는 쪽은 이 오류를 A2A Task failed로 돌려준다."""


def major_of(schema_version: str) -> int:
    try:
        return int(str(schema_version).split(".")[0])
    except ValueError as exc:
        raise ContractError(f"schema_version 형식이 잘못됐다: {schema_version!r}") from exc


def ensure_compatible(raw: dict[str, Any]) -> None:
    version = raw.get("schema_version")
    if version is None:
        raise ContractError("schema_version이 없다")
    if major_of(version) != CONTRACT_MAJOR:
        raise ContractError(
            f"지원하지 않는 계약 버전: {version} (지원: {CONTRACT_MAJOR}.x)"
        )


def _validate(model: type[ContractMessage], raw: dict[str, Any]) -> ContractMessage:
    try:
        return model.model_validate(raw)
    except ValidationError as exc:
        raise ContractError(f"{model.__name__} 형식 오류: {exc.errors(include_url=False)}") from exc


def parse_request(raw: Any) -> ContractMessage:
    """요청 메시지: kind로 모델을 고른다."""
    if not isinstance(raw, dict):
        raise ContractError("메시지는 JSON 객체여야 한다")
    ensure_compatible(raw)
    model = REQUEST_MODELS.get(raw.get("kind", ""))
    if model is None:
        raise ContractError(f"알 수 없는 요청 종류: {raw.get('kind')!r}")
    return _validate(model, raw)


def parse_response(raw: Any, expected_kind: str) -> ContractMessage:
    """응답 메시지: 기대한 kind인지 확인하고 status로 모델을 고른다."""
    if not isinstance(raw, dict):
        raise ContractError("메시지는 JSON 객체여야 한다")
    ensure_compatible(raw)
    if raw.get("kind") != expected_kind:
        raise ContractError(f"기대한 응답 종류 {expected_kind!r}가 아니다: {raw.get('kind')!r}")
    model = RESPONSE_MODELS.get((expected_kind, raw.get("status", "")))
    if model is None:
        raise ContractError(f"{expected_kind}의 알 수 없는 status: {raw.get('status')!r}")
    return _validate(model, raw)


def to_data(message: ContractMessage) -> dict[str, Any]:
    """보낼 때: data Part에 넣을 JSON 호환 dict."""
    return message.model_dump(mode="json")
