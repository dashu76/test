# 버전 규칙과 배포 절차

## 패키지 버전 (`pyproject.toml`의 version)과 메시지 버전 (`schema_version`)

| 바뀌는 것 | 패키지 버전 | `schema_version` | 호환 |
|---|---|---|---|
| 버그 수정, 설명·예시 변경 | patch: 1.0.0 → 1.0.1 | 그대로 `1.0` | 호환 |
| 선택 필드 추가, 새 메시지 종류·status 추가 | minor: 1.0.x → 1.1.0 | `1.1` | 호환. 1.0 수신자는 모르는 필드를 무시 |
| 필드 삭제·이름 변경·필수화, 의미 변경 | major: 1.x → 2.0.0 | `2.0` | 비호환. 수신자는 Task `failed` + "지원하지 않는 계약 버전" |

- `schema_version`은 `"major.minor"`만 씁니다. 호환 판단은 major만 봅니다.
- major를 올릴 때는 이전 major를 한동안 함께 받아 주는 서버가 있어야 합니다. 그 기간과 방법은 major를 올리는 시점에 따로 정합니다.

## 배포 절차

1. 이 폴더에서 수정 → `pyproject.toml` 버전 올리기 → `CHANGELOG.md` 기록.
2. 모델을 고쳤으면 `uv run python tools/export_schemas.py`.
3. `uv run pytest` → `uv build` → `dist\logistics_contract-X.Y.Z-py3-none-any.whl`.
4. **새 버전을 쓰기로 한 서버만** 자기 `vendor\`에 wheel을 복사하고 `pyproject.toml`을 고칩니다.

   ```toml
   dependencies = ["logistics-contract==X.Y.Z", ...]

   [tool.uv.sources]
   logistics-contract = { path = "vendor/logistics_contract-X.Y.Z-py3-none-any.whl" }
   ```

5. 그 서버에서 `uv sync` → 테스트.

서버마다 다른 버전을 써도 됩니다(예: 구매사 1.0.0, 물류사 B 1.1.0). 서버 폴더는 이 폴더를 경로로 참조하지 않으므로 혼자 복사해 가도 설치됩니다.
