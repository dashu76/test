from datetime import datetime, timedelta
from pathlib import Path

import pytest

from klogistics_carrier.domain import KST, load_pricing
from klogistics_carrier.settings import APP_ROOT, Settings
from klogistics_carrier.skills import CarrierService
from klogistics_carrier.store import Store


class FakeClock:
    def __init__(self) -> None:
        self.now = datetime(2026, 10, 15, 9, 0, tzinfo=KST)

    def __call__(self) -> datetime:
        return self.now

    def advance(self, **kwargs) -> None:
        self.now += timedelta(**kwargs)


def write_pricing(folder: Path, quote="auto", booking="auto", on_timeout="auto", timeout_min=30) -> Path:
    path = folder / f"pricing-{quote}-{booking}-{on_timeout}.toml"
    path.write_text(
        "[pricing]\nbase_krw = 35000\nper_kg_krw = 320\nround_to_krw = 1000\neta_days = 2\n"
        "max_weight_kg = 10000\nquote_valid_hours = 24\n"
        f'[modes]\nquote = "{quote}"\nbooking = "{booking}"\nmanual_timeout_min = {timeout_min}\n'
        f'on_timeout = "{on_timeout}"\n', encoding="utf-8")
    return path


def make_settings(tmp_path, port: int = 5020, public_url: str | None = None,
                  pricing_file: Path | None = None) -> Settings:
    return Settings(
        carrier_name="K-Logistics",
        id_prefix="K",
        bind_host="127.0.0.1",
        port=port,
        public_url=public_url or f"http://127.0.0.1:{port}",
        db_path=tmp_path / "klogistics.sqlite3",
        pricing_file=pricing_file or APP_ROOT / "config" / "pricing.toml",   # 기본: 수동+시간 초과
        allowed_callback_hosts=frozenset({"127.0.0.1", "localhost"}),
        poll_s=0.05,
    )


def make_service(settings: Settings, clock) -> CarrierService:
    return CarrierService(settings, Store(settings.db_path), load_pricing(settings.pricing_file), clock)


@pytest.fixture
def clock() -> FakeClock:
    return FakeClock()


@pytest.fixture
def settings(tmp_path) -> Settings:
    return make_settings(tmp_path)


@pytest.fixture
def service(settings, clock) -> CarrierService:
    """회사 설정 그대로: 견적·발주 모두 담당자 확인(30분 넘으면 규칙대로 자동 처리)."""
    return make_service(settings, clock)


@pytest.fixture
def auto_service(tmp_path, clock) -> CarrierService:
    return make_service(make_settings(tmp_path, pricing_file=write_pricing(tmp_path)), clock)


@pytest.fixture
def decline_service(tmp_path, clock) -> CarrierService:
    pricing = write_pricing(tmp_path, quote="manual-with-timeout", booking="manual-with-timeout", on_timeout="decline")
    return make_service(make_settings(tmp_path, pricing_file=pricing), clock)
