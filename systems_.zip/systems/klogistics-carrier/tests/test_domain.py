from datetime import datetime

import pytest

from logistics_contract import ShipmentStatus as S

from klogistics_carrier.domain import (
    KST,
    InvalidTransition,
    calc_price,
    can_cancel,
    check_transition,
    load_pricing,
    overweight_reason,
)
from klogistics_carrier.settings import APP_ROOT
from conftest import write_pricing

PRICING = load_pricing(APP_ROOT / "config" / "pricing.toml")


def test_company_config_is_manual_with_timeout():
    assert (PRICING.quote_mode, PRICING.booking_mode, PRICING.on_timeout) == ("manual-with-timeout",) * 2 + ("auto",)


def test_price():
    assert calc_price(480, PRICING) == (189000, 2)   # 35,000 + 320×480 = 188,600 → 189,000


def test_overweight():
    assert overweight_reason(10001, PRICING) and overweight_reason(10000, PRICING) is None


def test_due_at():
    now = datetime(2026, 10, 15, 9, 0, tzinfo=KST)
    assert PRICING.due_at("manual-with-timeout", now) == datetime(2026, 10, 15, 9, 30, tzinfo=KST)
    assert PRICING.due_at("manual", now) is None


def test_bad_mode_rejected(tmp_path):
    with pytest.raises(ValueError):
        load_pricing(write_pricing(tmp_path, quote="sometimes"))


def test_transitions():
    check_transition(S.PENDING, S.ACCEPTED)
    with pytest.raises(InvalidTransition):
        check_transition(S.DELIVERED, S.IN_TRANSIT)
    assert can_cancel(S.PENDING) and not can_cancel(S.PICKED_UP)
