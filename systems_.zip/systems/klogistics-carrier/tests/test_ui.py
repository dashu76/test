"""담당자 업무 화면(/ui)과 화면이 쓰는 내부 API (설계: systems/docs/p6-carrier-ui.md).

K-Logistics는 견적·발주 수락을 담당자가 확인한다. 화면의 처리 버튼은 아래 API를 그대로 부른다.
"""

import dataclasses
import json
import threading

import httpx
import pytest

from logistics_contract import BookingRequest, QuoteRequest

from conftest import make_settings
from fake_buyer import ThreadServer, free_port
from klogistics_carrier import obs_hook
from klogistics_carrier.app import build_app, build_service
from fake_hub import HubLog, build_fake_hub

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")


class Clock:
    """화면 테스트는 실제 서버 스레드에서 돌므로, 처리 마감 확인용으로 앞으로 돌릴 수 있는 시계를 넣는다."""

    def __init__(self, service) -> None:
        self.real, self.offset = service.clock, None

    def __call__(self):
        now = self.real()
        return now + self.offset if self.offset else now


def start(tmp_path, **changes):
    port = free_port()
    settings = dataclasses.replace(make_settings(tmp_path, port=port), outbox_interval_s=0, **changes)
    service = build_service(settings)
    service.clock = Clock(service)
    server = ThreadServer(build_app(settings, service), port).start()
    return settings, service, server


@pytest.fixture
def carrier(tmp_path):
    settings, service, server = start(tmp_path)
    yield settings, service, httpx.Client(base_url=settings.public_url, timeout=10)
    server.stop()


def test_ui_page_and_root_redirect(carrier):
    _, _, api = carrier
    page = api.get("/ui")
    assert page.status_code == 200 and "/api/stream" in page.text
    assert api.get("/", follow_redirects=False).headers["location"] == "/ui"


def test_ui_disabled_keeps_api(tmp_path):
    settings, _, server = start(tmp_path, ui_enabled=False)
    try:
        api = httpx.Client(base_url=settings.public_url, timeout=10)
        assert api.get("/ui").status_code == 404
        assert api.get("/api/inbox").status_code == 200
    finally:
        server.stop()


def test_meta_reports_manual_modes(carrier):
    _, service, api = carrier
    m = api.get("/api/meta").json()
    assert m["name"] == "K-Logistics"
    assert m["modes"] == {"quote": "manual-with-timeout", "booking": "manual-with-timeout"}
    assert m["pricing"]["manual_timeout_min"] == service.pricing.manual_timeout_min
    assert m["pricing"]["on_timeout"] == "auto" and m["poll_s"] == service.settings.poll_s
    assert set(m["transitions"]["in_transit"]) == {"customs_hold", "delivered"}


def test_quote_desk_flow(carrier):
    """견적 요청함: 대기 → 질문 → (구매사 답) → 가격을 고쳐 승인."""
    _, service, api = carrier
    service.quote(QuoteRequest(**RFQ), "t1")
    [q] = api.get("/api/quotes").json()
    assert q["status"] == "awaiting" and q["proposed_price"] == 189000 and q["price_krw"] is None
    assert q["item"] == "베어링" and q["due_at"] and q["created_at"]

    assert api.post("/api/quotes/RFQ-1/ask", json={"question": "팔레트 규격은?"}).status_code == 200
    assert api.get("/api/quotes").json()[0]["status"] == "question"
    service.answer("t1", "1100×1100")
    q = api.get("/api/quotes").json()[0]
    assert q["status"] == "awaiting" and q["qa"] == [{"q": "팔레트 규격은?", "a": "1100×1100"}]

    r = api.post("/api/quotes/RFQ-1/approve", json={"price_krw": 180000, "eta_days": 3})
    assert r.status_code == 200
    q = api.get("/api/quotes").json()[0]
    assert (q["status"], q["price_krw"], q["eta_days"], q["decided_by"]) == ("quoted", 180000, 3, "staff")
    assert q["valid_until"]
    again = api.post("/api/quotes/RFQ-1/decline", json={"reason": "x"})
    assert again.status_code == 409 and "이미 처리된" in again.json()["detail"]


def test_booking_desk_flow(carrier):
    """발주 수신함: 수락 대기 → 수락(운송장) / 다른 건은 거절(사유)."""
    _, service, api = carrier
    q = service.quote(QuoteRequest(**RFQ), "t1")
    q = service.approve_quote("RFQ-1")
    service.book(BookingRequest(business_key="k1", rfq_id="RFQ-1", quote_id=q.quote_id,
                                event_callback_url="http://127.0.0.1:5010"), "t2")
    [b] = [x for x in api.get("/api/bookings").json() if x["business_key"] == "k1"]
    assert b["status"] == "pending" and b["tracking_no"] is None and b["due_at"]

    r = api.post(f"/api/bookings/{b['booking_id']}/accept").json()
    b = next(x for x in api.get("/api/bookings").json() if x["business_key"] == "k1")
    assert b["status"] == "accepted" and b["tracking_no"] == r["tracking_no"] and b["decided_by"] == "staff"
    history = api.get(f"/api/shipments/{b['tracking_no']}/history").json()
    assert [(h["status"], h["note"]) for h in history] == [("accepted", "담당자 수락")]

    service.quote(QuoteRequest(**{**RFQ, "rfq_id": "RFQ-2"}), "t3")
    q2 = service.approve_quote("RFQ-2")
    service.book(BookingRequest(business_key="k2", rfq_id="RFQ-2", quote_id=q2.quote_id), "t4")
    b2 = next(x for x in api.get("/api/bookings").json() if x["business_key"] == "k2")
    api.post(f"/api/bookings/{b2['booking_id']}/reject", json={"reason": "차량 부족"})
    b2 = next(x for x in api.get("/api/bookings").json() if x["business_key"] == "k2")
    assert b2["status"] == "rejected" and b2["reason"] == "차량 부족"


def test_inbox_view_moves_revision_only_when_it_expires(carrier):
    """화면은 볼 때마다 inbox로 처리 마감을 정리한다. 정리할 것이 없으면 revision이 그대로여야 화면이 끝없이 다시 그리지 않는다."""
    _, service, api = carrier
    service.quote(QuoteRequest(**RFQ), "t1")
    rev = service.store.revision
    api.get("/api/inbox")
    api.get("/api/inbox")
    assert service.store.revision == rev

    from datetime import timedelta
    service.clock.offset = timedelta(minutes=service.pricing.manual_timeout_min + 1)
    api.get("/api/inbox")                                              # 마감 지남 → 규칙대로 자동 견적
    assert service.store.revision == rev + 1
    q = api.get("/api/quotes").json()[0]
    assert (q["status"], q["decided_by"]) == ("quoted", "timeout")


def test_stream_sends_change_on_staff_action(carrier):
    settings, service, api = carrier
    service.quote(QuoteRequest(**RFQ), "t1")
    got, ready = [], threading.Event()

    def read():
        with httpx.stream("GET", f"{settings.public_url}/api/stream", timeout=10) as response:
            for line in response.iter_lines():
                if line.startswith("data:"):
                    got.append(json.loads(line[5:]))
                    ready.set()
                    if len(got) >= 2:
                        return

    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    assert ready.wait(5)
    api.get("/api/inbox")                                              # 바뀐 것 없음
    api.post("/api/quotes/RFQ-1/approve", json={})
    reader.join(5)
    assert len(got) == 2 and got[1]["rev"] == got[0]["rev"] + 1


def test_started_event_links_console(tmp_path):
    log = HubLog()
    hub_port = free_port()
    hub = ThreadServer(build_fake_hub(log), hub_port).start()
    try:
        _, _, server = start(tmp_path, obs_url=f"http://127.0.0.1:{hub_port}")
        server.stop()
        log.wait_for(lambda h: "agent.started" in h.types())
        assert log.of("agent.started")[0]["payload"]["console"] == "/ui"
    finally:
        obs_hook.stop(timeout_s=0.5)
        hub.stop()
