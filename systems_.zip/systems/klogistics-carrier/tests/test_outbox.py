"""구매사 배송 알림 outbox (S-17·S-18). 담당자 수락·집하·통관이 알림으로 나가는지, 가짜 구매사로 확인한다."""

import asyncio

import pytest

from logistics_contract import BookingRequest, CancelBookingRequest, QuoteRequest, ShipmentStatus

from fake_buyer import BuyerBehavior, ThreadServer, build_fake_buyer, free_port
from klogistics_carrier.outbox import Notifier, Outbox

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")


@pytest.fixture
def buyer():
    b = BuyerBehavior()
    port = free_port()
    server = ThreadServer(build_fake_buyer(b, port), port).start()
    b.url = f"http://127.0.0.1:{port}"
    yield b
    server.stop()


@pytest.fixture
def outbox(service, clock):
    return Outbox(service.store, Notifier(timeout_s=1.0), clock, max_attempts=3)


def booking(service, callback_url):
    service.quote(QuoteRequest(**RFQ), "t1")
    q = service.approve_quote("RFQ-1")
    w = service.book(BookingRequest(business_key="k1", rfq_id="RFQ-1", quote_id=q.quote_id,
                                    event_callback_url=callback_url), "t2")
    return w, service.inbox()["bookings"][0]["booking_id"]


def test_staff_accept_and_customs_hold_are_notified(service, outbox, buyer):
    w, booking_id = booking(service, buyer.url)
    assert outbox.list() == []                          # 수락 전에는 알림 없음
    service.accept_booking(booking_id)
    tracking = service.poll(w).tracking_no
    service.advance_shipment(tracking, ShipmentStatus.PICKED_UP, "창원 집하")
    service.advance_shipment(tracking, ShipmentStatus.IN_TRANSIT)
    service.advance_shipment(tracking, ShipmentStatus.CUSTOMS_HOLD, "서류 보완 요청 · 2일 지연")   # S-21
    assert asyncio.run(outbox.dispatch_once())["sent"] == 4
    assert [(e.seq, e.shipment_status) for e in buyer.events] == [
        (1, "accepted"), (2, "picked_up"), (3, "in_transit"), (4, "customs_hold")]
    assert buyer.events[-1].note == "서류 보완 요청 · 2일 지연"
    assert buyer.events[0].carrier == "K-Logistics"


def test_cancel_before_accept_is_not_notified(service, outbox, buyer):
    _, booking_id = booking(service, buyer.url)
    service.cancel(CancelBookingRequest(business_key="c1", booking_id=booking_id))
    assert outbox.list() == []


def test_legacy_orders_have_no_callback(service, outbox):
    service.advance_shipment("ORDER-1001", ShipmentStatus.DELIVERED, "도착")
    assert outbox.list() == []
