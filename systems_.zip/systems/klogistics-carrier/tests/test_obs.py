"""관찰 이벤트 (S-25). 허브가 없으면 아무 일도 없고, 허브가 꺼져 있어도 업무는 그대로 된다."""

import asyncio
import dataclasses
import time

import pytest

from a2a.helpers.proto_helpers import new_data_part
from a2a.types.a2a_pb2 import Part, TaskState
from logistics_contract import BookingRequest, QuoteRequest, ShipmentStatus
from logistics_contract.examples import example

from conftest import make_settings
from fake_buyer import BuyerBehavior, ThreadServer, build_fake_buyer, free_port
from fake_hub import HubLog, build_fake_hub
from klogistics_carrier import obs_hook
from klogistics_carrier.app import build_app, build_service
from klogistics_carrier.outbox import Notifier, Outbox
from test_a2a_roundtrip import DONE, Buyer

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")
LEGACY_QUERY = {"schema_version": "1.0", "kind": "delivery-query", "tracking_no": "ORDER-1002"}


@pytest.fixture(autouse=True)
def reset_hook():
    yield
    obs_hook.stop(timeout_s=0.5)


@pytest.fixture
def hub():
    log = HubLog()
    port = free_port()
    server = ThreadServer(build_fake_hub(log), port).start()
    log.url = f"http://127.0.0.1:{port}"
    yield log
    server.stop()


def run_carrier(tmp_path, obs_url: str):
    port = free_port()
    settings = dataclasses.replace(make_settings(tmp_path, port=port), obs_url=obs_url, outbox_interval_s=0)
    service = build_service(settings)
    return settings, service, ThreadServer(build_app(settings, service), port).start()


def test_without_hub_nothing_is_sent():
    obs_hook.start("klogistics-carrier", "http://127.0.0.1:5020", "")
    obs_hook.emit("agent.started")
    assert not obs_hook.enabled() and obs_hook._queue.unfinished_tasks == 0


def test_manual_quote_with_question_reaches_hub(tmp_path, hub):
    settings, service, server = run_carrier(tmp_path, hub.url)
    try:
        buyer = Buyer(settings.public_url)
        task = asyncio.run(buyer.send([new_data_part(example("quote-request"))], context_id="RFQ-20261015-001"))
        asyncio.run(buyer.wait(task.id, DONE, timeout=0.3))
        service.ask("RFQ-20261015-001", "상차 시간대는?")
        asyncio.run(buyer.wait(task.id, (TaskState.TASK_STATE_INPUT_REQUIRED,)))
        asyncio.run(buyer.send([Part(text="오전 9~11시")], task_id=task.id, context_id=task.context_id))
        asyncio.run(buyer.wait(task.id, DONE, timeout=0.3))
        service.approve_quote("RFQ-20261015-001")
        assert asyncio.run(buyer.wait(task.id, DONE)).status.state == TaskState.TASK_STATE_COMPLETED
        hub.wait_for(lambda h: any(e["payload"].get("to") == "TASK_STATE_COMPLETED" for e in h.of("task.state")))
    finally:
        server.stop()

    assert hub.of("agent.started")[0]["payload"]["name"] == "K-Logistics"
    assert hub.of("task.received")[0]["payload"]["text"].startswith("quote-request")
    states = [e["payload"] for e in hub.of("task.state") if e["taskId"] == task.id]
    assert [s["to"] for s in states] == ["TASK_STATE_WORKING", "TASK_STATE_WORKING", "TASK_STATE_INPUT_REQUIRED",
                                         "TASK_STATE_WORKING", "TASK_STATE_WORKING", "TASK_STATE_COMPLETED"]
    assert "담당자" in states[1]["note"]
    assert states[2]["result"] == "상차 시간대는?"
    assert states[3]["from"] == "TASK_STATE_INPUT_REQUIRED"
    assert states[-1]["result"].startswith("quote quoted")
    assert hub.of("task.resumed")[0]["payload"]["text"] == "오전 9~11시"


def test_s25_hub_down_business_continues(tmp_path):
    settings, _, server = run_carrier(tmp_path, f"http://127.0.0.1:{free_port()}")   # 아무도 듣지 않는 주소
    try:
        buyer = Buyer(settings.public_url)
        started = time.monotonic()
        for _ in range(3):
            task = asyncio.run(buyer.send([new_data_part(LEGACY_QUERY)]))
            assert asyncio.run(buyer.wait(task.id, DONE)).status.state == TaskState.TASK_STATE_COMPLETED
        assert time.monotonic() - started < 10   # 허브를 기다리지 않는다
    finally:
        server.stop()


def test_outbox_requests_reach_hub(auto_service, clock, hub):
    service = auto_service
    obs_hook.start("klogistics-carrier", "http://127.0.0.1:5020", hub.url)
    behavior = BuyerBehavior()
    buyer_port = free_port()
    buyer_url = f"http://127.0.0.1:{buyer_port}"
    outbox = Outbox(service.store, Notifier(timeout_s=1.0), clock, max_attempts=3)
    q = service.quote(QuoteRequest(**RFQ), "t1")
    b = service.book(BookingRequest(business_key="k1", rfq_id="RFQ-1", quote_id=q.quote_id,
                                    event_callback_url=buyer_url), "t2")

    assert asyncio.run(outbox.dispatch_once())["retry"] == 1      # 구매사 꺼짐
    buyer = ThreadServer(build_fake_buyer(behavior, buyer_port), buyer_port).start()
    try:
        service.advance_shipment(b.tracking_no, ShipmentStatus.PICKED_UP)
        clock.advance(seconds=5)
        assert asyncio.run(outbox.dispatch_once())["sent"] == 2
    finally:
        buyer.stop()
    hub.wait_for(lambda h: len(h.of("outbox.sent")) == 2)

    assert hub.of("card.failed")[0]["payload"]["url"] == buyer_url
    assert len(hub.of("card.fetched")) == 1
    assert [e["payload"]["state"] for e in hub.of("request.done")] == ["TASK_STATE_COMPLETED"] * 2
    assert [e["payload"]["status"] for e in hub.of("outbox.sent")] == ["accepted", "picked_up"]
