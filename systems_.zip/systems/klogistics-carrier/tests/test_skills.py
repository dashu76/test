"""담당자 확인(수동) 흐름, 시간 초과, 재전송, 재시작, 기존 배송 데이터."""

import pytest

from logistics_contract import (
    Booking,
    BookingRejected,
    BookingRequest,
    CancelBookingRequest,
    ContractError,
    DeliveryQuery,
    DeliveryStatus,
    Quote,
    QuoteDeclined,
    QuoteRequest,
    ShipmentStatus,
)

from conftest import make_service
from klogistics_carrier.skills import Asking, BusinessKeyConflict, StaffError, Waiting

RFQ = dict(rfq_id="RFQ-1", buyer="K정밀웍스", item="베어링", weight_kg=480, origin="창원", destination="평택")
KEY = "K정밀웍스:RFQ-1:book:klogistics:v1"


def request_quote(service, task_id="t1", **overrides):
    return service.quote(QuoteRequest(**{**RFQ, **overrides}), task_id)


def approved_quote(service) -> Quote:
    assert isinstance(request_quote(service), Waiting)
    return service.approve_quote("RFQ-1")


def book(service, q: Quote, key=KEY, task_id="t2"):
    return service.book(BookingRequest(business_key=key, rfq_id=q.rfq_id, quote_id=q.quote_id), task_id)


# ---------- 수동 견적 ----------

def test_manual_quote_waits_for_staff(service):
    w = request_quote(service)
    assert w == Waiting("quote", "RFQ-1")
    box = service.inbox()
    assert box["quotes"][0]["proposed_price"] == 189000 and box["quotes"][0]["status"] == "awaiting"
    assert service.poll(w) == w

    q = service.approve_quote("RFQ-1")
    assert service.poll(w) == q
    assert (q.price_krw, q.eta_days, q.quote_id) == (189000, 2, "K-Q-0001")
    assert service.inbox()["quotes"] == []


def test_staff_can_change_price(service):
    request_quote(service)
    q = service.approve_quote("RFQ-1", price_krw=170000, eta_days=3)
    assert (q.price_krw, q.eta_days) == (170000, 3)


def test_staff_decline(service):
    w = request_quote(service)
    service.decline_quote("RFQ-1", "차량 없음")
    d = service.poll(w)
    assert isinstance(d, QuoteDeclined) and d.reason == "차량 없음"


def test_s07_question_and_answer(service):
    w = request_quote(service, task_id="task-9")
    service.ask("RFQ-1", "팔레트 규격은?")
    assert service.poll(w) == Asking("RFQ-1", "팔레트 규격은?")
    assert service.answer("task-9", "1100×1100, 2단 적재 불가") == w
    qa = service.inbox()["quotes"][0]["qa"]
    assert qa == [{"q": "팔레트 규격은?", "a": "1100×1100, 2단 적재 불가"}]
    q = service.approve_quote("RFQ-1")
    assert service.poll(w) == q


def test_answer_without_question_fails(service):
    request_quote(service, task_id="task-9")
    with pytest.raises(ContractError):
        service.answer("task-9", "묻지도 않았는데")


def test_s28_timeout_auto(service, clock):
    w = request_quote(service)
    clock.advance(minutes=31)
    q = service.poll(w)
    assert isinstance(q, Quote) and q.price_krw == 189000


def test_s28_timeout_decline(decline_service, clock):
    w = request_quote(decline_service)
    clock.advance(minutes=31)
    assert isinstance(decline_service.poll(w), QuoteDeclined)


def test_resend_while_waiting_moves_to_new_task(service):
    request_quote(service, task_id="old")
    assert request_quote(service, task_id="new") == Waiting("quote", "RFQ-1")
    service.ask("RFQ-1", "?")
    service.answer("new", "!")   # 새 Task로 답을 받는다


def test_resend_after_decision_returns_same(service):
    request_quote(service)
    q = service.approve_quote("RFQ-1")
    assert request_quote(service) == q


def test_conflict(service):
    request_quote(service)
    with pytest.raises(BusinessKeyConflict):
        request_quote(service, weight_kg=500)


def test_overweight_declined_without_staff(service):
    assert isinstance(request_quote(service, weight_kg=20000), QuoteDeclined)


def test_staff_errors(service):
    with pytest.raises(StaffError):
        service.approve_quote("RFQ-없음")
    request_quote(service)
    service.approve_quote("RFQ-1")
    with pytest.raises(StaffError):
        service.approve_quote("RFQ-1")
    with pytest.raises(StaffError):
        service.ask("RFQ-1", "이미 끝났는데?")


def test_restart_keeps_waiting_quote(settings, clock, service):
    """S-30: 재시작해도 대기 중인 견적이 남아 있고 이어서 처리된다."""
    w = request_quote(service)
    restarted = make_service(settings, clock)
    assert restarted.poll(w) == w
    restarted.approve_quote("RFQ-1")
    assert isinstance(restarted.poll(w), Quote)


# ---------- 수동 발주 ----------

def test_s14_manual_booking_accept(service):
    q = approved_quote(service)
    w = book(service, q)
    assert w == Waiting("booking", KEY)
    booking_id = service.inbox()["bookings"][0]["booking_id"]
    service.accept_booking(booking_id)
    b = service.poll(w)
    # 기존 배송 데이터 2건이 번호 1·2를 쓰므로 새 발주는 3번부터
    assert isinstance(b, Booking) and b.status == "accepted" and b.tracking_no == "K-T-100003"


def test_s13_manual_booking_reject(service):
    w = book(service, approved_quote(service))
    service.reject_booking(service.inbox()["bookings"][0]["booking_id"], "배차 불가")
    r = service.poll(w)
    assert isinstance(r, BookingRejected) and r.reason == "배차 불가"


def test_booking_resend_while_pending(service):
    q = approved_quote(service)
    w = book(service, q)
    assert book(service, q, task_id="t3") == w


def test_booking_timeout_auto_accept(service, clock):
    w = book(service, approved_quote(service))
    clock.advance(minutes=31)
    assert isinstance(service.poll(w), Booking)


def test_cancel_pending_booking(service):
    w = book(service, approved_quote(service))
    booking_id = service.inbox()["bookings"][0]["booking_id"]
    r = service.cancel(CancelBookingRequest(business_key="c1", booking_id=booking_id))
    assert r.status == "cancelled"
    assert isinstance(service.poll(w), BookingRejected)


def test_shipment_advance_and_errors(service):
    w = book(service, approved_quote(service))
    service.accept_booking(service.inbox()["bookings"][0]["booking_id"])
    tracking = service.poll(w).tracking_no
    service.advance_shipment(tracking, ShipmentStatus.PICKED_UP, "창원 집하")
    with pytest.raises(StaffError):
        service.advance_shipment(tracking, ShipmentStatus.ACCEPTED)
    with pytest.raises(StaffError):
        service.advance_shipment("없는-운송장", ShipmentStatus.PICKED_UP)
    s = service.check_delivery(DeliveryQuery(tracking_no=tracking))
    assert (s.shipment_status, s.seq, s.note) == (ShipmentStatus.PICKED_UP, 2, "창원 집하")


# ---------- 자동 모드 / 기존 데이터 ----------

def test_auto_mode_is_immediate(auto_service):
    q = request_quote(auto_service)
    assert isinstance(q, Quote)
    assert isinstance(book(auto_service, q), Booking)


def test_legacy_orders_from_part3(service):
    s1 = service.check_delivery(DeliveryQuery(tracking_no="ORDER-1001"))
    assert isinstance(s1, DeliveryStatus) and s1.shipment_status == ShipmentStatus.IN_TRANSIT
    assert str(s1.eta) == "2026-09-03"
    s2 = service.check_delivery(DeliveryQuery(tracking_no="ORDER-1002"))
    assert s2.shipment_status == ShipmentStatus.CUSTOMS_HOLD and "통관" in s2.note


def test_legacy_seed_runs_once(settings, clock, service):
    make_service(settings, clock)
    assert len([s for s in service.shipments() if s["tracking_no"].startswith("ORDER-")]) == 2
