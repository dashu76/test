"""계약 패키지에 들어 있는 예시로 이 서버가 받아야 할 요청을 처리하는지 확인한다."""

import pytest

from logistics_contract import ContractError, parse_request, parse_response, to_data
from logistics_contract.examples import example, load_examples


def test_contract_version_is_pinned():
    import logistics_contract

    assert logistics_contract.__version__ == "1.0.0"


def test_example_quote_request_gets_valid_quote(auto_service):
    result = auto_service.handle(parse_request(example("quote-request")))
    parse_response(to_data(result), "quote")


def test_example_newer_minor_request_accepted(auto_service):
    result = auto_service.handle(parse_request(example("quote-request-from-newer-minor")))
    parse_response(to_data(result), "quote")


def test_staff_approved_quote_matches_contract(service):
    service.handle(parse_request(example("quote-request")))
    parse_response(to_data(service.approve_quote("RFQ-20261015-001")), "quote")


def test_shipment_event_is_not_for_carriers(service):
    with pytest.raises(ContractError):
        service.handle(parse_request(example("shipment-event")))


@pytest.mark.parametrize("item", [e for e in load_examples() if e["expect"] == "error" and e["role"] == "request"],
                         ids=lambda e: e["name"])
def test_bad_requests_rejected_before_service(item):
    with pytest.raises(ContractError):
        parse_request(item["message"])
