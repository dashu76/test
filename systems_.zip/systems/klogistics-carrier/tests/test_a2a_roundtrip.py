"""실제 HTTP로 서버를 띄워 A2A로 왕복한다 (다른 회사 서버 없이).

구매사처럼 기다리지 않고 보내고(return_immediately) tasks/get으로 다시 확인하는 흐름을 본다.
"""

import asyncio
import socket
import threading
import time
import uuid

import httpx
import pytest
import uvicorn

from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import GetTaskRequest, Message, Part, Role, SendMessageRequest, TaskState
from logistics_contract import CONTRACT_TAG, parse_response
from logistics_contract.examples import example

from conftest import make_settings
from klogistics_carrier import cli
from klogistics_carrier.app import build_app, build_service


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def server(tmp_path):
    port = free_port()
    settings = make_settings(tmp_path, port=port)
    service = build_service(settings)
    srv = uvicorn.Server(uvicorn.Config(build_app(settings, service), host="127.0.0.1", port=port,
                                        log_level="warning"))
    thread = threading.Thread(target=srv.run, daemon=True)
    thread.start()
    deadline = time.time() + 10
    while not srv.started:
        assert time.time() < deadline, "서버가 뜨지 않았다"
        time.sleep(0.05)
    yield settings, service
    srv.should_exit = True
    thread.join(timeout=5)


class Buyer:
    """구매사 흉내: 보내고 바로 돌아온 뒤 tasks/get으로 확인한다."""

    def __init__(self, url: str) -> None:
        self.url = url

    async def _client(self, http):
        return await create_client(self.url, client_config=ClientConfig(httpx_client=http, streaming=False,
                                                                        polling=True))

    async def send(self, parts, task_id: str = "", context_id: str = ""):
        async with httpx.AsyncClient() as http:
            client = await self._client(http)
            msg = Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=parts,
                          task_id=task_id, context_id=context_id)
            task = [r async for r in client.send_message(SendMessageRequest(message=msg))][0].task
            await client.close()
            return task

    async def wait(self, task_id: str, states, timeout: float = 5.0):
        async with httpx.AsyncClient() as http:
            client = await self._client(http)
            deadline = time.time() + timeout
            while True:
                task = await client.get_task(GetTaskRequest(id=task_id))
                if task.status.state in states or time.time() > deadline:
                    await client.close()
                    return task
                await asyncio.sleep(0.05)


DONE = (TaskState.TASK_STATE_COMPLETED, TaskState.TASK_STATE_FAILED)


def test_card_and_health(server):
    settings, _ = server
    card = httpx.get(f"{settings.public_url}/.well-known/agent-card.json").json()
    assert card["supportedInterfaces"][0]["url"] == f"{settings.public_url}/"
    assert all(CONTRACT_TAG in s["tags"] for s in card["skills"])
    body = httpx.get(f"{settings.public_url}/healthz").json()
    assert body["contract_version"] == "1.0.0" and body["modes"]["quote"] == "manual-with-timeout"


def test_manual_quote_over_a2a(server):
    settings, service = server
    buyer = Buyer(settings.public_url)
    task = asyncio.run(buyer.send([new_data_part(example("quote-request"))], context_id="RFQ-20261015-001"))
    task = asyncio.run(buyer.wait(task.id, DONE, timeout=0.5))
    assert task.status.state == TaskState.TASK_STATE_WORKING          # 담당자 대기
    assert "담당자" in "".join(p.text for p in task.status.message.parts)

    service.approve_quote("RFQ-20261015-001")
    task = asyncio.run(buyer.wait(task.id, DONE))
    assert task.status.state == TaskState.TASK_STATE_COMPLETED
    assert parse_response(get_data_parts(task.artifacts[0].parts)[0], "quote").price_krw == 189000


def test_s07_input_required_round_trip_over_a2a(server):
    settings, service = server
    buyer = Buyer(settings.public_url)
    task = asyncio.run(buyer.send([new_data_part(example("quote-request"))], context_id="RFQ-20261015-001"))
    asyncio.run(buyer.wait(task.id, DONE, timeout=0.3))
    service.ask("RFQ-20261015-001", "상차 시간대는?")
    task = asyncio.run(buyer.wait(task.id, (TaskState.TASK_STATE_INPUT_REQUIRED,)))
    assert task.status.state == TaskState.TASK_STATE_INPUT_REQUIRED
    assert "".join(p.text for p in task.status.message.parts) == "상차 시간대는?"

    asyncio.run(buyer.send([Part(text="오전 9~11시")], task_id=task.id, context_id=task.context_id))
    asyncio.run(buyer.wait(task.id, DONE, timeout=0.3))
    assert service.inbox()["quotes"][0]["qa"][0]["a"] == "오전 9~11시"
    service.approve_quote("RFQ-20261015-001")
    task = asyncio.run(buyer.wait(task.id, DONE))
    assert task.status.state == TaskState.TASK_STATE_COMPLETED


def test_legacy_delivery_over_a2a(server):
    settings, _ = server
    buyer = Buyer(settings.public_url)
    task = asyncio.run(buyer.send([new_data_part({"schema_version": "1.0", "kind": "delivery-query",
                                                  "tracking_no": "ORDER-1002"})]))
    task = asyncio.run(buyer.wait(task.id, DONE))
    status = parse_response(get_data_parts(task.artifacts[0].parts)[0], "delivery-status")
    assert status.shipment_status == "customs_hold"


def test_contract_violation_fails(server):
    settings, _ = server
    buyer = Buyer(settings.public_url)
    task = asyncio.run(buyer.send([new_data_part({**example("quote-request"), "schema_version": "2.0"})]))
    task = asyncio.run(buyer.wait(task.id, DONE))
    assert task.status.state == TaskState.TASK_STATE_FAILED


def test_staff_cli(server, capsys):
    settings, service = server
    from logistics_contract import QuoteRequest
    service.quote(QuoteRequest(rfq_id="RFQ-9", buyer="K정밀웍스", item="볼트", weight_kg=10,
                               origin="창원", destination="인천"), "t")
    api = ["--api", settings.public_url]
    assert cli.main(api + ["inbox"]) == 0
    out = capsys.readouterr().out
    assert "RFQ-9" in out and "39,000원" in out          # 35,000 + 3,200 → 39,000
    assert cli.main(api + ["quote", "ask", "RFQ-9", "포장 형태는?"]) == 0
    assert cli.main(api + ["quote", "approve", "RFQ-9", "--price", "40000"]) == 0
    assert "quoted 40,000원" in capsys.readouterr().out
    assert cli.main(api + ["quote", "approve", "RFQ-9"]) == 1     # 이미 처리됨
    assert cli.main(api + ["shipment", "list"]) == 0
    assert "ORDER-1001" in capsys.readouterr().out
