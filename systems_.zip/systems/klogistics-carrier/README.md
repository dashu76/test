# K-Logistics — 담당자가 확인하는 물류 시스템

독립 시스템입니다. 이 폴더만 복사해 다른 머신에 두어도 설치·실행·테스트가 됩니다. 구매사나 관제 허브가 없어도 뜹니다.

**K-Logistics의 특징**
- 견적과 발주 수락을 **담당자가 확인**합니다. 그동안 A2A Task는 `working`("담당자 확인 대기")으로 남고, 구매사는 기다리지 않고 나중에 `tasks/get`으로 결과를 확인합니다.
- 정보가 부족하면 담당자가 **구매사에 되묻습니다**. Task가 `input-required`가 되고, 구매사가 같은 Task로 보낸 text 답을 받아 이어서 처리합니다 (S-07).
- 담당자가 처리 마감(기본 30분) 안에 처리하지 않으면 설정대로 처리합니다: 규칙대로 자동 처리 또는 거절 (S-28).
- 기존 실습(Part 3 `agent_delivery.py`)의 배송 데이터 `ORDER-1001`(운송 중), `ORDER-1002`(통관 대기)를 이어받아 `check-delivery`로 조회됩니다.
- 요금: 35,000원 + 320원/kg, 2일, 최대 10,000kg (초과하면 담당자 확인 없이 바로 거절).

## 설치·실행

```cmd
cd klogistics-carrier
uv sync
copy .env.example .env      :: 필요하면 값 수정
uv run python -m klogistics_carrier
```

- Agent Card: `http://127.0.0.1:5020/.well-known/agent-card.json`
- 담당자용 내부 API: `http://127.0.0.1:5020/api/...` (문서 `/docs`)
- 상태 확인: `http://127.0.0.1:5020/healthz`

## 담당자 CLI (화면 없이 업무 처리)

서버가 켜져 있어야 합니다. 다른 터미널에서:

```cmd
uv run python -m klogistics_carrier.cli inbox                                   :: 처리할 일
uv run python -m klogistics_carrier.cli quote approve RFQ-20261015-001          :: 제안가로 견적 확정
uv run python -m klogistics_carrier.cli quote approve RFQ-20261015-001 --price 185000 --eta 2
uv run python -m klogistics_carrier.cli quote decline RFQ-20261015-001 --reason "차량 없음"
uv run python -m klogistics_carrier.cli quote ask RFQ-20261015-001 "팔레트 규격과 2단 적재 가능 여부는?"
uv run python -m klogistics_carrier.cli booking accept K-B-0003
uv run python -m klogistics_carrier.cli booking reject K-B-0003 --reason "배차 불가"
uv run python -m klogistics_carrier.cli shipment list
uv run python -m klogistics_carrier.cli shipment advance K-T-100003 picked_up --note "창원 공장 집하"
```

`shipment advance`의 상태: `picked_up` → `in_transit` → (`customs_hold`) → `delivered`. 뒤로 가거나 건너뛰면 거부합니다.

### 구매사 배송 알림 (outbox)

```cmd
uv run python -m klogistics_carrier.cli outbox list [--state pending|sent|failed]
uv run python -m klogistics_carrier.cli outbox retry "<event_id>"
uv run python -m klogistics_carrier.cli outbox dispatch
```

- 발주 수락·배송 상태 변경 때마다 구매사 알림 주소(`event_callback_url`)로 보낼 `shipment-event`가 **같은 DB 트랜잭션에서** outbox에 쌓입니다. 수락 전 취소처럼 운송장이 없으면 보내지 않습니다.
- 발송기(`APP_OUTBOX_INTERVAL_S`, 기본 2초)가 쌓인 순서대로 보냅니다. 구매사가 꺼져 있으면 2·4·8…초(최대 5분) 간격으로 다시 보내고, 앞 알림이 안 끝나면 뒤 알림은 기다립니다.
- 구매사가 거부하거나 `APP_OUTBOX_MAX_ATTEMPTS`(기본 20)회 실패하면 `failed` → 담당자가 확인 후 `outbox retry`.

## 설정

`.env`(또는 환경변수):

| 이름 | 기본값 | 설명 |
|---|---|---|
| `APP_CARRIER_NAME` | `K-Logistics` | Agent Card 이름, 견적의 carrier |
| `APP_ID_PREFIX` | `K` | 견적·예약·운송장 번호 앞자리 |
| `APP_BIND_HOST` / `APP_PORT` | `127.0.0.1` / `5020` | 듣는 주소 |
| `APP_PUBLIC_URL` | `http://{bind}:{port}` | Agent Card에 실리는 주소 |
| `APP_DB_PATH` | `data/klogistics.sqlite3` | 업무 DB |
| `APP_PRICING_FILE` | `config/pricing.toml` | 요금 규칙과 처리 방식 |
| `APP_ALLOWED_CALLBACK_HOSTS` | `127.0.0.1,localhost` | 발주 요청의 알림 주소로 허용할 호스트 |
| `APP_POLL_S` | `1` | 담당자 처리를 기다리는 Task가 DB를 다시 보는 간격 |
| `A2A_OBS_URL` | (비움) | 관제 허브(`obs-hub`) 주소. 비우면 관찰 이벤트를 보내지 않는다 |
| `APP_UI_ENABLED` | `true` | 담당자 업무 화면(`/ui`). `false`면 화면만 끈다(A2A·내부 API·CLI는 그대로) |
| `APP_UI_ACCENT` | `#0f766e` | 화면 강조색(회사 색, `#rrggbb`) |
| `APP_A2A_AUTH` | `true` | 회사 사이 파트너 키(`X-Partner-Key`) 요구. `false`면 지금까지처럼 열림 |
| `APP_STAFF_AUTH` | `true` | 화면·내부 API·CLI 로그인 요구 |
| `APP_SESSION_HOURS` | `12` | 로그인 세션 유효 시간 |
| `APP_LOGIN_HINT` | (비움) | 로그인 화면 시험 계정 안내(예: `admin3 / 1234`, 사용자 이름을 미리 넣음). 운영에서는 비운다 |

`config/pricing.toml`의 `[modes]`:

| 항목 | 값 | 의미 |
|---|---|---|
| `quote`, `booking` | `auto` / `manual` / `manual-with-timeout` | 즉시 처리 / 담당자가 처리할 때까지 대기 / 처리 마감이 지나면 `on_timeout`대로 |
| `manual_timeout_min` | `30` | 처리 마감 (분) |
| `on_timeout` | `auto` / `decline` | 마감 시 규칙대로 견적·수락 / 견적 거절·발주 거절 |

## 재시작해도 이어지는 이유

견적·발주의 상태(처리 대기, 질문 중, 질문과 답)는 DB에 있습니다. 재시작으로 A2A Task가 사라지면 구매사가 같은 `rfq_id`·업무키로 다시 보내고, 새 Task가 이어서 기다립니다 (S-29, S-30).

## 스킬 (계약: `logistics-contract==1.0.0`)

| 스킬 | 요청 → 응답 | 비고 |
|---|---|---|
| `quote` | `quote-request` → `quote` (quoted / declined) | 담당자 확인. 같은 `rfq_id` 재요청은 같은 견적 (처리 중이면 이어서 대기) |
| `book-shipment` | `booking-request` → `booking` (accepted / rejected) | 담당자 수락. `business_key`로 중복 방지 |
| `cancel-booking` | `cancel-booking-request` → `cancel-booking-result` | 집하 전까지만. 수락 전 취소도 가능 |
| `check-delivery` | `delivery-query` → `delivery-status` | 기존 `ORDER-1001/1002` 포함 |

## 업무 화면 (담당자용)

브라우저로 `http://127.0.0.1:5020/` (→ `/ui`). 서버가 직접 내주는 화면이며 이 회사의 내부 API(`/api`)만 부릅니다. 설계: `systems/docs/p6-carrier-ui.md`.

- **견적 요청함**: 담당자 확인 대기 건에 운임·소요일을 고쳐 **승인**, 사유와 함께 **거절**, 구매사에 **질문**. 질문·답 이력과 처리 마감까지 남은 시간이 보인다.
- **발주 수신함**: 수락 대기 건을 **수락**(운송장 발행)하거나 사유와 함께 **거절**.
- **배송 관리**: 다음으로 갈 수 있는 상태만 버튼으로(메모 선택). 상태를 바꾸면 구매사 알림이 같은 트랜잭션에서 쌓인다. 상태 이력 펼치기.
- **알림 발송 현황**: 대기·보냄·실패 필터, **지금 발송**, 실패 건 **재시도**.
- **설정 보기**: 요금 규칙·처리 방식·스킬·발송 설정·관제 허브 주소. 관리자는 요금 규칙·처리 방식을 여기서 고친다.
- **관리** (관리자만): 사용자·역할, 발급한 파트너 키·받은 키, 감사 기록.
- 로그인해야 열리고, 역할에 없는 버튼은 보이지 않는다(판정은 서버).

DB가 바뀌면(A2A 요청·CLI·다른 담당자·발송기) `/api/stream`(SSE)으로 화면이 바로 갱신됩니다. 입력 중인 칸은 지워지지 않습니다.

## 인증과 권한 (Part 4)

설계: `systems/docs/security-and-db.md`. 로컬에서 다섯 회사를 한 번에 준비하려면 `systems\dev-env\setup_dev_auth.ps1`.

**회사 사이 — 파트너 키 (Ch18).** 구매사는 우리가 발급한 키를 `X-Partner-Key` 헤더로 냅니다(Agent Card의 `securitySchemes`에 적혀 있음). 키가 없거나 틀리거나 폐기됐거나 허용 스킬 밖이면 Task `rejected` + 이유, `GetTask` 등 그 밖의 호출은 401. 키가 맞아도 **다른 회사 이름의 견적 요청은 거부**하고, 남의 견적·예약·운송장은 "없는 것"으로 답합니다.

```cmd
uv run python -m klogistics_carrier.admin key issue "K정밀웍스"                  :: 구매사에 줄 키 (한 번만 보임)
uv run python -m klogistics_carrier.admin outbound set http://127.0.0.1:5010 <키>  :: 구매사가 준 키 (배송 알림을 보낼 때 냄)
uv run python -m klogistics_carrier.admin key list | key revoke <key_id>
```

**사내 — 로그인과 역할 (Ch19).**

| 역할 | 할 수 있는 일 |
|---|---|
| `viewer` 조회 | 목록·설정 보기 |
| `operator` 운영 | + 배송 상태 변경, 알림 지금 발송·재시도 |
| `manager` 승인 | + 견적 승인·거절·질문, 발주 수락·거절 |
| `admin` 관리자 | + 요금·처리 방식 변경, 사용자·키·감사 기록 (화면 "관리" 탭) |

```cmd
uv run python -m klogistics_carrier.admin user add kim --role admin     :: 첫 관리자 (서버 밖, DB에 직접)
uv run python -m klogistics_carrier.cli login kim                       :: CLI 로그인 (세션: data\.cli_session)
uv run python -m klogistics_carrier.admin audit                         :: 감사 기록
```

비밀번호는 PBKDF2 해시, 세션·발급 키는 SHA-256 해시로만 저장합니다. 로그인 5회 실패하면 5분 잠금. 요금 규칙(`config/pricing.toml`)은 처음 뜰 때 DB로 옮겨지고, 이후에는 화면 "설정 보기"(관리자)에서 고칩니다(`admin config reset pricing`으로 파일 값으로 되돌림).

## 관제 허브 (선택)

`A2A_OBS_URL`에 관제 허브(`obs-hub`, 기본 `http://127.0.0.1:5090`) 주소를 넣으면 이 시스템이 관찰 이벤트를 직접 보냅니다(`klogistics_carrier/obs_hook.py`). 비워 두면 아무 일도 하지 않습니다. 보내기는 백그라운드 스레드가 하므로 허브가 꺼져 있거나 느려도 업무는 기다리지 않습니다(S-25). 허브에 닿지 않으면 5초 동안은 이벤트를 버립니다 — 관찰 기록은 업무 기록이 아닙니다.

| 이벤트 | 언제 |
|---|---|
| `agent.started` / `agent.stopped` | 서버 기동·종료 |
| `task.received` / `task.state` | A2A 요청을 받음 / Task 상태가 바뀔 때마다 (완료·실패·질문이면 결과 요약) |
| `task.resumed` | 구매사가 질문에 답해 Task가 이어질 때 |
| `card.fetched` / `card.failed` | 구매사 카드 조회 결과가 바뀔 때 |
| `request.sent` / `request.done` / `request.error` | 구매사에 배송 알림(`receive-shipment-event`)을 보낼 때 |
| `outbox.sent` / `outbox.retry` / `outbox.failed` | 배송 알림 발송 결과 (상태·예약·시도 횟수·오류) |

## 테스트

```cmd
uv run pytest
```

담당자 확인·질문·시간 초과·재전송·재시작·기존 데이터를 확인하고, 실제 HTTP로 "보내고 바로 돌아온 뒤 tasks/get으로 확인"하는 흐름과 `input-required` 왕복, 담당자 CLI를 확인합니다. 관찰 이벤트는 `tests/fake_hub.py`(가짜 허브)로 확인합니다.

## 아직 없는 것

- TLS 없음 — 로컬·사내망 전제. 다른 머신과 주고받으려면 앞단에 HTTPS 프록시를 둔다 (키·세션이 평문 HTTP로 오간다)
