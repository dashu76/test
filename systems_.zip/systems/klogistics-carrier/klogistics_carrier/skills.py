# 파일명: skills.py
"""K-Logistics 업무 처리. A2A를 모르고, 계약 모델을 받아 결과(Outcome)를 돌려준다.

결과는 셋 중 하나다.
- 계약 메시지(Quote, Booking …): 처리가 끝났다 → A2A Task completed
- Waiting: 담당자 처리를 기다린다 → Task working 유지, 나중에 poll()로 다시 본다
- Asking: 담당자가 구매사에 질문했다 → Task input-required, 구매사 답은 answer()로 받는다

업무 상태의 원본은 DB다. A2A Task가 사라져도 구매사가 같은 rfq_id·업무키로 다시 보내면 이어서 처리한다.
"""

import dataclasses
import json
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from urllib.parse import urlsplit

from logistics_contract import (
    Booking,
    BookingRejected,
    BookingRequest,
    CancelBookingRequest,
    CancelBookingResult,
    ContractError,
    ContractMessage,
    DeliveryNotFound,
    DeliveryQuery,
    DeliveryStatus,
    Quote,
    QuoteDeclined,
    QuoteRequest,
    ShipmentEvent,
    ShipmentStatus,
    parse_response,
    to_data,
)

from .domain import (EDITABLE, STATUS_LABEL, Pricing, calc_price, can_cancel, check_transition, now_kst,
                     overweight_reason, pricing_from_dict)
from .settings import Settings
from .store import Store, canonical, dumps


class BusinessKeyConflict(ValueError):
    """같은 업무키(또는 rfq_id)로 다른 내용이 왔다 → Task failed."""


class PartnerMismatch(ValueError):
    """파트너 키의 회사와 요청 속 회사가 다르다 (예: 다른 회사 이름으로 견적 요청) → Task rejected."""


class StaffError(ValueError):
    """담당자 작업 오류 (없는 번호, 이미 처리됨 등)."""


@dataclass(frozen=True)
class Waiting:
    kind: str           # quote | booking
    key: str            # rfq_id | business_key
    note: str = "담당자 확인 대기"


@dataclass(frozen=True)
class Asking:
    rfq_id: str
    question: str


Outcome = ContractMessage | Waiting | Asking


class CarrierService:
    def __init__(self, settings: Settings, store: Store, pricing: Pricing,
                 clock: Callable[[], datetime] = now_kst) -> None:
        self.settings = settings
        self.store = store
        self.pricing = pricing
        self.clock = clock

    @property
    def name(self) -> str:
        return self.settings.carrier_name

    def _id(self, kind: str, seq: int) -> str:
        return f"{self.settings.id_prefix}-{kind}-{seq:04d}"

    # ================= A2A 쪽 =================

    def handle(self, message: ContractMessage, task_id: str = "", partner: str | None = None) -> Outcome:
        """partner: 파트너 키로 확인된 회사 (인증을 끄면 None → 회사 확인을 하지 않는다)."""
        match message:
            case QuoteRequest():
                return self.quote(message, task_id, partner)
            case BookingRequest():
                return self.book(message, task_id, partner)
            case CancelBookingRequest():
                return self.cancel(message, partner)
            case DeliveryQuery():
                return self.check_delivery(message, partner)
            case _:
                raise ContractError(f"{self.name}는 {message.kind} 요청을 받지 않는다")

    def poll(self, waiting: Waiting) -> Outcome:
        now = self.clock()
        with self.store.transaction() as conn:
            if waiting.kind == "quote":
                row = Store.find_quote_by_rfq(conn, waiting.key)
                return self._quote_outcome(self._expire_quote(conn, row, now))
            row = Store.find_booking_by_key(conn, waiting.key)
            return self._booking_outcome(self._expire_booking(conn, row, now))

    def answer(self, task_id: str, text: str) -> Outcome:
        """구매사가 질문에 답했다 (input-required였던 같은 Task로 온 text)."""
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_quote_by_task(conn, task_id)
            if row is None or row["status"] != "question":
                raise ContractError("이 Task에는 답을 기다리는 질문이 없다")
            qa = json.loads(row["qa_json"]) + [{"q": row["question"], "a": text}]
            due = self.pricing.due_at(self.pricing.quote_mode, now)  # 답을 받았으니 담당자 시간을 다시 준다
            Store.update(conn, "quotes", "quote_seq", row["quote_seq"], status="awaiting", question=None,
                         qa_json=dumps(qa), due_at=due.isoformat() if due else None, updated_at=now.isoformat())
            return Waiting("quote", row["rfq_id"])

    # ---------- quote ----------

    def quote(self, req: QuoteRequest, task_id: str = "", partner: str | None = None) -> Outcome:
        if partner is not None and req.buyer != partner:
            raise PartnerMismatch(f"{partner}의 키로 다른 회사({req.buyer}) 이름의 견적을 요청할 수 없다")
        key = canonical(to_data(req))
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_quote_by_rfq(conn, req.rfq_id)
            if row is not None:
                if row["request_key"] != key:
                    raise BusinessKeyConflict(f"같은 rfq_id({req.rfq_id})로 다른 견적 요청이 왔다")
                row = self._expire_quote(conn, row, now)
                if row["status"] in ("awaiting", "question"):
                    # 재전송(예: 이전 Task가 재시작으로 사라짐) → 이 Task가 이어서 기다린다
                    Store.update(conn, "quotes", "quote_seq", row["quote_seq"], task_id=task_id)
                return self._quote_outcome(row)

            seq = Store.insert_quote(conn, req.rfq_id, key, to_data(req), now.isoformat())
            price, eta = calc_price(req.weight_kg, self.pricing)
            Store.update(conn, "quotes", "quote_seq", seq, quote_id=self._id("Q", seq),
                         proposed_price=price, proposed_eta=eta, task_id=task_id)
            reason = overweight_reason(req.weight_kg, self.pricing)
            if reason:
                return self._decline_quote(conn, seq, req.rfq_id, reason, "auto", now)
            if self.pricing.quote_mode == "auto":
                return self._finish_quote(conn, seq, price, eta, "auto", now)
            due = self.pricing.due_at(self.pricing.quote_mode, now)
            Store.update(conn, "quotes", "quote_seq", seq, due_at=due.isoformat() if due else None)
            return Waiting("quote", req.rfq_id)

    def _finish_quote(self, conn, seq: int, price: int, eta: int, decided_by: str, now: datetime) -> Quote:
        row = conn.execute("SELECT * FROM quotes WHERE quote_seq=?", (seq,)).fetchone()
        result = Quote(quote_id=row["quote_id"], rfq_id=row["rfq_id"], carrier=self.name, price_krw=price,
                       eta_days=eta, valid_until=now + timedelta(hours=self.pricing.quote_valid_hours))
        Store.update(conn, "quotes", "quote_seq", seq, status="quoted", question=None,
                     valid_until=result.valid_until.isoformat(), decided_by=decided_by,
                     response_json=dumps(to_data(result)), updated_at=now.isoformat())
        return result

    def _decline_quote(self, conn, seq: int, rfq_id: str, reason: str, decided_by: str,
                       now: datetime) -> QuoteDeclined:
        result = QuoteDeclined(rfq_id=rfq_id, carrier=self.name, reason=reason)
        Store.update(conn, "quotes", "quote_seq", seq, status="declined", question=None, decided_by=decided_by,
                     response_json=dumps(to_data(result)), updated_at=now.isoformat())
        return result

    def _expire_quote(self, conn, row, now: datetime):
        """S-28: 담당자 처리 마감이 지났으면 on_timeout대로 처리한다."""
        if row["status"] == "awaiting" and row["due_at"] and now >= datetime.fromisoformat(row["due_at"]):
            if self.pricing.on_timeout == "auto":
                self._finish_quote(conn, row["quote_seq"], row["proposed_price"], row["proposed_eta"], "timeout", now)
            else:
                self._decline_quote(conn, row["quote_seq"], row["rfq_id"], "담당자 처리 시간 초과", "timeout", now)
            row = Store.find_quote_by_rfq(conn, row["rfq_id"])
        return row

    @staticmethod
    def _quote_outcome(row) -> Outcome:
        if row["status"] in ("quoted", "declined"):
            return parse_response(json.loads(row["response_json"]), "quote")
        if row["status"] == "question":
            return Asking(row["rfq_id"], row["question"])
        return Waiting("quote", row["rfq_id"])

    # ---------- book-shipment ----------

    def _booking_rejection(self, conn, req: BookingRequest, now: datetime, partner: str | None) -> str | None:
        quote = Store.find_quote(conn, req.quote_id)
        if quote is None or quote["status"] != "quoted":
            return "존재하지 않는 견적"
        if partner is not None and json.loads(quote["request_json"]).get("buyer") != partner:
            return "존재하지 않는 견적"   # 다른 회사가 받은 견적 — 있다는 것도 알려 주지 않는다
        if quote["rfq_id"] != req.rfq_id:
            return "견적의 운송 요청 번호가 다르다"
        if datetime.fromisoformat(quote["valid_until"]) < now:
            return "견적 유효기간이 지났다"
        if Store.find_active_booking_for_quote(conn, req.quote_id) is not None:
            return "이미 다른 발주에 사용된 견적"
        if req.event_callback_url is not None:
            host = urlsplit(req.event_callback_url).hostname
            if host not in self.settings.allowed_callback_hosts:
                return f"허용되지 않은 알림 주소: {host}"
        return None

    def book(self, req: BookingRequest, task_id: str = "", partner: str | None = None) -> Outcome:
        key = canonical(to_data(req))
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_booking_by_key(conn, req.business_key)
            if row is not None:
                if row["request_key"] != key or (partner is not None and row["partner"] not in (None, partner)):
                    raise BusinessKeyConflict("같은 업무키에 다른 발주 내용: 거부")
                return self._booking_outcome(self._expire_booking(conn, row, now))

            reason = self._booking_rejection(conn, req, now, partner)
            seq = Store.insert_booking(conn, req.business_key, key, req.quote_id, req.rfq_id,
                                       req.event_callback_url, now.isoformat(), partner)
            Store.update(conn, "bookings", "booking_seq", seq, booking_id=self._id("B", seq))
            if reason is not None:
                return self._reject_booking(conn, seq, reason, "auto", now)
            if self.pricing.booking_mode == "auto":
                return self._accept_booking(conn, seq, "auto", now)
            due = self.pricing.due_at(self.pricing.booking_mode, now)
            Store.update(conn, "bookings", "booking_seq", seq, due_at=due.isoformat() if due else None)
            return Waiting("booking", req.business_key)

    def _accept_booking(self, conn, seq: int, decided_by: str, now: datetime) -> Booking:
        row = conn.execute("SELECT * FROM bookings WHERE booking_seq=?", (seq,)).fetchone()
        quote = Store.find_quote(conn, row["quote_id"])
        tracking_no = f"{self.settings.id_prefix}-T-{100000 + seq}"
        eta = (now + timedelta(days=int(json.loads(quote["response_json"])["eta_days"]))).date()
        result = Booking(status="accepted", business_key=row["business_key"], booking_id=row["booking_id"],
                         quote_id=row["quote_id"], tracking_no=tracking_no)
        Store.update(conn, "bookings", "booking_seq", seq, tracking_no=tracking_no, eta=eta.isoformat(),
                     decided_by=decided_by, response_json=dumps(to_data(result)))
        note = {"auto": "자동 수락", "staff": "담당자 수락", "timeout": "처리 시간 초과로 자동 수락"}[decided_by]
        self._status_changed(conn, row["booking_id"], ShipmentStatus.ACCEPTED, note, now)
        return result

    def _status_changed(self, conn, booking_id: str, status: ShipmentStatus, note: str, now: datetime) -> int:
        """배송 상태를 바꾸고, 알림 주소가 있으면 같은 트랜잭션에서 구매사 알림을 outbox에 쌓는다."""
        seq = Store.set_booking_status(conn, booking_id, status.value, note, now.isoformat())
        row = Store.find_booking(conn, booking_id)
        if row["callback_url"] and row["tracking_no"]:   # 수락 전 취소는 운송장이 없어 알림 대상이 아니다
            event = ShipmentEvent(event_id=f"{self.name}:{booking_id}:{seq}", carrier=self.name,
                                  booking_id=booking_id, tracking_no=row["tracking_no"], seq=seq,
                                  shipment_status=status, at=now, note=note)
            Store.enqueue_event(conn, event.event_id, booking_id, row["callback_url"], to_data(event),
                                now.isoformat())
        return seq

    def _reject_booking(self, conn, seq: int, reason: str, decided_by: str, now: datetime) -> BookingRejected:
        row = conn.execute("SELECT * FROM bookings WHERE booking_seq=?", (seq,)).fetchone()
        result = BookingRejected(business_key=row["business_key"], quote_id=row["quote_id"], reason=reason)
        Store.update(conn, "bookings", "booking_seq", seq, status="rejected", decided_by=decided_by,
                     response_json=dumps(to_data(result)), updated_at=now.isoformat())
        return result

    def _expire_booking(self, conn, row, now: datetime):
        if row["status"] == "pending" and row["due_at"] and now >= datetime.fromisoformat(row["due_at"]):
            if self.pricing.on_timeout == "auto":
                self._accept_booking(conn, row["booking_seq"], "timeout", now)
            else:
                self._reject_booking(conn, row["booking_seq"], "담당자 처리 시간 초과", "timeout", now)
            row = Store.find_booking_by_key(conn, row["business_key"])
        return row

    @staticmethod
    def _booking_outcome(row) -> Outcome:
        if row["status"] == "pending":
            return Waiting("booking", row["business_key"])
        if row["response_json"] == "{}":  # 수락 전에 취소된 발주
            return BookingRejected(business_key=row["business_key"], quote_id=row["quote_id"],
                                   reason="수락 전에 취소됨")
        return parse_response(json.loads(row["response_json"]), "booking")

    # ---------- cancel-booking ----------

    @staticmethod
    def _owned(booking, partner: str | None) -> bool:
        """그 회사의 발주인가. 인증 전·기존 데이터(partner 없음, ORDER-1001 등)는 막지 않는다."""
        return booking is not None and (partner is None or booking["partner"] in (None, partner))

    def cancel(self, req: CancelBookingRequest, partner: str | None = None) -> CancelBookingResult:
        key = canonical(to_data(req))
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_cancel(conn, req.business_key)
            if row is not None:
                if row["request_key"] != key:
                    raise BusinessKeyConflict("같은 업무키에 다른 취소 내용: 거부")
                return parse_response(json.loads(row["response_json"]), "cancel-booking-result")

            booking = Store.find_booking(conn, req.booking_id)
            if not self._owned(booking, partner) or booking["status"] == "rejected":
                result = CancelBookingResult(status="rejected", booking_id=req.booking_id, reason="존재하지 않는 예약")
            else:
                current = ShipmentStatus(booking["status"])
                if can_cancel(current):
                    self._status_changed(conn, req.booking_id, ShipmentStatus.CANCELLED,
                                         req.reason or "구매사 요청 취소", now)
                    result = CancelBookingResult(status="cancelled", booking_id=req.booking_id)
                else:
                    result = CancelBookingResult(status="rejected", booking_id=req.booking_id,
                                                 reason=f"취소할 수 없는 상태: {STATUS_LABEL[current]}")
            Store.insert_cancel(conn, req.business_key, key, to_data(result), now.isoformat())
            return result

    # ---------- check-delivery ----------

    def check_delivery(self, req: DeliveryQuery, partner: str | None = None) -> DeliveryStatus | DeliveryNotFound:
        with self.store.read() as conn:
            row = Store.find_booking_by_tracking(conn, req.tracking_no)
            if not self._owned(row, partner):
                return DeliveryNotFound(tracking_no=req.tracking_no)
            return DeliveryStatus(tracking_no=req.tracking_no, shipment_status=ShipmentStatus(row["status"]),
                                  seq=row["seq"], eta=row["eta"], note=Store.last_note(conn, row["booking_id"]))

    # ================= 담당자 쪽 (내부 API·CLI) =================

    def update_pricing(self, changes: dict, actor: str) -> Pricing:
        """요금 규칙·처리 방식을 고친다 (화면 설정 보기 · admin 권한). DB가 원본이 되고 다음 요청부터 반영된다."""
        current = dataclasses.asdict(self.pricing)
        merged = {**current, **{k: v for k, v in changes.items() if k in EDITABLE and k in current}}
        pricing = pricing_from_dict(merged)
        self.store.set_config("pricing", dataclasses.asdict(pricing), actor, self.clock().isoformat())
        self.pricing = pricing
        return pricing

    def inbox(self) -> dict:
        """처리할 일: 견적 대기·질문 중, 발주 수락 대기. 볼 때 처리 마감이 지난 것은 먼저 정리한다."""
        now = self.clock()
        with self.store.transaction() as conn:
            for row in Store.open_quotes(conn):
                self._expire_quote(conn, row, now)
            for row in Store.pending_bookings(conn):
                self._expire_booking(conn, row, now)
            quotes = [self._quote_view(r) for r in Store.open_quotes(conn)]
            bookings = [dict(booking_id=r["booking_id"], rfq_id=r["rfq_id"], quote_id=r["quote_id"],
                             business_key=r["business_key"], due_at=r["due_at"], created_at=r["created_at"])
                        for r in Store.pending_bookings(conn)]
        return {"quotes": quotes, "bookings": bookings}

    @staticmethod
    def _quote_view(r) -> dict:
        req, res = json.loads(r["request_json"]), json.loads(r["response_json"] or "{}")
        return dict(rfq_id=r["rfq_id"], quote_id=r["quote_id"], status=r["status"], buyer=req["buyer"],
                    item=req["item"], weight_kg=req["weight_kg"], origin=req["origin"],
                    destination=req["destination"], need_by=req.get("need_by"),
                    proposed_price=r["proposed_price"], proposed_eta=r["proposed_eta"], due_at=r["due_at"],
                    question=r["question"], qa=json.loads(r["qa_json"]), decided_by=r["decided_by"],
                    price_krw=res.get("price_krw"), eta_days=res.get("eta_days"), co2_kg=res.get("co2_kg"),
                    valid_until=r["valid_until"], reason=res.get("reason"), created_at=r["created_at"])

    def quotes(self) -> list[dict]:
        with self.store.read() as conn:
            return [self._quote_view(r) for r in Store.all_quotes(conn)]

    def _open_quote(self, conn, rfq_id: str, allowed: tuple[str, ...]):
        row = Store.find_quote_by_rfq(conn, rfq_id)
        if row is None:
            raise StaffError(f"없는 견적 요청: {rfq_id}")
        if row["status"] not in allowed:
            raise StaffError(f"이미 처리된 견적 요청: {rfq_id} ({row['status']})")
        return row

    def approve_quote(self, rfq_id: str, price_krw: int | None = None, eta_days: int | None = None) -> Quote:
        now = self.clock()
        with self.store.transaction() as conn:
            row = self._open_quote(conn, rfq_id, ("awaiting", "question"))
            return self._finish_quote(conn, row["quote_seq"], price_krw or row["proposed_price"],
                                      eta_days or row["proposed_eta"], "staff", now)

    def decline_quote(self, rfq_id: str, reason: str) -> QuoteDeclined:
        now = self.clock()
        with self.store.transaction() as conn:
            row = self._open_quote(conn, rfq_id, ("awaiting", "question"))
            return self._decline_quote(conn, row["quote_seq"], rfq_id, reason or "담당자 거절", "staff", now)

    def ask(self, rfq_id: str, question: str) -> None:
        """S-07: 구매사에 되묻는다. 기다리던 Task는 input-required가 된다."""
        if not question.strip():
            raise StaffError("질문 내용이 비었다")
        now = self.clock()
        with self.store.transaction() as conn:
            row = self._open_quote(conn, rfq_id, ("awaiting",))
            Store.update(conn, "quotes", "quote_seq", row["quote_seq"], status="question", question=question,
                         updated_at=now.isoformat())

    def _pending_booking(self, conn, booking_id: str):
        row = Store.find_booking(conn, booking_id)
        if row is None:
            raise StaffError(f"없는 발주: {booking_id}")
        if row["status"] != "pending":
            raise StaffError(f"이미 처리된 발주: {booking_id} ({row['status']})")
        return row

    def accept_booking(self, booking_id: str) -> Booking:
        now = self.clock()
        with self.store.transaction() as conn:
            return self._accept_booking(conn, self._pending_booking(conn, booking_id)["booking_seq"], "staff", now)

    def reject_booking(self, booking_id: str, reason: str) -> BookingRejected:
        now = self.clock()
        with self.store.transaction() as conn:
            row = self._pending_booking(conn, booking_id)
            return self._reject_booking(conn, row["booking_seq"], reason or "담당자 거절", "staff", now)

    def bookings(self) -> list[dict]:
        """발주 수신함 (화면). 수락 대기·거절·취소된 발주까지 모두."""
        with self.store.read() as conn:
            rows = Store.all_bookings(conn)
        views = []
        for r in rows:
            res = json.loads(r["response_json"] or "{}")
            views.append(dict(
                booking_id=r["booking_id"], business_key=r["business_key"], rfq_id=r["rfq_id"],
                quote_id=r["quote_id"], status=r["status"], tracking_no=r["tracking_no"], seq=r["seq"],
                eta=r["eta"], callback_url=r["callback_url"], reason=res.get("reason"), due_at=r["due_at"],
                decided_by=r["decided_by"], created_at=r["created_at"], updated_at=r["updated_at"]))
        return views

    def history(self, tracking_no: str) -> list[dict]:
        with self.store.read() as conn:
            row = Store.find_booking_by_tracking(conn, tracking_no)
            if row is None:
                raise StaffError(f"없는 운송장: {tracking_no}")
            return [dict(seq=h["seq"], status=h["status"], note=h["note"], at=h["at"])
                    for h in Store.history(conn, row["booking_id"])]

    def shipments(self) -> list[dict]:
        with self.store.read() as conn:
            return [dict(tracking_no=r["tracking_no"], booking_id=r["booking_id"], rfq_id=r["rfq_id"],
                         status=r["status"], status_label=STATUS_LABEL.get(ShipmentStatus(r["status"]), r["status"]),
                         seq=r["seq"], eta=r["eta"], note=Store.last_note(conn, r["booking_id"]))
                    for r in Store.shipments(conn)]

    def advance_shipment(self, tracking_no: str, new_status: ShipmentStatus, note: str = "") -> int:
        now = self.clock()
        with self.store.transaction() as conn:
            row = Store.find_booking_by_tracking(conn, tracking_no)
            if row is None:
                raise StaffError(f"없는 운송장: {tracking_no}")
            try:
                check_transition(ShipmentStatus(row["status"]), new_status)
            except ValueError as exc:
                raise StaffError(str(exc)) from exc
            return self._status_changed(conn, row["booking_id"], new_status, note, now)
