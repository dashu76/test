# 파일명: cli.py
"""K-Logistics 담당자 CLI (화면 없이 업무 처리). 우리 회사 내부 API만 부른다.

  uv run python -m klogistics_carrier.cli inbox
  uv run python -m klogistics_carrier.cli quote approve RFQ-... [--price 190000] [--eta 2]
  uv run python -m klogistics_carrier.cli quote decline RFQ-... --reason "차량 없음"
  uv run python -m klogistics_carrier.cli quote ask RFQ-... "팔레트 규격(가로×세로)을 알려 주세요"
  uv run python -m klogistics_carrier.cli booking accept K-B-0001
  uv run python -m klogistics_carrier.cli booking reject K-B-0001 --reason "배차 불가"
  uv run python -m klogistics_carrier.cli shipment list
  uv run python -m klogistics_carrier.cli shipment advance K-T-100001 picked_up --note "창원 집하"
  uv run python -m klogistics_carrier.cli outbox list [--state pending|sent|failed]
  uv run python -m klogistics_carrier.cli outbox retry "K-Logistics:K-B-0003:2"
  uv run python -m klogistics_carrier.cli outbox dispatch

API 주소: --api 또는 KLOG_API_URL (기본: 설정의 주소)
"""

import argparse
import getpass
import os
import sys

import httpx

from .auth import cli_headers, cli_session_file, save_cli_session
from .settings import APP_ROOT

STATUSES = ["picked_up", "in_transit", "customs_hold", "delivered"]
OUTBOX_LABEL = {"pending": "발송 대기", "sent": "보냄", "failed": "실패(확인 필요)"}


def default_api() -> str:
    if os.getenv("KLOG_API_URL"):
        return os.environ["KLOG_API_URL"]
    from .settings import load_settings
    return load_settings().local_api


def won(v) -> str:
    return f"{v:,}원" if isinstance(v, int) else "-"


def print_inbox(box: dict) -> None:
    print(f"── 견적 요청 {len(box['quotes'])}건 ──")
    for q in box["quotes"]:
        due = (q["due_at"] or "없음")[:16].replace("T", " ")
        print(f"  {q['rfq_id']} [{'질문 중' if q['status'] == 'question' else '처리 대기'}] {q['buyer']} · {q['item']}"
              f" {q['weight_kg']:g}kg {q['origin']}→{q['destination']} 희망 {q['need_by'] or '-'}")
        print(f"     제안가 {won(q['proposed_price'])} / {q['proposed_eta']}일 · 처리 마감 {due}")
        for qa in q["qa"]:
            print(f"     Q: {qa['q']}  A: {qa['a']}")
        if q["question"]:
            print(f"     Q: {q['question']}  (구매사 답 대기)")
    print(f"── 발주 수락 대기 {len(box['bookings'])}건 ──")
    for b in box["bookings"]:
        print(f"  {b['booking_id']} 견적 {b['quote_id']} 운송 요청 {b['rfq_id']} · 처리 마감 {(b['due_at'] or '없음')[:16].replace('T', ' ')}")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="klogistics_carrier.cli", description="K-Logistics 담당자 CLI")
    p.add_argument("--api", default=None)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("inbox", help="처리할 일")

    q = sub.add_parser("quote").add_subparsers(dest="action", required=True)
    a = q.add_parser("approve")
    a.add_argument("rfq_id")
    a.add_argument("--price", type=int)
    a.add_argument("--eta", type=int)
    d = q.add_parser("decline")
    d.add_argument("rfq_id")
    d.add_argument("--reason", default="")
    k = q.add_parser("ask")
    k.add_argument("rfq_id")
    k.add_argument("question")

    b = sub.add_parser("booking").add_subparsers(dest="action", required=True)
    b.add_parser("accept").add_argument("booking_id")
    r = b.add_parser("reject")
    r.add_argument("booking_id")
    r.add_argument("--reason", default="")

    s = sub.add_parser("shipment").add_subparsers(dest="action", required=True)
    s.add_parser("list")
    v = s.add_parser("advance")
    v.add_argument("tracking_no")
    v.add_argument("status", choices=STATUSES)
    v.add_argument("--note", default="")

    o = sub.add_parser("outbox").add_subparsers(dest="action", required=True)
    o.add_parser("list").add_argument("--state", choices=list(OUTBOX_LABEL))
    o.add_parser("retry").add_argument("event_id")
    o.add_parser("dispatch")
    lg = sub.add_parser("login", help="로그인 (세션을 이 폴더 data/.cli_session에 저장)")
    lg.add_argument("username")
    lg.add_argument("--password", help="스크립트용. 없으면 묻는다")
    sub.add_parser("logout")
    sub.add_parser("whoami", help="로그인한 사용자와 권한")

    args = p.parse_args(argv)
    api = (args.api or default_api()).rstrip("/")
    try:
        with httpx.Client(base_url=api, timeout=30, headers=cli_headers(APP_ROOT)) as http:
            if args.cmd in ("login", "logout", "whoami"):
                return session_command(http, args)
            if args.cmd == "inbox":
                r = http.get("/api/inbox")
            elif args.cmd == "quote" and args.action == "approve":
                r = http.post(f"/api/quotes/{args.rfq_id}/approve", json={"price_krw": args.price, "eta_days": args.eta})
            elif args.cmd == "quote" and args.action == "decline":
                r = http.post(f"/api/quotes/{args.rfq_id}/decline", json={"reason": args.reason})
            elif args.cmd == "quote":
                r = http.post(f"/api/quotes/{args.rfq_id}/ask", json={"question": args.question})
            elif args.cmd == "booking" and args.action == "accept":
                r = http.post(f"/api/bookings/{args.booking_id}/accept")
            elif args.cmd == "booking":
                r = http.post(f"/api/bookings/{args.booking_id}/reject", json={"reason": args.reason})
            elif args.cmd == "outbox" and args.action == "list":
                r = http.get("/api/outbox", params={"state": args.state} if args.state else None)
            elif args.cmd == "outbox" and args.action == "retry":
                r = http.post(f"/api/outbox/{args.event_id}/retry")
            elif args.cmd == "outbox":
                r = http.post("/api/outbox/dispatch")
            elif args.action == "list":
                r = http.get("/api/shipments")
            else:
                r = http.post(f"/api/shipments/{args.tracking_no}/advance", json={"status": args.status, "note": args.note})

            if r.status_code == 401:
                print("로그인이 필요하다: uv run python -m klogistics_carrier.cli login <이름>", file=sys.stderr)
                return 1
            if r.status_code >= 400:
                print(f"거부: {r.json().get('detail', r.text)}", file=sys.stderr)
                return 1
            body = r.json()
            if args.cmd == "outbox":
                if args.action == "list":
                    for x in body:
                        err = f"  오류: {x['last_error']}" if x["last_error"] else ""
                        print(f"{x['event_id']:<28} {x['shipment_status']:<12} {OUTBOX_LABEL[x['state']]:<10} 시도 {x['attempts']}{err}")
                elif args.action == "retry":
                    print(f"{body['event_id']}: 다시 발송 대기")
                else:
                    print(f"보냄 {body['sent']} · 재시도 예정 {body['retry']} · 실패 {body['failed']}")
                return 0
            if args.cmd == "inbox":
                print_inbox(body)
            elif args.cmd == "shipment" and args.action == "list":
                for x in body:
                    print(f"{x['tracking_no']:<14} {x['status_label']:<6} 순번 {x['seq']} 도착 예정 {x['eta'] or '-'}  {x['note']}")
            elif args.cmd == "quote" and args.action == "ask":
                print(f"{body['rfq_id']}: 구매사에 질문을 보냈다 — {body['question']}")
            elif args.cmd == "shipment":
                print(f"{body['tracking_no']}: {body['status']} (순번 {body['seq']}) — 구매사 알림 대기열에 추가")
            else:
                status = body.get("status")
                extra = f" {won(body.get('price_krw'))} / {body.get('eta_days')}일" if status == "quoted" else ""
                extra += f" 운송장 {body.get('tracking_no')}" if body.get("tracking_no") else ""
                extra += f" 사유: {body.get('reason')}" if body.get("reason") else ""
                print(f"처리됨: {body.get('kind')} {status}{extra}")
            return 0
    except httpx.ConnectError:
        print(f"K-Logistics 시스템({api})에 연결할 수 없다. 서버가 켜져 있는지 확인하라.", file=sys.stderr)
        return 2


def session_command(http: httpx.Client, args) -> int:
    if args.cmd == "login":
        r = http.post("/api/login", json={"username": args.username,
                                          "password": args.password or getpass.getpass("비밀번호: ")})
        if r.status_code >= 400:
            print(f"로그인 실패: {r.json().get('detail', r.text)}", file=sys.stderr)
            return 1
        body = r.json()
        if body["token"]:
            save_cli_session(APP_ROOT, body["token"])
        print(f"로그인: {body['user']['display_name']} ({body['user']['role_label']})")
        return 0
    if args.cmd == "logout":
        http.post("/api/logout")
        cli_session_file(APP_ROOT).unlink(missing_ok=True)
        print("로그아웃")
        return 0
    r = http.get("/api/me")
    if r.status_code == 401:
        print("로그인하지 않았다", file=sys.stderr)
        return 1
    body = r.json()
    labels = body["permission_labels"]
    print(f"{body['user']['display_name']} ({body['user']['role_label']})"
          + ("" if body["staff_auth"] else " — 이 서버는 로그인을 끈 상태"))
    print("권한: " + ", ".join(labels.get(p, p) for p in body["user"]["permissions"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
