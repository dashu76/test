# 파일명: api.py
"""내부 API (/api). K-Logistics 담당자 화면·CLI 전용이다. 구매사는 A2A로만 들어온다.

모든 경로는 로그인이 필요하고(APP_STAFF_AUTH), 경로마다 권한이 다르다(permissions.py, Part 4 Ch19):
견적 확정·발주 수락처럼 회사가 약속하는 결정은 승인 역할(manager) 이상만.
로그인·사용자·키·감사 기록 경로는 auth.py에 있다.
"""

import asyncio
import dataclasses
import functools
import json

import logistics_contract
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from logistics_contract import ShipmentStatus, to_data

from . import __version__
from .auth import StaffUser, require
from .domain import EDITABLE, STATUS_LABEL, TRANSITIONS
from .skills import CarrierService, StaffError


class Approve(BaseModel):
    price_krw: int | None = Field(default=None, gt=0)
    eta_days: int | None = Field(default=None, ge=0)


class Reason(BaseModel):
    reason: str = ""


class Question(BaseModel):
    question: str = Field(min_length=1)


class Advance(BaseModel):
    status: ShipmentStatus
    note: str = ""


router = APIRouter(prefix="/api", dependencies=[Depends(require("read"))])
STREAM_CHECK_S = 0.5   # 화면 실시간 갱신: DB revision을 보는 간격


def svc(request: Request) -> CarrierService:
    return request.app.state.service


def audit(request: Request, user: StaffUser, action: str, target: str, detail: str = "") -> None:
    request.app.state.auth.audit(user.username, action, target, detail)


def staff(fn):
    """StaffError → 409 (담당자가 읽을 사유를 그대로 돌려준다)."""
    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):
        try:
            return await fn(*args, **kwargs)
        except StaffError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
    return wrapper


@router.get("/meta")
async def meta(request: Request):
    """화면이 이 회사에 맞게 그리는 데 필요한 것 (이름·처리 방식·요금·상태 전이 …)."""
    service, card = request.app.state.service, request.app.state.card
    s, p = service.settings, service.pricing
    pricing = dataclasses.asdict(p)
    return {
        "name": s.carrier_name, "id_prefix": s.id_prefix, "public_url": s.public_url,
        "app_version": __version__, "contract_version": logistics_contract.__version__,
        "skills": [{"id": k.id, "tags": list(k.tags)} for k in card.skills],
        "modes": {"quote": p.quote_mode, "booking": p.booking_mode},
        "pricing": pricing, "pricing_editable": [k for k in EDITABLE if k in pricing],
        "statuses": {st.value: label for st, label in STATUS_LABEL.items()},
        "transitions": {st.value: [n.value for n in nexts] for st, nexts in TRANSITIONS.items()},
        "outbox": {"interval_s": s.outbox_interval_s, "max_attempts": s.outbox_max_attempts},
        "allowed_callback_hosts": sorted(s.allowed_callback_hosts),
        "obs_url": s.obs_url, "db_path": str(s.db_path), "ui_enabled": s.ui_enabled,
        "accent": s.ui_accent, "a2a_auth": s.a2a_auth, "staff_auth": s.staff_auth,
        "poll_s": s.poll_s,
    }


@router.put("/pricing")
async def update_pricing(request: Request, body: dict, user: StaffUser = Depends(require("settings.edit"))):
    """요금 규칙·처리 방식 변경. DB가 원본이 되고 다음 요청부터 반영된다."""
    try:
        pricing = svc(request).update_pricing(body, user.username)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    audit(request, user, "pricing.update", "pricing", json.dumps(body, ensure_ascii=False))
    return dataclasses.asdict(pricing)


@router.get("/inbox")
async def inbox(request: Request):
    return svc(request).inbox()


@router.get("/quotes")
async def quotes(request: Request):
    return svc(request).quotes()


@router.post("/quotes/{rfq_id}/approve")
@staff
async def approve(request: Request, rfq_id: str, body: Approve, user: StaffUser = Depends(require("quote.decide"))):
    result = svc(request).approve_quote(rfq_id, body.price_krw, body.eta_days)
    audit(request, user, "quote.approve", rfq_id, f"{result.price_krw}원 {result.eta_days}일")
    return to_data(result)


@router.post("/quotes/{rfq_id}/decline")
@staff
async def decline(request: Request, rfq_id: str, body: Reason, user: StaffUser = Depends(require("quote.decide"))):
    result = svc(request).decline_quote(rfq_id, body.reason)
    audit(request, user, "quote.decline", rfq_id, body.reason)
    return to_data(result)


@router.post("/quotes/{rfq_id}/ask")
@staff
async def ask(request: Request, rfq_id: str, body: Question, user: StaffUser = Depends(require("quote.decide"))):
    svc(request).ask(rfq_id, body.question)
    audit(request, user, "quote.ask", rfq_id, body.question)
    return {"rfq_id": rfq_id, "status": "question", "question": body.question}


@router.get("/bookings")
async def bookings(request: Request):
    return svc(request).bookings()


@router.post("/bookings/{booking_id}/accept")
@staff
async def accept(request: Request, booking_id: str, user: StaffUser = Depends(require("booking.decide"))):
    result = svc(request).accept_booking(booking_id)
    audit(request, user, "booking.accept", booking_id, result.tracking_no or "")
    return to_data(result)


@router.post("/bookings/{booking_id}/reject")
@staff
async def reject(request: Request, booking_id: str, body: Reason, user: StaffUser = Depends(require("booking.decide"))):
    result = svc(request).reject_booking(booking_id, body.reason)
    audit(request, user, "booking.reject", booking_id, body.reason)
    return to_data(result)


@router.get("/shipments")
async def shipments(request: Request):
    return svc(request).shipments()


@router.get("/shipments/{tracking_no}/history")
async def history(request: Request, tracking_no: str):
    try:
        return svc(request).history(tracking_no)
    except StaffError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/stream")
async def stream(request: Request):
    """SSE. DB가 바뀔 때마다 {"rev": n}을 보낸다(연결 직후 한 번). 화면은 받으면 목록을 다시 읽는다."""
    store = svc(request).store

    async def changes():
        last = None
        while not await request.is_disconnected():
            if store.revision != last:
                last = store.revision
                yield {"data": json.dumps({"rev": last})}
            await asyncio.sleep(STREAM_CHECK_S)

    return EventSourceResponse(changes(), ping=15)


@router.post("/shipments/{tracking_no}/advance")
@staff
async def advance(request: Request, tracking_no: str, body: Advance,
                  user: StaffUser = Depends(require("shipment.update"))):
    seq = svc(request).advance_shipment(tracking_no, body.status, body.note)
    audit(request, user, "shipment.advance", tracking_no, f"{body.status.value} {body.note}".strip())
    return {"tracking_no": tracking_no, "status": body.status, "seq": seq}


@router.get("/outbox")
async def outbox(request: Request, state: str | None = None):
    return request.app.state.outbox.list(state)


@router.post("/outbox/{event_id}/retry")
async def retry(request: Request, event_id: str, user: StaffUser = Depends(require("outbox.manage"))):
    try:
        request.app.state.outbox.retry(event_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"없는 알림: {event_id}") from exc
    audit(request, user, "outbox.retry", event_id)
    return {"event_id": event_id, "state": "pending"}


@router.post("/outbox/dispatch")
async def dispatch(request: Request, _: StaffUser = Depends(require("outbox.manage"))):
    """발송 주기를 기다리지 않고 지금 보낸다."""
    return await request.app.state.outbox.dispatch_once()
