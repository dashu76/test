# 파일명: card.py
"""Agent Card. URL은 설정의 공개 주소 하나에서 만든다 (코드에 주소를 쓰지 않는다)."""

from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill
from logistics_contract import (
    CONTRACT_TAG,
    SKILL_BOOK_SHIPMENT,
    SKILL_CANCEL_BOOKING,
    SKILL_CHECK_DELIVERY,
    SKILL_QUOTE,
)

from . import __version__
from .a2a_auth import card_security
from .domain import Pricing
from .settings import Settings

JSON = "application/json"

MODE_TEXT = {
    "auto": "즉시 처리",
    "manual": "담당자 확인 후 처리 (Task가 working으로 남는다. tasks/get으로 확인)",
    "manual-with-timeout": "담당자 확인 후 처리, 처리 마감이 지나면 규칙대로 처리 (Task가 working으로 남는다. tasks/get으로 확인)",
}


def build_card(settings: Settings, pricing: Pricing) -> AgentCard:
    skills = [
        (SKILL_QUOTE, f"운송 견적: quote-request → quote(quoted|declined). {MODE_TEXT[pricing.quote_mode]}."
                      " 정보가 부족하면 input-required로 질문하고 같은 Task의 text 답을 받는다"),
        (SKILL_BOOK_SHIPMENT, f"운송 예약: booking-request → booking(accepted|rejected). business_key로 중복 방지."
                              f" {MODE_TEXT[pricing.booking_mode]}"),
        (SKILL_CANCEL_BOOKING, "예약 취소: 집하 전까지만 가능"),
        (SKILL_CHECK_DELIVERY, "배송 조회: 운송장 번호로 현재 상태와 순번(seq)을 돌려준다. 기존 주문번호(ORDER-1001 등)도 조회된다"),
    ]
    return AgentCard(
        name=settings.carrier_name,
        description=f"{settings.carrier_name}의 운송 견적·예약·배송 조회 에이전트",
        version=__version__,
        default_input_modes=[JSON],
        default_output_modes=[JSON],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[
            AgentInterface(url=f"{settings.public_url}/", protocol_binding="JSONRPC", protocol_version="1.0")
        ],
        skills=[
            AgentSkill(id=skill_id, name=skill_id, description=desc, tags=[CONTRACT_TAG],
                       input_modes=[JSON], output_modes=[JSON])
            for skill_id, desc in skills
        ],
        **(card_security() if settings.a2a_auth else {}),   # 부르려면 X-Partner-Key가 필요하다 (Ch18)
    )
