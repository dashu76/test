# 파일명: store.py
"""K-Logistics 전용 SQLite 저장소. 다른 회사와 공유하지 않는다.

견적·발주는 담당자 처리를 기다리는 동안에도 여기 남는다. A2A Task가 사라져도(재시작)
구매사가 같은 rfq_id·업무키로 다시 보내면 이어서 처리한다.
"""

import json
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS quotes (
    quote_seq      INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_id       TEXT UNIQUE,
    rfq_id         TEXT NOT NULL UNIQUE,
    request_key    TEXT NOT NULL,
    request_json   TEXT NOT NULL,
    status         TEXT NOT NULL,              -- awaiting | question | quoted | declined
    proposed_price INTEGER,
    proposed_eta   INTEGER,
    due_at         TEXT,                       -- 담당자 처리 마감 (manual-with-timeout)
    question       TEXT,
    qa_json        TEXT NOT NULL DEFAULT '[]', -- [{"q":..., "a":...}]
    task_id        TEXT NOT NULL DEFAULT '',   -- 지금 이 견적을 기다리는 A2A Task
    valid_until    TEXT,
    decided_by     TEXT,                       -- auto | staff | timeout
    response_json  TEXT NOT NULL DEFAULT '{}',
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bookings (
    booking_seq   INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id    TEXT UNIQUE,
    business_key  TEXT NOT NULL UNIQUE,
    request_key   TEXT NOT NULL,
    quote_id      TEXT NOT NULL,
    rfq_id        TEXT,
    tracking_no   TEXT UNIQUE,
    status        TEXT NOT NULL,               -- rejected 또는 ShipmentStatus 값 (pending = 담당자 수락 대기)
    seq           INTEGER NOT NULL DEFAULT 0,
    eta           TEXT,
    callback_url  TEXT,
    due_at        TEXT,
    decided_by    TEXT,
    response_json TEXT NOT NULL DEFAULT '{}',
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS shipment_history (
    booking_id TEXT NOT NULL,
    seq        INTEGER NOT NULL,
    status     TEXT NOT NULL,
    note       TEXT NOT NULL DEFAULT '',
    at         TEXT NOT NULL,
    PRIMARY KEY (booking_id, seq)
);
CREATE TABLE IF NOT EXISTS cancel_requests (
    business_key  TEXT PRIMARY KEY,
    request_key   TEXT NOT NULL,
    response_json TEXT NOT NULL,
    created_at    TEXT NOT NULL
);
-- 화면·API로 고치는 설정 (pricing 한 줄). 처음 뜰 때 config/pricing.toml로 채운다.
CREATE TABLE IF NOT EXISTS config (
    key        TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    updated_by TEXT NOT NULL
);
-- 구매사에 보낼 배송 상태 알림. 상태 변경과 같은 트랜잭션에서 쌓는다(transactional outbox).
CREATE TABLE IF NOT EXISTS outbox (
    event_id        TEXT PRIMARY KEY,
    booking_id      TEXT NOT NULL,
    target_url      TEXT NOT NULL,
    payload_json    TEXT NOT NULL,
    state           TEXT NOT NULL,             -- pending | sent | failed
    attempts        INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TEXT NOT NULL,
    last_error      TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL,
    sent_at         TEXT
);
"""

# 기존 실습(part3 server/agent_delivery.py)의 배송 데이터를 이어받는다.
LEGACY_SHIPMENTS = [
    ("ORDER-1001", "in_transit", "2026-09-03", "출고 완료 · 배송 중"),
    ("ORDER-1002", "customs_hold", None, "통관 대기 · 영업일 기준 2일 추가 소요"),
]


def canonical(data: dict[str, Any]) -> str:
    """같은 요청인지 비교하는 키. schema_version 차이(1.0 vs 1.1)는 같은 요청으로 본다."""
    body = {k: v for k, v in data.items() if k != "schema_version"}
    return json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False)


class Store:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.revision = 0                   # 바뀐 행이 있는 쓰기마다 1씩 오른다 (화면 실시간 갱신용)
        self._revision_lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.read() as conn:
            conn.executescript(SCHEMA)
            columns = {r["name"] for r in conn.execute("PRAGMA table_info(bookings)").fetchall()}
            if "partner" not in columns:   # 인증 도입 전 DB: 발주한 회사(파트너 키의 회사) 열을 더한다
                conn.execute("ALTER TABLE bookings ADD COLUMN partner TEXT")
        with self.transaction() as conn:
            self._seed_legacy(conn)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.execute("COMMIT")
            # 읽기만 한 트랜잭션(정리할 것이 없던 inbox 등)은 화면을 다시 그리게 하지 않는다
            if conn.total_changes:
                with self._revision_lock:
                    self.revision += 1
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.close()

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            yield conn
        finally:
            conn.close()

    @staticmethod
    def _seed_legacy(conn) -> None:
        for tracking, status, eta, note in LEGACY_SHIPMENTS:
            booking_id = f"K-LEGACY-{tracking}"
            cur = conn.execute(
                "INSERT OR IGNORE INTO bookings (booking_id, business_key, request_key, quote_id, tracking_no,"
                " status, seq, eta, decided_by, created_at, updated_at)"
                " VALUES (?, ?, '', 'legacy', ?, ?, 1, ?, 'legacy', '2026-09-01T09:00:00+09:00',"
                " '2026-09-01T09:00:00+09:00')",
                (booking_id, f"legacy:{tracking}", tracking, status, eta),
            )
            if cur.rowcount:
                conn.execute("INSERT INTO shipment_history VALUES (?, 1, ?, ?, '2026-09-01T09:00:00+09:00')",
                             (booking_id, status, note))

    # ---------- 공통 갱신 ----------

    @staticmethod
    def update(conn, table: str, where: str, value: Any, **fields: Any) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE {table} SET {cols} WHERE {where}=?", (*fields.values(), value))

    # ---------- 견적 ----------

    @staticmethod
    def find_quote_by_rfq(conn, rfq_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM quotes WHERE rfq_id=?", (rfq_id,)).fetchone()

    @staticmethod
    def find_quote(conn, quote_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM quotes WHERE quote_id=?", (quote_id,)).fetchone()

    @staticmethod
    def find_quote_by_task(conn, task_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM quotes WHERE task_id=? AND task_id != ''", (task_id,)).fetchone()

    @staticmethod
    def insert_quote(conn, rfq_id: str, request_key: str, request: dict, now: str) -> int:
        cur = conn.execute(
            "INSERT INTO quotes (rfq_id, request_key, request_json, status, created_at, updated_at)"
            " VALUES (?, ?, ?, 'awaiting', ?, ?)",
            (rfq_id, request_key, dumps(request), now, now),
        )
        return cur.lastrowid

    @staticmethod
    def open_quotes(conn) -> list[sqlite3.Row]:
        return conn.execute("SELECT * FROM quotes WHERE status IN ('awaiting', 'question') ORDER BY quote_seq").fetchall()

    @staticmethod
    def all_quotes(conn) -> list[sqlite3.Row]:
        return conn.execute("SELECT * FROM quotes ORDER BY quote_seq DESC").fetchall()

    # ---------- 발주 ----------

    @staticmethod
    def find_booking_by_key(conn, business_key: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM bookings WHERE business_key=?", (business_key,)).fetchone()

    @staticmethod
    def find_booking(conn, booking_id: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM bookings WHERE booking_id=?", (booking_id,)).fetchone()

    @staticmethod
    def find_booking_by_tracking(conn, tracking_no: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM bookings WHERE tracking_no=?", (tracking_no,)).fetchone()

    @staticmethod
    def find_active_booking_for_quote(conn, quote_id: str) -> sqlite3.Row | None:
        return conn.execute(
            "SELECT * FROM bookings WHERE quote_id=? AND status NOT IN ('rejected', 'cancelled')",
            (quote_id,),
        ).fetchone()

    @staticmethod
    def insert_booking(conn, business_key: str, request_key: str, quote_id: str, rfq_id: str,
                       callback_url: str | None, now: str, partner: str | None = None) -> int:
        cur = conn.execute(
            "INSERT INTO bookings (business_key, request_key, quote_id, rfq_id, status, callback_url,"
            " created_at, updated_at, partner) VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?)",
            (business_key, request_key, quote_id, rfq_id, callback_url, now, now, partner),
        )
        return cur.lastrowid

    @staticmethod
    def pending_bookings(conn) -> list[sqlite3.Row]:
        return conn.execute("SELECT * FROM bookings WHERE status='pending' ORDER BY booking_seq").fetchall()

    @staticmethod
    def all_bookings(conn) -> list[sqlite3.Row]:
        return conn.execute("SELECT * FROM bookings ORDER BY booking_seq DESC").fetchall()

    @staticmethod
    def history(conn, booking_id: str) -> list[sqlite3.Row]:
        return conn.execute(
            "SELECT * FROM shipment_history WHERE booking_id=? ORDER BY seq", (booking_id,)
        ).fetchall()

    @staticmethod
    def shipments(conn) -> list[sqlite3.Row]:
        return conn.execute(
            "SELECT * FROM bookings WHERE tracking_no IS NOT NULL ORDER BY booking_seq DESC").fetchall()

    @staticmethod
    def set_booking_status(conn, booking_id: str, status: str, note: str, at: str) -> int:
        row = conn.execute("SELECT seq FROM bookings WHERE booking_id=?", (booking_id,)).fetchone()
        seq = row["seq"] + 1
        conn.execute("UPDATE bookings SET status=?, seq=?, updated_at=? WHERE booking_id=?",
                     (status, seq, at, booking_id))
        conn.execute("INSERT INTO shipment_history (booking_id, seq, status, note, at) VALUES (?, ?, ?, ?, ?)",
                     (booking_id, seq, status, note, at))
        return seq

    @staticmethod
    def last_note(conn, booking_id: str) -> str:
        row = conn.execute(
            "SELECT note FROM shipment_history WHERE booking_id=? ORDER BY seq DESC LIMIT 1", (booking_id,)
        ).fetchone()
        return row["note"] if row else ""

    # ---------- 취소 ----------

    @staticmethod
    def find_cancel(conn, business_key: str) -> sqlite3.Row | None:
        return conn.execute("SELECT * FROM cancel_requests WHERE business_key=?", (business_key,)).fetchone()

    @staticmethod
    def insert_cancel(conn, business_key: str, request_key: str, response: dict, now: str) -> None:
        conn.execute(
            "INSERT INTO cancel_requests (business_key, request_key, response_json, created_at) VALUES (?, ?, ?, ?)",
            (business_key, request_key, dumps(response), now),
        )

    # ---------- 설정 ----------

    def get_config(self, key: str) -> dict | None:
        with self.read() as conn:
            row = conn.execute("SELECT value_json FROM config WHERE key=?", (key,)).fetchone()
        return json.loads(row["value_json"]) if row else None

    def set_config(self, key: str, value: dict, by: str, now: str) -> None:
        with self.transaction() as conn:
            conn.execute("INSERT INTO config (key, value_json, updated_at, updated_by) VALUES (?, ?, ?, ?)"
                         " ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,"
                         " updated_at=excluded.updated_at, updated_by=excluded.updated_by",
                         (key, json.dumps(value, ensure_ascii=False), now, by))

    # ---------- 알림 outbox ----------

    @staticmethod
    def enqueue_event(conn, event_id: str, booking_id: str, target_url: str, payload: dict, now: str) -> None:
        conn.execute(
            "INSERT OR IGNORE INTO outbox (event_id, booking_id, target_url, payload_json, state,"
            " next_attempt_at, created_at) VALUES (?, ?, ?, ?, 'pending', ?, ?)",
            (event_id, booking_id, target_url, dumps(payload), now, now),
        )

    @staticmethod
    def pending_events(conn) -> list[sqlite3.Row]:
        """쌓인 순서대로 (같은 트랜잭션 안의 순번까지 지키도록 rowid로 정렬)."""
        return conn.execute("SELECT * FROM outbox WHERE state='pending' ORDER BY rowid").fetchall()

    @staticmethod
    def outbox(conn, state: str | None = None) -> list[sqlite3.Row]:
        if state:
            return conn.execute("SELECT * FROM outbox WHERE state=? ORDER BY created_at DESC", (state,)).fetchall()
        return conn.execute("SELECT * FROM outbox ORDER BY created_at DESC").fetchall()

    @staticmethod
    def set_event(conn, event_id: str, **fields) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE outbox SET {cols} WHERE event_id=?", (*fields.values(), event_id))
