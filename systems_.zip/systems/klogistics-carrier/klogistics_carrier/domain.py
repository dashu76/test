# 파일명: domain.py
"""K-Logistics의 업무 규칙. 저장소·네트워크를 모르는 순수 함수만 둔다."""

import dataclasses
import math
import tomllib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from logistics_contract import ShipmentStatus

KST = timezone(timedelta(hours=9), "KST")

MODES = ("auto", "manual", "manual-with-timeout")
ON_TIMEOUT = ("auto", "decline")


def now_kst() -> datetime:
    return datetime.now(KST)


@dataclass(frozen=True)
class Pricing:
    base_krw: int
    per_kg_krw: int
    round_to_krw: int
    eta_days: int
    max_weight_kg: float
    quote_valid_hours: int
    quote_mode: str = "auto"
    booking_mode: str = "auto"
    manual_timeout_min: int = 30
    on_timeout: str = "auto"

    def due_at(self, mode: str, now: datetime) -> datetime | None:
        """담당자 처리 마감. manual은 마감 없음."""
        if mode == "manual-with-timeout":
            return now + timedelta(minutes=self.manual_timeout_min)
        return None


def load_pricing(path: Path) -> Pricing:
    with path.open("rb") as f:
        raw = tomllib.load(f)
    p, m = raw["pricing"], raw.get("modes", {})
    pricing = Pricing(
        base_krw=int(p["base_krw"]),
        per_kg_krw=int(p["per_kg_krw"]),
        round_to_krw=int(p.get("round_to_krw", 1)),
        eta_days=int(p["eta_days"]),
        max_weight_kg=float(p["max_weight_kg"]),
        quote_valid_hours=int(p["quote_valid_hours"]),
        quote_mode=m.get("quote", "auto"),
        booking_mode=m.get("booking", "auto"),
        manual_timeout_min=int(m.get("manual_timeout_min", 30)),
        on_timeout=m.get("on_timeout", "auto"),
    )
    for name in (pricing.quote_mode, pricing.booking_mode):
        if name not in MODES:
            raise ValueError(f"알 수 없는 처리 방식: {name} (가능: {MODES})")
    if pricing.on_timeout not in ON_TIMEOUT:
        raise ValueError(f"알 수 없는 on_timeout: {pricing.on_timeout} (가능: {ON_TIMEOUT})")
    return pricing


EDITABLE = ("base_krw", "per_kg_krw", "round_to_krw", "eta_days", "max_weight_kg", "quote_valid_hours",
            "quote_mode", "booking_mode", "manual_timeout_min", "on_timeout")   # 화면에서 고칠 수 있는 항목


def pricing_from_dict(values: dict) -> Pricing:
    """DB·화면에서 온 값으로 요금 규칙·처리 방식을 만든다. 모르는 항목은 무시하고, 잘못된 값은 ValueError."""
    kinds = {f.name: f.type for f in dataclasses.fields(Pricing)}
    clean = {}
    for name, kind in kinds.items():
        if name not in values or values[name] in (None, ""):
            continue
        v = values[name]
        if kind is int:
            if float(v) != int(float(v)):
                raise ValueError(f"{name}은(는) 정수여야 한다")
            clean[name] = int(float(v))
        elif kind is str:
            clean[name] = str(v)
        else:
            clean[name] = float(v)
    try:
        pricing = Pricing(**clean)
    except TypeError as exc:
        raise ValueError(f"요금 규칙 항목이 빠졌다: {exc}") from exc
    check_pricing(pricing)
    return pricing


def check_pricing(p: Pricing) -> None:
    if p.base_krw < 0 or p.per_kg_krw < 0 or p.round_to_krw < 1 or p.eta_days < 0:
        raise ValueError("운임은 0 이상, 올림 단위는 1 이상, 소요일은 0 이상이어야 한다")
    if p.max_weight_kg <= 0 or p.quote_valid_hours <= 0 or p.manual_timeout_min <= 0:
        raise ValueError("최대 중량·견적 유효시간·처리 마감은 0보다 커야 한다")
    for name in (p.quote_mode, p.booking_mode):
        if name not in MODES:
            raise ValueError(f"알 수 없는 처리 방식: {name} (가능: {', '.join(MODES)})")
    if p.on_timeout not in ON_TIMEOUT:
        raise ValueError(f"알 수 없는 마감 시 처리: {p.on_timeout} (가능: {', '.join(ON_TIMEOUT)})")


def overweight_reason(weight_kg: float, pricing: Pricing) -> str | None:
    if weight_kg > pricing.max_weight_kg:
        return f"최대 적재 중량 {pricing.max_weight_kg:g}kg 초과"
    return None


def calc_price(weight_kg: float, pricing: Pricing) -> tuple[int, int]:
    """규칙대로 낸 (운임, 소요일). 수동 모드에서는 담당자에게 보여 주는 제안값이다."""
    raw = pricing.base_krw + pricing.per_kg_krw * weight_kg
    step = max(pricing.round_to_krw, 1)
    return math.ceil(raw / step) * step, pricing.eta_days


# 배송 상태 전이 (뒤로 가거나 건너뛰는 변경은 막는다)
TRANSITIONS: dict[ShipmentStatus, frozenset[ShipmentStatus]] = {
    ShipmentStatus.PENDING: frozenset({ShipmentStatus.ACCEPTED, ShipmentStatus.CANCELLED}),
    ShipmentStatus.ACCEPTED: frozenset({ShipmentStatus.PICKED_UP, ShipmentStatus.CANCELLED}),
    ShipmentStatus.PICKED_UP: frozenset({ShipmentStatus.IN_TRANSIT}),
    ShipmentStatus.IN_TRANSIT: frozenset({ShipmentStatus.CUSTOMS_HOLD, ShipmentStatus.DELIVERED}),
    ShipmentStatus.CUSTOMS_HOLD: frozenset({ShipmentStatus.IN_TRANSIT, ShipmentStatus.DELIVERED}),
    ShipmentStatus.DELIVERED: frozenset(),
    ShipmentStatus.CANCELLED: frozenset(),
}

STATUS_LABEL = {
    ShipmentStatus.PENDING: "수락 대기",
    ShipmentStatus.ACCEPTED: "수락됨",
    ShipmentStatus.PICKED_UP: "집하",
    ShipmentStatus.IN_TRANSIT: "운송 중",
    ShipmentStatus.CUSTOMS_HOLD: "통관 대기",
    ShipmentStatus.DELIVERED: "배송 완료",
    ShipmentStatus.CANCELLED: "취소됨",
}


class InvalidTransition(ValueError):
    pass


def check_transition(current: ShipmentStatus, new: ShipmentStatus) -> None:
    if new not in TRANSITIONS[current]:
        raise InvalidTransition(f"{STATUS_LABEL[current]} → {STATUS_LABEL[new]} 변경은 허용되지 않는다")


def can_cancel(current: ShipmentStatus) -> bool:
    return ShipmentStatus.CANCELLED in TRANSITIONS[current]
