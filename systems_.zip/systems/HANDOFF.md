# HANDOFF — 회사별 독립 A2A 시스템 작업 인수인계

> 작성: 2026-10-15. 새 세션은 이 문서부터 읽고 시작한다.
> 진행 상황: **P0~P6 완료**(물류사·구매사 화면), **Part 4 인증·권한·DB 적용 완료**, **P7 남음**. (2026-10-15)

---

## 1. 무엇을 만들고 있나

Part 3 실습(Ch13~17)의 일회성 코드를 **각 회사가 실제로 운영하는 독립 시스템**으로 다시 만들고 있다.

- **K정밀웍스**(구매사)가 물류사 4곳에 운송 견적을 받아 비교하고, 발주하고, 배송을 추적하고, 입고 확인 후 지급한다.
- 회사마다 **완전히 독립된 폴더·환경·DB**를 가진다. 회사 간 소통은 **A2A(HTTP)로만** 한다.
- 웹 화면(업무 화면·관제 허브)이 없어도 회사 간 연동은 동작해야 한다. 지금은 CLI로 모든 업무를 처리한다.

### 설계 문서 (먼저 읽을 것)

| 문서 | 위치 | 내용 |
|---|---|---|
| plan_2.md | `a2a_lab/part3_orchestration/plan_2.md` | 업무 시나리오 S-01~S-30, 상태 모델, 화면 설계 (요구사항의 원본) |
| plan_3.md | `a2a_lab/part3_orchestration/plan_3.md` | 독립 구조, 확정된 결정, 진행 순서 P0~P7과 완료 기록 |
| systems/README.md | `a2a_lab/systems/README.md` | 시스템 목록, 다섯 회사 함께 실행하는 순서 |
| **p6-carrier-ui.md** | `a2a_lab/systems/docs/p6-carrier-ui.md` | 전체 개념 요약 + 물류사 업무 화면 설계·API·실시간 갱신·검증 (plan 문서가 없는 사본에서 작성) |
| **p6-buyer-ui.md** | `a2a_lab/systems/docs/p6-buyer-ui.md` | 구매사 업무 화면 설계·할 일 규칙·검증 |
| **security-and-db.md** | `a2a_lab/systems/docs/security-and-db.md` | Part 4 적용: 파트너 키(Ch18)·로그인과 역할(Ch19)·감사 기록·DB(인증·설정·거래처·허브 기록), 검증 결과·남은 한계 |
| 각 시스템 README | `a2a_lab/systems/<시스템>/README.md` | 설치·실행·설정·CLI·업무 규칙 |

### 사용자가 확정한 결정 (다시 묻지 말 것)

1. 시스템들은 Part 실습 폴더 밖 `a2a_lab/systems/`에서 관리.
2. 물류사 템플릿 생성 스크립트는 만들지 않음.
3. Docker는 범위에서 제외. Windows에서 `uv run`으로만.
4. 회사 간 계약은 버전 붙은 패키지 `logistics-contract`로 빌드해 각 서버가 버전 고정 설치.
5. 포트는 **5000번대** (2026-10-16 변경: 8000·9000번대는 다른 프로그램과 겹칠 수 있음). 구매사 5010, K-Logistics 5020, 물류사 A·B·C 5021~5023, 관제 허브 5090. 기존 Part 3 실습(`a2a_lab/part3_orchestration`)은 따로 8000번대로 바꿔 둔 그대로 — systems와 무관.
6. 인증은 Part 4 수준으로 회사 사이(파트너 키)와 사내(로그인·역할) 둘 다. DB는 인증 정보·관제 허브 기록·설정과 거래처에 쓴다.
7. 인증은 지금 "인증이 된다" 수준까지만. 세부 보강(HTTPS, Task 소유 확인, 키 보관·교체, 두 사람 승인 등)은 P7-B에 기록만 하고, 할 항목은 그때 사용자와 정한다.
8. 로컬 시험 계정은 시스템마다 다르게: 구매사 `admin1`, K-Logistics `admin2`, 물류사 A·B·C `admin3`~`admin5`, 관제 허브 `admin6`, 비밀번호 모두 `1234` (`setup_dev_auth.ps1` 기본, 비밀번호 최소 4자 — 운영 정책은 P7-B S5). 로그인 화면 안내는 각 `.env`의 `APP_LOGIN_HINT`(기본 비어 있음, 지우면 사라짐). 빠른 로그인은 만들었다가 사용자 요청으로 뺐다.
9. 한 PC에 여러 서버를 띄워도 로그인이 섞이지 않게 세션 쿠키 이름에 포트를 붙인다(`session_5010` …). 브라우저 쿠키는 호스트로만 나뉘고 포트로는 나뉘지 않는다(RFC 6265). 실제로 PC가 다르면 원래 섞이지 않는다.

---

## 2. 현재 구조

```text
a2a_lab/
├── part1~part6/                  기존 실습 (건드리지 않음. part3 포트만 8000번대로 변경했음 — systems는 5000번대)
└── systems/
    ├── HANDOFF.md                이 문서
    ├── README.md
    ├── interop-spec/             계약 패키지 logistics-contract (1.0.0, 1.1.0 빌드됨 → dist/)
    ├── kpw-buyer/                K정밀웍스 구매 시스템        :5010  계약 1.0.0
    ├── klogistics-carrier/       K-Logistics (담당자 확인형)  :5020  계약 1.0.0
    ├── carrier-a/                물류사 A (자동)              :5021  계약 1.0.0
    ├── carrier-b/                물류사 B (계약 1.1, co2_kg)  :5022  계약 1.1.0
    ├── carrier-c/                물류사 C (견적 응답 20초 지연) :5023  계약 1.0.0
    ├── obs-hub/                  관제 허브 (선택)              :5090  — (계약 패키지 안 씀)
    ├── docs/p6-carrier-ui.md     물류사 업무 화면 설계
    ├── docs/p6-buyer-ui.md       구매사 업무 화면 설계
    ├── docs/security-and-db.md   인증·권한과 DB 설계 (Part 4)
    └── dev-env/
        ├── check_independence.ps1   독립성 검사 6항목 (obs-hub 포함 6개 시스템)
        └── setup_dev_auth.ps1       로컬 개발용: 사용자·회사 사이 키·허브 수집 키 준비
```

아직 없음: `dev-env/start_all.ps1`·`stop_all.ps1`·`e2e/`(P7).

### 서버 하나의 공통 모양

```text
<system>/
├── pyproject.toml        package = false, 의존성 a2a-sdk==1.1.2, fastapi, uvicorn, sse_starlette, httpx, logistics-contract==X
├── uv.lock, .python-version(3.12), .env.example, .gitignore(.venv, data/, .env), README.md
├── vendor/logistics_contract-X.Y.Z-py3-none-any.whl     계약 wheel ([tool.uv.sources]가 이 경로를 가리킴)
├── config/               pricing.toml(물류사) / partners.toml(구매사)
├── <패키지>/             폴더명의 '-'를 '_'로: carrier_a, kpw_buyer, klogistics_carrier …
│   ├── __main__.py       실행: uv run python -m <패키지>
│   ├── settings.py       환경변수 > .env > 기본값. 상대 경로는 시스템 폴더 기준
│   ├── card.py           Agent Card. URL은 APP_PUBLIC_URL에서만 만든다
│   ├── domain.py         순수 업무 규칙(요금, 상태 전이, 업무키 …)
│   ├── store.py          SQLite (BEGIN IMMEDIATE 트랜잭션)
│   ├── skills.py|service.py  업무 처리 (A2A를 모름)
│   ├── executor.py       A2A AgentExecutor (data Part ↔ 계약 모델)
│   ├── api.py            내부 API /api/* (자기 회사 CLI·화면 전용)
│   ├── cli.py            uv run python -m <패키지>.cli …
│   ├── outbox.py         (물류사) 구매사 알림 발송기
│   ├── remote.py         (구매사) 물류사 호출 A2A 클라이언트
│   ├── obs_hook.py       관제 허브로 관찰 이벤트 보내기 (5개 시스템 모두 같은 파일, A2A_OBS_URL 비면 no-op)
│   ├── ui/index.html     담당자 업무 화면(물류사 4곳 같은 파일 + 구매사 따로)(로그인·역할별 버튼·관리 탭). 네 물류사 같은 파일, /api/meta로 회사별 차이
│   ├── auth.py           사용자·세션·발급 키·받은 키·감사 기록·로그인 API·require(권한) (여섯 시스템 같은 파일)
│   ├── a2a_auth.py       파트너 키: 카드 securitySchemes, 컨텍스트 빌더, 실행기 판정, GetTask 등 401 미들웨어 (다섯 시스템 같은 파일)
│   ├── permissions.py    이 회사의 역할 → 권한 표
│   ├── admin.py          서버 밖 관리 도구(DB 직접): user / key / outbound / config / audit (여섯 시스템 같은 파일)
│   └── app.py            FastAPI 조립 + 백그라운드 작업(lifespan)
└── tests/                pytest. 상대 회사는 tests/ 안의 가짜 서버(fake_carrier.py / fake_buyer.py)로 흉내
```

---

## 3. 핵심 설계 원칙 (코드 곳곳에 반영됨)

| 원칙 | 구현 |
|---|---|
| 폴더 하나 = 시스템 하나 | 다른 시스템 폴더 import·`..` 경로·`sys.path` 금지. `check_independence.ps1`가 검사 |
| 업무 상태의 원본은 각 회사 DB, A2A Task는 전달 수단 | A2A TaskStore는 `InMemoryTaskStore`. 재시작으로 Task가 사라져도 같은 `rfq_id`·업무키로 재전송하면 DB 상태로 이어서 처리 |
| 업무키로 한 번만 처리 | 발주 `K정밀웍스:{RFQ}:book:{거래처id}:v1`, 취소 `…:cancel:{예약}:v1`, 지급 `…:pay:{예약}:v1`. 같은 키·같은 내용 → 첫 결과 반환, 같은 키·다른 내용 → 거부(Task failed). 견적은 `rfq_id`가 키 (schema_version 차이는 같은 요청으로 봄) |
| 업무상 "안 됨" ≠ 장애 | 견적 거절·발주 거절·조회 결과 없음은 Task `completed` + `status: declined/rejected/not_found`. 계약 위반·키 충돌·내부 오류만 `failed` |
| 오래 걸리는 처리 | 물류사: Task를 `working`으로 두고 DB를 폴링하다 결정되면 `completed`. 되물을 땐 `input-required` + 질문 text, 같은 Task로 온 text 답으로 재개. 구매사: `ClientConfig(streaming=False, polling=True)`로 보내고 즉시 반환(`return_immediately`), `APP_QUICK_WAIT_S` 동안만 `tasks/get`, 이후 `waiting`으로 저장해 수집기가 나중에 확인. `TaskNotFoundError`면 같은 요청 재전송 |
| 배송 알림 | 물류사가 상태를 바꾸는 같은 트랜잭션에서 `outbox`에 `shipment-event` 적재 → 발송기가 순서대로 전송, 실패 시 2·4·8…초(최대 300초) 백오프, 같은 대상의 앞 알림이 안 끝나면 뒤 알림 대기, 거부·최대 시도 초과 시 `failed`(담당자 `outbox retry`). 구매사는 `event_id`로 중복, `seq`로 옛 상태를 거름 + 5분마다 보조 조회 |
| 알림 주소 | 구매사가 발주 요청에 `event_callback_url`(자기 공개 주소)을 넣음. 물류사는 `APP_ALLOWED_CALLBACK_HOSTS`에 있는 호스트만 허용 |
| 계약 | 모든 메시지는 data Part 하나 + `kind` + `schema_version`. major가 같으면 호환, 모르는 필드는 무시. Agent Card 스킬 `tags`에 `contract:logistics/1` |
| 숫자 | A2A data Part는 정수를 float로 돌려줌(174000 → 174000.0). 계약 모델이 소수부 0인 float만 int로 받음 |
| 업무 화면 (P6) | 자기 서버가 `/ui`로 내주고 자기 `/api`만 부른다. 화면이 할 수 있는 일 = CLI가 할 수 있는 일. 처리 방식(`/api/meta` modes)이 auto가 아니면 처리 버튼, auto면 조회 전용. `Store.revision`(바뀐 행이 있는 커밋만) → `/api/stream` SSE → 화면이 다시 읽음 |
| 인증 (Part 4) | 회사 사이: **받는 쪽이 키를 발급**, 보내는 쪽은 `outbound_keys`에 두고 `X-Partner-Key`로 냄. 실행기가 판정(없음·틀림·스킬 밖·남의 이름 → Task rejected + 이유), 그 밖의 JSON-RPC는 미들웨어 401. 키가 맞아도 업무 소유 확인(남의 견적·예약·운송장은 '없음'). 사내: 로그인(PBKDF2, 세션 해시, 5회 실패 5분 잠금) + 역할별 권한, 돈·약속이 걸린 결정은 승인 역할. 모든 결정·거부는 `audit_log`. **Settings 코드 기본값은 인증 꺼짐(테스트), load_settings 기본은 켜짐** |
| 설정·거래처 DB | 물류사 요금·처리 방식은 `config` 테이블, 구매사 거래처는 `partners` 테이블이 원본. 파일(`pricing.toml`·`partners.toml`)은 처음 값. 구매사는 키를 거래처 id로 찾아 주소가 바뀌어도(S-32) 그대로 |
| 관찰 (P5) | 각 서버가 `obs_hook.emit()`으로 허브에 **직접** 보냄(SDK 덮어쓰기 없음). 큐 + 데몬 스레드, 업무는 기다리지 않음. 허브에 닿지 않으면 5초간 이벤트를 버림. 허브는 Agent Card heartbeat로 켜짐·꺼짐을 스스로 판단 |

### 계약 (logistics-contract)

| 스킬 | 방향 | 요청 kind | 응답 kind / status |
|---|---|---|---|
| quote | 구매사→물류사 | quote-request | quote / quoted·declined (1.1: 선택 필드 `co2_kg`) |
| book-shipment | 구매사→물류사 | booking-request | booking / pending·accepted·rejected |
| cancel-booking | 구매사→물류사 | cancel-booking-request | cancel-booking-result / cancelled·rejected |
| check-delivery | 구매사→물류사 | delivery-query | delivery-status / found·not_found |
| receive-shipment-event | 물류사→구매사 | shipment-event | event-ack |

계약 변경 절차: `interop-spec`에서 모델 수정 → 버전·CHANGELOG → `uv run python tools/export_schemas.py` → `uv run pytest` → `uv build` → **새 버전을 쓰기로 한 서버만** `vendor/`에 wheel 복사, `pyproject.toml`의 버전과 `[tool.uv.sources]` 경로 수정 → `uv sync` → 테스트. (`VERSIONING.md`)

---

## 4. 시스템별 현황

| 시스템 | 테스트 | 할 수 있는 것 |
|---|---|---|
| interop-spec | 28 | 모델, parse_request/parse_response/to_data, ContractError, 예시 catalog.json, JSON Schema |
| kpw-buyer | 70 | RFQ 생성, 비동기 견적 수집(마감·재시도·waiting·question), 답장, 비교·추천(조건 충족 최저가), 마감 연장·지금 진행, 발주(재전송·수락 대기·거절 후 차순위), 취소, 배송 조회·보조 조회, 알림 수신(중복·순서), 납기 위험, 입고 확인(이상 시 지급 보류), 지급 기록, 로그인·역할(구매 담당/승인권자), 파트너 키, 거래처 DB, 업무 화면(할 일 목록·견적 비교·두 번 눌러 확정) |
| klogistics-carrier | 78 | 견적·발주 수락 수동(manual-with-timeout 30분, on_timeout=auto), 담당자 질문(input-required), 기존 ORDER-1001/1002 배송 데이터, outbox, 담당자 CLI(inbox, quote approve/decline/ask, booking accept/reject, shipment, outbox), 업무 화면, 로그인·역할(승인만 결정), 파트너 키, 요금·처리 방식 DB |
| carrier-a | 72 | 자동 견적·수락, outbox, 담당자 CLI(shipment list/advance, outbox list/retry/dispatch), 업무 화면, 로그인·역할, 파트너 키, 요금 DB |
| carrier-b | 72 | A와 같음 + 계약 1.1.0(`co2_kg`), 요금 25,000+280/kg, 4일, 유효 48h, 업무 화면, 로그인·역할, 파트너 키, 요금 DB |
| carrier-c | 74 | A와 같음 + `APP_QUOTE_DELAY_S`(기본 20초) 느린 견적, 요금 20,000+250/kg, 2일, 유효 12h, 업무 화면, 로그인·역할, 파트너 키, 요금 DB |
| obs-hub | 10 | 이벤트 수신(중복 거름·검증), SQLite 기록(재기동 유지), SSE, events.jsonl, /agents, heartbeat, 관제 화면, 로그인, 수집 키(이름 = 이벤트 process) |

요금(480kg 기준): A 174,000/3일, B 160,000/4일, C 140,000/2일, K-Logistics 제안가 189,000/2일.

### 주요 CLI

```cmd
:: 구매사 (kpw-buyer 폴더)
uv run python -m kpw_buyer.cli partners --check
uv run python -m kpw_buyer.cli rfq create --item "정밀 베어링 2팔레트" --weight 480 --origin 창원 --dest 평택 --need-by 2026-10-20 [--deadline-min 10] [--partners carrier-a,carrier-b]
uv run python -m kpw_buyer.cli rfq list | show | collect | close | track RFQ-…
uv run python -m kpw_buyer.cli rfq extend RFQ-… --minutes 30
uv run python -m kpw_buyer.cli rfq answer RFQ-… klogistics "답"
uv run python -m kpw_buyer.cli rfq award RFQ-… carrier-a [--allow-ineligible]
uv run python -m kpw_buyer.cli rfq cancel RFQ-… --reason "…"
uv run python -m kpw_buyer.cli rfq receive RFQ-… [--damaged] [--note "…"]
uv run python -m kpw_buyer.cli rfq pay RFQ-…
:: K-Logistics (klogistics-carrier 폴더)
uv run python -m klogistics_carrier.cli inbox
uv run python -m klogistics_carrier.cli quote approve|decline|ask RFQ-… …
uv run python -m klogistics_carrier.cli booking accept|reject K-B-…
uv run python -m klogistics_carrier.cli shipment list | advance <운송장> picked_up|in_transit|customs_hold|delivered [--note]
uv run python -m klogistics_carrier.cli outbox list|retry|dispatch
:: 물류사 A·B·C
uv run python -m carrier_a.cli shipment list | advance …   /   outbox list|retry|dispatch
```

---

## 5. 검증 방법

1. **시스템별 테스트**: 각 폴더에서 `uv run pytest` (구매사는 연결 실패·타임아웃을 실제로 기다려 약 50초).
2. **독립성 검사**: `systems\dev-env\check_independence.ps1 [-System <이름>]`. 폴더를 임시 디렉터리에 혼자 복사 → ①폴더 밖 참조 없음 ②uv sync ③pytest ④거래처 없이 기동 ⑤카드 URL == APP_PUBLIC_URL(일부러 `localhost`로 바꿔 확인) ⑥DB가 설정 경로에 생성. **마지막 결과: 여섯 시스템(obs-hub 포함) 모두 6/6** (2026-10-15, P5 후). 관제 허브는 ⑤를 `/healthz`의 public_url, ⑥을 `APP_EVENTS_FILE`로 본다.
3. **실제 시스템 연동**: 각 서버를 별도 프로세스로 띄우고 CLI로만 진행. DB는 `APP_DB_PATH`로 세션 scratchpad에 둔다(프로젝트 `data/` 오염 방지). 띄우는 예(PowerShell):
   ```powershell
   $env:APP_DB_PATH = "<scratchpad>\carrier_a.sqlite3"
   Start-Process uv -ArgumentList 'run','python','-m','carrier_a' -WorkingDirectory "<systems>\carrier-a" -WindowStyle Hidden -RedirectStandardOutput … -RedirectStandardError …
   ```
   끌 때는 **포트로 찾아서** 끈다: `Get-NetTCPConnection -LocalPort 5010 -State Listen | % { Stop-Process -Id $_.OwningProcess -Force }`.
   ⚠ 사용자가 따로 띄워 둔 `uv` 프로세스(오전부터 실행 중)가 있다. 프로세스 이름으로 일괄 종료하지 말 것.
4. 지금까지 실제 연동으로 확인한 시나리오: S-01, S-02, S-03, S-07, S-14, S-17, S-18, S-21, S-23, S-25, S-31.
   - S-25(P5): 다섯 서버를 `A2A_OBS_URL=http://127.0.0.1:5090`으로 띄우고 허브는 끈 채 견적(A·B 즉시, C 지연, K 담당자 승인)·발주·배송 알림 → 정상, 서버 로그 오류 없음. 허브를 켜자 다섯 곳 모두 online, 두 번째 RFQ(K-Logistics 질문·답 포함)의 서버 뷰·클라이언트 뷰가 같은 taskId로 이어짐. 허브를 중간에 끄고 배송 완료·입고·지급까지 정상.

---

## 6. 작업 환경 주의사항 (시행착오에서 얻은 것)

- Windows PowerShell 5.1. `&&` 없음. 한글 출력은 `$env:PYTHONIOENCODING='utf-8'; [Console]::OutputEncoding=[Text.Encoding]::UTF8`.
- `.ps1`에 한글이 있으면 **UTF-8 with BOM**으로 저장해야 5.1이 읽는다(`check_independence.ps1`가 그렇게 저장됨).
- CLI 출력에 cp949에 없는 문자(예: ⚠) 쓰지 말 것. `[!]` 사용.
- `Invoke-RestMethod`로 보면 한글 JSON이 깨져 보인다(charset 없음). 서버 문제 아님.
- Windows에서 닫힌 localhost 포트 연결은 거부까지 약 2초 걸린다 → 재시도·테스트 시간이 그만큼 늘어난다.
- 다른 폴더에서 복사해 만든 파일은 Edit 전에 Read가 필요(도구 제약). 대량 이름 바꾸기는 PowerShell로 UTF-8(BOM 없음) 저장.
- a2a-sdk 1.1.2 메모:
  - `DefaultRequestHandler`는 클라이언트가 끊겨도 실행을 이어가고 TaskStore를 갱신한다 → `tasks/get`으로 나중 결과 확인 가능.
  - 질문 답으로 재개되는 Task(`context.current_task` 있음)는 `enqueue_event(task)`를 다시 하지 말 것(“already exists” 로그).
  - 답을 보낸 직후 스냅샷은 아직 이전 `input-required`일 수 있다 → 구매사 `reply_text(..., answered_question=)`가 상태 변화까지 잠깐 더 확인.
  - 클라이언트의 Task 없음 예외: `a2a.utils.errors.TaskNotFoundError`.
  - protobuf `label() is deprecated` 경고는 SDK 내부 → pytest `filterwarnings`로 숨김.
- 물류사 4곳은 **의도적으로 코드가 중복**돼 있다(독립성). 물류사 공통 동작을 고칠 때는 4개 폴더(carrier-a/b/c, klogistics-carrier)를 각각 고치고 각각 테스트할 것. A·B·C는 거의 같고, K-Logistics는 수동 흐름 때문에 skills/executor/store가 다르다.
- K-Logistics 예약·운송장 번호는 기존 데이터 2건 때문에 3번부터 시작(K-B-0003, K-T-100003).
- 이 폴더의 파일은 **LF** 줄바꿈이다. Windows 파이썬으로 `write_text`하면 CRLF가 되므로 `newline="\n"`을 줄 것.
- `obs_hook`의 전송 스레드는 프로세스에 하나다. 허브에 닿지 않으면 5초간 버리는 상태가 남으므로 `start()`가 이를 초기화한다(테스트에서 허브 꺼짐 → 켜짐 순서로 돌 때 필요했다). 테스트는 `obs_hook.stop()`으로 정리.
- CLI 출력을 `Select-Object -First`로 자르면 파이프가 끊겨 종료 코드 255가 날 수 있다(시스템 오류 아님).

### 아직 손대지 않은 것 / 알려진 사항

- 계약 패키지 예시(`interop-spec/.../examples/catalog.json`)의 `event_callback_url`은 아직 옛 포트 `http://127.0.0.1:8010`. 이미 빌드해 각 서버 `vendor/`에 넣은 1.0.0·1.1.0 wheel에 들어 있는 예시 데이터라 그대로 뒀다(동작과 무관). 다음 계약 버전을 낼 때 5010으로 고친다.
- 기존 실습 `part3_orchestration/server/agent_delivery.py:75`의 카드 URL이 `8888`(실제 8099). 실습 의도인지 확인 안 됨 → 사용자에게 물어보고 고칠 것. 새 시스템(klogistics-carrier)에는 해당 없음.
- `shipment-event`에는 도착 예정일이 없다. 구매사는 발주 수락 시 견적 소요일로 추정하고, `track`하면 물류사 값으로 갱신.
- 인증·권한은 적용됨(아래 Part 4). TLS 없음 — 로컬·사내망 전제. 남은 한계는 `docs/security-and-db.md` 7.2.
- 지급 보류 이후 클레임 처리, 미선정 업체 통보는 범위 밖.
- git 저장소 아님(커밋 없음).

---

## 7. 남은 작업

### P5 — 관제 허브 분리 (S-25) — 완료 (2026-10-15)

- `obs-hub/`(:5090) 독립 프로젝트: `POST /events`(eventId·type 필수, 중복 거름), `GET /stream`(SSE, 지난 기록 → 실시간), `GET /events.jsonl`, `GET /agents`, `GET /healthz`(public_url 포함), `GET /`(관제 화면). Agent Card heartbeat로 `agent.online/offline`을 허브가 만든다. 기본 지켜보기 주소 = 다섯 회사 기본 주소(`APP_WATCH_URLS`). 이벤트 기록 `APP_EVENTS_FILE`(재기동 시 비움). 참고 코드의 pull 경로(`/obs/events`)는 새 서버들이 직접 보내므로 뺐다.
- 각 시스템 `obs_hook.py`(5개 모두 **같은 파일** — 고칠 때 5곳 복사): `start(name, agent_url, obs_url)`, `emit()`, `stop()`, `ObservedUpdater`(TaskUpdater 상속, 상태 바뀔 때 `task.state`), `RequestTrace`(request.sent → request.done … | request.error, 상대가 working이면 끝난 것 아님), `card_fetched/failed`(결과가 바뀔 때만).
- 호출 지점: lifespan(`agent.started/stopped`), executor(`task.received`, K-Logistics는 답으로 재개 시 `task.resumed`), 구매사 `remote.py`(call·reply_text·get_task — 수집기의 `tasks/get` 결과가 바뀌면 같은 requestId로 `request.done`), 물류사 `Notifier`(배송 알림 요청), `Outbox`(`outbox.sent/retry/failed`).
- 설정 `A2A_OBS_URL`(각 settings DEFAULTS + `.env.example`, 기본 비움). Settings 필드 `obs_url`은 기본값이 있어 기존 테스트의 `make_settings`는 그대로.
- 테스트: 각 시스템 `tests/fake_hub.py` + `tests/test_obs.py`(허브 없음 no-op, 이벤트 도착, 허브 꺼짐에도 업무 정상), obs-hub 8개.
- 화면(`obs_hub/ui/index.html`)은 참고 obs_ui.html 기반 + `agent.started` 이름 표시, `agent.stopped`, 요청 스킬 표시, taskId로 나중 확인 결과 연결, working이면 막대 계속 늘림, `outbox.*` 기록 표시. 실제 이벤트 42건을 node로 재생해 렌더링 오류 없음 확인(브라우저로 눈으로 본 것은 아님).

### P6 — 회사별 업무 화면 — 완료 (2026-10-15)

설계·결과: `systems/docs/p6-carrier-ui.md`.
- 물류사 4곳 `<패키지>/ui/index.html`(같은 파일 4벌): 견적 요청함·발주 수신함·배송 관리·알림 발송 현황·설정 보기. `GET /` → `/ui`.
- 새 내부 API: `/api/meta`, `/api/quotes`(A·B·C), `/api/bookings`, `/api/shipments/{t}/history`, `/api/stream`. 설정 `APP_UI_ENABLED`, `APP_UI_ACCENT`(회사 색).
- `agent.started`에 `console: "/ui"` → 관제 허브 화면이 업무 화면 링크를 건다.
- 검증: 실제 다섯 서버 + 설치된 Edge를 Playwright(스크래치 패드, `channel="msedge"`)로 구동해 클릭까지 확인. Chrome 확장은 연결되지 않았고, Edge `--screenshot`은 SSE 연결 때문에 끝나지 않는다.
- 발견한 문제(구매사 알림 거부, 문서 11장) — **해결**: 구매사 `learn_tracking`이 그 거래처의 처리 중 발주를 먼저 확인. 인증 켠 실제 연동에서 첫 시도 전송 확인.

- 구매사 화면(`kpw_buyer/ui/index.html`, 설계 `docs/p6-buyer-ui.md`): 운송 요청 목록(할 일 표시) + 상세(견적 비교·질문 답·발주·배송·입고·지급), 새 요청, 거래처, 설정, 관리. 새 API `/api/meta`·`/api/board`·`/api/stream`. 발주·취소·지급은 두 번 눌러 확정.
- 검증 중 고친 것: 거래처 Agent Card 확인(`/api/partners?check=true`)이 거래처 DB 변경 뒤 깨져 있던 것.

원래 계획(참고):

plan_2 7장의 화면을 각 시스템 `<패키지>/ui/index.html`(빌드 도구 없는 HTML+JS)로. 내부 API `/api/*`를 fetch, 실시간 갱신은 `/api/stream`(SSE, sse_starlette 이미 의존성에 있음)을 새로 만든다. `APP_UI_ENABLED=false`면 `/ui` 미등록. 구매사: 운송 요청·견적 비교(질문 답장)·발주·배송 추적(납기 위험)·입고·지급·거래처. 물류사: 견적 요청함·발주 수신함·배송 관리·알림 발송 현황·설정 보기. 화면 상단에 관제 허브 링크.

### Part 4 — 인증·권한·DB — 완료 (2026-10-15)

설계·결과: `systems/docs/security-and-db.md`. 사용자 요청: "Part 4의 로그인, 권한처럼 인증 절차" + "필요한 곳에 간단한 DB" (선택: 회사 사이 키와 사내 로그인 둘 다, DB는 인증 정보·관제 허브 기록·설정과 거래처).
- 파일: 각 시스템 `auth.py`·`a2a_auth.py`(허브 제외)·`permissions.py`·`admin.py`, 화면 로그인·관리 탭, 허브 `store.py`(이벤트 SQLite).
- 역할 — 물류사: viewer/operator/manager/admin, 구매사: viewer/buyer/approver/admin, 허브: viewer/admin.
- 로컬 준비: `dev-env\setup_dev_auth.ps1 [-DbDir …] [-Password …]`. 키 교환 규칙: 물류사 → 구매사 키는 회사 이름 `K정밀웍스`로 발급하고 구매사가 거래처 id로 저장, 구매사 → 물류사 알림 키는 거래처 id로 발급하고 물류사가 `http://127.0.0.1:5010`으로 저장, 허브 수집 키는 시스템 이름으로 발급하고 각 시스템이 `obs`로 저장.
- 검증 중 고친 것: 구매사 CLI 로그인 안 함 traceback, 키 거부(401) 시 구매사 500 → `RemoteRejected`, 허브 `__main__` 옛 설정 이름.
- 남은 한계 → P7-B로 기록(S1~S19). 카드 설명은 재기동 후 반영.

### P7 — 마무리

**인증 현재 수준(결정, 2026-10-15)**: "인증이 된다"까지만 — 파트너 키(받는 쪽 발급·스킬 제한·업무 소유 확인), 사내 로그인·역할별 권한, 감사 기록, 허브 수집 키·로그인. 더 넣지 않고 아래 P7-B에 기록만 남겼다.

**P7-A — dev-env**
- `start_all.ps1`: 옵션 `-NoUi`, `-WithObs`, DB 폴더 지정. 인증이 켜져 있으므로 처음이면 `setup_dev_auth.ps1`을 부르거나 안내.
- `stop_all.ps1`: 포트 기준 종료(사용자의 다른 `uv` 프로세스는 건드리지 않는다).
- `e2e/`: 자기 pyproject를 가진 블랙박스 테스트(서버를 HTTP로만 호출). **인증을 켠 채** 돌린다. 대상 시나리오: S-01, S-03, S-07, S-12, S-18, S-23, S-25~S-27, S-29, S-30, S-31, S-32(물류사 C 포트·공개 주소 변경 후 구매사 거래처 주소만 변경 — `cli partner set`, 키는 거래처 id라 그대로). 모두 화면·허브 없이 통과해야 완료. 인증 시나리오: `docs/security-and-db.md` 8.4.

**P7-B — 인증 세부 사항 (상세·우선순위: `docs/security-and-db.md` 8장)**
- 필수(운영 전): S1 HTTPS, S2 Task 소유 확인(남의 Task `GetTask`·`ListTasks`), S3 받은 키 보관(DPAPI 등), S4 운영 키 교환 절차, S5 첫 관리자·비밀번호 정책(본인 변경·첫 로그인 변경).
- 권장: S6 키 교체·만료, S7 두 사람 승인(고액 발주·지급, Ch19 확장), S8 역할별 한도, S9 세션 관리, S10 요청 횟수 제한, S11 감사 기록 보존·위변조 방지, S12 회사 사이 텍스트는 데이터(Ch20), S13 알림 주소 검증 강화.
- 선택: S14 OAuth2/mTLS, S15 Agent Card 서명, S16 MFA, S17 허브 회사별 보기 범위, S18 허브 사용자 관리 화면, S19 구매사 여럿(견적 키 `(회사, rfq_id)`).

---

## 8. 새 세션 시작 방법

1. 이 문서 → `plan_3.md` 7장(진행 순서) → `plan_2.md`(시나리오) 순서로 읽는다.
2. 상태 확인: `systems\dev-env\check_independence.ps1` (여섯 시스템 모두 6/6이어야 함).
3. 사용자 요청이 "다음 작업 진행"이면 **P7-A(dev-env)**부터, 그다음 사용자와 P7-B(인증 세부)에서 무엇을 할지 정한다: `start_all.ps1`(인증 켬 기본, `-WithObs`, `-NoUi`, DB 폴더 지정 — 처음이면 `setup_dev_auth.ps1`을 먼저 부르거나 안내), `stop_all.ps1`(포트 기준), `e2e/`(로그인·파트너 키를 쓰는 블랙박스 시나리오). 완료 시 `plan_3.md` 7장 표와 각 README, 이 문서를 갱신한다.

[!] P5는 `Desktop\A2A\systems` 사본에서 진행했다. 이 사본 옆 `Desktop\A2A\Agent\a2a_lab\part3_orchestration`에는 `obs/` 참고 코드는 있지만 `plan_2.md`·`plan_3.md`가 없어서, P5는 이 문서 7장 명세대로 진행했고 **`plan_3.md` 7장 완료 기록은 갱신하지 못했다.** 원본 `a2a_lab`에서 이어 갈 때 plan_3 7장에 P5 완료를 적을 것.

시작 프롬프트 예: “`a2a_lab/systems/HANDOFF.md`를 읽고 P7(dev-env 마무리)를 진행해줘.”
