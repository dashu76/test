﻿# todolist — plan_3 구현 작업 목록

기준 문서: [plan_3.md](plan_3.md) (기능·시나리오는 [plan_2.md](plan_2.md))

## 진행 규칙

- 작업 하나를 끝내면 즉시 `[ ]`를 `[x]`로 바꾸고 맨 아래 **진행 기록**에 한 줄을 남긴다.
- 단계(Q0~Q6)의 마지막 항목은 **완료 기준 검증**이다. 이 항목이 통과해야 다음 단계로 간다.
- 막힌 작업은 `[!]`로 표시하고 사유를 항목 아래에 적는다.
- 진행 중인 작업은 `[~]`로 표시한다. 동시에 `[~]`는 1개만 둔다.
- 범례: `[ ]` 대기 · `[~]` 진행 중 · `[x]` 완료 · `[!]` 막힘

## 전체 현황

| 단계 | 내용 | 상태 |
|---|---|---|
| Q0 | 준비: legacy 이동, 허브 분리, 환경 확인 | [x] (빈 폴더 2개 잔존) |
| Q1 | contracts 문서 작성 | [x] |
| Q2 | 물류사 뼈대 `carrier_klogistics` 완성 | [x] |
| Q3 | 물류사 A·B·C·D 복제 | [x] |
| Q4 | 구매사 `buyer_kjm` 구현 | [x] |
| Q5 | 인증 적용 및 secrets 분리 | [x] |
| Q6 | e2e 시나리오·독립성 검증 | [x] |

---

## Q0. 준비

- [x] Q0-1 현재 상태 백업 (폴더 전체 압축 또는 복사본 1개)
- [x] Q0-2 `legacy/` 생성 후 `server/`, `ch13_*`~`ch17_*`를 이동
  - `server/`, `ch14_delegation/`는 파일만 이동됐고 빈 폴더가 남아 있다(다른 프로그램이 폴더를 잡고 있어 삭제 불가). 해당 터미널/탭을 닫은 뒤 직접 삭제하면 된다
- [x] Q0-3 기존 `obs/`(관찰 코드 `obs.py`, `obs_run.py` 포함)를 `legacy/obs/`로 이동
- [x] Q0-4 `obs_hub/` 신설: 허브(`obs_hub.py`)와 UI(`obs_ui.html`)를 복사하고 독립 `pyproject.toml`·`run.ps1` 작성
- [x] Q0-5 `legacy/` 이동 후 import 경로가 깨지지 않는지 확인 (`legacy/server`에서 서버 1개 기동)
- [x] Q0-6 a2a-sdk에서 Agent Card 서명(`signatures`)·보안 스킴(`security_schemes`) 지원 범위 확인
- [x] Q0-7 서명 방식 확정 (SDK 지원 / 별도 `agent-card.sig` 파일) 후 plan_3에 기록
  - 결정: SDK의 `a2a.utils.signing`(`create_agent_card_signer`/`create_signature_verifier`, JWS)을 사용한다. 각 회사 `pyproject.toml`에 `pyjwt[crypto]`를 추가한다
- [x] Q0-8 `.gitignore` 공통 규칙 정리 (`secrets/`, `data/`, `.env`, `.venv/`)
- [x] Q0-9 **검증:** `legacy/` 실습 1건과 `obs_hub`(8000)가 각각 단독 기동된다

## Q1. contracts (문서만)

- [x] Q1-1 `contracts/README.md` (계약 버전 규칙: 파일명 `v1`, 깨지면 `v2` 신설)
- [x] Q1-2 `contracts/skills.md` — 스킬별 입력·출력·오류: `quote`, `accept-shipment`, `check-delivery`, `cancel-shipment`, `compare-quotes`, `route-delivery-inquiry`
- [x] Q1-3 `contracts/quote.v1.schema.json` — `carrier`, `price_krw`, `eta_days`, `order`, `valid_until`
- [x] Q1-4 `contracts/shipment.v1.schema.json` — 수주 요청·상태(출고/통관/배송중/도착/보류/취소). 수주 요청은 `shipment_request.v1.schema.json`으로 분리
- [x] Q1-5 `contracts/auth.md` — `X-A2A-Key` 헤더, 스킬별 scope, 카드 서명 방식
- [x] Q1-6 계약 예제 JSON(정상·불일치)을 `contracts/examples/`에 추가
- [x] Q1-7 **검증:** 예제 JSON이 스키마 검증을 통과/실패하는지 확인한다

## Q2. 물류사 뼈대 `carrier_klogistics/` (:8020)

### 프로젝트 기반
- [x] Q2-1 폴더·`pyproject.toml`(a2a-sdk 1.1.2, fastapi, uvicorn, httpx, jinja2, pyyaml, jsonschema)·`.python-version`·`uv sync`
- [x] Q2-2 `config.yaml`, `.env.example`, `app/settings.py` (포트, `public_url`, `obs_url`, DB 경로)
- [x] Q2-3 `run.ps1`, `run.sh`, `README.md`, `.gitignore`

### kit (복사본으로 유지할 공통 기능)
- [x] Q2-4 `app/kit/task_store.py` — SQLite 기반 TaskStore (InMemory 대체)
- [x] Q2-5 `app/kit/idempotency.py` — 업무 키 중복 방지
- [x] Q2-6 `app/kit/outbox.py` — 전송 실패 재시도 큐
- [x] Q2-7 `app/kit/obs_emit.py` — 이벤트 발행 (`obs_url` 없으면 무동작, 허브 오류 무시)
- [x] Q2-8 `app/kit/partners.py` — `partners.yaml` 로더 + Agent Card 발견·캐시
- [x] Q2-9 `app/kit/a2a_server.py` — 카드·핸들러·라우트 조립 (`public_url`에서 카드 주소 생성)
- [x] Q2-10 `app/kit/web.py` — 템플릿 렌더링·정적 파일 공통
- [x] Q2-11 `app/kit/VERSION` 작성 (1.0.0)

### 업무 계층
- [x] Q2-12 `db/schema.sql`: `shipments`, `rate_table`, `status_log`. 중복 방지는 `shipments.business_key UNIQUE` + kit의 `idempotency` 테이블로 처리(별도 `received` 테이블 대신)
- [x] Q2-13 `db/seed.sql`: 요금표·샘플 수주
- [x] Q2-14 `app/domain/`: 견적 계산, 수주 수락·거절, 상태 전이, 취소(출고 전만)
- [x] Q2-15 `app/agent.py`: `quote`, `check-delivery`, `accept-shipment`, `cancel-shipment` 스킬 구현
- [x] Q2-16 `check-delivery`가 없는 주문번호에 "조회 결과 없음"(업무 결과)을 돌려주도록 구현
- [x] Q2-17 `app/api.py`: 요금표 조회·수정, 수주 목록, 수락·거절, 상태 갱신 API

### UI
- [x] Q2-18 `web/shipments.html` — 수주 목록, 상태 갱신, 출고 전 취소 버튼. (수락·거절은 규칙으로 자동 처리: 모르는 구간·수량 초과는 거절. 수동 수락 모드는 필요해지면 추가)
- [x] Q2-19 `web/rates.html` — 요금표 조회·수정
- [x] Q2-20 `web/static/` JS·CSS (`obs_ui.html`과 같은 방식: 서버 렌더링 + 가벼운 JS)

### 테스트·검증
- [x] Q2-21 `tests/test_domain.py` (견적 계산, 상태 전이, 중복 수주)
- [x] Q2-22 `tests/test_contract.py` (복사한 스키마로 `quote` 응답 검증)
- [x] Q2-23 **검증 V1:** 폴더만 빈 디렉터리에 복사해 `uv sync` → 기동 → UI·A2A 호출 성공
- [x] Q2-24 **검증 V7:** 이 폴더의 `tests/`만 단독으로 통과
- [x] Q2-25 UI에서 바꾼 상태가 A2A `check-delivery`에 반영되는지 확인

## Q3. 물류사 A·B·C·D 복제

- [x] Q3-1 `carrier_klogistics`를 `carrier_a`로 복사 → `config.yaml`(8031)·이름·요금표 수정
- [x] Q3-2 `carrier_b` (8032) 생성·수정
- [x] Q3-3 `carrier_c` (8033) 생성·수정 (응답 지연을 실험할 수 있도록 `config.yaml`에 `simulate_delay_s` 옵션)
- [x] Q3-4 `carrier_d_mismatch` (8034) — 필드 이름을 바꿔 응답하는 `contract_mode: mismatch` 옵션
- [x] Q3-5 각 폴더의 카드 이름·skills·`secrets/`·DB 경로가 서로 겹치지 않는지 확인
- [x] Q3-6 **검증:** 5개 물류사가 각자 단독 기동되고 서로 다른 견적을 돌려준다

## Q4. 구매사 `buyer_kjm/` (:8010)

### 프로젝트 기반
- [x] Q4-1 폴더·`pyproject.toml`·`config.yaml`·`run.ps1`·`README.md` (물류사 뼈대와 같은 구성)
- [x] Q4-2 `app/kit/` 복사 (Q2의 kit 복사본, VERSION 동일)
- [x] Q4-3 `partners.yaml` — 물류사 5곳의 주소·허용 스킬 (공개키는 Q5에서 채움). 포트: K-Logistics 8020, A 8031, B 8032, C 8033, D 8034

### 업무 계층
- [x] Q4-4 `db/schema.sql`: `orders`, `quotes`, `partners`, `outbox`
- [x] Q4-5 `app/domain/`: 주문 상태 전이 (`DRAFT → REQUESTED → QUOTED → CONFIRM_PENDING → CONFIRMED → IN_TRANSIT → DELIVERED`, 분기 `CANCELED`)
- [x] Q4-6 `app/domain/policy.py`: 제한 시간(2초)·계약 검증·납기 판단 (기존 `parallel_policy.py` 이식)
- [x] Q4-7 `app/agent.py`: 견적 동시 요청(`asyncio.gather`) + 부분 실패 처리 (S2-0~S2-6)
- [x] Q4-8 견적 비교·추천(납기 충족 중 최저가), 납기 초과는 선택 불가 처리 (S4-1~S4-4)
- [x] Q4-9 확정 요청 전송 + 멱등성(`orderNo+carrier`) + 아웃박스 재시도 (S3-0~S3-4)
- [x] Q4-10 배송 조회 + 마지막 상태 캐시 (S5-1~S5-5)
- [x] Q4-11 취소 요청 처리: 출고 전 허용 / 출고 후 거절 (S5-6, S5-7)
- [x] Q4-12 `app/api.py`: 주문 등록·견적 요청·비교표·확정·조회·취소 API

### UI
- [x] Q4-13 `web/orders.html` — 주문 목록·등록, 상태 배지
- [x] Q4-14 `web/quotes.html` — 견적 비교표(제외 사유 표시), 확정 버튼, 다시 요청 버튼
- [x] Q4-15 `web/tracking.html` — 주문번호 조회, 상태 타임라인, 갱신 시각
- [x] Q4-16 `INPUT_REQUIRED` 질문 표시 및 같은 Task로 답 전송 UI (S2-6). 입력은 간단히 브라우저 입력창(prompt)으로 받는다. 이 과정에서 재개한 Task의 첫 스냅샷에서 멈추던 a2a_client 결함을 고쳤다

### 테스트·검증
- [x] Q4-17 `tests/test_domain.py`, `tests/test_policy.py`
- [x] Q4-18 **검증 V3:** 물류사 1곳을 끈 채로 견적·확정이 진행된다
- [x] Q4-19 **검증 V5:** 물류사 A를 다른 포트로 옮기고 `partners.yaml` 한 줄만 바꿔도 동작한다
- [x] Q4-20 **검증:** 정상 경로(S1)를 UI만으로 끝까지 수행한다 (허브 없이)

## Q5. 인증 적용 · secrets 분리

- [x] Q5-1 `dev/gen_keys.ps1`(또는 `.py`): 회사별 Ed25519 키쌍·API 키를 생성해 각 폴더 `secrets/`로 배치
- [x] Q5-2 `app/kit/auth.py`: `X-A2A-Key` 검사 + 키별 허용 스킬(scope) 적용
- [x] Q5-3 `app/kit/card_signing.py`: Agent Card 서명 생성·검증 (Q0-7에서 확정한 방식)
- [x] Q5-4 호출 측: `secrets/peer_keys.json`의 키를 요청 헤더에 부착
- [x] Q5-5 수신 측: `secrets/api_keys.json`으로 검사하고 scope 밖 스킬은 거절
- [x] Q5-6 구매사 `partners.yaml`에 물류사 공개키를 반영하고 카드 서명 불일치 시 호출하지 않도록 구현 (S2-4)
- [x] Q5-7 모든 폴더의 `.gitignore`에 `secrets/` 확인, 키가 코드·로그에 출력되지 않는지 확인
- [x] Q5-8 `tests/test_auth.py` (키 없음·틀림·scope 밖·서명 불일치)
- [x] Q5-9 **검증 V6:** 각 폴더 `secrets/`에 다른 회사의 비밀키가 없다

## Q6. e2e 시나리오 · 독립성 검증

- [x] Q6-1 `dev/run_all.ps1`, `dev/stop_all.ps1` (각 폴더의 `run.ps1`을 순서대로 호출할 뿐이다), `-WithHub` 옵션
- [x] Q6-2 `dev/seed_all.ps1` (+ `dev/seed_demo.py`, `-Reset`으로 데이터 초기화)
- [x] Q6-3 `dev/e2e/test_scenarios.py`: HTTP·A2A로만 접근해 S1~S6 시나리오 실행 (회사 코드 import 금지)
- [x] Q6-4 `dev/e2e/test_no_hub.py`: 허브 없이 S1~S5 정상 경로 통과 (V4)
- [x] Q6-5 독립성 검사 스크립트: 다른 회사 폴더 참조 검색 (`import buyer_kjm`, `..\carrier_` 등) → 0건 (V2)
- [x] Q6-6 V1: 각 회사 폴더를 빈 디렉터리로 복사해 단독 기동
- [x] Q6-7 V5: 물류사 A를 옮긴 상황 재현 (수동 확인 + e2e `test_s6_move_carrier_to_new_address_with_one_line_change`)
- [x] Q6-8 루트 `README.md` 갱신 (폴더 안내, 포트 표, 실행 순서)
- [x] Q6-9 **최종 검증:** V1~V7 전부 통과, plan_2의 시나리오 표(S1~S6) 항목별 결과를 이 문서에 기록

---

## 진행 기록

| 일시 | 작업 | 메모 |
|---|---|---|
| 2026-10-15 | todolist.md 작성 | 아직 구현 시작 전 |
| 2026-10-15 | Q0 완료 | legacy 이동, obs_hub 독립(자체 venv로 8000 기동 확인), legacy 서버 기동 확인, SDK 서명 지원 확인 |
| 2026-10-15 | Q1 완료 | contracts 문서·스키마 3종·예제 7개 작성, 예제 검증 7건 통과(jsonschema) |
| 2026-10-15 | Q2 완료 | carrier_klogistics: kit·도메인·API·UI·A2A 4스킬 구현. pytest 25건 통과, A2A 호출 11건(정상·예외) 확인, 폴더 단독 복사 기동(V1) 확인, 재시작 후 데이터·Task 유지 확인. 스킬 선택은 message.metadata.skill 규약(contracts/skills.md 반영) |
| 2026-10-15 | Q3 완료 | carrier_a(8031)·b(8032)·c(8033)·d_mismatch(8034) 생성. 각 폴더 pytest 25건 통과. 서울→부산 20개 견적: K-Logistics 42,000/3일, A 42,000/3일, B 39,500/4일, C 45,000/2일, D는 필드명이 다른 응답 |
| 2026-10-15 | Q4 완료 | buyer_kjm 구현(주문 서비스·정책·아웃박스·UI·A2A 2스킬). pytest 36건 통과. 통합(dev/e2e) 12건 통과: 허브 없이 S1~S6 주요 시나리오(일부 물류사 다운, 계약 불일치, 납기, 추가 정보, 확정 중 장애→자동 확정, 거절, 취소, 보류 경고, 재시작 복구). V5(물류사 A를 8931로 옮기고 partners.yaml 한 줄만 수정) 통과. 허브 연동 확인(6개 에이전트·이벤트 수집). 부수 개선: kit에 connect 타임아웃, outbox reset/get/cancel, dev/run_all·stop_all 추가 |
| 2026-10-15 | Q5 완료 | API 키(X-A2A-Key, 호출자별 scope, 401/403) + Agent Card 서명(JWS EdDSA, SDK signing) 적용. kit에 auth.py·card_signing.py 추가, 구매사 net.py가 키 부착·카드 서명 검증·AUTH 판정. dev/gen_keys.py(.ps1)·dev/check_independence.py 추가. 단위 테스트 각 폴더에 test_auth.py(12건 추가, 물류사 37건·구매사 48건 통과), 통합 test_auth 7건 포함 e2e 19건 통과, V2·V6 통과, 키 문자열이 로그·코드에 노출되지 않음 확인 |
| 2026-10-15 | Q6 완료 | dev/e2e 22건 통과(허브 없이 · 허브가 도중에 꺼져도 · 물류사 주소 이전 포함), dev/check_standalone.ps1(V1·V7) 6개 폴더 통과, dev/check_independence.py(V2·V6) 통과, 루트 README 갱신 |

---

## 최종 검증 결과

### 독립성 검사 (plan_3 7절)

| # | 검사 | 결과 | 근거 |
|---|---|---|---|
| V1 | 회사 폴더만 빈 디렉터리에 복사해 환경 구성·기동 | 통과 (6개 폴더) | `dev/check_standalone.ps1` |
| V2 | 다른 회사 폴더 참조 | 0건 | `dev/check_independence.py` |
| V3 | 한 회사를 끄고 나머지 기동 | 통과 | e2e `test_s2_partner_down_does_not_block` |
| V4 | 허브 없이 전체 업무 | 통과 (처음부터 없는 경우, 도중에 꺼지는 경우) | e2e `test_no_hub.py` |
| V5 | 물류사를 다른 포트로 옮기고 `partners.yaml` 한 줄만 수정 | 통과 | e2e `test_s6_move_carrier_...` |
| V6 | secrets에 다른 회사의 비밀키가 없음 | 통과 | `dev/check_independence.py` |
| V7 | 각 폴더 `tests/`만 단독 실행 | 통과 (물류사 37건·구매사 48건) | `check_standalone.ps1` |

### 업무 시나리오 (plan_2 3절) — 어디서 검증했는가

`E` = 서버를 실제로 띄운 통합 테스트(dev/e2e), `U` = 폴더별 단위 테스트(가짜 상대 사용)

| ID | 결과 | 검증 |
|---|---|---|
| S1-1 ~ S1-3 등록·중복 요청 | 통과 | U + E |
| S2-0 ~ S2-1 전원 정상·일부 다운 | 통과 | U + E |
| S2-2 응답 시간 초과 | 통과 | U만 (실제 지연 서버를 띄운 통합 테스트는 없음) |
| S2-3 계약 불일치 | 통과 | U + E |
| S2-4 인증 실패(키·카드 서명) | 통과 | U + E |
| S2-5 전원 실패 | 통과 | U만 |
| S2-6 추가 정보 요청 → 같은 Task로 답변 | 통과 | U + E |
| S4-1 ~ S4-3 추천·납기 초과·견적 만료 | 통과 | U + E(S4-3은 U만) |
| S4-4 추천 외 업체 선택 | 부분 | 선택은 가능, **선택 사유 기록은 구현하지 않음** |
| S3-0 ~ S3-3 수락·중복 확정·물류사 다운·거절 | 통과 | U + E |
| S3-4 재시도 한도 초과 알림·수동 재시도 | 통과 | U만 |
| S5-1 ~ S5-5 상태 갱신·조회·없는 주문·다운 중 조회·보류 알림 | 통과 | U + E |
| S5-6 ~ S5-7 출고 전 취소 허용 / 출고 후 거절 | 통과 | U + E |
| S6-1 허브 없이 실행 | 통과 | E |
| S6-2 새 물류사 참여 | 구조상 지원 | `partners.yaml` 항목 추가만으로 가능하지만, 신규 회사를 추가하는 자동 테스트는 없음 |
| S6-3 물류사 주소 변경 | 통과 | E |
| S6-4 재시작 후 복구 | 통과 | E |
| S6-5 허브 재시작·중단 | 통과 | E |

### 알려진 한계

- 화면(HTML)은 서버 응답과 렌더링까지만 확인했다. 브라우저에서의 버튼 동작(JS)은 자동 테스트가 없고, 이 PC에 node가 없어 문법 검사도 하지 못했다.
- 물류사의 수락은 규칙 기반 자동 처리다(수동 수락 모드 없음).
- 키는 개발용 로컬 키다. 운영에서는 HTTPS와 실제 키가 필요하다.
- UI·업무 API는 A2A 키 대상이 아니다(사내 로그인·네트워크 제한 전제).
