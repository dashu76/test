# 파일명: check_install.py
import a2a
from a2a.utils.constants import PROTOCOL_VERSION_CURRENT

print("a2a 패키지 위치:", a2a.__file__)
print("구현 프로토콜 버전:", PROTOCOL_VERSION_CURRENT)
