INSERT OR IGNORE INTO rate_table(origin, dest, base_krw, per_unit_krw, eta_days) VALUES
    ('서울', '부산', 29000, 600, 4),
    ('서울', '대전', 17000, 400, 3),
    ('서울', '광주', 25000, 550, 4),
    ('인천', '부산', 33000, 650, 5);
