INSERT OR IGNORE INTO rate_table(origin, dest, base_krw, per_unit_krw, eta_days) VALUES
    ('서울', '부산', 33000, 600, 2),
    ('서울', '대전', 21000, 450, 1),
    ('서울', '광주', 29000, 600, 2),
    ('인천', '부산', 37000, 700, 3);
