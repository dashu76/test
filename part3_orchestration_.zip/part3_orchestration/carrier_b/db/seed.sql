INSERT OR IGNORE INTO rate_table(origin, dest, base_krw, per_unit_krw, eta_days) VALUES
    ('서울', '부산', 27500, 600, 4),
    ('서울', '대전', 16000, 380, 3),
    ('서울', '광주', 24000, 520, 4),
    ('인천', '부산', 31000, 620, 5);
