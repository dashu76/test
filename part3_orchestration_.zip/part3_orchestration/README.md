# Part 3 — 여러 에이전트 오케스트레이션 → 회사별 업무 시스템

기존 실습(Ch13~17)은 `legacy/`에 그대로 있고, 이 폴더의 나머지는 **회사마다 완전히 독립된 서버**로 만든 업무 시스템이다.
구매사가 주문을 내고 여러 물류사의 견적을 받아 비교·확정·추적하는 흐름을 각 회사의 화면으로 쓸 수 있고, 회사 사이는 A2A(+API 키·카드 서명)로만 연결된다. 관제 허브는 선택 사항이다.

설계 문서: [plan_2.md](plan_2.md)(업무 시나리오) · [plan_3.md](plan_3.md)(독립 구조) · 진행 기록: [todolist.md](todolist.md)

## 폴더

```text
part3_orchestration/
├── buyer_kjm/            K정밀웍스 (구매사)        :8010   UI · 업무 API · A2A · 자기 DB
├── carrier_klogistics/   K-Logistics (물류사)      :8020   〃
├── carrier_a/ b/ c/      물류사 A · B · C          :8031 · 8032 · 8033   (같은 뼈대, 설정·요금표만 다름)
├── carrier_d_mismatch/   계약 불일치 실험용 물류사   :8034   (견적 응답의 필드 이름이 다르다)
├── obs_hub/              관제 허브 (선택)          :8000
├── contracts/            회사 간 약속 (문서·스키마만, 코드 아님)
├── dev/                  개발 편의: 전체 기동·키 생성·통합 테스트·독립성 검사 (지워도 각 회사는 동작)
└── legacy/               기존 실습 Ch13~17 (수정하지 않음)
```

각 회사 폴더는 자기 `pyproject.toml`·가상환경·`config.yaml`·`partners.yaml`·`secrets/`·`data/`·`tests/`를 가진 독립 프로젝트다. 폴더 하나만 다른 서버로 옮겨도 실행되고, 회사 폴더끼리 코드를 import하지 않는다.
공통 기능은 각 폴더 `app/kit/`에 복사본으로 들어 있다(`VERSION` 참고).

## 빠른 시작

```powershell
./dev/gen_keys.ps1          # 개발용 키 생성 (이미 있으면 유지)
./dev/run_all.ps1           # 회사 서버 6개 기동 (허브 없이)   ← 관제도 함께 보려면 -WithHub
./dev/seed_all.ps1          # (선택) 데모 주문 채우기. 처음부터 다시: -Reset
./dev/stop_all.ps1          # 모두 종료
```

처음 한 번은 회사 폴더마다 환경을 만든다: 각 폴더에서 `uv sync` (또는 `run.ps1`이 처음 실행 때 만든다).

| 화면 | 주소 |
|---|---|
| 구매사 (주문·견적 비교·배송 추적) | http://127.0.0.1:8010 |
| K-Logistics · 물류사 A · B · C (수주·상태 갱신·요금표) | http://127.0.0.1:8020 · 8031 · 8032 · 8033 |
| 관제 허브 (`-WithHub`일 때) | http://127.0.0.1:8000 |

한 회사만 띄우려면 그 폴더에서 `./run.ps1`. 서버 로그는 `dev/logs/`.

## 업무 흐름

1. **구매사**에서 주문 등록 → "견적 요청": 모든 물류사에 동시에 묻는다. 느리거나 꺼졌거나 계약과 다른 응답은 사유와 함께 제외된다.
2. 납기를 맞춘 견적 중 최저가가 추천된다. 업체를 골라 **확정**하면 물류사에 수주가 생긴다 (중복 클릭·일시 장애에도 한 번만 처리, 물류사가 꺼져 있으면 자동 재전송).
3. **물류사** 화면에서 출고·통관·배송 중·도착으로 상태를 바꾸면, 구매사의 **배송 추적**에 반영된다. 출고 전에는 취소할 수 있다.

## 확인·테스트

| 무엇을 | 명령 | 결과(기록 시점) |
|---|---|---|
| 회사별 단위·계약·인증 테스트 | 각 폴더에서 `uv run pytest` | 물류사 37건 · 구매사 48건 통과 |
| 통합 테스트 (서버를 실제로 띄움) | `uv run --no-project --with pytest --with httpx pytest dev/e2e -v` | 22건 통과 (허브 없이, 인증 켠 상태) |
| 회사 폴더 단독 기동 (V1·V7) | `./dev/check_standalone.ps1` | 6개 폴더 모두 통과 |
| 독립성·비밀 분리 (V2·V6) | `uv run --no-project --with cryptography python dev/check_independence.py` | 통과 |

## 인증

회사 간 호출은 `X-A2A-Key` 헤더의 API 키(호출자별 허용 스킬 scope)와 Agent Card 서명(EdDSA)으로 보호한다. 지금은 `dev/gen_keys.ps1`이 만든 로컬 키를 쓰며, 운영에서는 같은 위치에 실제 키를 놓는다. 자세한 규칙은 [contracts/auth.md](contracts/auth.md).

## 기존 실습 (legacy)

Ch13~17 실습 코드와 안내는 [legacy/README.md](legacy/README.md).