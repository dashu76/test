CREATE TABLE IF NOT EXISTS rate_table (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    origin TEXT NOT NULL,
    dest TEXT NOT NULL,
    base_krw INTEGER NOT NULL,
    per_unit_krw INTEGER NOT NULL,
    eta_days INTEGER NOT NULL,
    UNIQUE (origin, dest)
);

CREATE TABLE IF NOT EXISTS shipments (
    order_no TEXT PRIMARY KEY,
    business_key TEXT NOT NULL UNIQUE,
    buyer TEXT NOT NULL DEFAULT '',
    item TEXT NOT NULL,
    qty INTEGER NOT NULL,
    origin TEXT NOT NULL,
    dest TEXT NOT NULL,
    price_krw INTEGER NOT NULL,
    status TEXT NOT NULL,
    held_from TEXT NOT NULL DEFAULT '',
    eta TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS status_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no TEXT NOT NULL,
    status TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    at TEXT NOT NULL
);
