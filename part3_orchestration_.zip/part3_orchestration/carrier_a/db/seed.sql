INSERT OR IGNORE INTO rate_table(origin, dest, base_krw, per_unit_krw, eta_days) VALUES
    ('서울', '부산', 30000, 600, 3),
    ('서울', '대전', 18000, 400, 2),
    ('서울', '광주', 26000, 550, 3),
    ('인천', '부산', 34000, 650, 4);
