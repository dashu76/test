import pytest

from app.domain import quote, rates, shipments
from app.kit.a2a_server import NeedInput
from tests.conftest import accept_request


def test_quote_uses_rate_table(db, cfg):
    q = quote.make_quote(db, cfg, {"order_no": "ORDER-1", "qty": 20, "origin": "서울", "dest": "부산"})
    rate = rates.find_rate(db, "서울", "부산")
    assert q["price_krw"] == rate["base_krw"] + rate["per_unit_krw"] * 20
    assert q["eta_days"] == rate["eta_days"] and q["carrier"] == cfg["display_name"]


def test_quote_changes_when_rate_changes(db, cfg):
    rates.upsert_rate(db, "서울", "부산", 10000, 100, 5)
    q = quote.make_quote(db, cfg, {"order_no": "ORDER-1", "qty": 10, "origin": "서울", "dest": "부산"})
    assert (q["price_krw"], q["eta_days"]) == (11000, 5)


@pytest.mark.parametrize("payload", [
    {"order_no": "1", "qty": 1, "origin": "서울", "dest": "부산"},
    {"order_no": "ORDER-1", "qty": 0, "origin": "서울", "dest": "부산"},
    {"order_no": "ORDER-1", "qty": 1, "origin": "서울", "dest": "제주"},
])
def test_quote_asks_for_input_when_unusable(db, cfg, payload):
    with pytest.raises(NeedInput):
        quote.make_quote(db, cfg, payload)


def test_accept_creates_one_shipment_even_if_repeated(db, idem, cfg):
    req = accept_request()
    first = shipments.accept(db, idem, cfg, req)
    second = shipments.accept(db, idem, cfg, req)
    assert first == second and first["status"] == "ACCEPTED"
    assert db.one("SELECT COUNT(*) AS n FROM shipments WHERE order_no='ORDER-3001'")["n"] == 1


def test_accept_rejects_unknown_route_and_too_many(db, idem, cfg):
    assert shipments.accept(db, idem, cfg, accept_request("ORDER-3002", dest="제주"))["status"] == "REJECTED"
    assert shipments.accept(db, idem, cfg, accept_request("ORDER-3003", qty=501))["status"] == "REJECTED"
    assert shipments.get(db, "ORDER-3002") is None  # 거절은 수주로 남지 않는다


def test_accept_rejects_order_number_taken_by_another_key(db, idem, cfg):
    shipments.accept(db, idem, cfg, accept_request("ORDER-3004"))
    other = {**accept_request("ORDER-3004"), "business_key": "ORDER-3004:other"}
    assert shipments.accept(db, idem, cfg, other)["status"] == "REJECTED"


def test_accept_requires_business_key(db, idem, cfg):
    with pytest.raises(shipments.RuleError):
        shipments.accept(db, idem, cfg, {**accept_request(), "business_key": ""})


def test_check_delivery_not_found_is_a_result_not_an_error(db, idem, cfg):
    assert shipments.check_delivery(db, "ORDER-9999") == {"order_no": "ORDER-9999", "found": False}
    shipments.accept(db, idem, cfg, accept_request())
    assert shipments.check_delivery(db, "ORDER-3001")["status"] == "ACCEPTED"


def test_status_must_move_forward(db, idem, cfg):
    shipments.accept(db, idem, cfg, accept_request())
    assert shipments.set_status(db, "ORDER-3001", "DISPATCHED")["status"] == "DISPATCHED"
    with pytest.raises(shipments.RuleError):
        shipments.set_status(db, "ORDER-3001", "ACCEPTED")
    shipments.set_status(db, "ORDER-3001", "DELIVERED")
    with pytest.raises(shipments.RuleError):  # 종료 후에는 변경 불가
        shipments.set_status(db, "ORDER-3001", "ON_HOLD")


def test_hold_and_resume(db, idem, cfg):
    shipments.accept(db, idem, cfg, accept_request())
    shipments.set_status(db, "ORDER-3001", "CUSTOMS")
    held = shipments.set_status(db, "ORDER-3001", "ON_HOLD", "서류 보완")
    assert held["status"] == "ON_HOLD" and held["reason"] == "서류 보완"
    with pytest.raises(shipments.RuleError):  # 보류 전 단계(통관)로는 되돌아갈 수 없다
        shipments.set_status(db, "ORDER-3001", "DISPATCHED")
    resumed = shipments.set_status(db, "ORDER-3001", "IN_TRANSIT")
    assert resumed["status"] == "IN_TRANSIT" and "reason" not in resumed


def test_cancel_only_before_dispatch(db, idem, cfg):
    shipments.accept(db, idem, cfg, accept_request())
    assert shipments.cancel(db, "ORDER-3001")["status"] == "CANCELED"
    assert shipments.cancel(db, "ORDER-3001")["reason"]  # 이미 취소됨
    shipments.accept(db, idem, cfg, accept_request("ORDER-3005"))
    shipments.set_status(db, "ORDER-3005", "DISPATCHED")
    refused = shipments.cancel(db, "ORDER-3005")
    assert refused["status"] == "DISPATCHED" and "출고" in refused["reason"]
    assert shipments.cancel(db, "ORDER-9999")["found"] is False


def test_history_records_each_change(db, idem, cfg):
    shipments.accept(db, idem, cfg, accept_request())
    shipments.set_status(db, "ORDER-3001", "DISPATCHED")
    assert [h["status"] for h in shipments.history(db, "ORDER-3001")] == ["ACCEPTED", "DISPATCHED"]
