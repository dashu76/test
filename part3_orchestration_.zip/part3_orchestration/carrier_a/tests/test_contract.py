"""contracts/의 스키마(tests/contracts/에 복사해 둔 것)를 이 회사의 실제 응답이 만족하는지 검사한다."""

import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from app.domain import quote, shipments
from tests.conftest import accept_request

HERE = Path(__file__).parent / "contracts"


def valid(schema_name: str, data: dict) -> bool:
    schema = json.loads((HERE / f"{schema_name}.schema.json").read_text(encoding="utf-8"))
    return not list(Draft202012Validator(schema).iter_errors(data))


def test_quote_matches_contract(db, cfg):
    q = quote.make_quote(db, cfg, {"order_no": "ORDER-1", "qty": 5, "origin": "서울", "dest": "대전"})
    assert valid("quote.v1", q)


def test_mismatch_mode_breaks_the_contract(db, cfg):
    q = quote.to_mismatch(quote.make_quote(db, cfg, {"order_no": "ORDER-1", "qty": 5, "origin": "서울", "dest": "대전"}))
    assert not valid("quote.v1", q)


def test_accept_request_example_and_responses_match_contract(db, idem, cfg):
    req = accept_request()
    assert valid("shipment_request.v1", req)
    assert valid("shipment.v1", shipments.accept(db, idem, cfg, req))
    assert valid("shipment.v1", shipments.accept(db, idem, cfg, accept_request("ORDER-3002", dest="제주")))  # REJECTED
    assert valid("shipment.v1", shipments.check_delivery(db, "ORDER-9999"))  # found: false
    assert valid("shipment.v1", shipments.check_delivery(db, "ORDER-3001"))
    assert valid("shipment.v1", shipments.cancel(db, "ORDER-3001"))
    shipments.accept(db, idem, cfg, accept_request("ORDER-3009"))
    shipments.set_status(db, "ORDER-3009", "DISPATCHED")
    assert valid("shipment.v1", shipments.cancel(db, "ORDER-3009"))  # 취소 거절


@pytest.mark.parametrize("name, schema, expected", [
    ("quote.ok", "quote.v1", True), ("quote.mismatch", "quote.v1", False),
    ("shipment.ok", "shipment.v1", True), ("shipment.notfound", "shipment.v1", True), ("shipment.bad", "shipment.v1", False),
    ("shipment_request.ok", "shipment_request.v1", True), ("shipment_request.bad", "shipment_request.v1", False),
])
def test_contract_examples(name, schema, expected):
    data = json.loads((HERE / "examples" / f"{name}.json").read_text(encoding="utf-8"))
    assert valid(schema, data) is expected
