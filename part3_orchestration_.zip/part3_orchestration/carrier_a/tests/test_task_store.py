import asyncio

from a2a.server.context import ServerCallContext
from a2a.types.a2a_pb2 import Task, TaskState, TaskStatus

from app.kit.db import Db
from app.kit.task_store import SqliteTaskStore


def test_task_survives_restart(tmp_path):
    path = tmp_path / "t.db"
    ctx = ServerCallContext()
    task = Task(id="t1", context_id="c1", status=TaskStatus(state=TaskState.TASK_STATE_COMPLETED))
    asyncio.run(SqliteTaskStore(Db(path)).save(task, ctx))

    reopened = SqliteTaskStore(Db(path))  # 서버를 다시 켠 것과 같다
    loaded = asyncio.run(reopened.get("t1", ctx))
    assert loaded is not None and loaded.status.state == TaskState.TASK_STATE_COMPLETED
    assert asyncio.run(reopened.get("missing", ctx)) is None
    assert asyncio.run(reopened.list(__import__("a2a.types.a2a_pb2", fromlist=["x"]).ListTasksRequest(context_id="c1"), ctx)).total_size == 1
