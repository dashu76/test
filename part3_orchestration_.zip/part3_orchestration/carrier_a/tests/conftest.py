import pytest

from app.kit.db import Db
from app.kit.idempotency import Idempotency
from app.settings import ROOT

CFG = {"display_name": "K-Logistics", "quote_valid_minutes": 60, "max_qty": 500}


@pytest.fixture
def db(tmp_path):
    database = Db(tmp_path / "test.db")
    database.script((ROOT / "db" / "schema.sql").read_text(encoding="utf-8"))
    database.script((ROOT / "db" / "seed.sql").read_text(encoding="utf-8"))
    return database


@pytest.fixture
def idem(db):
    return Idempotency(db)


@pytest.fixture
def cfg():
    return dict(CFG)


def accept_request(order_no="ORDER-3001", qty=20, dest="부산"):
    return {
        "order_no": order_no, "carrier": "carrier_klogistics", "business_key": f"{order_no}:carrier_klogistics",
        "item": "노트북", "qty": qty, "origin": "서울", "dest": dest,
    }
