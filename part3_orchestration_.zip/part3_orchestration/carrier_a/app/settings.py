"""config.yaml + .env(+환경변수)에서 설정을 읽는다. 코드에는 주소·포트를 두지 않는다."""

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip())


@dataclass
class Settings:
    company_id: str
    name: str
    host: str
    port: int
    public_url: str
    obs_url: str
    db_path: Path
    carrier: dict = field(default_factory=dict)
    auth: dict = field(default_factory=dict)
    root: Path = ROOT


def load_settings(config_path: Path | None = None) -> Settings:
    _load_dotenv(ROOT / ".env")
    path = Path(os.getenv("CONFIG_PATH") or config_path or ROOT / "config.yaml")
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    port = int(os.getenv("PORT", raw["port"]))
    public_url = os.getenv("PUBLIC_URL", raw["public_url"]).rstrip("/")
    db_path = Path(raw["db_path"])
    if os.getenv("DATA_DIR"):  # 통합 테스트에서 실제 데이터와 섞이지 않게 회사별 하위 폴더를 쓴다
        db_path = Path(os.environ["DATA_DIR"]) / raw["company_id"] / db_path.name
    return Settings(
        company_id=raw["company_id"],
        name=raw["name"],
        host=raw.get("host", "127.0.0.1"),
        port=port,
        public_url=public_url,
        obs_url=os.getenv("A2A_OBS_URL", raw.get("obs_url", "")).rstrip("/"),
        db_path=db_path if db_path.is_absolute() else ROOT / db_path,
        carrier=raw.get("carrier", {}),
        auth=raw.get("auth", {}),
    )


def secret_path(settings: Settings, name: str, default: str) -> Path:
    """auth 설정의 파일 경로 (폴더 기준 상대경로). 같은 이름의 대문자 환경변수(예: PEER_KEYS_FILE)가 있으면 그것을 쓴다."""
    override = os.getenv(name.removesuffix("_file").upper() + "_FILE")
    return Path(override) if override else settings.root / settings.auth.get(name, default)
