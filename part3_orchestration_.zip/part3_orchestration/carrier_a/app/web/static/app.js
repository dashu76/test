// 서버 렌더링된 화면에 붙는 가벼운 동작: 버튼 → 이 회사 API 호출 → 화면 다시 불러오기
const toast = (msg) => {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2500);
};

async function call(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || res.statusText);
  return data;
}

const rowValues = (row) => Object.fromEntries([...row.querySelectorAll("input")].map((i) => [i.name, i.value]));

document.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-act]");
  if (!button) return;
  const row = button.closest("tr");
  try {
    switch (button.dataset.act) {
      case "status": {
        const status = row.querySelector("select.next").value;
        const note = status === "ON_HOLD" ? prompt("보류 사유를 입력하세요") ?? "" : "";
        await call("POST", `/api/shipments/${row.dataset.order}/status`, { status, note });
        break;
      }
      case "cancel":
        if (!confirm(`${row.dataset.order} 주문을 취소할까요?`)) return;
        await call("POST", `/api/shipments/${row.dataset.order}/cancel`, {});
        break;
      case "save-rate":
        await call("PUT", "/api/rates", { origin: button.dataset.origin, dest: button.dataset.dest, ...rowValues(row) });
        break;
      case "delete-rate":
        if (!confirm("이 구간 요금을 삭제할까요?")) return;
        await call("DELETE", `/api/rates/${row.dataset.id}`);
        break;
      case "add-rate":
        await call("PUT", "/api/rates", rowValues(row));
        break;
    }
    toast("반영했습니다");
    setTimeout(() => location.reload(), 400);
  } catch (error) {
    toast(error.message);
  }
});

// 수주 목록은 5초마다 새로 고침 (사용자가 선택 중이면 건너뜀)
if (document.querySelector("tr[data-order]")) {
  setInterval(() => {
    if (!document.activeElement || document.activeElement === document.body) location.reload();
  }, 5000);
}
