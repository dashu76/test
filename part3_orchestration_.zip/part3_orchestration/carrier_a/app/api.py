"""이 회사의 업무 API(/api/*)와 화면(/). UI는 이 회사의 API만 부른다."""

from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse

from app.domain import rates, shipments
from app.kit.db import Db


def register(app: FastAPI, db: Db, templates, company_name: str) -> None:
    api = APIRouter(prefix="/api")

    @api.get("/health")
    async def health():
        return {"ok": True}

    @api.get("/shipments")
    async def list_shipments():
        return shipments.list_all(db)

    @api.get("/shipments/{order_no}")
    async def get_shipment(order_no: str):
        row = shipments.get(db, order_no)
        if row is None:
            raise HTTPException(404, "없는 주문입니다")
        return {**row, "history": shipments.history(db, order_no)}

    @api.post("/shipments/{order_no}/status")
    async def set_status(order_no: str, body: dict):
        try:
            return shipments.set_status(db, order_no, str(body.get("status", "")), str(body.get("note", "")))
        except shipments.RuleError as error:
            raise HTTPException(409, str(error)) from error

    @api.post("/shipments/{order_no}/cancel")
    async def cancel(order_no: str, body: dict | None = None):
        result = shipments.cancel(db, order_no, str((body or {}).get("reason", "")))
        if not result["found"]:
            raise HTTPException(404, "없는 주문입니다")
        if result.get("status") != "CANCELED":
            raise HTTPException(409, result.get("reason", "취소할 수 없습니다"))
        return result

    @api.get("/rates")
    async def list_rates():
        return rates.list_rates(db)

    @api.put("/rates")
    async def upsert_rate(body: dict):
        try:
            rates.upsert_rate(
                db, str(body.get("origin", "")), str(body.get("dest", "")),
                int(body.get("base_krw", -1)), int(body.get("per_unit_krw", -1)), int(body.get("eta_days", -1)),
            )
        except (ValueError, TypeError) as error:
            raise HTTPException(422, str(error)) from error
        return {"ok": True}

    @api.delete("/rates/{rate_id}")
    async def delete_rate(rate_id: int):
        if not rates.delete_rate(db, rate_id):
            raise HTTPException(404, "없는 요금입니다")
        return {"ok": True}

    app.include_router(api)

    def page(request: Request, name: str, **ctx):
        return templates.TemplateResponse(request, name, {"company": company_name, "labels": shipments.LABELS, **ctx})

    @app.get("/", response_class=HTMLResponse)
    async def shipments_page(request: Request):
        return page(request, "shipments.html", rows=shipments.list_all(db), active="shipments")

    @app.get("/rates", response_class=HTMLResponse)
    async def rates_page(request: Request):
        return page(request, "rates.html", rows=rates.list_rates(db), active="rates")
