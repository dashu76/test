"""A2A 스킬 구현 (contracts/skills.md). 업무 규칙은 app/domain에 있고, 여기서는 연결만 한다."""

import asyncio
import re

from app.domain import quote as quote_domain
from app.domain import shipments
from app.kit.a2a_server import NeedInput
from app.kit.db import Db
from app.kit.idempotency import Idempotency
from app.settings import Settings

SKILLS = [
    ("quote", "구간·수량으로 운임 견적을 계산해 돌려준다"),
    ("accept-shipment", "확정된 주문을 수주한다 (같은 business_key는 한 번만 처리)"),
    ("check-delivery", "주문번호로 배송 상태를 조회한다"),
    ("cancel-shipment", "출고 전 주문을 취소한다"),
]


class CarrierAgent:
    def __init__(self, db: Db, settings: Settings) -> None:
        self.db = db
        self.cfg = settings.carrier
        self.idem = Idempotency(db)

    async def handle(self, skill: str, payload: dict) -> dict:
        # 스킬을 지정하지 않은 텍스트 요청("ORDER-1001")은 예전 실습 클라이언트와 같은 배송 조회로 본다.
        if not skill and "text" in payload:
            skill, payload = "check-delivery", {"order_no": payload["text"]}
        if skill == "quote":
            await asyncio.sleep(float(self.cfg.get("simulate_delay_s", 0)))
            quote = quote_domain.make_quote(self.db, self.cfg, payload)
            return quote_domain.to_mismatch(quote) if self.cfg.get("contract_mode") == "mismatch" else quote
        if skill == "check-delivery":
            order_no = str(payload.get("order_no", "")).strip()
            return shipments.check_delivery(self.db, order_no)
        if skill == "accept-shipment":
            try:
                return shipments.accept(self.db, self.idem, self.cfg, payload, buyer=str(payload.get("buyer", "")))
            except shipments.RuleError as error:
                raise NeedInput(str(error)) from error
        if skill == "cancel-shipment":
            order_no = str(payload.get("order_no", "")).strip()
            if not re.match(r"^ORDER-[0-9]+$", order_no):
                raise NeedInput("주문번호 형식이 올바르지 않습니다 (예: ORDER-1001)")
            return shipments.cancel(self.db, order_no, str(payload.get("reason", "")))
        raise NeedInput(f"지원하지 않는 스킬입니다: '{skill}' (지원: {', '.join(s for s, _ in SKILLS)})")
