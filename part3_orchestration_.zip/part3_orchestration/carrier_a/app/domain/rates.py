"""요금표. 견적은 이 표로만 계산한다."""

from app.kit.db import Db


def list_rates(db: Db) -> list[dict]:
    return db.all("SELECT * FROM rate_table ORDER BY origin, dest")


def find_rate(db: Db, origin: str, dest: str) -> dict | None:
    return db.one("SELECT * FROM rate_table WHERE origin=? AND dest=?", (origin, dest))


def upsert_rate(db: Db, origin: str, dest: str, base_krw: int, per_unit_krw: int, eta_days: int) -> None:
    if min(base_krw, per_unit_krw, eta_days) < 0:
        raise ValueError("요금과 일수는 0 이상이어야 한다")
    if not origin.strip() or not dest.strip():
        raise ValueError("출발지·도착지가 필요하다")
    db.run(
        "INSERT INTO rate_table(origin, dest, base_krw, per_unit_krw, eta_days) VALUES (?,?,?,?,?) "
        "ON CONFLICT(origin, dest) DO UPDATE SET base_krw=excluded.base_krw, "
        "per_unit_krw=excluded.per_unit_krw, eta_days=excluded.eta_days",
        (origin.strip(), dest.strip(), base_krw, per_unit_krw, eta_days),
    )


def delete_rate(db: Db, rate_id: int) -> bool:
    return db.run("DELETE FROM rate_table WHERE id=?", (rate_id,)) > 0
