"""수주·배송 상태 (contracts/shipment.v1, shipment_request.v1)."""

from datetime import date, timedelta

from app.domain.quote import ORDER_NO, now_iso
from app.domain.rates import find_rate
from app.kit.db import Db
from app.kit.idempotency import Idempotency

FLOW = ["ACCEPTED", "DISPATCHED", "CUSTOMS", "IN_TRANSIT", "DELIVERED"]
FINAL = {"DELIVERED", "REJECTED", "CANCELED"}
LABELS = {
    "ACCEPTED": "수주됨", "DISPATCHED": "출고", "CUSTOMS": "통관", "IN_TRANSIT": "배송 중",
    "DELIVERED": "도착", "ON_HOLD": "보류", "REJECTED": "거절", "CANCELED": "취소",
}


class RuleError(ValueError):
    """업무 규칙 위반 (UI·API가 사유를 그대로 보여 준다)."""


def to_contract(row: dict | None, order_no: str = "") -> dict:
    if row is None:
        return {"order_no": order_no, "found": False}
    out = {"order_no": row["order_no"], "found": True, "status": row["status"], "updated_at": row["updated_at"]}
    if row["eta"]:
        out["eta"] = row["eta"]
    if row["reason"]:
        out["reason"] = row["reason"]
    return out


def get(db: Db, order_no: str) -> dict | None:
    return db.one("SELECT * FROM shipments WHERE order_no=?", (order_no,))


def list_all(db: Db) -> list[dict]:
    return db.all("SELECT * FROM shipments ORDER BY created_at DESC, order_no DESC")


def history(db: Db, order_no: str) -> list[dict]:
    return db.all("SELECT status, note, at FROM status_log WHERE order_no=? ORDER BY id", (order_no,))


def _log(db: Db, order_no: str, status: str, note: str = "") -> None:
    db.run("INSERT INTO status_log(order_no, status, note, at) VALUES (?,?,?,?)", (order_no, status, note, now_iso()))


def check_delivery(db: Db, order_no: str) -> dict:
    """없는 주문은 실패가 아니라 'found: false'라는 업무 결과다."""
    return to_contract(get(db, order_no), order_no)


def accept(db: Db, idem: Idempotency, carrier_cfg: dict, req: dict, buyer: str = "") -> dict:
    """확정(수주) 요청. 같은 business_key는 처음 결과를 그대로 돌려준다."""
    key = str(req.get("business_key", ""))
    order_no = str(req.get("order_no", ""))
    if not ORDER_NO.match(order_no) or not key.startswith(order_no + ":"):
        raise RuleError("order_no와 business_key(order_no:carrier)가 필요합니다")
    with db.transaction():
        done = idem.get(key)
        if done is not None:
            return done
        existing = db.one("SELECT * FROM shipments WHERE business_key=?", (key,))
        if existing is not None:  # 같은 업무 키로 이미 접수된 건 (시드 데이터 등)
            return to_contract(existing)
        result = _decide(db, carrier_cfg, req, order_no, key, buyer)
        idem.put(key, result)
        return result


def _decide(db: Db, carrier_cfg: dict, req: dict, order_no: str, key: str, buyer: str) -> dict:
    qty = int(req.get("qty", 0))
    origin, dest = str(req.get("origin", "")), str(req.get("dest", ""))
    reason = ""
    rate = find_rate(db, origin, dest)
    if get(db, order_no) is not None:
        reason = "이미 접수된 주문번호입니다"
    elif rate is None:
        reason = f"운송할 수 없는 구간입니다 ({origin} → {dest})"
    elif qty > int(carrier_cfg.get("max_qty", 500)):
        reason = f"수량 한도({carrier_cfg.get('max_qty', 500)})를 초과했습니다"
    if reason:
        return {"order_no": order_no, "found": True, "status": "REJECTED", "reason": reason, "updated_at": now_iso()}
    eta = (date.today() + timedelta(days=rate["eta_days"])).isoformat()
    price = int(req.get("agreed_price_krw", rate["base_krw"] + rate["per_unit_krw"] * qty))
    now = now_iso()
    db.run(
        "INSERT INTO shipments(order_no, business_key, buyer, item, qty, origin, dest, price_krw, status, eta, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (order_no, key, buyer, str(req.get("item", "")), qty, origin, dest, price, "ACCEPTED", eta, now, now),
    )
    _log(db, order_no, "ACCEPTED")
    return to_contract(get(db, order_no))


def set_status(db: Db, order_no: str, new_status: str, note: str = "") -> dict:
    """운영자가 상태를 갱신한다. 흐름: 수주됨→출고→통관→배송 중→도착 (보류는 어디서든, 보류 후 복귀 가능)."""
    with db.transaction():
        row = get(db, order_no)
        if row is None:
            raise RuleError(f"{order_no}: 없는 주문입니다")
        current = row["status"]
        if current in FINAL:
            raise RuleError(f"이미 종료된 주문입니다 ({LABELS[current]})")
        held_from = ""
        if new_status == "ON_HOLD":
            if current == "ON_HOLD":
                raise RuleError("이미 보류 상태입니다")
            held_from = current
        elif new_status in FLOW:
            base = row["held_from"] if current == "ON_HOLD" else current
            if FLOW.index(new_status) <= FLOW.index(base):
                raise RuleError(f"{LABELS[base]} 이후 단계로만 변경할 수 있습니다")
        else:
            raise RuleError(f"변경할 수 없는 상태입니다: {new_status}")
        db.run(
            "UPDATE shipments SET status=?, held_from=?, reason=?, updated_at=? WHERE order_no=?",
            (new_status, held_from, note if new_status == "ON_HOLD" else "", now_iso(), order_no),
        )
        _log(db, order_no, new_status, note)
        return to_contract(get(db, order_no))


def cancel(db: Db, order_no: str, reason: str = "") -> dict:
    """출고 전(수주됨)에만 취소할 수 있다. 거절 시 기존 상태와 사유를 돌려준다 (Task는 정상 완료)."""
    with db.transaction():
        row = get(db, order_no)
        if row is None:
            return {"order_no": order_no, "found": False}
        if row["status"] != "ACCEPTED":
            out = to_contract(row)
            out["reason"] = "출고 이후에는 취소할 수 없습니다" if row["status"] != "CANCELED" else "이미 취소된 주문입니다"
            return out
        db.run(
            "UPDATE shipments SET status='CANCELED', reason=?, updated_at=? WHERE order_no=?",
            (reason, now_iso(), order_no),
        )
        _log(db, order_no, "CANCELED", reason)
        return to_contract(get(db, order_no))
