"""견적 계산 (contracts/quote.v1)."""

import re
from datetime import datetime, timedelta, timezone

from app.domain.rates import find_rate
from app.kit.a2a_server import NeedInput
from app.kit.db import Db

ORDER_NO = re.compile(r"^ORDER-[0-9]+$")


def now_iso(delta: timedelta = timedelta()) -> str:
    return (datetime.now(timezone.utc) + delta).strftime("%Y-%m-%dT%H:%M:%SZ")


def make_quote(db: Db, carrier_cfg: dict, payload: dict) -> dict:
    order_no = str(payload.get("order_no", ""))
    if not ORDER_NO.match(order_no):
        raise NeedInput("주문번호 형식이 올바르지 않습니다 (예: ORDER-1001)")
    try:
        qty = int(payload.get("qty", 0))
    except (TypeError, ValueError):
        qty = 0
    if qty < 1:
        raise NeedInput("수량을 1 이상으로 입력해 주세요")
    origin, dest = str(payload.get("origin", "")).strip(), str(payload.get("dest", "")).strip()
    rate = find_rate(db, origin, dest)
    if rate is None:
        raise NeedInput(f"'{origin}' → '{dest}' 구간 요금이 없습니다. 출발지·도착지를 확인해 주세요")
    return {
        "order_no": order_no,
        "carrier": carrier_cfg.get("display_name", "carrier"),
        "price_krw": rate["base_krw"] + rate["per_unit_krw"] * qty,
        "eta_days": rate["eta_days"],
        "valid_until": now_iso(timedelta(minutes=int(carrier_cfg.get("quote_valid_minutes", 60)))),
    }


def to_mismatch(quote: dict) -> dict:
    """계약 불일치 실험용: 필드 이름을 바꿔서 돌려준다 (contracts/examples/quote.mismatch.json)."""
    return {"소요일": quote["eta_days"], "업체": quote["carrier"], "가격": quote["price_krw"], "주문": quote["order_no"]}
