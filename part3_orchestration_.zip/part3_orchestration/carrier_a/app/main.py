"""물류사 서버 진입점: UI + 업무 API + A2A를 한 프로세스로 조립한다.

실행: uv run python -m app.main   (또는 run.ps1)
"""

import uvicorn

from app import agent as agent_module
from app import api
from app.kit import obs_emit
from app.kit.auth import HEADER, ApiKeyAuth
from app.kit.card_signing import sign_card
from app.kit.a2a_server import build_app, make_card
from app.kit.db import Db
from app.kit.task_store import SqliteTaskStore
from app.kit.web import setup_web
from app.settings import ROOT, load_settings, secret_path


def create_app(settings=None):
    settings = settings or load_settings()
    db = Db(settings.db_path)
    db.script((ROOT / "db" / "schema.sql").read_text(encoding="utf-8"))
    db.script((ROOT / "db" / "seed.sql").read_text(encoding="utf-8"))

    obs_emit.start(settings.obs_url, settings.company_id, settings.public_url)
    carrier = agent_module.CarrierAgent(db, settings)
    secured = settings.auth.get("mode", "required") == "required"   # off면 키·서명 검사를 하지 않는다 (로컬 실험용)
    auth = ApiKeyAuth(secret_path(settings, "api_keys_file", "secrets/api_keys.json")) if secured else None
    card = make_card(
        api_key_header=HEADER if secured else "",
        name=settings.name,
        description=f"{settings.carrier.get('display_name', settings.name)}의 견적·수주·배송 에이전트",
        public_url=settings.public_url,
        skills=agent_module.SKILLS,
    )
    if secured:
        sign_card(card, secret_path(settings, "signing_key_file", "secrets/card_signing.key"), kid=settings.company_id)
    app = build_app(card, carrier.handle, SqliteTaskStore(db), auth=auth, default_skill="check-delivery")
    templates = setup_web(app, ROOT / "app" / "web")
    api.register(app, db, templates, settings.name)
    obs_emit.emit("agent.started", "server")
    return app, settings


app, _settings = create_app()

if __name__ == "__main__":
    print(f"[{_settings.company_id}] {_settings.public_url}  (UI: /, API: /api, A2A: /a2a)", flush=True)
    uvicorn.run(app, host=_settings.host, port=_settings.port, log_level="warning")
