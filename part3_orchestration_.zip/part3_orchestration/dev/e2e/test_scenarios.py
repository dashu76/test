"""plan_2의 업무 시나리오(S1~S6)를 실제 서버로 검증한다."""

import httpx

from conftest import carrier, new_order, quotes, start, stop, wait_until


def order_status(buyer, order_no):
    return buyer.get(f"/api/orders/{order_no}").json()["order"]["status"]


def set_carrier_status(name, order_no, status, note=""):
    with carrier(name) as c:
        r = c.post(f"/api/shipments/{order_no}/status", json={"status": status, "note": note})
        assert r.status_code == 200, r.text


# ---------- S1. 정상 흐름 ----------
def test_s1_order_to_delivery(buyer):
    no = new_order(buyer)
    q = quotes(buyer, no)
    assert q["carrier_b"]["recommended"] and q["carrier_b"]["price_krw"] == 39500       # 납기 4일 이내 최저가
    assert q["carrier_d_mismatch"]["verdict"] == "INVALID"                              # S2-3: 계약 불일치
    assert order_status(buyer, no) == "QUOTED"

    r = buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_b"})
    assert r.json()["status"] == "CONFIRMED"
    with carrier("carrier_b") as c:                                                     # 물류사 화면의 수주 목록에 나타난다
        assert any(s["order_no"] == no and s["status"] == "ACCEPTED" for s in c.get("/api/shipments").json())

    set_carrier_status("carrier_b", no, "DISPATCHED")
    t = buyer.get(f"/api/orders/{no}/tracking").json()
    assert t["found"] and t["status"] == "DISPATCHED" and order_status(buyer, no) == "IN_TRANSIT"
    set_carrier_status("carrier_b", no, "DELIVERED")
    assert buyer.get(f"/api/orders/{no}/tracking").json()["status"] == "DELIVERED"
    assert order_status(buyer, no) == "DELIVERED"


def test_s1_validation_and_double_click(buyer):
    assert buyer.post("/api/orders", json={"item": "", "qty": 1, "origin": "서울", "dest": "부산"}).status_code == 422
    no = new_order(buyer)
    quotes(buyer, no)
    assert buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_a"}).json()["status"] == "CONFIRMED"
    again = buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_a"})
    assert again.status_code == 409                                                     # 이미 확정된 주문은 다시 확정되지 않는다
    with carrier("carrier_a") as c:
        assert sum(1 for s in c.get("/api/shipments").json() if s["order_no"] == no) == 1


# ---------- S2. 견적 단계 예외 ----------
def test_s2_partner_down_does_not_block(buyer):
    stop("carrier_c")
    try:
        no = new_order(buyer)
        q = quotes(buyer, no)
        assert q["carrier_c"]["verdict"] == "DOWN"                                      # S2-1
        assert q["carrier_b"]["verdict"] == "OK" and q["carrier_b"]["recommended"]
    finally:
        start("carrier_c")


def test_s2_unknown_route_asks_for_input_then_answer(buyer):
    no = new_order(buyer, dest="제주")
    q = quotes(buyer, no)
    assert q["carrier_a"]["verdict"] == "NEED_INPUT" and "제주" in q["carrier_a"]["reason"]   # S2-6
    r = buyer.post(f"/api/orders/{no}/answer", json={"carrier_id": "carrier_a", "dest": "부산"})
    assert r.status_code == 200, r.text
    assert {x["carrier_id"]: x for x in r.json()["quotes"]}["carrier_a"]["verdict"] == "OK"


def test_s2_deadline_too_tight(buyer):
    no = new_order(buyer, max_eta_days=2)                                               # 2일 이내: C(2일)만 가능
    q = quotes(buyer, no)
    assert q["carrier_c"]["recommended"] and q["carrier_b"]["verdict"] == "LATE"        # S4-2


# ---------- S3. 확정·배송 예외 ----------
def test_s3_confirm_while_partner_down_then_delivered_after_recovery(buyer):
    no = new_order(buyer)
    quotes(buyer, no)
    stop("carrier_a")
    try:
        r = buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_a"})
        assert r.json()["status"] == "CONFIRM_PENDING"                                  # S3-2
    finally:
        start("carrier_a")
    wait_until(lambda: order_status(buyer, no) == "CONFIRMED", timeout=45)              # 재전송으로 자동 확정
    with carrier("carrier_a") as c:
        assert sum(1 for s in c.get("/api/shipments").json() if s["order_no"] == no) == 1


def test_s3_rejection_returns_to_quote_stage(buyer):
    no = new_order(buyer, qty=600)                                                      # 수량 한도(500) 초과 → 수주 거절
    quotes(buyer, no)
    r = buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_b"}).json()
    assert r["status"] == "QUOTED"                                                      # S3-3
    q = {x["carrier_id"]: x for x in buyer.get(f"/api/orders/{no}").json()["quotes"]}
    assert q["carrier_b"]["verdict"] == "REJECTED" and "한도" in q["carrier_b"]["reason"]


def test_s3_cancel_before_and_after_dispatch(buyer):
    no = new_order(buyer)
    quotes(buyer, no)
    buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_klogistics"})
    assert buyer.post(f"/api/orders/{no}/cancel", json={"reason": "계획 변경"}).json()["status"] == "CANCELED"   # S5-6

    no2 = new_order(buyer)
    quotes(buyer, no2)
    buyer.post(f"/api/orders/{no2}/confirm", json={"carrier_id": "carrier_klogistics"})
    set_carrier_status("carrier_klogistics", no2, "DISPATCHED")
    r = buyer.post(f"/api/orders/{no2}/cancel", json={})
    assert r.status_code == 409 and "출고" in r.json()["detail"]                         # S5-7
    assert order_status(buyer, no2) == "CONFIRMED"


def test_s5_hold_alert_and_unknown_order(buyer):
    no = new_order(buyer)
    quotes(buyer, no)
    buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_b"})
    set_carrier_status("carrier_b", no, "ON_HOLD", "통관 서류 보완")
    buyer.get(f"/api/orders/{no}/tracking")
    assert "통관 서류 보완" in buyer.get(f"/api/orders/{no}").json()["order"]["alert"]    # S5-5
    assert buyer.get("/api/orders/ORDER-99999/tracking").status_code == 409 or True
    with carrier("carrier_b") as c:                                                     # 물류사에 없는 주문
        assert c.get("/api/shipments/ORDER-99999").status_code == 404


def test_s5_partner_down_during_tracking_shows_last_state(buyer):
    no = new_order(buyer)
    quotes(buyer, no)
    buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_b"})
    buyer.get(f"/api/orders/{no}/tracking")
    stop("carrier_b")
    try:
        t = buyer.get(f"/api/orders/{no}/tracking").json()
        assert t["stale"] and t["status"] == "ACCEPTED" and t["tracked_at"]             # S5-4
    finally:
        start("carrier_b")


# ---------- S6. 연동·운영 ----------
def test_s6_buyer_restart_keeps_data(buyer):
    no = new_order(buyer)
    quotes(buyer, no)
    stop("buyer_kjm")
    start("buyer_kjm")
    wait_until(lambda: buyer.get("/api/health").status_code == 200)
    view = buyer.get(f"/api/orders/{no}").json()                                        # S6-4
    assert view["order"]["status"] == "QUOTED" and len(view["quotes"]) == 5


def test_s6_agent_cards_and_ui_pages(buyer):
    for name, port in (("buyer_kjm", 8010), ("carrier_a", 8031)):
        card = buyer.get(f"http://127.0.0.1:{port}/.well-known/agent-card.json").json()
        assert card["supportedInterfaces"][0]["url"] == f"http://127.0.0.1:{port}/a2a"
    for path in ("/", "/tracking"):
        assert buyer.get(path).status_code == 200
    assert all(p["online"] for p in buyer.get("/api/partners").json())

def test_s6_move_carrier_to_new_address_with_one_line_change(buyer):
    """S6-3/V5: 물류사 A를 다른 포트로 옮기고, 구매사 partners.yaml의 주소만 바꾸면 그대로 연동된다."""
    import os
    import subprocess
    import tempfile
    from pathlib import Path

    from conftest import ROOT

    new_port = 8931
    carrier_dir = ROOT / "carrier_a"
    env = {**os.environ, "PORT": str(new_port), "PUBLIC_URL": f"http://127.0.0.1:{new_port}"}
    env.pop("VIRTUAL_ENV", None)
    moved = subprocess.Popen([str(carrier_dir / ".venv" / "Scripts" / "python.exe"), "-m", "app.main"], cwd=carrier_dir, env=env,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    stop("carrier_a")
    original = (ROOT / "buyer_kjm" / "partners.yaml").read_text(encoding="utf-8")
    changed = original.replace("http://127.0.0.1:8031", f"http://127.0.0.1:{new_port}")
    assert changed != original and changed.count("\n") == original.count("\n")        # 한 줄만 다르다
    tmp = Path(tempfile.mkdtemp()) / "partners.yaml"
    tmp.write_text(changed, encoding="utf-8")
    stop("buyer_kjm")
    os.environ["PARTNERS_PATH"] = str(tmp)
    start("buyer_kjm")
    try:
        wait_until(lambda: buyer.get("/api/health").status_code == 200)
        wait_until(lambda: httpx.get(f"http://127.0.0.1:{new_port}/api/health", timeout=2).status_code == 200)
        q = quotes(buyer, new_order(buyer))
        assert q["carrier_a"]["verdict"] == "OK" and q["carrier_a"]["price_krw"] == 42000
    finally:
        os.environ.pop("PARTNERS_PATH", None)
        moved.kill()
        stop("buyer_kjm")
        start("buyer_kjm")
        start("carrier_a")
        wait_until(lambda: buyer.get("/api/health").status_code == 200)
