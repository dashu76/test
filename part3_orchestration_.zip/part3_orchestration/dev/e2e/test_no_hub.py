"""V4: 관제 허브가 없어도(처음부터 없거나, 도중에 꺼져도) 회사 간 업무가 끝까지 흐른다."""

import os
import socket
import subprocess

import httpx

from conftest import DEV, new_order, ps, quotes, stop, wait_until


def listening(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def full_flow(buyer) -> None:
    no = new_order(buyer)
    q = quotes(buyer, no)
    assert q["carrier_b"]["recommended"]
    assert buyer.post(f"/api/orders/{no}/confirm", json={"carrier_id": "carrier_b"}).json()["status"] == "CONFIRMED"
    with httpx.Client(base_url="http://127.0.0.1:8032", timeout=30) as c:
        assert c.post(f"/api/shipments/{no}/status", json={"status": "DISPATCHED"}).status_code == 200
    assert buyer.get(f"/api/orders/{no}/tracking").json()["status"] == "DISPATCHED"


def test_flow_without_any_hub(buyer):
    assert not listening(8000)                      # 허브는 어디에도 없다 (S6-1)
    full_flow(buyer)


def test_flow_continues_when_hub_dies_midway(buyer):
    ps("stop_all.ps1")
    os.environ["A2A_OBS_URL"] = "http://127.0.0.1:8000"        # 회사들이 허브로 이벤트를 보내도록 켠다
    try:
        ps("run_all.ps1", "-WithHub")
        wait_until(lambda: listening(8000) and buyer.get("/api/health").status_code == 200)
        full_flow(buyer)                             # 허브가 살아 있을 때
        hub_events = httpx.get("http://127.0.0.1:8000/events.jsonl", timeout=10).text
        assert "task.state" in hub_events            # 이벤트가 실제로 허브에 모였다
        stop_hub = subprocess.run(["powershell", "-NoProfile", "-File", str(DEV / "stop_all.ps1"), "-Ports", "8000"],
                                  stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert stop_hub.returncode == 0 and not listening(8000)
        full_flow(buyer)                             # 허브가 꺼진 뒤에도 업무는 그대로 흐른다 (S6-5)
    finally:
        os.environ.pop("A2A_OBS_URL", None)
        ps("stop_all.ps1")
        ps("run_all.ps1")                            # 허브 없는 상태로 되돌린다
        wait_until(lambda: buyer.get("/api/health").status_code == 200)