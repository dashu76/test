"""인증(API 키 + Agent Card 서명) 통합 검증. 키는 구매사의 secrets에서 '구매사처럼' 읽어 쓴다."""

import json
import os
import tempfile
import uuid
from pathlib import Path

import httpx

from conftest import ROOT, new_order, quotes, start, stop, wait_until

BUYER_SECRETS = ROOT / "buyer_kjm" / "secrets"


def rpc(skill: str, data: dict) -> dict:
    return {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {
        "messageId": str(uuid.uuid4()), "role": "ROLE_USER", "parts": [{"data": data}], "metadata": {"skill": skill}}}}


def post(port: int, body: dict, key: str | None):
    headers = {"A2A-Version": "1.0", **({"X-A2A-Key": key} if key else {})}
    return httpx.post(f"http://127.0.0.1:{port}/a2a", json=body, headers=headers, timeout=20)


def peer_keys() -> dict:
    return json.loads((BUYER_SECRETS / "peer_keys.json").read_text(encoding="utf-8"))


def test_carrier_rejects_missing_or_wrong_key():
    body = rpc("check-delivery", {"order_no": "ORDER-1001"})
    assert post(8031, body, None).status_code == 401
    assert post(8031, body, "not-a-real-key").status_code == 401
    assert post(8031, body, peer_keys()["carrier_b"]).status_code == 401      # 다른 물류사용 키로는 들어갈 수 없다


def test_carrier_accepts_buyer_key():
    r = post(8031, rpc("check-delivery", {"order_no": "ORDER-1001"}), peer_keys()["carrier_a"])
    assert r.status_code == 200 and "error" not in r.json(), r.text


def test_scope_limits_skills_on_buyer_endpoint():
    dev_key = json.loads((BUYER_SECRETS / "api_keys.json").read_text(encoding="utf-8"))["keys"][0]["key"]
    assert post(8010, rpc("route-delivery-inquiry", {"order_no": "ORDER-1"}), None).status_code == 401
    assert post(8010, rpc("quote", {"order_no": "ORDER-1"}), dev_key).status_code == 403   # scope 밖 스킬
    ok = post(8010, rpc("route-delivery-inquiry", {"order_no": "ORDER-1"}), dev_key)
    assert ok.status_code == 200 and "error" not in ok.json(), ok.text


def test_agent_card_is_public_signed_and_declares_the_key():
    card = httpx.get("http://127.0.0.1:8031/.well-known/agent-card.json").json()      # 카드는 키 없이 읽는다
    assert card["signatures"] and card["signatures"][0]["signature"]
    scheme = card["securitySchemes"]["apiKey"]["apiKeySecurityScheme"]
    assert scheme["name"] == "X-A2A-Key" and scheme["location"] == "header"
    assert card["securityRequirements"]


def test_ui_and_business_api_need_no_a2a_key(buyer):
    assert buyer.get("/").status_code == 200 and buyer.get("/api/orders").status_code == 200


def test_buyer_marks_partner_auth_failed_when_key_is_wrong(buyer):
    keys = peer_keys()
    keys["carrier_b"] = "wrong-key"
    tmp = Path(tempfile.mkdtemp()) / "peer_keys.json"
    tmp.write_text(json.dumps(keys), encoding="utf-8")
    stop("buyer_kjm")
    os.environ["PEER_KEYS_FILE"] = str(tmp)
    start("buyer_kjm")
    try:
        wait_until(lambda: buyer.get("/api/health").status_code == 200)
        q = quotes(buyer, new_order(buyer))
        assert q["carrier_b"]["verdict"] == "AUTH" and "401" in q["carrier_b"]["reason"]
        assert q["carrier_a"]["verdict"] == "OK"                                       # 나머지는 영향 없음
    finally:
        os.environ.pop("PEER_KEYS_FILE", None)
        stop("buyer_kjm")
        start("buyer_kjm")
        wait_until(lambda: buyer.get("/api/health").status_code == 200)


def test_buyer_refuses_card_signed_by_someone_else(buyer):
    """partners.yaml에 다른 회사의 공개키가 적혀 있으면(= 서명이 맞지 않으면) 그 상대를 호출하지 않는다."""
    src = (ROOT / "buyer_kjm" / "partners.yaml").read_text(encoding="utf-8").splitlines()
    keys = {}
    current = None
    for line in src:
        s = line.strip()
        if s.startswith("- id:"):
            current = s.split(":", 1)[1].strip()
        elif s.startswith("card_public_key:"):
            keys[current] = s.split(":", 1)[1].strip()
    swapped = "\n".join(
        line.replace(keys["carrier_c"], keys["carrier_a"]) if keys["carrier_c"] in line else line for line in src)
    tmp = Path(tempfile.mkdtemp()) / "partners.yaml"
    tmp.write_text(swapped, encoding="utf-8")
    stop("buyer_kjm")
    os.environ["PARTNERS_PATH"] = str(tmp)
    start("buyer_kjm")
    try:
        wait_until(lambda: buyer.get("/api/health").status_code == 200)
        q = quotes(buyer, new_order(buyer))
        assert q["carrier_c"]["verdict"] == "AUTH" and "서명" in q["carrier_c"]["reason"]
        assert q["carrier_b"]["verdict"] == "OK"
    finally:
        os.environ.pop("PARTNERS_PATH", None)
        stop("buyer_kjm")
        start("buyer_kjm")
        wait_until(lambda: buyer.get("/api/health").status_code == 200)