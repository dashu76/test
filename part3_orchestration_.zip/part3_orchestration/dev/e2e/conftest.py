"""통합 테스트: 회사 서버를 실제로 띄우고 HTTP로만 접근한다 (회사 코드를 import하지 않는다).

실행: uv run --no-project --with pytest --with httpx pytest dev/e2e -v
각 서버는 임시 DATA_DIR의 별도 DB를 쓰므로 실제 데이터와 섞이지 않는다. 허브는 띄우지 않는다.
"""

import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import httpx
import pytest

DEV = Path(__file__).resolve().parent.parent
ROOT = DEV.parent
PORTS = {"buyer_kjm": 8010, "carrier_klogistics": 8020, "carrier_a": 8031, "carrier_b": 8032, "carrier_c": 8033, "carrier_d_mismatch": 8034}


def ps(script: str, *args: str) -> None:
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(DEV / script), *args],
                   check=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  # pipe를 쓰면 서버가 핸들을 잡아 끝나지 않는다


def stop(name: str) -> None:
    ps("stop_all.ps1", "-Ports", str(PORTS[name]))


def start(name: str) -> None:
    ps("run_all.ps1", "-Only", name)


def wait_until(check, timeout=40.0, interval=0.5):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = check()
        if last:
            return last
        time.sleep(interval)
    raise AssertionError(f"시간 안에 조건이 만족되지 않았습니다 (마지막 값: {last})")


@pytest.fixture(scope="session", autouse=True)
def stack():
    data_dir = tempfile.mkdtemp(prefix="a2a_e2e_")
    os.environ["DATA_DIR"] = data_dir
    os.environ.pop("A2A_OBS_URL", None)  # 허브 없이 돈다 (V4)
    ps("stop_all.ps1")
    ps("gen_keys.ps1")  # 개발용 키가 없으면 만든다 (있으면 그대로 둔다)
    ps("run_all.ps1")
    yield
    ps("stop_all.ps1")
    shutil.rmtree(data_dir, ignore_errors=True)


@pytest.fixture
def buyer():
    with httpx.Client(base_url="http://127.0.0.1:8010", timeout=30) as client:
        yield client


def carrier(name: str) -> httpx.Client:
    return httpx.Client(base_url=f"http://127.0.0.1:{PORTS[name]}", timeout=30)


def new_order(buyer: httpx.Client, **over) -> str:
    body = {"item": "노트북", "qty": 20, "origin": "서울", "dest": "부산", "max_eta_days": 4, **over}
    r = buyer.post("/api/orders", json=body)
    assert r.status_code == 200, r.text
    return r.json()["order_no"]


def quotes(buyer: httpx.Client, order_no: str) -> dict:
    r = buyer.post(f"/api/orders/{order_no}/quotes")
    assert r.status_code == 200, r.text
    return {q["carrier_id"]: q for q in r.json()["quotes"]}