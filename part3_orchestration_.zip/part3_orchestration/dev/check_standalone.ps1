﻿# V1: 각 회사 폴더를 "빈 디렉터리에 그 폴더만" 복사해 환경 구성 → 테스트 → 기동까지 되는지 확인한다.
# 다른 회사 폴더가 없어도 실행돼야 한다. secrets/는 폴더와 함께 가져간 것으로 본다(운영에서는 별도 경로로 옮긴다).
$root = Split-Path $PSScriptRoot -Parent
Remove-Item Env:VIRTUAL_ENV -ErrorAction SilentlyContinue
$env:PYTHONIOENCODING = 'utf-8'
$ports = @{ buyer_kjm = 8910; carrier_klogistics = 8920; carrier_a = 8931; carrier_b = 8932; carrier_c = 8933; carrier_d_mismatch = 8934 }
$failed = 0
foreach ($c in $ports.Keys) {
    $dst = Join-Path $env:TEMP "standalone_$c"
    if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
    New-Item -ItemType Directory $dst | Out-Null
    robocopy (Join-Path $root $c) $dst /E /XD .venv __pycache__ .pytest_cache data /NFL /NDL /NJH /NJS | Out-Null
    Push-Location $dst
    uv sync 2>&1 | Out-Null
    $tests = (uv run pytest -q 2>&1 | Select-Object -Last 1)
    $env:PORT = $ports[$c]; $env:PUBLIC_URL = "http://127.0.0.1:$($ports[$c])"
    $p = Start-Process (Join-Path $dst '.venv\Scripts\python.exe') -ArgumentList '-m', 'app.main' -WorkingDirectory $dst -WindowStyle Hidden -PassThru
    $ok = $false
    foreach ($i in 1..40) {
        Start-Sleep -Milliseconds 250
        try { $r = Invoke-WebRequest "http://127.0.0.1:$($ports[$c])/api/health" -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { $ok = $true; break } } catch {}
    }
    $card = $null
    if ($ok) { try { $card = (Invoke-RestMethod "http://127.0.0.1:$($ports[$c])/.well-known/agent-card.json").supportedInterfaces[0].url } catch {} }
    Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match [regex]::Escape($dst) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Remove-Item Env:PORT, Env:PUBLIC_URL
    Pop-Location
    Remove-Item $dst -Recurse -Force -ErrorAction SilentlyContinue
    $good = $ok -and $card -eq "http://127.0.0.1:$($ports[$c])/a2a" -and $tests -match 'passed' -and $tests -notmatch 'failed'
    if (-not $good) { $failed++ }
    Write-Host ("{0,-20} {1} | tests: {2} | health: {3} | card: {4}" -f $c, $(if ($good) { 'OK  ' } else { 'FAIL' }), $tests, $ok, $card)
}
exit $failed