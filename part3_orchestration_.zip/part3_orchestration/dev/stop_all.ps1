﻿# 개발용 서버를 모두 종료한다 (회사 서버 + 관제 허브). 포트를 잡은 프로세스와, 그 부모가 uv일 때 uv도 끈다.
param([int[]]$Ports = @(8000, 8010, 8020, 8031, 8032, 8033, 8034))
$lines = netstat -ano -p TCP | Select-String 'LISTENING'
foreach ($port in $Ports) {
    foreach ($line in $lines) {
        $cols = ($line.ToString().Trim() -split '\s+')
        if ($cols[1] -notmatch ":$port$") { continue }
        $procId = [int]$cols[-1]
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$procId"
        if ($proc -and $proc.ParentProcessId) {
            $parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($proc.ParentProcessId)"
            if ($parent -and $parent.Name -eq 'uv.exe') { Stop-Process -Id $parent.ProcessId -Force -ErrorAction SilentlyContinue }
        }
        # venv python은 base python을 자식으로 띄우므로 부모(venv 런처)도 정리한다
        if ($proc -and $proc.ParentProcessId) {
            $parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($proc.ParentProcessId)"
            if ($parent -and $parent.CommandLine -match '\\\.venv\\Scripts\\python\.exe') { Stop-Process -Id $parent.ProcessId -Force -ErrorAction SilentlyContinue }
        }
        Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
        Write-Host "stopped: port $port"
    }
}