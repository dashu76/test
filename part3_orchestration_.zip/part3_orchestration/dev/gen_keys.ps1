﻿# 개발용 키를 만든다 (이미 있으면 유지). 모두 다시 만들려면 -Force
param([switch]$Force)
$root = Split-Path $PSScriptRoot -Parent
Remove-Item Env:VIRTUAL_ENV -ErrorAction SilentlyContinue
$extra = if ($Force) { '--force' } else { $null }
uv run --no-project --with cryptography python (Join-Path $PSScriptRoot 'gen_keys.py') $extra
