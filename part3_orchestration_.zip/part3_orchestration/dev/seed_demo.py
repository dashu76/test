"""데모 데이터: 구매사 화면에 여러 상태의 주문을 만들어 둔다 (서버가 모두 떠 있어야 한다).

실행: uv run --no-project --with httpx python dev/seed_demo.py
"""

import httpx

buyer = httpx.Client(base_url="http://127.0.0.1:8010", timeout=30)


def order(**over) -> str:
    body = {"item": "노트북", "qty": 20, "origin": "서울", "dest": "부산", "max_eta_days": 4, **over}
    return buyer.post("/api/orders", json=body).json()["order_no"]


def carrier_status(port: int, order_no: str, status: str, note: str = "") -> None:
    httpx.post(f"http://127.0.0.1:{port}/api/shipments/{order_no}/status", json={"status": status, "note": note}, timeout=30).raise_for_status()


a = order()                                              # 배송 중
buyer.post(f"/api/orders/{a}/quotes")
buyer.post(f"/api/orders/{a}/confirm", json={"carrier_id": "carrier_b"})
carrier_status(8032, a, "DISPATCHED")
buyer.get(f"/api/orders/{a}/tracking")

b = order(item="모니터", qty=10, dest="대전")           # 견적 비교 중
buyer.post(f"/api/orders/{b}/quotes")

c = order(item="서버", qty=2, dest="광주", max_eta_days=3)   # 보류 경고
buyer.post(f"/api/orders/{c}/quotes")
buyer.post(f"/api/orders/{c}/confirm", json={"carrier_id": "carrier_klogistics"})
carrier_status(8020, c, "ON_HOLD", "통관 서류 보완")
buyer.get(f"/api/orders/{c}/tracking")

d = order(item="케이블", qty=100)                        # 작성 중
print("데모 주문:", a, "(배송 중)", b, "(견적 비교)", c, "(보류 경고)", d, "(작성 중)")