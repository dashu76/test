"""독립성 검사(V2·V6): 회사 폴더끼리 코드를 참조하지 않는지, 비밀이 자기 폴더에만 있는지 확인한다.

실행: uv run --no-project --with cryptography python dev/check_independence.py
"""

import base64
import json
import re
import sys
from pathlib import Path

from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, load_pem_private_key

ROOT = Path(__file__).resolve().parent.parent
COMPANIES = ["buyer_kjm", "carrier_klogistics", "carrier_a", "carrier_b", "carrier_c", "carrier_d_mismatch"]
EXCLUDE = {".venv", "__pycache__", ".pytest_cache", "data", "secrets"}
failures = []


def fail(message: str) -> None:
    failures.append(message)
    print("FAIL", message)


def code_files(company: str):
    for path in (ROOT / company).rglob("*"):
        if path.is_file() and path.suffix in {".py", ".html", ".js", ".ps1", ".sh", ".toml"} and not (set(path.parts) & EXCLUDE):
            yield path


def check_v2() -> None:
    """V2: 코드가 다른 회사 폴더를 import·참조하지 않는다 (주소·설정 값은 제외: 이름은 partners.yaml에서만 나온다)."""
    for company in COMPANIES:
        others = [c for c in COMPANIES if c != company] + ["obs_hub", "legacy", "contracts"]
        pattern = re.compile(r"(import|from)\s+(" + "|".join(others) + r")\b|\.\.[\\/](" + "|".join(others) + r")\b")
        for path in code_files(company):
            for number, line in enumerate(path.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if pattern.search(line):
                    fail(f"V2 {path.relative_to(ROOT)}:{number} 다른 폴더 참조: {line.strip()}")
    print("V2 검사 끝")


def public_of(pem_path: Path) -> str:
    key = load_pem_private_key(pem_path.read_bytes(), password=None)
    return base64.b64encode(key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)).decode()


def check_v6() -> None:
    """V6: 각 폴더 secrets/에는 자기 비밀키와 자기가 쓰는 API 키만 있다."""
    own_private = {c: ROOT / c / "secrets" / "card_signing.key" for c in COMPANIES}
    public = {}
    for company, path in own_private.items():
        if not path.exists():
            fail(f"V6 {company}: card_signing.key가 없다 (dev/gen_keys.ps1)")
        else:
            public[company] = public_of(path)
    # 비밀키 파일의 내용이 서로 다르다 = 다른 회사의 비밀키를 복사해 둔 곳이 없다
    pems = {c: p.read_text() for c, p in own_private.items() if p.exists()}
    if len(set(pems.values())) != len(pems):
        fail("V6 서로 같은 비밀키를 쓰는 회사가 있다")
    allowed = {"buyer_kjm": {"card_signing.key", "api_keys.json", "peer_keys.json"}}
    for company in COMPANIES:
        folder = ROOT / company / "secrets"
        names = {p.name for p in folder.glob("*") if p.is_file()} if folder.exists() else set()
        extra = names - allowed.get(company, {"card_signing.key", "api_keys.json"})
        if extra:
            fail(f"V6 {company}/secrets에 있어야 하지 않은 파일: {sorted(extra)}")
        # 다른 회사의 비밀키 내용이 어떤 비밀 파일에도 들어 있지 않다
        for path in folder.glob("*") if folder.exists() else []:
            text = path.read_text(encoding="utf-8", errors="ignore")
            for other, pem in pems.items():
                if other != company and pem.strip() and pem.strip() in text:
                    fail(f"V6 {company}/secrets/{path.name}에 {other}의 비밀키가 들어 있다")
    # 공개키 등록이 실제 키와 맞다
    buyer_partners = (ROOT / "buyer_kjm" / "partners.yaml").read_text(encoding="utf-8")
    for company in COMPANIES[1:]:
        if company in public and public[company] not in buyer_partners:
            fail(f"V6 buyer_kjm/partners.yaml에 {company}의 공개키가 없거나 다르다")
    # 물류사의 api_keys.json에는 구매사 호출자만 있고, 구매사가 호출에 쓰는 키와 일치한다
    peer = json.loads((ROOT / "buyer_kjm" / "secrets" / "peer_keys.json").read_text(encoding="utf-8"))
    for company in COMPANIES[1:]:
        keys = json.loads((ROOT / company / "secrets" / "api_keys.json").read_text(encoding="utf-8"))["keys"]
        if {k["caller"] for k in keys} != {"buyer_kjm"}:
            fail(f"V6 {company}: 구매사 외 호출자가 등록돼 있다")
        if peer.get(company) not in {k["key"] for k in keys}:
            fail(f"V6 {company}: 구매사가 쓰는 키와 등록된 키가 다르다")
        for other in COMPANIES[1:]:  # 구매사의 다른 물류사용 키가 이 물류사에 있으면 안 된다
            if other != company and peer.get(other) in {k["key"] for k in keys}:
                fail(f"V6 {company}: {other}용 키가 들어 있다")
    # 물류사의 partners.yaml에는 경쟁 물류사 정보가 없다
    for company in COMPANIES[1:]:
        text = (ROOT / company / "partners.yaml").read_text(encoding="utf-8")
        leaked = [o for o in COMPANIES[1:] if o != company and o in text]
        if leaked:
            fail(f"V6 {company}/partners.yaml에 다른 물류사 정보가 있다: {leaked}")
    print("V6 검사 끝")


check_v2()
check_v6()
print("모든 검사 통과" if not failures else f"실패 {len(failures)}건")
sys.exit(1 if failures else 0)