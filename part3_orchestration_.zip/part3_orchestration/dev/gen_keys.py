"""개발용 키 생성: 회사별 카드 서명 키쌍, 회사 쌍별 API 키, 공개키 등록(partners.yaml).

실행: uv run --no-project --with cryptography python dev/gen_keys.py [--force]
- 각 회사의 secrets/ 폴더(저장소에 넣지 않는다)에 그 회사가 가져야 할 것만 둔다.
    카드 서명 비밀키(card_signing.key) · 받아 줄 키(api_keys.json) · [구매사] 호출할 때 쓸 키(peer_keys.json)
- 상대의 공개키만 partners.yaml에 적는다. 비밀키는 다른 회사에 가지 않는다.
- 이미 있으면 건드리지 않는다 (--force로 모두 다시 만든다). 운영 키에는 쓰지 않는다.
"""

import base64
import json
import re
import secrets
import sys
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat

ROOT = Path(__file__).resolve().parent.parent
BUYER = "buyer_kjm"
CARRIERS = ["carrier_klogistics", "carrier_a", "carrier_b", "carrier_c", "carrier_d_mismatch"]
CARRIER_SCOPES = {c: ["quote", "accept-shipment", "check-delivery", "cancel-shipment"] for c in CARRIERS}
BUYER_SCOPES = ["compare-quotes", "route-delivery-inquiry"]
force = "--force" in sys.argv


def write(path: Path, text: str, secret: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def ensure_signing_key(company: str) -> str:
    """비밀키(PEM)를 만들거나 읽고, 공개키(Base64 DER)를 돌려준다."""
    path = ROOT / company / "secrets" / "card_signing.key"
    if path.exists() and not force:
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        key = load_pem_private_key(path.read_bytes(), password=None)
    else:
        key = Ed25519PrivateKey.generate()
        write(path, key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()).decode())
        print(f"  새 서명 키: {company}")
    return base64.b64encode(key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)).decode()


def set_public_key(partners_file: Path, partner_id: str, public_key: str) -> None:
    """partners.yaml에서 해당 항목의 card_public_key를 설정한다 (주석·나머지는 그대로)."""
    lines = partners_file.read_text(encoding="utf-8").splitlines()
    out, i = [], 0
    while i < len(lines):
        line = lines[i]
        out.append(line)
        if re.match(rf"\s*- id: {re.escape(partner_id)}\s*$", line):
            indent = re.match(r"\s*", line).group(0) + "  "
            j = i + 1
            block = []
            while j < len(lines) and not re.match(r"\s*- id:", lines[j]) and lines[j].strip():
                block.append(lines[j]); j += 1
            block = [b for b in block if not b.strip().startswith("card_public_key:")]
            # url 다음 줄에 공개키를 둔다
            pos = next((k for k, b in enumerate(block) if b.strip().startswith("url:")), len(block) - 1) + 1
            block.insert(pos, f"{indent}card_public_key: {public_key}")
            out.extend(block)
            i = j
            continue
        i += 1
    partners_file.write_text("\n".join(out) + "\n", encoding="utf-8")


def main() -> None:
    print("서명 키 확인")
    public = {c: ensure_signing_key(c) for c in [BUYER, *CARRIERS]}

    print("공개키 등록 (partners.yaml)")
    buyer_partners = ROOT / BUYER / "partners.yaml"
    for c in CARRIERS:
        set_public_key(buyer_partners, c, public[c])
    for c in CARRIERS:  # 물류사는 자기를 부르는 구매사의 공개키만 안다
        pf = ROOT / c / "partners.yaml"
        write(pf, f"# 이 회사({c})가 아는 상대. 구매사의 공개키만 가진다 (경쟁 물류사 정보는 없다).\n"
                  f"partners:\n  - id: {BUYER}\n    name: K정밀웍스\n    card_public_key: {public[BUYER]}\n")

    print("API 키")
    peer_keys_path = ROOT / BUYER / "secrets" / "peer_keys.json"
    peer_keys = json.loads(peer_keys_path.read_text(encoding="utf-8")) if peer_keys_path.exists() and not force else {}
    for c in CARRIERS:
        keys_path = ROOT / c / "secrets" / "api_keys.json"
        if keys_path.exists() and peer_keys.get(c) and not force:
            continue
        key = secrets.token_urlsafe(32)
        peer_keys[c] = key
        write(keys_path, json.dumps({"keys": [{"key": key, "caller": BUYER, "scopes": CARRIER_SCOPES[c]}]}, indent=2) + "\n")
        print(f"  새 API 키: {BUYER} → {c}")
    write(peer_keys_path, json.dumps(peer_keys, indent=2) + "\n")

    own = ROOT / BUYER / "secrets" / "api_keys.json"   # 구매사의 A2A 엔드포인트를 부를 수 있는 호출자 (개발 콘솔)
    if force or not own.exists():
        write(own, json.dumps({"keys": [{"key": secrets.token_urlsafe(32), "caller": "dev_console", "scopes": BUYER_SCOPES}]}, indent=2) + "\n")
        print("  새 API 키: dev_console → buyer_kjm")
    print("완료. 키는 각 회사 secrets/ 폴더에 있다 (저장소 제외).")


main()