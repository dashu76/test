﻿# 데모 데이터를 넣는다. 서버가 떠 있지 않으면 먼저 기동한다. 처음부터 다시 하려면 -Reset (모든 데이터 삭제)
param([switch]$Reset)
$root = Split-Path $PSScriptRoot -Parent
Remove-Item Env:VIRTUAL_ENV -ErrorAction SilentlyContinue
if ($Reset) {
    & (Join-Path $PSScriptRoot 'stop_all.ps1') | Out-Null
    foreach ($c in 'buyer_kjm','carrier_klogistics','carrier_a','carrier_b','carrier_c','carrier_d_mismatch') {
        Remove-Item (Join-Path $root "$c\data\*.db*") -Force -ErrorAction SilentlyContinue
    }
    Write-Host '모든 회사의 데이터를 지웠습니다.'
}
& (Join-Path $PSScriptRoot 'gen_keys.ps1') | Out-Null
& (Join-Path $PSScriptRoot 'run_all.ps1') | Out-Null
uv run --no-project --with httpx python (Join-Path $PSScriptRoot 'seed_demo.py')