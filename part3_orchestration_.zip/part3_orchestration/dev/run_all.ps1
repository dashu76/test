﻿# 개발 편의: 각 회사 폴더를 따로 기동한다 (각 폴더는 이 스크립트 없이도 자기 run.ps1로 실행된다).
#   ./dev/run_all.ps1              회사 서버만 (관제 허브 없이)
#   ./dev/run_all.ps1 -WithHub     관제 허브(8000)도 함께, 회사들이 허브로 이벤트를 보낸다
#   ./dev/run_all.ps1 -Only buyer_kjm,carrier_a
param([switch]$WithHub, [string[]]$Only)

$root = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory $logs -Force | Out-Null
Remove-Item Env:VIRTUAL_ENV -ErrorAction SilentlyContinue
$env:PYTHONIOENCODING = 'utf-8'
if ($WithHub) { $env:A2A_OBS_URL = 'http://127.0.0.1:8000' } else { Remove-Item Env:A2A_OBS_URL -ErrorAction SilentlyContinue }

$apps = [ordered]@{
    'carrier_klogistics' = 8020; 'carrier_a' = 8031; 'carrier_b' = 8032; 'carrier_c' = 8033
    'carrier_d_mismatch' = 8034; 'buyer_kjm' = 8010
}

function Test-Listening([int]$port) {   # Get-NetTCPConnection은 매우 느려서 .NET으로 확인한다
    return [bool]([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() | Where-Object { $_.Port -eq $port })
}

function Start-App($name, $port, $argsList) {
    if (Test-Listening $port) { Write-Host "$name : port $port already in use (left as is)"; return }
    $dir = Join-Path $root $name
    $venvPython = Join-Path $dir '.venv\Scripts\python.exe'
    # venv가 이미 있으면 python을 바로 쓴다 (uv run은 시작이 느리다). 없으면 uv가 만든다.
    if ((Test-Path $venvPython) -and $argsList[0] -eq 'run' -and $argsList[1] -eq 'python') { $exe = $venvPython; $argsList = $argsList[2..($argsList.Count - 1)] } else { $exe = 'uv' }
    Start-Process $exe -ArgumentList $argsList -WorkingDirectory $dir -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $logs "$name.out.log") -RedirectStandardError (Join-Path $logs "$name.err.log")
    Write-Host "$name : starting (port $port)"
}

if ($WithHub) { Start-App 'obs_hub' 8000 @('run', 'obs_hub.py') }
foreach ($name in $apps.Keys) {
    if ($Only -and $Only -notcontains $name) { continue }
    Start-App $name $apps[$name] @('run', 'python', '-m', 'app.main')
}

$ports = @(); if ($WithHub) { $ports += 8000 }
foreach ($name in $apps.Keys) { if (-not $Only -or $Only -contains $name) { $ports += $apps[$name] } }
$deadline = (Get-Date).AddSeconds(90)
foreach ($p in $ports) {
    while (-not (Test-Listening $p) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 200 }
    Write-Host ("  :{0} {1}" -f $p, $(if (Test-Listening $p) { 'OK' } else { 'no response - see dev/logs' }))
}
Write-Host "Buyer UI http://127.0.0.1:8010 | Carrier UI 8020(K-Logistics) 8031(A) 8032(B) 8033(C)" $(if ($WithHub) { '| Hub http://127.0.0.1:8000' })