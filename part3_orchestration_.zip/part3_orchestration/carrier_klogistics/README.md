# carrier_klogistics — K-Logistics 물류사 서버 (독립 실행)

견적·수주·배송 상태를 다루는 물류사 한 곳의 서버. UI + 업무 API + A2A 에이전트를 한 프로세스로 제공한다.
이 폴더만 복사해도 실행되며, 다른 회사 폴더의 코드를 참조하지 않는다.

## 실행

```powershell
./run.ps1            # 또는: uv run python -m app.main
```

처음 실행하면 `data/carrier.db`가 만들어지고 `db/schema.sql`, `db/seed.sql`(요금표·샘플 수주)이 적용된다.

| 주소 | 내용 |
|---|---|
| `http://127.0.0.1:8020/` | 수주·배송 화면 (상태 변경, 출고 전 취소) |
| `http://127.0.0.1:8020/rates` | 요금표 조회·수정 (견적 = 기본요금 + 단가 × 수량) |
| `http://127.0.0.1:8020/api/*` | 이 회사의 업무 API (UI가 쓴다) |
| `http://127.0.0.1:8020/a2a` | A2A 엔드포인트 (JSON-RPC) |
| `http://127.0.0.1:8020/.well-known/agent-card.json` | Agent Card |

## 설정

`config.yaml`이 기본값이며 환경변수·`.env`로 덮어쓴다 (`.env.example` 참고).

| 항목 | 설명 |
|---|---|
| `port`, `host` | 이 서버가 열리는 곳 |
| `public_url` | **다른 회사가 이 서버를 부르는 주소.** Agent Card에 그대로 들어간다. 서버를 다른 호스트로 옮기면 이 값만 바꾼다 |
| `obs_url` | 관제 허브 주소. 비우면 이벤트를 보내지 않는다 (허브가 없어도 동작) |
| `carrier.*` | 표시 이름, 견적 유효시간, 수량 한도, 응답 지연 실험(`simulate_delay_s`), 계약 불일치 실험(`contract_mode: mismatch`) |

## A2A 스킬

스킬은 메시지 `metadata.skill`로 고르고, 입력은 data Part(JSON), 결과는 data artifact(JSON)다. 자세한 입출력은 `../contracts/skills.md`.

| 스킬 | 하는 일 |
|---|---|
| `quote` | 요금표로 견적 계산. 구간이 없으면 `INPUT_REQUIRED` |
| `accept-shipment` | 수주. 같은 `business_key`는 한 번만 처리(두 번째부터는 처음 결과 반환). 모르는 구간·수량 초과는 `REJECTED` |
| `check-delivery` | 배송 조회. 없는 주문은 `found: false` (Task는 정상 완료) |
| `cancel-shipment` | 출고 전(수주됨)에만 취소 |

## 구조

```
app/main.py        조립 · app/agent.py 스킬 연결 · app/api.py 업무 API·화면
app/domain/        견적·요금표·수주/상태 규칙 (이 회사만의 업무 로직)
app/kit/           복사해서 쓰는 공통 기능 (VERSION 참고): SQLite TaskStore, 멱등성, 아웃박스, 이벤트 발행, 파트너 발견, A2A 서버 조립
app/web/           templates + static (서버 렌더링 HTML + 가벼운 JS)
db/                schema.sql, seed.sql
tests/             단위 테스트 + 계약 테스트 (tests/contracts에 계약 스키마 복사본)
```

## 테스트

```powershell
uv run pytest        # 도메인 · 계약 · TaskStore 영속화
```

## 데이터

`data/`(SQLite)는 실행하며 쌓이고 저장소에 넣지 않는다. 서버를 껐다 켜도 수주·Task 이력이 유지된다.

## 인증 (회사 간 호출)

- `/a2a` 호출은 헤더 `X-A2A-Key`가 필요하다. 키는 `secrets/api_keys.json`에 호출자별로 등록하고, 호출자마다 허용 스킬(scope)을 정한다. 키가 없거나 틀리면 401, scope 밖 스킬이면 403이며 Task는 만들어지지 않는다.
- Agent Card는 누구나 읽을 수 있고, `securitySchemes`로 키가 필요하다고 알린다. 카드에는 내 비밀키(`secrets/card_signing.key`)로 한 **서명**이 붙어, 호출하는 쪽이 `partners.yaml`의 공개키로 진짜 이 서버가 맞는지 확인한다.
- UI(`/`)와 업무 API(`/api/*`)는 A2A 키 대상이 아니다. 운영에서는 사내 로그인·네트워크 제한 뒤에 둔다.
- 개발용 키: 저장소 루트에서 `dev/gen_keys.ps1` (이미 있으면 유지). 로컬 실험으로 검사를 끄려면 `config.yaml`의 `auth.mode: off`.
- 운영: 같은 위치에 실제 키를 놓거나 `API_KEYS_FILE`, `SIGNING_KEY_FILE` 환경변수로 경로를 지정하고, HTTPS를 쓴다.