INSERT OR IGNORE INTO rate_table(origin, dest, base_krw, per_unit_krw, eta_days) VALUES
    ('서울', '부산', 30000, 600, 3),
    ('서울', '대전', 18000, 400, 2),
    ('서울', '광주', 26000, 550, 3),
    ('인천', '부산', 34000, 650, 4);

INSERT OR IGNORE INTO shipments(order_no, business_key, buyer, item, qty, origin, dest, price_krw, status, eta, created_at, updated_at) VALUES
    ('ORDER-1001', 'ORDER-1001:carrier_klogistics', 'buyer_kjm', '노트북', 20, '서울', '부산', 42000, 'IN_TRANSIT', '2026-09-03', '2026-08-30T00:00:00Z', '2026-08-31T00:00:00Z'),
    ('ORDER-1002', 'ORDER-1002:carrier_klogistics', 'buyer_kjm', '모니터', 10, '인천', '부산', 40500, 'CUSTOMS', '영업일 기준 2일 추가 소요', '2026-08-30T00:00:00Z', '2026-08-31T00:00:00Z');

INSERT OR IGNORE INTO status_log(id, order_no, status, note, at) VALUES
    (1, 'ORDER-1001', 'ACCEPTED', '', '2026-08-30T00:00:00Z'),
    (2, 'ORDER-1001', 'IN_TRANSIT', '', '2026-08-31T00:00:00Z'),
    (3, 'ORDER-1002', 'ACCEPTED', '', '2026-08-30T00:00:00Z'),
    (4, 'ORDER-1002', 'CUSTOMS', '', '2026-08-31T00:00:00Z');
