# 스킬 명세 (계약 v1)

모든 스킬은 A2A `SendMessage`로 호출한다. 호출할 스킬은 **메시지 `metadata.skill`**(예: `{"skill": "quote"}`)로 지정한다. 입력은 `data` Part(JSON 객체) 1개, 결과는 Task의 artifact에 `data` Part(JSON 객체) 1개로 돌려준다.
(`metadata.skill`이 없는 텍스트 메시지는 `check-delivery`로 간주한다 — 옛 실습 클라이언트와의 호환용이다.)
호출 헤더에는 `X-A2A-Key`가 필요하다 (`auth.md`).

Task 상태 규칙:

| 상황 | Task 상태 |
|---|---|
| 업무가 처리됨 (결과가 "없음"이거나 "거절"인 경우도 포함) | `COMPLETED` |
| 정보가 부족해 사람의 입력이 필요 | `INPUT_REQUIRED` + 질문 메시지 |
| 시스템 오류 | `FAILED` |
| 키·권한 오류 | A2A 호출 자체를 거절 (HTTP 401/403) |

"조회했더니 없다", "수주를 거절한다"는 업무 결과이므로 `FAILED`가 아니라 `COMPLETED` + 결과 안의 필드로 표현한다.

---

## 물류사가 제공하는 스킬

### `quote` — 운임 견적

| | |
|---|---|
| 입력 | `{ "order_no": "ORDER-1001", "item": "노트북", "qty": 20, "origin": "서울", "dest": "부산", "max_eta_days": 4 }` |
| 출력 | `quote.v1` (`quote.v1.schema.json`) |
| 비고 | `max_eta_days`는 참고 값이다. 납기를 못 맞춰도 견적은 돌려주고 판단은 구매사가 한다 |
| 오류 | 구간 요금이 없으면 `INPUT_REQUIRED`(예: "출발지·도착지를 확인해 주세요") |

### `accept-shipment` — 확정(수주) 요청

| | |
|---|---|
| 입력 | `shipment_request.v1` — `business_key`(= `order_no` + `:` + `carrier`)를 반드시 포함한다 |
| 출력 | `shipment.v1` — `status`가 `ACCEPTED` 또는 `REJECTED`(+`reason`) |
| 멱등성 | 같은 `business_key`가 다시 오면 새로 만들지 않고 처음 결과를 그대로 돌려준다 |

### `check-delivery` — 배송 조회

| | |
|---|---|
| 입력 | `{ "order_no": "ORDER-1001" }` |
| 출력 | `shipment.v1` — 모르는 주문이면 `found: false` (Task는 `COMPLETED`) |

### `cancel-shipment` — 취소 요청

| | |
|---|---|
| 입력 | `{ "order_no": "ORDER-1001", "business_key": "ORDER-1001:carrier_a" }` |
| 출력 | `shipment.v1` — 취소되면 `status: CANCELED`, 거절되면 기존 상태 + `reason` (출고 이후에는 거절) |

---

## 구매사가 제공하는 스킬 (구매사 내부 UI·에이전트용, 외부에는 노출하지 않아도 된다)

| 스킬 | 설명 |
|---|---|
| `compare-quotes` | 후보 물류사 전체에 동시에 `quote`를 요청해 검증·납기 판단 후 비교 결과를 돌려준다 |
| `route-delivery-inquiry` | 배송 조회를 확정된 물류사의 `check-delivery`로 위임한다 |

---

## 상태 값 (`shipment.v1.status`)

`ACCEPTED`(수주됨) → `DISPATCHED`(출고) → `CUSTOMS`(통관) → `IN_TRANSIT`(배송 중) → `DELIVERED`(도착)
그 밖: `ON_HOLD`(통관 보류 등 예외), `REJECTED`(수주 거절), `CANCELED`(취소).
`NOT_FOUND`는 쓰지 않는다 — 없는 주문은 `found: false`로 표현한다.
