# 인증 (계약 v1)

회사 간 호출은 **API 키**로 호출자를 확인하고, **Agent Card 서명**으로 상대 서버가 진짜인지 확인한다.

## 1. API 키

- 호출하는 쪽은 모든 A2A 요청에 헤더 `X-A2A-Key: <키>`를 붙인다.
- 받는 쪽은 자기 `secrets/api_keys.json`에서 키를 찾아 호출자와 허용 스킬(scope)을 확인한다.
  ```json
  { "keys": [ { "key": "…", "caller": "buyer_kjm", "scopes": ["quote", "accept-shipment", "check-delivery", "cancel-shipment"] } ] }
  ```
- 오류: 키가 없거나 틀리면 HTTP `401`, 키는 맞지만 scope에 없는 스킬이면 HTTP `403`. 두 경우 모두 Task를 만들지 않는다.
- 키는 회사 쌍마다 따로 발급한다 (구매사→물류사 A 키와 구매사→물류사 B 키는 다르다).
- Agent Card(`/.well-known/agent-card.json`)는 키 없이 읽을 수 있고, 카드의 `security_schemes`에 `apiKey`(헤더 `X-A2A-Key`)를 선언한다.

## 2. Agent Card 서명

- 각 회사는 자기 Agent Card에 JWS 서명(`AgentCard.signatures`)을 붙여 제공한다. 알고리즘은 `EdDSA`(Ed25519).
- 서명하는 쪽은 `secrets/card_signing.key`(비밀키)를, 확인하는 쪽은 `partners.yaml`에 적어 둔 상대의 공개키를 쓴다.
- 확인하는 쪽은 카드를 읽을 때마다 서명을 검증하고, 실패하면 그 상대를 호출하지 않는다 (`인증 실패`로 표시).
- 공개키는 공개 정보라 주고받아도 되지만, 비밀키는 어떤 경우에도 다른 회사에 주지 않는다.

## 3. 로컬 개발과 운영

| | 로컬 개발 | 운영 |
|---|---|---|
| 키 값 | `dev/`의 스크립트가 생성한 개발용 키 | 각 회사가 발급한 실제 키 |
| 키 위치 | 각 회사 `secrets/` | 같은 위치 또는 환경변수 |
| 전송 | HTTP | HTTPS 필수 |

코드는 어느 쪽이든 같다. 바뀌는 것은 키 값과 `partners.yaml`의 주소·공개키뿐이다.
