# 파일명: parallel_policy_check.py
"""네트워크 실험과 별도로 주문·금액·납기·취소 경계를 검증한다."""
import asyncio
from parallel_policy import ask_valid_quote


async def main():
    order = "노트북 20대, 서울->부산"
    normal = dict(carrier="물류사 B", order=order, price_krw=39500, eta_days=4)
    for label, raw, deadline, rejected in [
        ("정상 견적", normal, 4, False),
        ("3일 납기에서 B 제외", normal, 3, True),
        ("다른 주문 제외", {**normal, "order": "다른 주문"}, 4, True),
        ("음수 가격 제외", {**normal, "price_krw": -1}, 4, True),
    ]:
        async def ask(*args):
            return raw
        try:
            quote = await ask_valid_quote(ask, "물류사 B", None, order, "context", 2, deadline)
        except ValueError as exc:
            assert rejected
            print(label, "통과:", str(exc).splitlines()[0])
        else:
            assert not rejected and quote["price_krw"] == 39500
            print(label, "통과")
    async def canceled(*args):
        raise asyncio.CancelledError()
    try:
        await ask_valid_quote(canceled, "물류사 B", None, order, "context", 2, 4)
    except asyncio.CancelledError:
        print("상위 취소 전파 통과")
    else:
        raise AssertionError("취소가 성공으로 분류되었습니다")


if __name__ == "__main__":
    asyncio.run(main())
