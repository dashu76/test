# 파일명: gather_demo.py
"""서버 없이 asyncio.gather()의 두 가지 동작을 확인한다: 동시 실행, 부분 실패."""
import asyncio
import time


async def ask(name: str, delay: float, fail: bool = False) -> str:
    await asyncio.sleep(delay)  # 네트워크로 견적을 묻는 시간이라고 생각한다
    if fail:
        raise ConnectionError(f"{name}: 연결 실패")
    return f"{name} 견적 도착"


async def main() -> None:
    start = time.perf_counter()
    seq = [await ask("A", 0.2), await ask("B", 0.2), await ask("C", 0.2)]
    print(f"순서대로: {time.perf_counter() - start:.1f}초 {seq}")

    start = time.perf_counter()
    par = await asyncio.gather(ask("A", 0.2), ask("B", 0.2), ask("C", 0.2))
    print(f"동시에:   {time.perf_counter() - start:.1f}초 {par}")

    try:
        await asyncio.gather(ask("A", 0.2), ask("B", 0.2), ask("C", 0.1, fail=True))
    except ConnectionError as e:
        print(f"return_exceptions=False -> 예외만 남음: {e}")

    results = await asyncio.gather(
        ask("A", 0.2), ask("B", 0.2), ask("C", 0.1, fail=True), return_exceptions=True
    )
    print("return_exceptions=True -> 자리마다 결과 또는 예외:")
    for r in results:
        print("  실패:" if isinstance(r, Exception) else "  성공:", r)


if __name__ == "__main__":
    asyncio.run(main())
