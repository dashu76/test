# 파일명: discovery_lib.py
"""Ch17판 discovery_lib.py -- Ch13판의 find_agent_with_skill()(첫 번째 일치에서 멈춤) 대신
discover_all()(살아 있는 후보 전부)을 담았다. 이 폴더가 다른 폴더를 import하지 않고 혼자 실행되도록
같은 이름의 파일을 따로 둔다. 두 폴더는 서로 다른 예제이지 하나의 애플리케이션이 아니다.
"""

import httpx

from a2a.client import A2ACardResolver
from a2a.types.a2a_pb2 import AgentCard


async def discover_all(candidates: list[str]) -> dict[str, AgentCard]:
    """후보 주소 목록을 전부 훑어, 살아 있는 에이전트의 이름 -> AgentCard 딕셔너리를 돌려준다."""
    cards: dict[str, AgentCard] = {}
    async with httpx.AsyncClient() as httpx_client:
        for base_url in candidates:
            resolver = A2ACardResolver(httpx_client, base_url)
            try:
                card = await resolver.get_agent_card()
            except Exception as e:
                print(f"  [skip] {base_url} 조회 실패: {e}")
                continue
            print(f"  [found] {base_url} -> name={card.name!r}")
            cards[card.name] = card
    return cards
