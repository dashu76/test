# 파일명: client_demo.py
"""Quote Aggregator(8063) 검증용 클라이언트.

Ch15 검증 방식과 같다 -- 이 스크립트를 두 번 실행한다. 한 번은 물류사 A/B/C가 전부 살아있는
상태로, 한 번은 물류사 C를 강제 종료한 뒤로. 코드는 완전히 같고, 상대의 생존 여부만 다르다.
"""

import asyncio
import uuid

from a2a.client import create_client
from a2a.helpers.proto_helpers import get_stream_response_text
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest

AGGREGATOR_URL = "http://127.0.0.1:8063"


async def main() -> None:
    client = await create_client(AGGREGATOR_URL)
    request = SendMessageRequest(
        message=Message(
            message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[Part(text="노트북 20대, 서울->부산")]
        )
    )
    async for response in client.send_message(request):
        kind = response.WhichOneof("payload")
        text = get_stream_response_text(response)
        print(f"[{kind}] {text}")


if __name__ == "__main__":
    asyncio.run(main())
