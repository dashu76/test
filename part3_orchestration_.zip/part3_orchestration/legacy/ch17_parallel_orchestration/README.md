# Ch17 병렬 오케스트레이션

| 파일 | 역할 |
|---|---|
| `quote_agent_a.py` / `quote_agent_b.py` / `quote_agent_c.py` | 물류사 A·B·C 견적 에이전트 (8060, 8061, 8062) |
| `quote_aggregator.py` | 세 곳에 동시에 묻는 집계 에이전트 (8063) |
| `discovery_lib.py` | `discover_all()` 후보 발견 |
| `a2a_result.py` | Ch12 결과 수신기 복사본 |
| `quote_contract.py` | Ch16 견적 계약 |
| `parallel_policy.py` | 시간 제한·계약·납기 검사를 묶은 `ask_valid_quote()` |
| `parallel_policy_check.py` | 서버 없이 정책 검사만 실행 |
| `client_demo.py` | 집계 에이전트에만 요청 |
| `slow_c_experiment.py` | 응답을 4초 늦추는 물류사 C (8062, 시간 초과 실험) |
| `state_check.py` | 최종 상태 확인 |
| `gather_demo.py` | 서버 없이 `asyncio.gather()`의 동시 실행·부분 실패 확인(17-01) |

```cmd
:: 터미널 1~3
uv run quote_agent_a.py
uv run quote_agent_b.py
uv run quote_agent_c.py
:: 터미널 4
uv run quote_aggregator.py
:: 터미널 5
uv run client_demo.py
```

- 일부 실패: 터미널 3(물류사 C)을 끈 뒤 `uv run client_demo.py`
- 시간 초과: 터미널 3에서 `uv run slow_c_experiment.py` 후 `uv run client_demo.py`
- 전체 실패: A·B·C를 모두 끈 뒤 `uv run state_check.py --port 8063 --state failed`
- 서버 없이: `uv run gather_demo.py`, `uv run parallel_policy_check.py`
