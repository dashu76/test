# 파일명: quote_aggregator.py
"""Quote Aggregator -- 포트 8063. 이 폴더의 핵심 파일.

Ch14의 Router Agent와 뿌리는 같지만 결정적으로 다른 점이 하나 있다. Router는 후보 중
**하나**를 찾아 위임했다(`find_agent_with_skill`이 첫 번째 일치를 찾으면 즉시 멈춘다). 이
파일은 살아 있는 후보 **전부**에게 동시에 요청을 보내고, 그 결과를 한데 모은다.

또 하나 다른 점 -- 이번에는 discover_all()을 매 요청마다 다시 부르지 않는다. 첫 요청이 올 때
한 번만 후보를 찾아 카드를 캐시해 둔다. 그래야 "발견할 때는 살아 있었지만 지금은 죽어 있는"
상황을 실습에서 재현할 수 있다 -- Ch15에서 배송 조회 에이전트를 나중에 껐던 것과 같은 구조다.
"""

import asyncio
import uuid

import uvicorn
from fastapi import FastAPI

from a2a.client import create_client
from a2a.helpers.proto_helpers import new_task_from_user_message, new_text_artifact
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    Message,
    Part,
    Role,
    SendMessageRequest,
    TaskState,
)
from discovery_lib import discover_all
from a2a_result import receive_result
from parallel_policy import ask_valid_quote

CANDIDATES = ["http://127.0.0.1:8060", "http://127.0.0.1:8061", "http://127.0.0.1:8062"]


class QuoteAggregator:
    def __init__(self, candidates: list[str]) -> None:
        self.candidates = candidates
        self.cards: dict[str, AgentCard] = {}

    async def _ensure_discovered(self) -> None:
        if not self.cards:
            self.cards = await discover_all(self.candidates)

    async def _ask_one(self, name: str, card: AgentCard, order_desc: str, context_id: str) -> dict:
        client = await create_client(card)
        request = SendMessageRequest(
            message=Message(
                message_id=str(uuid.uuid4()),
                context_id=context_id,
                role=Role.ROLE_USER,
                parts=[Part(text=order_desc)],
            )
        )
        result = await receive_result(client, request)
        result.require_completed()
        data_list = result.data()
        if len(data_list) != 1 or not isinstance(data_list[0], dict):
            raise ValueError(f"{name}: 견적 결과는 JSON 객체 하나여야 한다")
        return data_list[0]

    async def invoke(self, order_desc: str, context_id: str) -> str:
        await self._ensure_discovered()
        if not self.cards:
            raise RuntimeError("연결 가능한 물류사 에이전트를 하나도 찾지 못했다")

        names = list(self.cards.keys())
        timeout_s = 2.0  # 발견 이후 각 병렬 조회의 응답 타임아웃
        max_eta_days = 4  # 이번 주문의 납기 조건
        results = await asyncio.gather(
            *(ask_valid_quote(self._ask_one, name, self.cards[name],
                             order_desc, context_id, timeout_s, max_eta_days)
              for name in names),
            return_exceptions=True,
        )

        succeeded: list[dict] = []
        failed: list[tuple[str, Exception]] = []
        for name, result in zip(names, results):
            if isinstance(result, asyncio.CancelledError):
                raise result  # 사용자/상위 작업의 취소를 성공 결과로 분류하지 않는다
            if isinstance(result, Exception):
                failed.append((name, result))
            else:
                succeeded.append(result)

        if not succeeded:
            raise RuntimeError(f"모든 물류사 조회가 실패했다: {[n for n, _ in failed]}")

        best = min(succeeded, key=lambda q: q["price_krw"])
        # 표현: 응답을 받아 검증했고 납기를 충족한 업체 중 최저가

        lines = [f"{len(succeeded)}곳 응답 성공, {len(failed)}곳 실패"]
        for q in sorted(succeeded, key=lambda q: q["price_krw"]):
            lines.append(f"  - {q['carrier']}: {q['price_krw']:,.0f}원 / {q['eta_days']:.0f}일")
        for name, err in failed:
            lines.append(f"  - {name}: 실패 ({err})")
        lines.append(f"검증·납기 충족 응답 중 최저가 선택: {best['carrier']} ({best['price_krw']:,.0f}원)")
        return "\n".join(lines)


class QuoteAggregatorExecutor(AgentExecutor):
    def __init__(self) -> None:
        self.agent = QuoteAggregator(CANDIDATES)

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)

        task_updater = TaskUpdater(event_queue, task.id, task.context_id)
        await task_updater.update_status(TaskState.TASK_STATE_WORKING)

        try:
            # 이 Task 자체의 context_id를, 아래로 뻗어나가는 3개의 병렬 하위 요청에도 그대로 물려준다.
            reply = await self.agent.invoke(context.get_user_input(), context_id=task.context_id)
        except Exception as e:
            await task_updater.update_status(TaskState.TASK_STATE_FAILED, message=None)
            print(f"[aggregator] 전체 실패: {e}")
            return

        artifact = new_text_artifact(name="comparison", text=reply)
        await task_updater.add_artifact(parts=list(artifact.parts))
        await task_updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


agent_card = AgentCard(
    name="Quote Aggregator",
    description="여러 물류사에 동시에 견적을 요청해 최저가를 골라주는 견적 비교 에이전트",
    version="0.1.0",
    default_input_modes=["text/plain"],
    default_output_modes=["text/plain"],
    capabilities=AgentCapabilities(streaming=True),
    supported_interfaces=[
        AgentInterface(url="http://127.0.0.1:8063/", protocol_binding="JSONRPC", protocol_version="1.0")
    ],
    skills=[
        AgentSkill(
            id="compare-quotes",
            name="compare-quotes",
            description="여러 물류사에게 동시에 견적을 요청해 비교한다",
            input_modes=["text/plain"],
            output_modes=["text/plain"],
        )
    ],
)

request_handler = DefaultRequestHandler(
    agent_executor=QuoteAggregatorExecutor(),
    task_store=InMemoryTaskStore(),
    agent_card=agent_card,
)

app = FastAPI()
add_a2a_routes_to_fastapi(
    app,
    agent_card_routes=create_agent_card_routes(agent_card),
    jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url="/"),
)

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8063, log_level="warning")
