# 파일명: parallel_policy.py
import asyncio
from quote_contract import validate_quote


async def ask_valid_quote(ask_one, name, card, order_desc, context_id,
                          timeout_s, max_eta_days):
    try:
        raw = await asyncio.wait_for(
            ask_one(name, card, order_desc, context_id), timeout=timeout_s
        )
    except TimeoutError as exc:
        raise TimeoutError(f"{name}: 견적 응답 대기시간 초과") from exc
    quote = validate_quote(raw, order_desc)
    if quote.eta_days > max_eta_days:
        raise ValueError(f"{name}: 요청 납기 {max_eta_days}일 초과")
    return quote.model_dump()
