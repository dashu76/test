# 파일명: quote_agent_a.py
"""물류사 A -- 포트 8060. Ch16의 견적 에이전트와 같은 뼈대로, 견적을 data Part(JSON)로 돌려준다."""

import uvicorn
from fastapi import FastAPI

from a2a.helpers.proto_helpers import new_data_artifact, new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import AgentCapabilities, AgentCard, AgentInterface, AgentSkill, TaskState

CARRIER, PORT, PRICE, DAYS = "물류사 A", 8060, 42000, 3


class QuoteAgent:
    async def invoke(self, order_desc: str) -> dict:
        return {"carrier": CARRIER, "order": order_desc, "price_krw": PRICE, "eta_days": DAYS}


class QuoteAgentExecutor(AgentExecutor):
    def __init__(self) -> None:
        self.agent = QuoteAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        task_updater = TaskUpdater(event_queue, task.id, task.context_id)
        await task_updater.update_status(TaskState.TASK_STATE_WORKING)
        quote = await self.agent.invoke(context.get_user_input())
        artifact = new_data_artifact(name="quote", data=quote)
        await task_updater.add_artifact(parts=list(artifact.parts))
        await task_updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


agent_card = AgentCard(
    name=CARRIER,
    description=f"{CARRIER}의 배송 견적 에이전트",
    version="0.1.0",
    default_input_modes=["text/plain"],
    default_output_modes=["application/json"],
    capabilities=AgentCapabilities(streaming=True),
    supported_interfaces=[
        AgentInterface(url=f"http://127.0.0.1:{PORT}/", protocol_binding="JSONRPC", protocol_version="1.0")
    ],
    skills=[
        AgentSkill(
            id="quote", name="quote", description="주문 설명을 받아 배송 견적을 JSON으로 돌려준다",
            input_modes=["text/plain"], output_modes=["application/json"],
        )
    ],
)

request_handler = DefaultRequestHandler(
    agent_executor=QuoteAgentExecutor(), task_store=InMemoryTaskStore(), agent_card=agent_card,
)

app = FastAPI()
add_a2a_routes_to_fastapi(
    app,
    agent_card_routes=create_agent_card_routes(agent_card),
    jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url="/"),
)

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="warning")
