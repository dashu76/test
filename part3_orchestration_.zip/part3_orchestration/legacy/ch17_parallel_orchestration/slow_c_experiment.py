# 파일명: slow_c_experiment.py
"""원본 C 코드를 보존하고 실험 실행에서만 4초 지연을 적용한다."""
import asyncio
import time
import uvicorn
import quote_agent_c

original_invoke = quote_agent_c.QuoteAgent.invoke


async def delayed_invoke(self, order_desc):
    print(f"C 지연 시작: {time.monotonic():.3f}", flush=True)
    await asyncio.sleep(4)
    result = await original_invoke(self, order_desc)
    print(f"C 원격 계산 완료: {time.monotonic():.3f}", flush=True)
    return result


if __name__ == "__main__":
    quote_agent_c.QuoteAgent.invoke = delayed_invoke
    uvicorn.run(quote_agent_c.app, host="127.0.0.1", port=8062, log_level="warning")
