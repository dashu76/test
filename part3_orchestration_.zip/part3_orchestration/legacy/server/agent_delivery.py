# 파일명: agent_delivery.py
import os
import uvicorn
from fastapi import FastAPI

from a2a.helpers.proto_helpers import new_task_from_user_message, new_text_artifact
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    TaskState, Message, Part, Role,
)


class DeliveryAgent:
    async def invoke(self, text: str) -> str:
        orders = {
            "ORDER-1001": "출고 완료 · 배송 중 · 도착 예정 2026-09-03",
            "ORDER-1002": "통관 대기 · 영업일 기준 2일 추가 소요",
        }
        order_no = text.strip()
        if order_no not in orders:
            # 없는 주문도 "조회는 끝났고 결과가 없다"는 업무 결과다. Task 실패와 구분한다(Ch08).
            return f"[{order_no}] 조회 결과 없음: 등록된 주문이 없습니다"
        return f"[{order_no}] 상태: {orders[order_no]}"


class DeliveryAgentExecutor(AgentExecutor):
    def __init__(self) -> None:
        self.agent = DeliveryAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)

        task_updater = TaskUpdater(event_queue, task.id, task.context_id)
        await task_updater.update_status(TaskState.TASK_STATE_WORKING)

        forced = os.getenv("DELIVERY_FORCE_STATE", "")
        if forced in ("failed", "input_required"):
            state = (TaskState.TASK_STATE_FAILED if forced == "failed"
                     else TaskState.TASK_STATE_INPUT_REQUIRED)
            text = "배송 조회 실패 실험" if forced == "failed" else "주문번호 확인이 필요합니다"
            await task_updater.update_status(
                state, message=Message(role=Role.ROLE_AGENT, parts=[Part(text=text)])
            )
            return
        reply = await self.agent.invoke(context.get_user_input())

        artifact = new_text_artifact(name="reply", text=reply)
        await task_updater.add_artifact(parts=list(artifact.parts))
        await task_updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("취소를 지원하지 않습니다")


agent_card = AgentCard(
    name="K-Logistics 배송 조회",
    description="주문번호로 배송 상태를 조회하는 물류 파트너",
    version="0.1.0",
    default_input_modes=["text/plain"],
    default_output_modes=["text/plain"],
    capabilities=AgentCapabilities(streaming=True),
    supported_interfaces=[
        AgentInterface(url="http://127.0.0.1:8099/", protocol_binding="JSONRPC", protocol_version="1.0")
    ],
    skills=[
        AgentSkill(
            id="check-delivery",
            name="check-delivery",
            description="주문번호에 해당하는 배송 상태를 반환한다",
            input_modes=["text/plain"],
            output_modes=["text/plain"],
        )
    ],
)

request_handler = DefaultRequestHandler(
    agent_executor=DeliveryAgentExecutor(),
    task_store=InMemoryTaskStore(),
    agent_card=agent_card,
)

app = FastAPI()
add_a2a_routes_to_fastapi(
    app,
    agent_card_routes=create_agent_card_routes(agent_card),
    jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url="/"),
)

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8099, log_level="warning")
