# 파일명: agent_procurement_router.py
import uuid

from a2a.client import create_client
from a2a_result import receive_result
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest
from discovery_lib import find_agent_with_skill

CANDIDATES = ["http://127.0.0.1:8099", "http://127.0.0.1:8098"]


class ProcurementRouterAgent:
    """스스로 일하지 않고, 배송 조회가 필요하면 'check-delivery' 스킬을 가진 에이전트를 찾아 위임한다."""

    async def invoke(self, text: str) -> str:
        card = await find_agent_with_skill(CANDIDATES, "check-delivery")
        if card is None:
            raise RuntimeError("check-delivery 스킬을 가진 에이전트를 찾지 못했다")

        client = await create_client(card)
        request = SendMessageRequest(
            message=Message(
                message_id=str(uuid.uuid4()),
                role=Role.ROLE_USER,
                parts=[Part(text=text)],
            )
        )
        result = await receive_result(client, request)
        result.require_completed()
        return f"[구매 라우터 -> {card.name}] {result.text()}"


from a2a.helpers.proto_helpers import new_task_from_user_message, new_text_artifact
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import TaskState


class ProcurementRouterAgentExecutor(AgentExecutor):
    def __init__(self) -> None:
        self.agent = ProcurementRouterAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)

        task_updater = TaskUpdater(event_queue, task.id, task.context_id)
        await task_updater.update_status(TaskState.TASK_STATE_WORKING)

        try:
            reply = await self.agent.invoke(context.get_user_input())
        except Exception as e:
            await task_updater.update_status(TaskState.TASK_STATE_FAILED, message=None)
            print(f"[구매 라우터] 위임 실패: {e}")
            return

        artifact = new_text_artifact(name="reply", text=reply)
        await task_updater.add_artifact(parts=list(artifact.parts))
        await task_updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("취소를 지원하지 않습니다")

import uvicorn
from fastapi import FastAPI
from a2a.types.a2a_pb2 import AgentCard, AgentSkill, AgentCapabilities, AgentInterface
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore

agent_card = AgentCard(
    name="K정밀웍스 구매 라우터",
    description="배송 조회 요청을 물류 파트너에게 위임한다",
    version="0.1.0",
    default_input_modes=["text/plain"],
    default_output_modes=["text/plain"],
    capabilities=AgentCapabilities(streaming=True),
    supported_interfaces=[
        AgentInterface(url="http://127.0.0.1:8097/", protocol_binding="JSONRPC", protocol_version="1.0")
    ],
    skills=[
        AgentSkill(
            id="route-delivery-inquiry",
            name="route-delivery-inquiry",
            description="배송 조회를 물류 파트너에게 위임해 결과를 반환한다",
            input_modes=["text/plain"],
            output_modes=["text/plain"],
        )
    ],
)

request_handler = DefaultRequestHandler(
    agent_executor=ProcurementRouterAgentExecutor(),
    task_store=InMemoryTaskStore(),
    agent_card=agent_card,
)

app = FastAPI()
add_a2a_routes_to_fastapi(
    app,
    agent_card_routes=create_agent_card_routes(agent_card),
    jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url="/"),
)

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8097, log_level="warning")
