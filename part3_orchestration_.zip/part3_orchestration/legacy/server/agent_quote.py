# 파일명: agent_quote.py
import uvicorn
from fastapi import FastAPI

from a2a.helpers.proto_helpers import new_task_from_user_message, new_text_artifact
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    TaskState,
)


class QuoteAgent:
    async def invoke(self, text: str) -> str:
        return "견적 42,000원 · 3일"


class QuoteAgentExecutor(AgentExecutor):
    def __init__(self) -> None:
        self.agent = QuoteAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)

        task_updater = TaskUpdater(event_queue, task.id, task.context_id)
        await task_updater.update_status(TaskState.TASK_STATE_WORKING)

        reply = await self.agent.invoke(context.get_user_input())

        artifact = new_text_artifact(name="reply", text=reply)
        await task_updater.add_artifact(parts=list(artifact.parts))
        await task_updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("취소를 지원하지 않습니다")


agent_card = AgentCard(
    name="K-Logistics 운임 견적",
    description="주문 설명을 받아 고정 규칙으로 운임을 안내하는 물류 파트너",
    version="0.1.0",
    default_input_modes=["text/plain"],
    default_output_modes=["text/plain"],
    capabilities=AgentCapabilities(streaming=True),
    supported_interfaces=[
        AgentInterface(url="http://127.0.0.1:8098/", protocol_binding="JSONRPC", protocol_version="1.0")
    ],
    skills=[
        AgentSkill(
            id="quote",
            name="quote",
            description="주문 설명을 받아 운임 견적을 반환한다",
            input_modes=["text/plain"],
            output_modes=["text/plain"],
        )
    ],
)

request_handler = DefaultRequestHandler(
    agent_executor=QuoteAgentExecutor(),
    task_store=InMemoryTaskStore(),
    agent_card=agent_card,
)

app = FastAPI()
add_a2a_routes_to_fastapi(
    app,
    agent_card_routes=create_agent_card_routes(agent_card),
    jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url="/"),
)

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8098, log_level="warning")
