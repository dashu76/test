# 파일명: client_demo.py
import asyncio
import uuid

from a2a.client import create_client
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest
from pydantic import ValidationError

from a2a_result import receive_result
from quote_contract import validate_quote


async def fetch_quote(url: str, order_desc: str) -> dict:
    client = await create_client(url)
    request = SendMessageRequest(
        message=Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[Part(text=order_desc)])
    )
    result = await receive_result(client, request)
    result.require_completed()
    data_list = result.data()
    if len(data_list) != 1 or not isinstance(data_list[0], dict):
        raise ValueError("견적 결과는 JSON 객체 하나여야 한다")
    return data_list[0]


async def ask_and_validate(label: str, url: str) -> None:
    print(f"\n--- {label} ---")
    raw = await fetch_quote(url, "노트북 20대, 서울->부산")
    print("받은 원본 데이터:", raw)

    try:
        quote = validate_quote(raw, "노트북 20대, 서울->부산")
    except ValidationError as e:
        print("검증 실패 -- 이 응답은 우리가 기대한 모양이 아니다:")
        for err in e.errors():
            print(f"  - {err['loc']}: {err['msg']}")
        return

    except ValueError as e:
        print("검증 실패 --", e)
        return

    print(f"검증 통과 -- {quote.carrier}: {quote.price_krw:,}원 / {quote.eta_days}일")


async def main() -> None:
    await ask_and_validate("물류사 A (우리가 기대한 모양)", "http://127.0.0.1:8050")
    await ask_and_validate("물류사 B (다른 회사, 다른 필드 이름)", "http://127.0.0.1:8051")


if __name__ == "__main__":
    asyncio.run(main())
