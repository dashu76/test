# 파일명: contract_check.py
from quote_contract import validate_quote

order = "노트북 20대, 서울->부산"
normal = dict(carrier="A", order=order, price_krw=42000, eta_days=3)
for label, raw in [
    ("정상", normal),
    ("다른 주문", {**normal, "order": "다른 주문"}),
    ("음수 금액", {**normal, "price_krw": -1}),
]:
    try:
        validate_quote(raw, order)
        print(label, "통과")
    except ValueError:
        print(label, "거부")
