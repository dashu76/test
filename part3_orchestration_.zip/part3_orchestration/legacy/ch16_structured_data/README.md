# Ch16 구조화된 데이터 교환

| 파일 | 역할 |
|---|---|
| `structured_quote_agent.py` | 견적 dict를 DataPart로 보내는 서버 (8050) |
| `mismatched_quote_agent.py` | 같은 스킬이지만 필드 이름이 다른 서버 (8051) |
| `quote_contract.py` | Pydantic `Quote` 계약과 `validate_quote()` |
| `a2a_result.py` | Ch12 결과 수신기 복사본 |
| `client_demo.py` | 두 서버에서 받아 계약으로 검증 |
| `contract_check.py` | 서버 없이 계약 검사만 실행 |
| `float_check.py` | data Part를 거친 숫자(정수·큰 정수)가 어떻게 바뀌는지 확인 — 서버 필요 없음 |

```cmd
:: 터미널 1
uv run structured_quote_agent.py
:: 터미널 2
uv run mismatched_quote_agent.py
:: 터미널 3
uv run client_demo.py
```

서버 없이:

```cmd
uv run contract_check.py
uv run float_check.py
```
