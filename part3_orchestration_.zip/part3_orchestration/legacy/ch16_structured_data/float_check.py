# 파일명: float_check.py
from a2a.helpers.proto_helpers import get_data_parts, new_data_part

sent = {"price_krw": 42000, "eta_days": 3, "big_id": 9007199254740993}
part = new_data_part(sent)  # 서버가 Artifact에 싣는 것과 같은 data Part
received = get_data_parts([part])[0]

for key, value in sent.items():
    print(f"{key}: 보냄 {value!r} -> 받음 {received[key]!r}")
print("big_id 그대로인가?", int(received["big_id"]) == sent["big_id"])
