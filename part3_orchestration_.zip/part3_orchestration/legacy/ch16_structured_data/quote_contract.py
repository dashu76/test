# 파일명: quote_contract.py
from pydantic import BaseModel, Field


class Quote(BaseModel):
    carrier: str
    order: str
    price_krw: int = Field(ge=0)
    eta_days: int = Field(ge=0)


def validate_quote(raw: dict, requested_order: str) -> Quote:
    quote = Quote.model_validate(raw)
    if quote.order != requested_order:
        raise ValueError("요청한 주문과 다른 견적이다")
    return quote
