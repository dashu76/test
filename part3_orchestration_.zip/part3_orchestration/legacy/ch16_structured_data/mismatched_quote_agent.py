# 파일명: mismatched_quote_agent.py
""""다른 회사가 만든" 견적 에이전트 -- 포트 8051.

structured_quote_agent.py(물류사 A)와 같은 스킬(quote)을 표방하지만, 필드 이름이 다르다.
이 파일의 목적은 버그가 아니라 **정상적인 상황**을 재현하는 것이다 -- A2A로 연결하는 상대는
우리가 만들지 않은, 우리 마음대로 필드 이름을 정할 수 없는 다른 회사의 시스템이다.
"물류사 B"는 자기들 방식대로 한글 키("가격", "소요일")를 쓰기로 정했을 뿐이고,
그건 이 에이전트 입장에서는 전혀 잘못이 아니다. 문제가 되는지 아닌지는 이걸 받는 쪽
(client_demo.py의 검증)에서 결정된다.
"""

import uvicorn
from fastapi import FastAPI

from a2a.helpers.proto_helpers import new_data_artifact, new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    TaskState,
)


class MismatchedQuoteAgent:
    async def invoke(self, order_desc: str) -> dict:
        # 물류사 A는 price_krw / eta_days를 쓰지만, 이 회사는 자기들 방식대로 짓는다.
        return {"업체": "물류사 B", "주문": order_desc, "가격": 39500, "소요일": 4}


class MismatchedQuoteAgentExecutor(AgentExecutor):
    def __init__(self) -> None:
        self.agent = MismatchedQuoteAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)

        task_updater = TaskUpdater(event_queue, task.id, task.context_id)
        await task_updater.update_status(TaskState.TASK_STATE_WORKING)

        quote = await self.agent.invoke(context.get_user_input())

        artifact = new_data_artifact(name="quote", data=quote)
        await task_updater.add_artifact(parts=list(artifact.parts))
        await task_updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported")


agent_card = AgentCard(
    name="물류사 B",
    description="배송 견적을 구조화된 데이터(JSON)로 돌려주는 예제 에이전트 (물류사 A와 다른 회사)",
    version="0.1.0",
    default_input_modes=["text/plain"],
    default_output_modes=["application/json"],
    capabilities=AgentCapabilities(streaming=True),
    supported_interfaces=[
        AgentInterface(url="http://127.0.0.1:8051/", protocol_binding="JSONRPC", protocol_version="1.0")
    ],
    skills=[
        AgentSkill(
            id="quote",
            name="quote",
            description="주문 설명을 받아 배송 견적을 JSON으로 돌려준다",
            input_modes=["text/plain"],
            output_modes=["application/json"],
        )
    ],
)

request_handler = DefaultRequestHandler(
    agent_executor=MismatchedQuoteAgentExecutor(),
    task_store=InMemoryTaskStore(),
    agent_card=agent_card,
)

app = FastAPI()
add_a2a_routes_to_fastapi(
    app,
    agent_card_routes=create_agent_card_routes(agent_card),
    jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url="/"),
)

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8051, log_level="warning")
