> **이 문서는 기존 실습(Ch13~17) 안내입니다.** 코드는 이 legacy/ 폴더에 있고 수정하지 않습니다. 명령은 모두 이 폴더 아래에서 실행하세요 (환경은 상위 폴더의 pyproject.toml·.venv를 씁니다).
> 포트는 99xx에서 80xx로 바뀌었습니다 (배송 조회 8099 · 이송 견적 8098 · 구매 라우터 8097 · Ch16 8050/8051 · Ch17 8060~8063 · 관제 허브 8000).
> 새 업무 시스템은 상위 폴더의 README.md를 보세요.

# Part 3 — 여러 에이전트 오케스트레이션 (Ch13~17)

```text
part3_orchestration/
├── pyproject.toml · uv.lock · .python-version · check_install.py · .venv/   (requirements.txt는 참고용)
├── server/                          # Ch13~15의 미니 시스템(K정밀웍스 구매 라우터 + K-Logistics 에이전트 둘)
│   ├── agent_delivery.py            # K-Logistics 배송 조회(8099, check-delivery) — Ch13·14·15
│   ├── agent_quote.py               # K-Logistics 운임 견적(8098, quote) — Ch13·14·15
│   ├── agent_procurement_router.py  # 구매 라우터(8097) — Ch14·15
│   ├── discovery_lib.py             # 라우터가 쓰는 스킬 탐색(Ch13과 같은 코드)
│   └── a2a_result.py                # 라우터가 쓰는 결과 수신기(Ch12와 같은 코드)
├── ch13_discovery/                  # discover.py, discovery_lib.py
├── ch14_delegation/                 # call_router.py, state_check.py, a2a_result.py
├── ch15_failure_retry/              # state_check.py, a2a_result.py, idempotency_test.py, get_task_test.py, business_key_demo.py
├── ch16_structured_data/            # 이 장 전용 서버 8050·8051과 클라이언트
└── ch17_parallel_orchestration/     # 이 장 전용 서버 8060~8063과 클라이언트
```

`a2a_result.py`(Ch12), `discovery_lib.py`(Ch13), `state_check.py`(Ch14)는 쓰는 폴더마다 같은 파일을 둡니다. 새로 배우는 코드가 아니라 앞에서 본 코드를 그 폴더에서 import하려고 복사한 것입니다.

## 준비

```cmd
cd a2a-lab\part3_orchestration
uv sync
uv run check_install.py
```

## Ch13

```cmd
:: 터미널 1·2 (part3_orchestration\server에서)
uv run agent_delivery.py
uv run agent_quote.py
:: 터미널 3
cd ch13_discovery
uv run discover.py
```

## Ch14 — 터미널 1·2는 그대로

```cmd
:: 터미널 3 (server에서)
uv run agent_procurement_router.py
:: 터미널 4
cd ch14_delegation
uv run call_router.py
uv run state_check.py
```

하위 작업 실패·입력 대기 실험: 터미널 1의 배송 조회를 끄고 `set DELIVERY_FORCE_STATE=failed`(또는 `input_required`) 후 `uv run agent_delivery.py`로 다시 띄운 뒤 `uv run state_check.py --state failed`. 끝나면 `set DELIVERY_FORCE_STATE=` 후 다시 띄웁니다.

## Ch15

```cmd
cd ch15_failure_retry
:: 실험 1 — 터미널 1의 배송 조회를 Ctrl+C로 끈 상태에서
uv run state_check.py --state failed
:: 배송 조회를 다시 띄운 뒤
uv run state_check.py
:: 실험 2 — 배송 조회(8099)만 있으면 됨
uv run idempotency_test.py
uv run get_task_test.py
:: 업무키 — 서버 없이
uv run business_key_demo.py
```

Ch16 전에 터미널 1~3의 서버를 모두 끕니다.

## Ch16

```cmd
cd ch16_structured_data
:: 터미널 1, 2
uv run structured_quote_agent.py
uv run mismatched_quote_agent.py
:: 터미널 3
uv run client_demo.py
:: 서버 없이
uv run contract_check.py
uv run float_check.py
```

## Ch17

```cmd
cd ch17_parallel_orchestration
:: 서버 없이
uv run gather_demo.py
uv run parallel_policy_check.py
:: 터미널 1~4
uv run quote_agent_a.py
uv run quote_agent_b.py
uv run quote_agent_c.py
uv run quote_aggregator.py
:: 터미널 5
uv run client_demo.py
:: C를 끄고 다시 / 느린 C(slow_c_experiment.py)로 바꿔 다시
uv run client_demo.py
:: A·B·C를 모두 끈 뒤
uv run state_check.py --port 8063 --state failed
```

## 17-04 [선택] — 같은 결과를 웹 화면으로 (`obs/`)

실습 파일은 그대로 두고, 실행할 파일 앞에 `..\obs\obs_run.py`만 붙입니다. 관제 허브를 먼저 띄우고 브라우저로 http://127.0.0.1:8000 을 엽니다.

```cmd
:: 터미널 0
cd obs
uv run obs_hub.py
:: 터미널 1~3 (server에서)
uv run ..\obs\obs_run.py agent_delivery.py
uv run ..\obs\obs_run.py agent_quote.py
uv run ..\obs\obs_run.py agent_procurement_router.py
:: 터미널 4
cd ch14_delegation
uv run ..\obs\obs_run.py call_router.py
```

- `obs.py` 이벤트 발행(`A2A_OBS_URL`이 없으면 아무것도 안 함), `obs_run.py` SDK 네 곳 덧씌우기, `obs_hub.py` 허브(POST /events, GET /stream SSE, GET /events.jsonl, 2초마다 Agent Card로 켜짐·꺼짐 판단), `obs_ui.html` 서버 뷰·클라이언트 뷰.
- `http://127.0.0.1:8000/?snapshot=1` 은 실시간 연결 없이 지금까지의 기록만 그립니다(다시 보기). `&select=<taskId 앞부분>`으로 Task 하나를 강조할 수 있습니다.
- 관찰을 켜도 콘솔 출력은 첫 줄 `[관찰] …`만 늘고 같습니다(2026-10-07 Ch13~Ch17 실행 여덟 가지로 확인).
