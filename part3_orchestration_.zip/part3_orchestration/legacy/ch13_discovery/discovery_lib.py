# 파일명: discovery_lib.py
# discovery_lib.py -- Ch14에서도 그대로 재사용할 탐색 함수
import httpx
from a2a.client import A2ACardResolver
from a2a.types.a2a_pb2 import AgentCard


async def find_agent_with_skill(candidates: list[str], skill_id: str) -> AgentCard | None:
    """후보 주소 목록을 훑어, skill_id를 가진 첫 번째 에이전트의 Agent Card를 돌려준다."""
    async with httpx.AsyncClient() as httpx_client:
        for base_url in candidates:
            resolver = A2ACardResolver(httpx_client, base_url)
            try:
                card = await resolver.get_agent_card()
            except Exception as e:
                print(f"  [skip] {base_url} 조회 실패: {e}")
                continue
            skill_ids = [s.id for s in card.skills]
            print(f"  [check] {base_url} -> name={card.name!r} skills={skill_ids}")
            if skill_id in skill_ids:
                return card
    return None
