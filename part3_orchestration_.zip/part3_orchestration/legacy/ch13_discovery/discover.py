# 파일명: discover.py
import asyncio
import uuid

from a2a.client import create_client
from a2a.helpers.proto_helpers import get_stream_response_text
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest
from discovery_lib import find_agent_with_skill

CANDIDATES = ["http://127.0.0.1:8099", "http://127.0.0.1:8098"]


async def ask_via_discovery(skill_id: str, text: str) -> None:
    print(f"'{skill_id}' 스킬을 가진 에이전트를 찾는다:")
    card = await find_agent_with_skill(CANDIDATES, skill_id)
    if card is None:
        print("해당 스킬을 가진 에이전트를 찾지 못했다.")
        return

    target_url = card.supported_interfaces[0].url
    print(f"발견: {card.name} @ {target_url}")

    client = await create_client(card)
    request = SendMessageRequest(
        message=Message(message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[Part(text=text)])
    )
    async for response in client.send_message(request):
        out_text = get_stream_response_text(response)
        if out_text:
            print("결과:", out_text)
    print()


async def main() -> None:
    await ask_via_discovery("quote", "노트북 20대, 서울->부산")
    await ask_via_discovery("check-delivery", "ORDER-1001")


if __name__ == "__main__":
    asyncio.run(main())
