# 파일명: business_key_demo.py
import json
import sqlite3
from contextlib import closing
from tempfile import TemporaryDirectory
from pathlib import Path


def record_mock_payment(db_path, business_key, order_no, amount_krw):
    if not business_key or not order_no or type(amount_krw) is not int or amount_krw <= 0:
        raise ValueError("업무키·주문번호·양의 정수 금액이 필요합니다")
    payload = json.dumps([order_no, amount_krw], ensure_ascii=False)
    conn = sqlite3.connect(db_path, timeout=5)
    try:
        conn.execute("CREATE TABLE IF NOT EXISTS mock_payments "
                     "(business_key TEXT PRIMARY KEY, payload TEXT NOT NULL)")
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT payload FROM mock_payments WHERE business_key=?",
                           (business_key,)).fetchone()
        if row is not None:
            if row[0] != payload:
                raise ValueError("같은 업무키에 다른 지급 내용: 거부")
            result = "이미 기록됨"
        else:
            conn.execute("INSERT INTO mock_payments VALUES (?, ?)", (business_key, payload))
            result = "모의 지급 기록 1건 생성"
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    with TemporaryDirectory() as folder:
        db = str(Path(folder) / "payments.sqlite3")
        key = "K정밀웍스:ORDER-1001:receipt-payment:v1"
        print(record_mock_payment(db, key, "ORDER-1001", 360000))
        print(record_mock_payment(db, key, "ORDER-1001", 360000))
        try:
            record_mock_payment(db, key, "ORDER-1001", 9000)
        except ValueError as error:
            print(error)
        with closing(sqlite3.connect(db)) as conn:
            assert conn.execute("SELECT COUNT(*) FROM mock_payments").fetchone()[0] == 1
        print("확인: 장부에는 1건만 남음")
