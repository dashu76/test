# 파일명: idempotency_test.py
import asyncio
import uuid

from a2a.client import create_client
from a2a.helpers.proto_helpers import get_stream_response_text
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest


async def send(client, text: str, task_id: str | None = None) -> str | None:
    msg_kwargs = dict(
        message_id=str(uuid.uuid4()),
        role=Role.ROLE_USER,
        parts=[Part(text=text)],
    )
    if task_id:
        msg_kwargs["task_id"] = task_id
    request = SendMessageRequest(message=Message(**msg_kwargs))

    got_task_id = None
    try:
        async for response in client.send_message(request):
            kind = response.WhichOneof("payload")
            text_out = get_stream_response_text(response)
            print(f"  [{kind}] {text_out}")
            if response.HasField("task"):
                got_task_id = response.task.id
            elif response.HasField("status_update"):
                got_task_id = response.status_update.task_id
    except Exception as e:
        print(f"  !! 예외: {type(e).__name__}: {e}")
    return got_task_id


async def main() -> None:
    client = await create_client("http://127.0.0.1:8099")

    print("1) 존재하지 않는 임의의 task_id로 첫 요청을 보내면?")
    fake_id = str(uuid.uuid4())
    await send(client, "ORDER-1001", task_id=fake_id)

    print()
    print("2) task_id 없이 정상 요청 -> 완료된 task_id를 얻는다")
    real_id = await send(client, "ORDER-1001")
    print("   완료된 task_id:", real_id)

    print()
    print("3) 방금 완료된 task_id를 재사용해서 다시 보내면?")
    await send(client, "ORDER-1001", task_id=real_id)


if __name__ == "__main__":
    asyncio.run(main())
