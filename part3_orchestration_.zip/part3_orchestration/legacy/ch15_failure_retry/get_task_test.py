# 파일명: get_task_test.py
import asyncio
import uuid

from a2a.client import create_client
from a2a.types.a2a_pb2 import GetTaskRequest, Message, Part, Role, SendMessageRequest


async def main() -> None:
    client = await create_client("http://127.0.0.1:8099")

    request = SendMessageRequest(
        message=Message(
            message_id=str(uuid.uuid4()),
            role=Role.ROLE_USER,
            parts=[Part(text="ORDER-1001")],
        )
    )
    task_id = None
    async for response in client.send_message(request):
        if response.HasField("task"):
            task_id = response.task.id

    print("완료된 task_id:", task_id)

    task = await client.get_task(GetTaskRequest(id=task_id))
    print("get_task 결과 state:", task.status.state)
    print("get_task 결과 artifacts 수:", len(task.artifacts))


if __name__ == "__main__":
    asyncio.run(main())
