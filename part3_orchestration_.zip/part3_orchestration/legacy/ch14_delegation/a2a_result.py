# 파일명: a2a_result.py
from copy import deepcopy
from dataclasses import dataclass, field

from a2a.helpers.proto_helpers import get_data_parts
from a2a.types.a2a_pb2 import Artifact, Message, TaskState


def part_text(parts) -> str:
    return "".join(p.text for p in parts if p.WhichOneof("content") == "text")


@dataclass
class RemoteResult:
    task_id: str = ""
    context_id: str = ""
    state: int | None = None
    artifacts: dict[str, Artifact] = field(default_factory=dict)
    message: Message | None = None
    status_text: str = ""

    def require_completed(self) -> None:
        if self.message is not None and not self.task_id:
            return  # Task 없이 즉시 응답한 Message도 정상 경로다.
        if self.state != TaskState.TASK_STATE_COMPLETED:
            name = TaskState.Name(self.state) if self.state is not None else "NO_RESULT"
            raise RuntimeError(f"하위 작업을 완료 결과로 사용할 수 없습니다: {name}")

    def text(self) -> str:
        if self.message is not None and not self.task_id:
            return part_text(self.message.parts)
        return "\n".join(part_text(a.parts) for a in self.artifacts.values())

    def data(self) -> list:
        if self.message is not None and not self.task_id:
            return get_data_parts(self.message.parts)
        return [v for a in self.artifacts.values() for v in get_data_parts(a.parts)]


async def receive_result(client, request) -> RemoteResult:
    result = RemoteResult()
    stream = client.send_message(request)
    try:
        async for response in stream:
            kind = response.WhichOneof("payload")
            if kind == "message":
                if result.task_id:
                    raise ValueError("Task와 즉시 Message 응답이 섞였습니다")
                result.message = deepcopy(response.message)
            elif kind in ("task", "status_update", "artifact_update"):
                item = getattr(response, kind)
                task_id = item.id if kind == "task" else item.task_id
                if result.message is not None or (result.task_id and result.task_id != task_id):
                    raise ValueError("서로 다른 작업의 응답이 섞였습니다")
                result.task_id, result.context_id = task_id, item.context_id
                if kind == "task":
                    result.state = item.status.state
                    result.status_text = part_text(item.status.message.parts)
                    result.artifacts = {a.artifact_id: deepcopy(a) for a in item.artifacts}
                elif kind == "status_update":
                    result.state = item.status.state
                    result.status_text = part_text(item.status.message.parts)
                else:
                    artifact = item.artifact
                    key = artifact.artifact_id
                    if not key:
                        raise ValueError("artifact_id가 없는 결과물입니다")
                    if item.append:
                        if key not in result.artifacts:
                            raise ValueError("첫 조각 없이 append가 도착했습니다")
                        result.artifacts[key].parts.extend(artifact.parts)
                    else:
                        result.artifacts[key] = deepcopy(artifact)
                    # last_chunk는 이 Artifact의 끝이며 Task 완료 신호가 아니다.
            if kind == "status_update" and result.state in (
                TaskState.TASK_STATE_INPUT_REQUIRED,
                TaskState.TASK_STATE_AUTH_REQUIRED,
            ):
                break  # 재개 첫 Task 스냅샷이 아니라 새 대기 이벤트에서 멈춘다.
    finally:
        close = getattr(stream, "aclose", None)
        if close is not None:
            await close()
    if not result.task_id and result.message is None:
        raise RuntimeError("하위 에이전트가 작업이나 메시지를 반환하지 않았습니다")
    return result
