# 파일명: state_check.py
"""실제 서버의 상태와 완료 결과물 유무를 검증한다."""
import argparse
import asyncio
import uuid
from a2a.client import create_client
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest, TaskState
from a2a_result import receive_result


async def main(args):
    client = await create_client(f"http://127.0.0.1:{args.port}")
    result = await receive_result(client, SendMessageRequest(message=Message(
        message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[Part(text=args.text)])))
    name = TaskState.Name(result.state)
    print("상태:", name)
    print("결과물 수:", len(result.artifacts))
    print("상태 안내:", result.status_text)
    print("결과:", result.text())
    assert name == "TASK_STATE_" + args.state.upper()
    if args.state == "completed":
        result.require_completed()
        assert result.artifacts
    else:
        assert not result.artifacts
        try:
            result.require_completed()
        except RuntimeError as exc:
            print("완료 오인 방지:", exc)
        else:
            raise AssertionError("미완료 결과가 허용되었습니다")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8097)
    parser.add_argument("--text", default="ORDER-1001")
    parser.add_argument("--state", default="completed")
    asyncio.run(main(parser.parse_args()))
