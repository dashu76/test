# 파일명: call_router.py
import asyncio
import uuid

from a2a.client import create_client
from a2a.helpers.proto_helpers import get_stream_response_text
from a2a.types.a2a_pb2 import Message, Part, Role, SendMessageRequest


async def main() -> None:
    client = await create_client("http://127.0.0.1:8097")
    request = SendMessageRequest(
        message=Message(
            message_id=str(uuid.uuid4()),
            role=Role.ROLE_USER,
            parts=[Part(text="ORDER-1001")],
        )
    )
    async for response in client.send_message(request):
        kind = response.WhichOneof("payload")
        text = get_stream_response_text(response)
        print(f"[{kind}] {text}")


if __name__ == "__main__":
    asyncio.run(main())
