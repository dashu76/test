# 파일명: obs_hub.py
"""17-04: 관찰 이벤트를 모아 웹 화면으로 보여 주는 관제 허브 (http://127.0.0.1:8000).

POST /events      에이전트·클라이언트가 이벤트를 보낸다 (obs.py)
GET  /stream      이벤트를 실시간으로 내보낸다 (SSE) — 웹 화면이 구독한다
GET  /events.jsonl 지금까지 받은 이벤트 전체
GET  /            서버 뷰 · 클라이언트 뷰 화면 (obs_ui.html)
허브는 알게 된 에이전트 주소의 Agent Card를 2초마다 읽어, 응답이 끊기면 스스로 '꺼짐'으로 판단한다.
"""

import asyncio
import json
import time
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, PlainTextResponse
from sse_starlette.sse import EventSourceResponse

HERE = Path(__file__).resolve().parent
LOG = HERE / 'events.jsonl'
events = []          # 받은 이벤트 전체 (허브를 다시 켜면 비운다)
subscribers = set()  # 화면마다 하나씩 생기는 큐
agents = {}          # 주소 → {'online': True/False/None}


def publish(event):
    events.append(event)
    with LOG.open('a', encoding='utf-8') as log:
        log.write(json.dumps(event, ensure_ascii=False) + '\n')
    for q in subscribers:
        q.put_nowait(event)


def watch(url):
    if url and url.startswith('http') and url not in agents:
        agents[url] = {'online': None}


def hub_event(type_, url, payload):
    publish({'v': 1, 'eventId': f'hub-{len(events) + 1}', 'ts': int(time.time() * 1000),
             'agentId': url, 'side': 'hub', 'type': type_, 'taskId': '', 'contextId': '',
             'process': 'obs_hub', 'payload': payload})


async def check(http, url, info):
    try:
        response = await http.get(url + '/.well-known/agent-card.json')
        response.raise_for_status()
        card, online, reason = response.json(), True, ''
    except Exception as error:
        card, online, reason = None, False, type(error).__name__
    if online != info['online']:
        info['online'] = online
        if online:
            skills = [s.get('id') for s in card.get('skills', [])]
            hub_event('agent.online', url, {'name': card.get('name', url), 'skills': skills})
        else:
            hub_event('agent.offline', url, {'reason': reason})


async def heartbeat():
    """에이전트가 신고하지 않아도 허브가 Agent Card를 읽어 온라인 여부를 파생한다.
    꺼진 주소는 응답을 기다리느라 느리므로, 모든 주소를 동시에 확인한다."""
    async with httpx.AsyncClient(timeout=1) as http:
        while True:
            await asyncio.gather(*(check(http, url, info) for url, info in list(agents.items())))
            await asyncio.sleep(2)


@asynccontextmanager
async def lifespan(app):
    LOG.write_text('', encoding='utf-8')
    task = asyncio.create_task(heartbeat())
    yield
    task.cancel()


app = FastAPI(lifespan=lifespan)


@app.post('/events')
async def receive(event: dict):
    payload = event.get('payload', {})
    if event.get('side') == 'server':
        watch(event.get('agentId'))
    watch(payload.get('to'))
    watch(payload.get('url'))
    publish(event)
    return {'ok': True}


@app.get('/stream')
async def stream(request: Request):
    q = asyncio.Queue()
    for event in events:          # 화면을 늦게 열어도 지금까지의 기록부터 보여 준다
        q.put_nowait(event)
    subscribers.add(q)

    async def generate():
        try:
            while not await request.is_disconnected():
                try:
                    event = await asyncio.wait_for(q.get(), timeout=15)
                except asyncio.TimeoutError:
                    continue
                yield {'data': json.dumps(event, ensure_ascii=False)}
        finally:
            subscribers.discard(q)

    return EventSourceResponse(generate())


@app.get('/events.jsonl')
async def dump():
    return PlainTextResponse(''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in events))


@app.get('/')
async def page():
    return FileResponse(HERE / 'obs_ui.html')


if __name__ == '__main__':
    print('관제 허브: http://127.0.0.1:8000 (브라우저로 여세요)', flush=True)
    uvicorn.run(app, host='127.0.0.1', port=8000, log_level='warning')
