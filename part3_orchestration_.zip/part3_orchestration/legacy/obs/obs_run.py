# 파일명: obs_run.py
"""17-04: 실습 파일을 한 줄도 고치지 않고 관찰 이벤트를 덧씌워 실행한다.

사용:  python ..\\obs\\obs_run.py agent_delivery.py [원래 인자 ...]
서버 쪽은 Task 상태가 바뀔 때마다, 클라이언트 쪽은 요청을 보내고 응답을 받을 때마다 허브에 알린다.
"""

import os
import runpy
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import obs  # noqa: E402

TERMINAL = {'TASK_STATE_COMPLETED', 'TASK_STATE_FAILED', 'TASK_STATE_CANCELED', 'TASK_STATE_REJECTED'}


def part_text(parts):
    return ''.join(p.text for p in parts if p.WhichOneof('content') == 'text')


def short(text, size=160):
    text = ' '.join(text.split())
    return text if len(text) <= size else text[:size] + '…'


def watch_server():
    """① 서버 주소: uvicorn.run()이 불릴 때 이 프로세스가 어느 주소의 에이전트인지 기록한다."""
    import uvicorn

    original = uvicorn.run

    def run(app, *args, **kwargs):
        obs.AGENT = f"http://{kwargs.get('host', '127.0.0.1')}:{kwargs.get('port', 8000)}"
        obs.emit('agent.started', 'server', obs.AGENT)
        return original(app, *args, **kwargs)

    uvicorn.run = run


def watch_tasks():
    """② 서버 쪽: Task가 저장될 때마다 상태를 비교해, 바뀌었으면 알린다."""
    from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
    from a2a.types.a2a_pb2 import TaskState

    original = InMemoryTaskStore.save
    last_state = {}

    async def save(self, task, context):
        await original(self, task, context)
        state = TaskState.Name(task.status.state)
        before = last_state.get(task.id)
        if before is None:
            first = part_text(task.history[0].parts) if task.history else ''
            obs.emit('task.received', 'server', obs.AGENT, {'text': short(first)}, task.id, task.context_id)
        if before != state:
            payload = {'from': before, 'to': state}
            if state in TERMINAL or state.endswith('_REQUIRED'):
                result = '\n'.join(part_text(a.parts) for a in task.artifacts)
                payload['result'] = short(result or part_text(task.status.message.parts))
            obs.emit('task.state', 'server', obs.AGENT, payload, task.id, task.context_id)
            last_state[task.id] = state

    InMemoryTaskStore.save = save


def watch_requests():
    """③ 클라이언트 쪽: send_message()가 돌려주는 응답 흐름을 그대로 넘기면서 하나씩 알린다."""
    import itertools

    from a2a.client.base_client import BaseClient
    from a2a.types.a2a_pb2 import TaskState

    original = BaseClient.send_message
    numbers = itertools.count(1)

    async def send_message(self, request, *, context=None):
        card = self._card
        to = card.supported_interfaces[0].url.rstrip('/') if card.supported_interfaces else ''
        request_id = f'{obs.ME}-{os.getpid()}-r{next(numbers)}'
        base = {'requestId': request_id, 'to': to, 'toName': card.name}
        obs.emit('request.sent', 'client', obs.who(), {**base, 'text': short(part_text(request.message.parts))})
        task_id = context_id = ''
        state = None
        finished = False
        try:
            async for response in original(self, request, context=context):
                kind = response.WhichOneof('payload')
                item = getattr(response, kind)
                if kind == 'task':
                    task_id, context_id, state = item.id, item.context_id, TaskState.Name(item.status.state)
                elif kind == 'status_update':
                    task_id, context_id, state = item.task_id, item.context_id, TaskState.Name(item.status.state)
                elif kind == 'artifact_update':
                    task_id, context_id = item.task_id, item.context_id
                else:
                    state = 'MESSAGE'
                obs.emit('request.event', 'client', obs.who(), {**base, 'kind': kind, 'state': state}, task_id, context_id)
                yield response
            finished = True
        except GeneratorExit:
            raise
        except BaseException as error:  # 호출한 쪽이 기다리다 취소한 경우(CancelledError)도 남긴다
            obs.emit('request.error', 'client', obs.who(), {**base, 'error': type(error).__name__}, task_id, context_id)
            raise
        finally:
            # 수신기가 INPUT_REQUIRED에서 먼저 멈춰도(12-02) 마지막 상태를 남긴다.
            obs.emit('request.done', 'client', obs.who(), {**base, 'state': state, 'stoppedEarly': not finished}, task_id, context_id)

    BaseClient.send_message = send_message


def watch_cards():
    """④ 발견: Agent Card를 읽을 때마다 성공·실패를 알린다(Ch13·Ch17)."""
    from a2a.client import A2ACardResolver

    original = A2ACardResolver.get_agent_card

    async def get_agent_card(self, *args, **kwargs):
        try:
            card = await original(self, *args, **kwargs)
        except Exception as error:
            obs.emit('card.failed', 'client', obs.who(), {'url': self.base_url, 'error': type(error).__name__})
            raise
        obs.emit('card.fetched', 'client', obs.who(),
                 {'url': self.base_url, 'name': card.name, 'skills': [s.id for s in card.skills]})
        return card

    A2ACardResolver.get_agent_card = get_agent_card


def main():
    if len(sys.argv) < 2:
        raise SystemExit('사용: python obs_run.py <실행할 파일.py> [인자 ...]')
    script = Path(sys.argv[1]).resolve()
    os.environ.setdefault('A2A_OBS_URL', 'http://127.0.0.1:8000')
    obs.start(script.stem)
    watch_server()
    watch_tasks()
    watch_requests()
    watch_cards()
    print(f"[관찰] {script.name} → {os.environ['A2A_OBS_URL']}", flush=True)
    # 원래 파일을 그 폴더에서 직접 실행한 것과 같게 만든다(import 경로와 명령줄 인자).
    sys.argv = [str(script), *sys.argv[2:]]
    sys.path.insert(0, str(script.parent))
    runpy.run_path(str(script), run_name='__main__')


if __name__ == '__main__':
    main()
