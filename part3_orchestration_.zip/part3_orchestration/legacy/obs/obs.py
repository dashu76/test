# 파일명: obs.py
"""17-04: 관찰 이벤트 한 건을 관제 허브로 보낸다. A2A_OBS_URL이 없으면 아무것도 하지 않는다."""

import atexit
import itertools
import os
import queue
import threading
import time

import httpx

ME = ''       # 이 프로세스의 이름 (실행한 파일 이름)
AGENT = ''    # 이 프로세스가 서버라면 자기 주소 (uvicorn.run이 알려 준다)
_url = ''
_queue = queue.Queue(maxsize=10000)
_count = itertools.count(1)


def start(name):
    global ME, _url
    ME = name
    _url = os.getenv('A2A_OBS_URL', '').rstrip('/')
    if _url:
        threading.Thread(target=_send_loop, daemon=True).start()
        atexit.register(_flush)


def who():
    """일을 맡기는 쪽의 이름. 서버이면서 다른 에이전트를 부르는 라우터는 자기 주소로 나온다."""
    return AGENT or ME


def emit(type_, side, agent_id, payload=None, task_id='', context_id=''):
    if not _url:
        return
    event = {
        'v': 1,
        'eventId': f'{ME}-{os.getpid()}-{next(_count)}',
        'ts': int(time.time() * 1000),
        'agentId': agent_id,
        'side': side,            # server: 일을 받은 쪽 / client: 일을 맡긴 쪽
        'type': type_,
        'taskId': task_id,
        'contextId': context_id,
        'process': ME,
        'payload': payload or {},
    }
    try:
        _queue.put_nowait(event)
    except queue.Full:
        pass


def _send_loop():
    with httpx.Client(timeout=2) as http:
        while True:
            event = _queue.get()
            try:
                http.post(_url + '/events', json=event)
            except Exception:
                pass  # 허브가 꺼져 있어도 실습은 그대로 진행한다
            finally:
                _queue.task_done()


def _flush():
    # 금방 끝나는 클라이언트가 마지막 이벤트를 보내기 전에 꺼지지 않도록 최대 2초 기다린다.
    deadline = time.time() + 2
    while _queue.unfinished_tasks and time.time() < deadline:
        time.sleep(0.05)
