# obs_hub — 관제 허브 (독립 서버)

회사 서버들이 보내는 관찰 이벤트를 모아 웹 화면으로 보여 준다. **선택 사항**이며 꺼져 있어도 회사 간 연동에는 영향이 없다.

- 실행: `./run.ps1` (또는 `uv run obs_hub.py`) → http://127.0.0.1:8000
- `POST /events` 이벤트 수신 · `GET /stream` SSE · `GET /events.jsonl` 전체 기록 · `GET /` 화면
- 이벤트 기록(`events.jsonl`)은 허브를 켤 때마다 비워진다.
