# 관제 허브 기동 (이 폴더만으로 실행된다)
Set-Location $PSScriptRoot
$env:PYTHONIOENCODING = 'utf-8'
uv run obs_hub.py
