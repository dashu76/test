﻿# plan_3 — 회사별 완전 독립 구조로 폴더 재구성

> plan_2의 기능·시나리오·인증 설계는 그대로 유지한다. 이 문서는 **폴더·배포 구조만** 바꾼다.
> 플로우 차트는 Mermaid로 작성했다 (VS Code는 Mermaid 지원 확장 필요).

## 1. 왜 다시 나누는가 (plan_2의 한계)

plan_2의 구조는 한 저장소에서 `apps/common`을 모든 회사가 import하고, 한 `pyproject.toml`·한 `.venv`·한 `partners.yaml`·한 `keys/`를 공유한다. 개발에는 편하지만, 회사가 서로 다른 서버 시스템을 쓰는 실제 운영과는 맞지 않는다.

| # | plan_2 구조의 문제 | 실제 운영에서 생기는 일 |
|---|---|---|
| L1 | `apps/common`을 모든 회사가 import한다 | 한 회사가 공통 코드를 고치면 다른 회사 코드가 같이 바뀐다. 다른 회사 서버에 그 코드를 줄 수 없다 |
| L2 | 한 `pyproject.toml`·`.venv`를 공유한다 | 회사마다 Python·라이브러리 버전이 다를 수 있는데 맞출 수 없다 |
| L3 | `keys/`에 모든 회사의 키가 한곳에 있다 | 회사의 비밀키가 다른 회사 서버에 놓이게 된다 |
| L4 | `partners.yaml` 하나를 공유한다 | 각 회사는 "자기가 아는 파트너"만 가져야 한다 |
| L5 | 물류사 코드 1벌을 4곳이 공유한다 (`apps/carrier`) | 물류사 A가 자기 방식대로 바꾸면 B·C도 영향을 받는다 |
| L6 | `data/`에 모든 DB가 한 폴더에 있다 | 한 서버를 옮기면 다른 회사 DB가 따라온다 |
| L7 | `scripts/run_all.ps1`이 전체를 한 번에 기동한다 | 회사별로 따로 배포·재시작할 수 없다 |
| L8 | 포트·주소가 `127.0.0.1` 전제다 | 서버가 다른 호스트에 있으면 주소를 코드에서 고쳐야 한다 |

## 2. 설계 원칙

1. **한 회사 = 한 폴더 = 하나의 독립 프로젝트.** 폴더 하나만 복사해 다른 서버에 놓아도 실행된다.
2. **회사 폴더끼리 코드를 import하지 않는다.** 다른 회사 폴더의 어떤 파일도 참조하지 않는다.
3. **회사 사이의 약속은 코드가 아니라 "계약 문서"(JSON Schema + 스킬 명세)로만 공유한다.** 각 회사는 계약을 자기 코드로 구현한다.
4. **공통으로 쓰던 코드는 각 회사 폴더 안에 복사해 둔다(vendoring).** 같은 기능이 중복되더라도 독립성이 우선이다. 중복을 줄이고 싶으면 공통 코드를 버전이 붙은 패키지로 따로 배포하는 방식(8절)을 쓴다.
5. **비밀은 자기 폴더에만 둔다.** 다른 회사와는 공개키·API 키 값만 교환한다.
6. **주소는 설정으로 받는다.** 코드에 `127.0.0.1`을 넣지 않는다.
7. **관제 허브도 하나의 독립 서버다.** 회사는 허브 주소가 있을 때만 이벤트를 보낸다.

## 3. 새 폴더 구조

저장소 루트(`part3_orchestration/`)는 **묶음 폴더일 뿐**이다. 각 회사 폴더가 독립 프로젝트이고, 루트에는 공유 코드가 없다.

```
part3_orchestration/
├── plan_2.md · plan_3.md
├── README.md                          # 전체 개요와 각 회사 폴더 안내만
│
├── contracts/                         # 회사 간 약속 (문서만, 코드 아님)
│   ├── README.md                      # 계약 버전 규칙
│   ├── skills.md                      # 스킬 목록·입출력 설명 (quote, accept-shipment ...)
│   ├── quote.v1.schema.json           # 견적 응답 JSON Schema
│   ├── shipment.v1.schema.json        # 수주·배송 상태 JSON Schema
│   └── auth.md                        # API 키 헤더·카드 서명 방식
│
├── buyer_kjm/                         # [독립] K정밀웍스 (구매사)
├── carrier_klogistics/                # [독립] K-Logistics
├── carrier_a/                         # [독립] 물류사 A
├── carrier_b/                         # [독립] 물류사 B
├── carrier_c/                         # [독립] 물류사 C
├── carrier_d_mismatch/                # [독립] 계약 불일치 실험용 (테스트 전용)
├── obs_hub/                           # [독립] 관제 허브
│
├── legacy/                            # 기존 실습 코드를 그대로 이동 (참고용, 수정하지 않음)
│   ├── server/ · ch13_discovery/ · ch14_delegation/
│   ├── ch15_failure_retry/ · ch16_structured_data/ · ch17_parallel_orchestration/
│   └── obs/                           # 기존 관찰 코드(obs_run.py 등)
│
└── dev/                               # 개발 편의용 (운영과 무관, 지워도 각 회사는 동작한다)
    ├── run_all.ps1 · stop_all.ps1     # 각 회사 폴더의 run 스크립트를 순서대로 호출할 뿐이다
    ├── seed_all.ps1
    └── e2e/                           # 회사를 실제로 기동해 흐름을 검증하는 시나리오 테스트
        └── test_scenarios.py
```

### 3.1 회사 폴더의 내부 구조 (물류사 예시: `carrier_a/`)

모든 회사 폴더가 **같은 뼈대**를 따른다. 뼈대가 같아도 코드는 각자 소유한다.

```
carrier_a/
├── pyproject.toml · uv.lock · .python-version   # 자기 의존성·자기 가상환경
├── .env.example                       # 설정 항목 예시 (실제 값은 .env, 저장소 제외)
├── config.yaml                        # 포트·공개 주소·허브 주소·DB 경로 (비밀 아님)
├── partners.yaml                      # 이 회사가 아는 파트너 목록 (공개키·주소)
├── run.ps1 · run.sh                   # 이 폴더만으로 기동
├── Dockerfile                         # (선택) 이 회사만 컨테이너로 배포
├── README.md                          # 이 회사 서버의 실행·설정·API 설명
│
├── secrets/                           # 이 회사의 비밀 (저장소 제외, 다른 회사에 주지 않는다)
│   ├── api_keys.json                  # 이 회사가 "받아 줄" 상대 회사의 API 키와 허용 스킬
│   ├── peer_keys.json                 # 이 회사가 "호출할 때 쓸" 상대 회사의 API 키
│   └── card_signing.key               # 이 회사 Agent Card 서명용 비밀키
│
├── app/
│   ├── main.py                        # 진입점: UI + API + A2A를 한 서버로 조립
│   ├── settings.py                    # config.yaml/.env 로드
│   ├── kit/                           # [복사본] 공통 기능 (a2a 서버 조립, 인증, 서명, 아웃박스 등)
│   │   ├── a2a_server.py · auth.py · card_signing.py
│   │   ├── task_store.py · outbox.py · idempotency.py
│   │   ├── partners.py · obs_emit.py · web.py
│   │   └── VERSION                    # 복사해 온 kit 버전 (예: 1.0.0)
│   ├── domain/                        # 이 회사만의 업무 규칙 (견적 계산, 수주 규칙 ...)
│   ├── agent.py                       # A2A 스킬 구현
│   ├── api.py                         # /api/* 업무 API
│   └── web/                           # templates/*.html + static/(js, css)
├── db/
│   ├── schema.sql
│   └── seed.sql                       # 요금표 등 초기 데이터
├── data/                              # 실행 중 생성되는 SQLite (저장소 제외)
└── tests/
    ├── test_domain.py                 # 이 회사 로직 단위 테스트
    └── test_contract.py               # contracts/의 스키마를 만족하는지 검사 (복사해 온 스키마 사용)
```

구매사 `buyer_kjm/`은 위 뼈대에서 `app/domain/`이 주문·견적 비교·확정·추적 로직이고, `partners.yaml`에 물류사 목록이 들어간다. 나머지 구조는 같다.

### 3.2 한 폴더를 다른 서버로 옮기는 방법

| 순서 | 작업 |
|---|---|
| 1 | `carrier_a/` 폴더 전체를 대상 서버로 복사한다 (`secrets/`는 안전한 경로로 따로 옮겨도 된다) |
| 2 | `config.yaml`의 `public_url`을 그 서버 주소로 바꾼다 (예: `https://carrier-a.example.com`) |
| 3 | `uv sync` → `run.ps1` (또는 `docker build`) |
| 4 | 구매사 `partners.yaml`에서 물류사 A의 `url`만 새 주소로 바꾼다 |
| 5 | 확인: 구매사 UI에서 견적 요청 → 물류사 A가 응답한다 |

다른 회사 폴더는 수정하지 않는다. 구매사에서 바뀌는 것은 `partners.yaml`의 주소 한 줄뿐이다.

## 4. 회사별 설정 (포트·주소·허브)

각 회사는 자기 `config.yaml`만 읽는다. 아래 포트는 **같은 PC에서 개발할 때의 기본값**이며, 실제 배포 시 호스트·포트는 자유롭게 바꾼다.

| 폴더 | 회사 | 개발 포트 | `public_url` (다른 회사가 부르는 주소) | 허브 주소 |
|---|---|---|---|---|
| `obs_hub/` | 관제 허브 | 8000 | `http://127.0.0.1:8000` | — |
| `buyer_kjm/` | K정밀웍스 | 8010 | `http://127.0.0.1:8010` | 선택 (`obs_url`) |
| `carrier_klogistics/` | K-Logistics | 8020 | `http://127.0.0.1:8020` | 선택 |
| `carrier_a/` | 물류사 A | 8031 | `http://127.0.0.1:8031` | 선택 |
| `carrier_b/` | 물류사 B | 8032 | `http://127.0.0.1:8032` | 선택 |
| `carrier_c/` | 물류사 C | 8033 | `http://127.0.0.1:8033` | 선택 |
| `carrier_d_mismatch/` | 물류사 D (실험) | 8034 | `http://127.0.0.1:8034` | 선택 |

- Agent Card의 `supported_interfaces[].url`은 코드가 아니라 `public_url`에서 만든다. 서버가 다른 호스트로 옮겨도 카드가 올바른 주소를 알려 준다.
- `obs_url`이 비어 있으면 이벤트를 보내지 않는다. 허브가 없어도 회사 간 연동은 그대로 동작한다.

### 4.1 파트너 목록 — 회사마다 따로

`partners.yaml`은 **그 회사가 아는 상대만** 적는다. 공유 파일이 아니다.

```yaml
# buyer_kjm/partners.yaml  (구매사가 호출할 물류사들)
partners:
  - id: carrier_a
    url: http://127.0.0.1:8031
    card_public_key: MCowBQYDK2VwAyEA...   # 이 회사가 서명을 검증할 때 쓰는 상대 공개키
    skills: [quote, accept-shipment, check-delivery, cancel-shipment]
  - id: carrier_b
    url: http://127.0.0.1:8032
    ...
```

```yaml
# carrier_a/partners.yaml  (물류사 A가 아는 호출자 — 필요하면 구매사 공개키만)
partners:
  - id: buyer_kjm
    card_public_key: MCowBQYDK2VwAyEA...
```

물류사는 다른 물류사를 알 필요가 없으므로 경쟁사 정보를 갖지 않는다.

## 5. 회사 사이의 연동 — 계약만 공유한다

```mermaid
flowchart LR
    subgraph C[contracts/  문서만]
        S[skills.md]
        Q[quote.v1.schema.json]
        H[shipment.v1.schema.json]
        U[auth.md]
    end
    subgraph B[buyer_kjm  독립 서버]
        BA[자기 코드·DB·키]
    end
    subgraph A[carrier_a  독립 서버]
        AA[자기 코드·DB·키]
    end
    C -. 참고해서 각자 구현 .-> B
    C -. 참고해서 각자 구현 .-> A
    B ==>|A2A + API 키<br/>Agent Card 서명 검증| A
    B -. 이벤트(선택) .-> O[obs_hub  독립 서버]
    A -. 이벤트(선택) .-> O
```

| 약속 | 담는 곳 | 각 회사가 하는 일 |
|---|---|---|
| 스킬 이름·입출력 | `contracts/skills.md` | 자기 `agent.py`에서 구현 |
| 견적·배송 데이터 모양 | `contracts/*.schema.json` | 자기 `tests/`로 가져가 계약 테스트를 돌린다 (파일을 복사해 간다) |
| 인증 방식 | `contracts/auth.md` | 자기 `kit/auth.py`로 구현 |
| 계약 버전 | 파일명의 `v1`, 스킬 카드의 `version` | 호환이 깨지면 `v2`를 새로 만들고 한동안 둘 다 지원 |

- 회사 폴더는 `contracts/`를 **참고 문서로만** 쓴다. 실행 중에 `contracts/` 폴더를 읽지 않는다 (테스트용 스키마는 각 회사 `tests/`에 복사).
- 상대 회사의 응답이 계약과 다르면 구매사의 검증이 걸러낸다 (물류사 D 시나리오).

## 6. 비밀과 키의 위치

| 대상 | 두는 곳 | 다른 회사에 주는가 |
|---|---|---|
| 내 카드 서명 비밀키 | 내 `secrets/card_signing.key` | **아니오** |
| 내 카드 서명 공개키 | 상대의 `partners.yaml`에 적힌다 | 예 (공개키는 공개 정보) |
| 내가 받아 줄 상대의 API 키 | 내 `secrets/api_keys.json` | 상대에게 키 값을 한 번 전달한다 |
| 내가 호출할 때 쓰는 상대의 API 키 | 내 `secrets/peer_keys.json` | **아니오** |
| 내 DB | 내 `data/` | **아니오** |

- `secrets/`, `data/`, `.env`는 각 회사 폴더의 `.gitignore`로 제외한다. 폴더를 복사할 때 비밀은 별도 경로로 옮긴다.
- 개발 편의를 위해 `dev/`에 개발용 키를 생성해 각 회사의 `secrets/`로 넣어 주는 스크립트를 둔다. 운영 키는 이 스크립트를 쓰지 않는다.
- 지금은 로컬 키로 동작하고, 운영에서는 같은 파일 위치에 실제 키를 놓거나 환경변수로 바꾼다.

## 7. 독립성 검증 기준

| # | 검사 | 기대 결과 |
|---|---|---|
| V1 | 한 회사 폴더만 빈 디렉터리에 복사해 `uv sync` 후 실행 | 다른 폴더가 없어도 기동한다 |
| V2 | 코드 안에서 다른 회사 폴더를 참조하는지 검색 (`import buyer_kjm`, `..\carrier_a` 등) | 0건 |
| V3 | 한 회사 서버를 끈 채 나머지를 기동 | 꺼진 회사만 "응답 없음"으로 다뤄지고 나머지는 정상 |
| V4 | 허브(`obs_hub`)를 띄우지 않고 전체 시나리오 실행 | 정상 경로 전부 통과 |
| V5 | 물류사 A 폴더만 다른 PC·다른 포트로 옮기고 구매사 `partners.yaml` 한 줄만 수정 | 견적·확정·조회가 그대로 동작 |
| V6 | 각 폴더의 `secrets/`에 다른 회사의 비밀키가 없는지 확인 | 자기 키와 상대의 공개키·API 키 값만 있음 |
| V7 | 회사별 `tests/`만 실행 | 각 폴더에서 단독으로 통과 |

`dev/e2e/test_scenarios.py`는 위 독립 구조를 **전제로 서버를 따로 띄워** plan_2의 시나리오(S1~S6)를 검증한다. 이 테스트는 회사 폴더의 코드를 import하지 않고 HTTP·A2A로만 접근한다.

## 8. 중복 코드(`kit/`) 관리 방법

`kit/`를 회사마다 복사하면 수정 시 여러 곳을 고쳐야 한다. 독립성을 해치지 않는 선택지는 다음과 같다.

| 방식 | 설명 | 독립성 | 관리 난이도 |
|---|---|---|---|
| **A. 복사 + VERSION 기록 (기본 채택)** | 각 폴더 `app/kit/`에 복사하고 `VERSION`에 버전을 적는다. 수정이 필요하면 각자 수정한다 | 완전 독립 | 중복 수정 필요, 대신 한 회사 변경이 다른 회사에 영향 없음 |
| B. 버전이 붙은 패키지로 배포 | `kit`를 별도 저장소·패키지로 만들어 각 회사가 `pyproject.toml`에서 `a2a-biz-kit==1.0.0`으로 설치한다 | 독립(버전 고정) | 패키지 저장소가 필요하다 |

처음에는 **A**로 시작하고, 회사가 늘어 중복이 부담스러워지면 B로 옮긴다. 두 방식 모두 회사 간에 `kit` 코드를 실행 중에 공유하지 않는다.

## 9. plan_2 대비 변경점 요약

| 항목 | plan_2 | plan_3 |
|---|---|---|
| 공통 코드 | `apps/common` 하나를 모두가 import | 각 회사 `app/kit/` 복사본 |
| 물류사 코드 | `apps/carrier` 1벌 + 설정 4개 | 물류사마다 독립 폴더 4개 (+ D) |
| 가상환경·의존성 | 루트 1개 | 회사마다 `pyproject.toml`·`uv.lock` |
| 키 | 루트 `keys/` 공유 | 회사별 `secrets/` |
| 파트너 목록 | 루트 `partners.yaml` 1개 | 회사별 `partners.yaml` |
| DB | 루트 `data/` | 회사별 `data/` |
| 기동 | `scripts/run_all.ps1` | 회사별 `run.ps1`, 전체는 `dev/run_all.ps1` (선택) |
| 회사 간 공유 | 코드 | `contracts/` 문서만 |
| 주소 | 코드 안 포트 | `config.yaml`의 `public_url` |
| 기존 실습 | 루트에 그대로 | `legacy/`로 이동 (수정하지 않음) |

기능·시나리오(plan_2의 3절), 상태 모델, 인증 방식, 허브 없이 동작하는 요건은 변하지 않는다.

## 10. 구현 단계

| 단계 | 내용 | 완료 기준 |
|---|---|---|
| Q0 | 기존 실습 폴더를 `legacy/`로 이동하고 `obs/` 허브를 `obs_hub/`로 분리한다. `uv sync`, 서명 지원 범위 확인 | `legacy/` 실습이 그대로 실행된다 |
| Q1 | `contracts/` 작성 (스킬 명세, 스키마, 인증 문서) | 두 회사가 문서만 보고 구현할 수 있다 |
| Q2 | 물류사 뼈대 1개(`carrier_klogistics/`) 완성: kit, DB, API, UI, A2A, 계약 테스트 | V1, V7 통과 |
| Q3 | 같은 뼈대를 복사해 `carrier_a`, `carrier_b`, `carrier_c`, `carrier_d_mismatch` 생성 후 각자 설정·요금표 변경 | 각 폴더가 단독 기동 |
| Q4 | `buyer_kjm/` 구현 (주문·견적 비교·확정·추적, 아웃박스) | V3, V5 통과 |
| Q5 | 인증 적용 (API 키, 카드 서명 검증), 회사별 `secrets/` 분리 | V6 통과 |
| Q6 | `dev/e2e` 시나리오 테스트, 허브 없는 실행 검증, 독립성 검사 (V1~V7) | 모든 검사 통과 |

## 부록. 서명 방식 확정 (Q0-7)

SDK가 Agent Card 서명을 지원한다(2a.utils.signing의 create_agent_card_signer·create_signature_verifier, JWS, PyJWT 사용). 별도 서명 파일 대신 SDK 방식을 쓰고, 각 회사 pyproject.toml에 pyjwt[crypto]를 추가한다.

