#!/usr/bin/env sh
cd "$(dirname "$0")"
uv run python -m app.main
