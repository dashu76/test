// 서버 렌더링된 화면에 붙는 가벼운 동작. 모든 호출은 이 회사(구매사)의 API로만 간다.
const $ = (sel, root = document) => root.querySelector(sel);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

const toast = (msg) => {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 3000);
};

async function call(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || res.statusText);
  return data;
}

const reload = () => setTimeout(() => location.reload(), 300);

// 물류사 연결 상태 (헤더)
async function loadPartners() {
  const box = $("#partners");
  if (!box) return;
  try {
    const list = await call("GET", "/api/partners");
    box.innerHTML = list.map((p) => `<span><i class="${p.online ? "on" : "off"}"></i>${esc(p.name)}</span>`).join("");
  } catch (e) { box.textContent = ""; }
}
loadPartners();
setInterval(loadPartners, 10000);

// 새 주문
$("#new-order")?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const body = Object.fromEntries(new FormData(event.target));
  try {
    const order = await call("POST", "/api/orders", body);
    location.href = `/orders/${order.order_no}`;
  } catch (e) { toast(e.message); }
});

// 주문 상세 (견적 비교)
const orderEl = $("#order");
const orderNo = orderEl?.dataset.order;

document.addEventListener("click", async (event) => {
  const b = event.target.closest("button[data-act]");
  if (!b || !orderNo) return;
  b.disabled = true;
  try {
    switch (b.dataset.act) {
      case "request-quotes": {
        b.textContent = "물류사에 문의 중…";
        const r = await call("POST", `/api/orders/${orderNo}/quotes`);
        toast(r.busy ? "이미 견적을 요청 중입니다" : "견적을 받았습니다");
        break;
      }
      case "confirm": {
        const r = await call("POST", `/api/orders/${orderNo}/confirm`, { carrier_id: b.dataset.carrier });
        toast(r.status === "CONFIRMED" ? "확정되었습니다" : "확정 요청을 보냈습니다");
        break;
      }
      case "retry":
        await call("POST", `/api/orders/${orderNo}/retry`);
        toast("다시 전송했습니다");
        break;
      case "answer": {
        const dest = prompt("도착지를 확인해 주세요 (바꾸지 않으려면 비워 두세요)") ?? null;
        if (dest === null) { b.disabled = false; return; }
        const qty = prompt("수량 (바꾸지 않으려면 비워 두세요)") ?? "";
        await call("POST", `/api/orders/${orderNo}/answer`, { carrier_id: b.dataset.carrier, dest, qty });
        toast("정보를 보냈습니다");
        break;
      }
      case "cancel-order": {
        if (!confirm(`${orderNo} 주문을 취소할까요?`)) { b.disabled = false; return; }
        const reason = prompt("취소 사유 (선택)") ?? "";
        await call("POST", `/api/orders/${orderNo}/cancel`, { reason });
        toast("취소했습니다");
        break;
      }
    }
    reload();
  } catch (e) {
    toast(e.message);
    b.disabled = false;
  }
});

// 확정 전송 중인 주문은 자동으로 새로 고침 (물류사가 살아나면 확정으로 바뀐다)
if (orderEl && orderEl.dataset.status === "CONFIRM_PENDING") setInterval(() => location.reload(), 4000);

// 배송 추적
const trackEl = $("#tracking");
async function track(no) {
  const out = $("#track-result");
  out.innerHTML = '<span class="muted">조회 중…</span>';
  try {
    const t = await call("GET", `/api/orders/${encodeURIComponent(no)}/tracking`);
    const detail = await call("GET", `/api/orders/${encodeURIComponent(no)}`).catch(() => null);
    if (!t.found) {
      out.innerHTML = `<p>조회 결과가 없습니다. <span class="muted">${esc(t.reason)}</span></p>`;
      return;
    }
    const stale = t.stale ? `<p class="notice warn stale">물류사에 연결할 수 없어 마지막으로 알던 상태를 보여 줍니다 (조회 시각 ${esc(t.tracked_at)})</p>` : "";
    const alert = detail?.order?.alert ? `<p class="notice warn">${esc(detail.order.alert)}</p>` : "";
    const events = (detail?.events || []).map((e) => `<li><span class="muted">${esc(e.at)}</span> ${esc(e.status)} ${esc(e.note)}</li>`).join("");
    out.innerHTML = `${stale}${alert}
      <p><strong>${esc(t.order_no)}</strong> · 물류사 상태 <span class="badge">${esc(t.status)}</span>
      ${t.eta ? ` · 도착 예정 ${esc(t.eta)}` : ""} <span class="muted">· 조회 ${esc(t.tracked_at)}</span></p>
      ${t.reason ? `<p class="muted">${esc(t.reason)}</p>` : ""}<ol class="timeline">${events}</ol>`;
  } catch (e) {
    out.innerHTML = `<p class="notice warn">${esc(e.message)}</p>`;
  }
}
$("#track-form")?.addEventListener("submit", (event) => {
  event.preventDefault();
  track(new FormData(event.target).get("order_no").trim());
});
if (trackEl?.dataset.order) track(trackEl.dataset.order);
