"""구매사가 A2A로 제공하는 스킬 (contracts/skills.md). 화면(UI)이 쓰는 것과 같은 서비스를 부른다."""

from app.domain.orders import OrderService, RuleError
from app.kit.a2a_server import NeedInput

SKILLS = [
    ("compare-quotes", "주문 조건을 받아 모든 물류사에 동시에 견적을 요청하고 비교 결과를 돌려준다 (주문은 저장하지 않는다)"),
    ("route-delivery-inquiry", "주문번호의 배송 상태를 확정된 물류사에 물어 돌려준다"),
]


class BuyerAgent:
    def __init__(self, service: OrderService) -> None:
        self.service = service

    async def handle(self, skill: str, payload: dict) -> dict:
        try:
            if skill == "compare-quotes":
                return await self.service.compare(payload)
            if skill == "route-delivery-inquiry":
                order_no = str(payload.get("order_no") or payload.get("text") or "").strip()
                return await self.service.track(order_no)
        except RuleError as error:
            raise NeedInput(str(error)) from error
        raise NeedInput(f"지원하지 않는 스킬입니다: '{skill}' (지원: {', '.join(s for s, _ in SKILLS)})")
