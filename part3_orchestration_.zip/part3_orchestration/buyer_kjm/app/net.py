"""물류사 호출 계층: Agent Card 발견·서명 검증·캐시 + API 키를 붙인 스킬 호출.

업무 로직은 이 인터페이스(call/card/forget/is_online)만 안다. 인증 실패는 PermissionError로 올린다.
- 카드: partners.yaml의 card_public_key로 서명을 검증한 뒤에만 캐시한다 (서명이 없거나 틀리면 호출하지 않는다)
- 호출: secrets/peer_keys.json의 해당 물류사 키를 X-A2A-Key 헤더로 보낸다
"""

import asyncio
import json
from pathlib import Path

import httpx
from a2a.types.a2a_pb2 import AgentCard

from app.kit import a2a_client, obs_emit
from app.kit.auth import HEADER
from app.kit.card_signing import make_verifier
from app.kit.partners import Partner, fetch_card


class AuthFailed(PermissionError):
    """키가 거절됐거나 카드 서명이 맞지 않는다."""


def _status_of(error: BaseException) -> int | None:
    """a2a/httpx 예외 사슬에서 HTTP 상태 코드를 찾는다."""
    seen = set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        response = getattr(error, "response", None)
        status = getattr(response, "status_code", None) or getattr(error, "status_code", None)
        if isinstance(status, int):
            return status
        error = error.__cause__ or error.__context__
    return None


class PartnerNet:
    def __init__(self, me: str, card_timeout_s: float = 2.0, peer_keys_file=None, verify_cards: bool = False) -> None:
        self.me = me
        self.card_timeout_s = card_timeout_s
        self.verify_cards = verify_cards
        self._cards: dict[str, AgentCard] = {}
        self._keys: dict[str, str] = {}
        if peer_keys_file is not None:
            path = Path(peer_keys_file)
            if not path.exists():
                raise FileNotFoundError(
                    f"물류사 API 키 파일이 없습니다: {path}\n개발용 키는 `dev/gen_keys.ps1`로 만들거나, config.yaml의 auth.mode를 off로 바꾸세요."
                )
            self._keys = json.loads(path.read_text(encoding="utf-8"))

    def _headers(self, partner: Partner) -> dict | None:
        if not self.verify_cards:
            return None
        key = self._keys.get(partner.id)
        if not key:
            raise AuthFailed(f"'{partner.id}'에 쓸 API 키가 설정되지 않았습니다 (secrets/peer_keys.json)")
        return {HEADER: key}

    async def card(self, partner: Partner) -> AgentCard:
        card = self._cards.get(partner.id)
        if card is None:
            card = await fetch_card(partner.url, timeout_s=self.card_timeout_s)
            if self.verify_cards:
                self._verify(partner, card)
            self._cards[partner.id] = card
        return card

    def _verify(self, partner: Partner, card: AgentCard) -> None:
        if not partner.card_public_key:
            raise AuthFailed(f"'{partner.id}'의 카드 공개키가 partners.yaml에 없습니다")
        try:
            make_verifier(partner.card_public_key, partner.id)(card)
        except Exception as error:
            obs_emit.emit("card.rejected", "client", {"url": partner.url, "error": type(error).__name__})
            raise AuthFailed(f"'{partner.id}'의 Agent Card 서명을 확인할 수 없습니다 ({type(error).__name__})") from error

    def forget(self, partner: Partner) -> None:
        """다음 호출 때 카드를 다시 읽는다 (상대 주소·스킬·키가 바뀌었을 수 있다)."""
        self._cards.pop(partner.id, None)

    async def call(
        self, partner: Partner, skill: str, payload: dict, *, timeout_s: float = 5.0,
        task_id: str = "", context_id: str = "",
    ) -> a2a_client.CallResult:
        headers = self._headers(partner)
        card = await asyncio.wait_for(self.card(partner), timeout_s)
        try:
            return await a2a_client.call_skill(
                card, skill, payload, me=self.me, headers=headers, timeout_s=timeout_s, task_id=task_id, context_id=context_id,
            )
        except (asyncio.TimeoutError, asyncio.CancelledError):
            raise
        except Exception as error:
            status = _status_of(error)
            if status in (401, 403):
                raise AuthFailed(f"'{partner.id}'가 호출을 거절했습니다 (HTTP {status})") from error
            raise

    async def is_online(self, partner: Partner, timeout_s: float = 1.0) -> bool:
        try:
            await fetch_card(partner.url, timeout_s=timeout_s)
            return True
        except Exception:
            return False