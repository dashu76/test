"""구매사 업무 API(/api/*)와 화면. UI는 이 회사의 API만 부른다."""

import asyncio

from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse

from app.domain import policy
from app.domain.orders import CARRIER_LABELS, LABELS, OrderService, RuleError


def register(app: FastAPI, service: OrderService, templates, company_name: str) -> None:
    api = APIRouter(prefix="/api")

    def guard(error: RuleError):
        return HTTPException(409, str(error))

    @api.get("/health")
    async def health():
        return {"ok": True}

    @api.get("/partners")
    async def partners():
        """물류사 상태: Agent Card를 읽을 수 있으면 온라인."""
        ps = list(service.partners.values())
        online = await asyncio.gather(*(service.net.is_online(p) for p in ps))
        return [{"id": p.id, "name": p.name or p.id, "url": p.url, "skills": p.skills, "online": o} for p, o in zip(ps, online)]

    @api.get("/orders")
    async def list_orders():
        return service.list_orders()

    @api.post("/orders")
    async def create_order(body: dict):
        try:
            return service.create_order(body)
        except RuleError as error:
            raise HTTPException(422, str(error)) from error

    @api.get("/orders/{order_no}")
    async def get_order(order_no: str):
        view = service.order_view(order_no)
        if view is None:
            raise HTTPException(404, "없는 주문입니다")
        return {"order": view, "quotes": service.quotes(order_no), "events": service.events(order_no)}

    @api.post("/orders/{order_no}/quotes")
    async def request_quotes(order_no: str):
        try:
            return await service.request_quotes(order_no)
        except RuleError as error:
            raise guard(error) from error

    @api.post("/orders/{order_no}/answer")
    async def answer(order_no: str, body: dict):
        try:
            return await service.answer_question(order_no, str(body.get("carrier_id", "")), body)
        except RuleError as error:
            raise guard(error) from error

    @api.post("/orders/{order_no}/confirm")
    async def confirm(order_no: str, body: dict):
        try:
            return await service.confirm(order_no, str(body.get("carrier_id", "")))
        except RuleError as error:
            raise guard(error) from error

    @api.post("/orders/{order_no}/retry")
    async def retry(order_no: str):
        try:
            result = service.retry_confirm(order_no)
            await service.process_outbox()
            return service.order_view(order_no) or result
        except RuleError as error:
            raise guard(error) from error

    @api.get("/orders/{order_no}/tracking")
    async def tracking(order_no: str):
        try:
            return await service.track(order_no)
        except RuleError as error:
            raise guard(error) from error

    @api.post("/orders/{order_no}/cancel")
    async def cancel(order_no: str, body: dict | None = None):
        try:
            return await service.cancel(order_no, str((body or {}).get("reason", "")))
        except RuleError as error:
            raise guard(error) from error

    app.include_router(api)

    def page(request: Request, name: str, **ctx):
        return templates.TemplateResponse(
            request, name,
            {"company": company_name, "labels": LABELS, "carrier_labels": CARRIER_LABELS,
             "verdict_labels": policy.VERDICT_LABELS, **ctx})

    @app.get("/", response_class=HTMLResponse)
    async def orders_page(request: Request):
        return page(request, "orders.html", rows=service.list_orders(), active="orders")

    @app.get("/orders/{order_no}", response_class=HTMLResponse)
    async def quotes_page(request: Request, order_no: str):
        view = service.order_view(order_no)
        if view is None:
            raise HTTPException(404, "없는 주문입니다")
        return page(request, "quotes.html", order=view, quotes=service.quotes(order_no),
                    events=service.events(order_no), active="orders")

    @app.get("/tracking", response_class=HTMLResponse)
    async def tracking_page(request: Request, order_no: str = ""):
        return page(request, "tracking.html", order_no=order_no, active="tracking")
