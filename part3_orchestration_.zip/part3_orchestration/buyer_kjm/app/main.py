"""구매사 서버 진입점: UI + 업무 API + A2A + 확정 재전송 작업을 한 프로세스로 조립한다.

실행: uv run python -m app.main   (또는 run.ps1)
"""

import asyncio
from contextlib import asynccontextmanager

import uvicorn

from app import agent as agent_module
from app import api
from app.domain.orders import OrderService
from app.kit import obs_emit
from app.kit.auth import HEADER, ApiKeyAuth
from app.kit.card_signing import sign_card
from app.kit.a2a_server import build_app, make_card
from app.kit.db import Db
from app.kit.outbox import Outbox
from app.kit.partners import load_partners
from app.kit.task_store import SqliteTaskStore
from app.kit.web import setup_web
from app.net import PartnerNet
from app.settings import ROOT, load_settings, secret_path


def create_app(settings=None, net=None):
    settings = settings or load_settings()
    cfg = settings.buyer
    db = Db(settings.db_path)
    db.script((ROOT / "db" / "schema.sql").read_text(encoding="utf-8"))
    db.script((ROOT / "db" / "seed.sql").read_text(encoding="utf-8"))

    obs_emit.start(settings.obs_url, settings.company_id, settings.public_url)
    outbox = Outbox(db, max_attempts=int(cfg.get("outbox_max_attempts", 5)), backoff_s=int(cfg.get("outbox_backoff_s", 5)))
    secured = settings.auth.get("mode", "required") == "required"   # off면 키·서명 검사를 하지 않는다 (로컬 실험용)
    net = net or PartnerNet(
        me=settings.company_id,
        peer_keys_file=secret_path(settings, "peer_keys_file", "secrets/peer_keys.json") if secured else None,
        verify_cards=secured,
    )
    service = OrderService(db, cfg, load_partners(settings.partners_path), net, outbox, me=settings.company_id)
    buyer_agent = agent_module.BuyerAgent(service)

    @asynccontextmanager
    async def lifespan(app):
        async def worker():
            while True:  # 전송에 실패한 확정 요청을 주기적으로 다시 보낸다 (물류사가 살아나면 자동 전달)
                try:
                    await service.process_outbox()
                except Exception:
                    pass
                await asyncio.sleep(float(cfg.get("outbox_poll_s", 3)))

        task = asyncio.create_task(worker())
        yield
        task.cancel()

    auth = ApiKeyAuth(secret_path(settings, "api_keys_file", "secrets/api_keys.json")) if secured else None
    card = make_card(
        api_key_header=HEADER if secured else "",
        name=settings.name,
        description="K정밀웍스 구매사: 견적 비교와 배송 조회를 제공한다",
        public_url=settings.public_url,
        skills=agent_module.SKILLS,
    )
    if secured:
        sign_card(card, secret_path(settings, "signing_key_file", "secrets/card_signing.key"), kid=settings.company_id)
    app = build_app(card, buyer_agent.handle, SqliteTaskStore(db), lifespan=lifespan, auth=auth, default_skill="route-delivery-inquiry")
    templates = setup_web(app, ROOT / "app" / "web")
    api.register(app, service, templates, settings.name)
    obs_emit.emit("agent.started", "server")
    return app, settings


app, _settings = create_app()

if __name__ == "__main__":
    print(f"[{_settings.company_id}] {_settings.public_url}  (UI: /, API: /api, A2A: /a2a)", flush=True)
    uvicorn.run(app, host=_settings.host, port=_settings.port, log_level="warning")
