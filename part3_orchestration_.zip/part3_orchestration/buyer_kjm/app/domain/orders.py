"""구매사 업무: 주문 → 견적 비교 → 확정 → 추적 → 취소.

주문 상태: DRAFT → REQUESTED → QUOTED → CONFIRM_PENDING → CONFIRMED → IN_TRANSIT → DELIVERED (분기: CANCELED)
물류사 호출은 `net.call(partner, skill, payload, ...)` 하나로만 한다 (테스트에서는 가짜로 바꾼다).
"""

import asyncio
import re
from datetime import datetime, timezone

from app.domain import policy
from app.kit.db import Db
from app.kit.outbox import Outbox
from app.kit.partners import Partner

LABELS = {
    "DRAFT": "작성 중", "REQUESTED": "견적 요청됨", "QUOTED": "견적 도착", "CONFIRM_PENDING": "확정 전송 중",
    "CONFIRMED": "확정됨", "IN_TRANSIT": "배송 중", "DELIVERED": "도착", "CANCELED": "취소",
}
QUOTABLE = {"DRAFT", "REQUESTED", "QUOTED"}
# 물류사가 알려 준 상태 → 주문 상태 (ON_HOLD는 주문 상태를 바꾸지 않고 경고만 올린다)
CARRIER_TO_ORDER = {
    "ACCEPTED": "CONFIRMED", "DISPATCHED": "IN_TRANSIT", "CUSTOMS": "IN_TRANSIT", "IN_TRANSIT": "IN_TRANSIT",
    "DELIVERED": "DELIVERED", "CANCELED": "CANCELED",
}
CARRIER_LABELS = {
    "ACCEPTED": "수주됨", "DISPATCHED": "출고", "CUSTOMS": "통관", "IN_TRANSIT": "배송 중",
    "DELIVERED": "도착", "ON_HOLD": "보류", "REJECTED": "거절", "CANCELED": "취소",
}


class RuleError(ValueError):
    """업무 규칙 위반. 화면에 사유를 그대로 보여 준다."""


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class OrderService:
    def __init__(self, db: Db, cfg: dict, partners: list[Partner], net, outbox: Outbox, me: str = "buyer") -> None:
        self.db, self.cfg, self.net, self.outbox, self.me = db, cfg, net, outbox, me
        self.partners = {p.id: p for p in partners}
        self._locks: dict[str, asyncio.Lock] = {}

    # ---------- 조회 ----------
    def get(self, order_no: str) -> dict | None:
        return self.db.one("SELECT * FROM orders WHERE order_no=?", (order_no,))

    def list_orders(self) -> list[dict]:
        return self.db.all("SELECT * FROM orders ORDER BY created_at DESC, order_no DESC")

    def events(self, order_no: str) -> list[dict]:
        return self.db.all("SELECT status, note, at FROM order_events WHERE order_no=? ORDER BY id", (order_no,))

    def quotes(self, order_no: str) -> list[dict]:
        """비교표. 유효시간이 지난 OK 견적은 EXPIRED로 보여 준다."""
        rows = self.db.all("SELECT * FROM quotes WHERE order_no=? ORDER BY price_krw IS NULL, price_krw, carrier_id", (order_no,))
        for row in rows:
            if row["verdict"] == "OK" and policy.is_expired(row["valid_until"]):
                row["verdict"], row["reason"] = "EXPIRED", "견적 유효시간이 지났습니다"
            row["verdict_label"] = policy.VERDICT_LABELS.get(row["verdict"], row["verdict"])
        best = policy.recommend(rows)
        for row in rows:
            row["recommended"] = row["carrier_id"] == best
        return rows

    def order_view(self, order_no: str) -> dict | None:
        order = self.get(order_no)
        if order is None:
            return None
        pending = self.outbox.get(f"{order_no}:{order['chosen_carrier']}") if order["chosen_carrier"] else None
        if order["status"] == "CONFIRM_PENDING" and pending and not pending["done"]:
            order["send_attempts"] = pending["attempts"]
            order["send_exhausted"] = pending["attempts"] >= self.outbox.max_attempts
            order["send_error"] = pending["last_error"]
        return order

    def _set(self, order_no: str, status: str | None = None, note: str | None = None, **fields) -> None:
        fields["updated_at"] = now_iso()
        if status is not None:
            fields["status"] = status
        if note is not None:
            fields["note"] = note
        cols = ", ".join(f"{k}=?" for k in fields)
        self.db.run(f"UPDATE orders SET {cols} WHERE order_no=?", (*fields.values(), order_no))
        if status is not None:
            self.db.run("INSERT INTO order_events(order_no, status, note, at) VALUES (?,?,?,?)",
                        (order_no, status, note or "", now_iso()))

    # ---------- 주문 ----------
    def create_order(self, data: dict) -> dict:
        item = str(data.get("item", "")).strip()
        origin, dest = str(data.get("origin", "")).strip(), str(data.get("dest", "")).strip()
        try:
            qty = int(data.get("qty", 0))
            max_eta = int(data.get("max_eta_days") or self.cfg.get("quote_default_max_eta_days", 4))
        except (TypeError, ValueError):
            raise RuleError("수량과 납기 한도는 숫자여야 합니다") from None
        missing = [n for n, v in (("품목", item), ("출발지", origin), ("도착지", dest)) if not v]
        if missing:
            raise RuleError("필수 항목이 비었습니다: " + ", ".join(missing))
        if qty < 1 or max_eta < 1:
            raise RuleError("수량과 납기 한도는 1 이상이어야 합니다")
        with self.db.transaction():
            self.db.run("UPDATE counters SET value=value+1 WHERE name='order_no'")
            order_no = f"ORDER-{self.db.one('SELECT value FROM counters WHERE name=?', ('order_no',))['value']}"
            now = now_iso()
            self.db.run(
                "INSERT INTO orders(order_no, item, qty, origin, dest, max_eta_days, status, created_at, updated_at) "
                "VALUES (?,?,?,?,?,?,?,?,?)", (order_no, item, qty, origin, dest, max_eta, "DRAFT", now, now))
            self.db.run("INSERT INTO order_events(order_no, status, note, at) VALUES (?,?,?,?)", (order_no, "DRAFT", "", now))
        return self.get(order_no)

    # ---------- 견적 ----------
    def _quote_payload(self, order: dict) -> dict:
        return {k: order[k] for k in ("order_no", "item", "qty", "origin", "dest", "max_eta_days")}

    async def _quote_one(self, partner: Partner, order: dict, task_id: str = "", context_id: str = "") -> dict:
        row = {"carrier_id": partner.id, "carrier_name": partner.name or partner.id, "price_krw": None, "eta_days": None,
               "valid_until": "", "verdict": "FAILED", "reason": "", "task_id": "", "context_id": "", "fetched_at": now_iso()}
        timeout_s = float(self.cfg.get("quote_timeout_s", 2.0))
        try:
            res = await self.net.call(partner, "quote", self._quote_payload(order), timeout_s=timeout_s,
                                      task_id=task_id, context_id=context_id)
        except asyncio.TimeoutError:
            self.net.forget(partner)
            return {**row, "verdict": "TIMEOUT", "reason": f"{timeout_s:g}초 안에 응답하지 않았습니다"}
        except PermissionError as error:
            return {**row, "verdict": "AUTH", "reason": str(error) or "인증에 실패했습니다"}
        except Exception as error:
            self.net.forget(partner)
            return {**row, "verdict": "DOWN", "reason": f"연결할 수 없습니다 ({type(error).__name__})"}
        row["task_id"], row["context_id"] = res.task_id, res.context_id
        if res.needs_input:
            return {**row, "verdict": "NEED_INPUT", "reason": res.text or "추가 정보가 필요합니다"}
        if not res.completed:
            return {**row, "verdict": "FAILED", "reason": res.text or f"작업이 완료되지 않았습니다 ({res.state})"}
        data = res.first()
        verdict, reason = policy.judge_quote(data, int(order["max_eta_days"]))
        if verdict == "INVALID":
            return {**row, "verdict": verdict, "reason": reason}
        return {**row, "verdict": verdict, "reason": reason, "carrier_name": data.get("carrier") or row["carrier_name"],
                "price_krw": int(data["price_krw"]), "eta_days": float(data["eta_days"]), "valid_until": data["valid_until"]}

    async def collect_quotes(self, order: dict) -> list[dict]:
        """quote 스킬을 가진 모든 파트너에게 동시에 묻는다. 한 곳이 느리거나 죽어도 나머지는 그대로 모은다."""
        targets = [p for p in self.partners.values() if p.enabled and "quote" in p.skills]
        if not targets:
            raise RuleError("견적을 요청할 물류사가 없습니다 (partners.yaml)")
        return list(await asyncio.gather(*(self._quote_one(p, order) for p in targets)))

    def _store_quotes(self, order_no: str, rows: list[dict]) -> None:
        with self.db.transaction():
            self.db.run("DELETE FROM quotes WHERE order_no=?", (order_no,))
            for r in rows:
                self.db.run(
                    "INSERT INTO quotes(order_no, carrier_id, carrier_name, price_krw, eta_days, valid_until, verdict, reason, "
                    "task_id, context_id, fetched_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (order_no, r["carrier_id"], r["carrier_name"], r["price_krw"], r["eta_days"], r["valid_until"],
                     r["verdict"], r["reason"], r["task_id"], r["context_id"], r["fetched_at"]))

    async def request_quotes(self, order_no: str) -> dict:
        order = self.get(order_no)
        if order is None:
            raise RuleError("없는 주문입니다")
        if order["status"] not in QUOTABLE:
            raise RuleError(f"{LABELS[order['status']]} 상태에서는 견적을 요청할 수 없습니다")
        lock = self._locks.setdefault(order_no, asyncio.Lock())
        if lock.locked():  # 버튼을 연달아 눌러도 진행 중인 요청 하나만 돈다
            return {"order": self.order_view(order_no), "quotes": self.quotes(order_no), "busy": True}
        async with lock:
            self._set(order_no, "REQUESTED", "견적 요청")
            rows = await self.collect_quotes(order)
            self._store_quotes(order_no, rows)
            if any(r["verdict"] in ("OK", "LATE") for r in rows):
                self._set(order_no, "QUOTED", "견적 도착")
            else:
                self._set(order_no, note="사용할 수 있는 견적이 없습니다. 사유를 확인하고 다시 요청하세요")
        return {"order": self.order_view(order_no), "quotes": self.quotes(order_no), "busy": False}

    async def compare(self, payload: dict) -> dict:
        """A2A `compare-quotes`: 주문을 저장하지 않고 비교 결과만 돌려준다."""
        order = {"order_no": str(payload.get("order_no", "ORDER-0")), "item": str(payload.get("item", "")),
                 "qty": int(payload.get("qty", 0)), "origin": str(payload.get("origin", "")),
                 "dest": str(payload.get("dest", "")),
                 "max_eta_days": int(payload.get("max_eta_days") or self.cfg.get("quote_default_max_eta_days", 4))}
        if order["qty"] < 1 or not order["origin"] or not order["dest"]:
            raise RuleError("qty, origin, dest가 필요합니다")
        rows = await self.collect_quotes(order)
        view = [{**r, "recommended": False} for r in rows]
        best = policy.recommend(view)
        for r in view:
            r["recommended"] = r["carrier_id"] == best
        return {"order_no": order["order_no"], "quotes": view, "recommended": best}

    async def answer_question(self, order_no: str, carrier_id: str, fixes: dict) -> dict:
        """INPUT_REQUIRED(추가 정보)에 답한다: 주문 값을 고치고, 같은 Task에 이어서 다시 보낸다."""
        order, partner = self.get(order_no), self.partners.get(carrier_id)
        if order is None or partner is None:
            raise RuleError("없는 주문이거나 알 수 없는 물류사입니다")
        row = self.db.one("SELECT * FROM quotes WHERE order_no=? AND carrier_id=?", (order_no, carrier_id))
        if row is None or row["verdict"] != "NEED_INPUT":
            raise RuleError("추가 정보를 기다리는 견적이 아닙니다")
        updates = {}
        for key in ("origin", "dest", "item"):
            if str(fixes.get(key, "")).strip():
                updates[key] = str(fixes[key]).strip()
        if str(fixes.get("qty", "")).strip():
            try:
                updates["qty"] = int(fixes["qty"])
            except ValueError:
                raise RuleError("수량은 숫자여야 합니다") from None
        if updates:
            self._set(order_no, **updates)
            order = self.get(order_no)
        new = await self._quote_one(partner, order, row["task_id"], row["context_id"])
        if new["verdict"] in ("DOWN", "FAILED") and row["task_id"]:  # 이어 보내기가 막히면 새 요청으로 다시 묻는다
            new = await self._quote_one(partner, order)
        self.db.run("DELETE FROM quotes WHERE order_no=? AND carrier_id=?", (order_no, carrier_id))
        self.db.run(
            "INSERT INTO quotes(order_no, carrier_id, carrier_name, price_krw, eta_days, valid_until, verdict, reason, task_id, "
            "context_id, fetched_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (order_no, carrier_id, new["carrier_name"], new["price_krw"], new["eta_days"], new["valid_until"],
             new["verdict"], new["reason"], new["task_id"], new["context_id"], new["fetched_at"]))
        if new["verdict"] in ("OK", "LATE") and order["status"] in ("REQUESTED", "DRAFT"):
            self._set(order_no, "QUOTED", "견적 도착")
        return {"order": self.order_view(order_no), "quotes": self.quotes(order_no)}

    # ---------- 확정 ----------
    def _accept_payload(self, order: dict, carrier_id: str) -> dict:
        return {"order_no": order["order_no"], "carrier": carrier_id, "business_key": f"{order['order_no']}:{carrier_id}",
                "item": order["item"], "qty": order["qty"], "origin": order["origin"], "dest": order["dest"],
                "agreed_price_krw": order["chosen_price"], "buyer": self.me}

    async def confirm(self, order_no: str, carrier_id: str) -> dict:
        order = self.get(order_no)
        if order is None:
            raise RuleError("없는 주문입니다")
        if order["status"] == "CONFIRM_PENDING" and order["chosen_carrier"] == carrier_id:
            return self.order_view(order_no)  # 같은 확정을 또 눌러도 한 번만 처리된다
        if order["status"] != "QUOTED":
            raise RuleError(f"{LABELS[order['status']]} 상태에서는 확정할 수 없습니다")
        quote = next((q for q in self.quotes(order_no) if q["carrier_id"] == carrier_id), None)
        if quote is None:
            raise RuleError("이 물류사의 견적이 없습니다")
        if quote["verdict"] == "EXPIRED":
            raise RuleError("견적 유효시간이 지났습니다. 다시 견적을 요청해 주세요")
        if quote["verdict"] != "OK":
            raise RuleError(f"선택할 수 없는 견적입니다: {quote['verdict_label']}")
        with self.db.transaction():
            self._set(order_no, "CONFIRM_PENDING", f"{quote['carrier_name']} 확정 요청", chosen_carrier=carrier_id,
                      chosen_price=int(quote["price_krw"]), chosen_reason="", alert="")
            self.outbox.enqueue("accept-shipment", f"{order_no}:{carrier_id}", self._accept_payload(self.get(order_no), carrier_id))
        await self.process_outbox()
        return self.order_view(order_no)

    async def process_outbox(self) -> int:
        """전송에 실패한 확정 요청을 다시 보낸다. 처리한 건수를 돌려준다."""
        done = 0
        for row in self.outbox.due():
            payload = row["payload"]
            order_no, carrier_id = payload["order_no"], payload["carrier"]
            partner = self.partners.get(carrier_id)
            try:
                if partner is None:
                    raise RuntimeError(f"알 수 없는 물류사: {carrier_id}")
                res = await self.net.call(partner, "accept-shipment", payload, timeout_s=float(self.cfg.get("call_timeout_s", 5.0)))
                if not (res.completed or res.needs_input):
                    raise RuntimeError(res.text or f"작업이 완료되지 않았습니다 ({res.state})")
            except Exception as error:
                if partner is not None:
                    self.net.forget(partner)
                self.outbox.mark_failed(row["id"], f"{type(error).__name__}: {error}"[:200])
                self._after_failed_attempt(row, order_no)
                continue
            self.outbox.mark_done(row["id"])
            self._on_accept_result(order_no, carrier_id, res)
            done += 1
        return done

    def _after_failed_attempt(self, row: dict, order_no: str) -> None:
        if row["attempts"] + 1 >= self.outbox.max_attempts:
            self._set(order_no, alert="확정 전송이 반복해서 실패했습니다. 물류사 상태를 확인한 뒤 '다시 시도'를 누르세요")

    def _on_accept_result(self, order_no: str, carrier_id: str, res) -> None:
        data = res.first()
        if res.completed and data.get("status") == "ACCEPTED":
            self._set(order_no, "CONFIRMED", "수주 확인", carrier_status="ACCEPTED", carrier_eta=str(data.get("eta", "")),
                      tracked_at=now_iso(), alert="")
            return
        reason = data.get("reason") or res.text or "물류사가 수주를 거절했습니다"
        self.db.run("UPDATE quotes SET verdict='REJECTED', reason=? WHERE order_no=? AND carrier_id=?", (reason, order_no, carrier_id))
        self._set(order_no, "QUOTED", f"수주 거절: {reason}", chosen_carrier="", chosen_price=0, chosen_reason=reason, alert="")

    def retry_confirm(self, order_no: str) -> dict:
        order = self.get(order_no)
        if order is None or order["status"] != "CONFIRM_PENDING":
            raise RuleError("확정 전송 중인 주문이 아닙니다")
        if not self.outbox.reset(f"{order_no}:{order['chosen_carrier']}"):
            raise RuleError("다시 보낼 전송 건이 없습니다")
        self._set(order_no, alert="")
        return self.order_view(order_no)

    # ---------- 추적 ----------
    async def track(self, order_no: str) -> dict:
        order = self.get(order_no)
        if order is None:
            return {"order_no": order_no, "found": False, "reason": "등록된 주문이 아닙니다"}
        if not order["chosen_carrier"] or order["status"] in ("DRAFT", "REQUESTED", "QUOTED", "CONFIRM_PENDING"):
            raise RuleError("아직 물류사에 확정되지 않은 주문입니다")
        partner = self.partners.get(order["chosen_carrier"])
        cached = {"order_no": order_no, "found": True, "status": order["carrier_status"], "eta": order["carrier_eta"],
                  "reason": order["carrier_note"], "tracked_at": order["tracked_at"]}
        try:
            res = await self.net.call(partner, "check-delivery", {"order_no": order_no}, timeout_s=float(self.cfg.get("call_timeout_s", 5.0)))
            if not res.completed:
                raise RuntimeError(res.text or res.state)
        except Exception as error:  # 물류사가 안 되면 마지막으로 알던 상태를 시각과 함께 보여 준다
            if partner is not None:
                self.net.forget(partner)
            return {**cached, "stale": True, "stale_reason": f"{type(error).__name__}"}
        data = res.first()
        if not data.get("found"):
            return {"order_no": order_no, "found": False, "reason": "물류사에 조회 결과가 없습니다"}
        status = data.get("status", "")
        new_status = CARRIER_TO_ORDER.get(status)
        alert = f"물류사가 '보류'로 갱신했습니다: {data.get('reason', '사유 없음')}" if status == "ON_HOLD" else ""
        fields = dict(carrier_status=status, carrier_eta=str(data.get("eta", "")), carrier_note=str(data.get("reason", "")),
                      tracked_at=now_iso(), alert=alert)
        if new_status and new_status != order["status"]:
            self._set(order_no, new_status, f"물류사 상태: {CARRIER_LABELS.get(status, status)}", **fields)
        else:
            self._set(order_no, **fields)
        return {"order_no": order_no, "found": True, "status": status, "eta": fields["carrier_eta"], "reason": fields["carrier_note"],
                "tracked_at": fields["tracked_at"], "stale": False}

    # ---------- 취소 ----------
    async def cancel(self, order_no: str, reason: str = "") -> dict:
        order = self.get(order_no)
        if order is None:
            raise RuleError("없는 주문입니다")
        status = order["status"]
        if status in ("CANCELED", "DELIVERED"):
            raise RuleError(f"{LABELS[status]} 상태의 주문은 취소할 수 없습니다")
        if status in ("DRAFT", "REQUESTED", "QUOTED"):
            self._set(order_no, "CANCELED", reason or "구매사 취소")
            return self.order_view(order_no)
        partner = self.partners.get(order["chosen_carrier"])
        key = f"{order_no}:{order['chosen_carrier']}"
        if status == "CONFIRM_PENDING":  # 아직 물류사에 전달되지 않았을 수도 있다: 전송을 멈추고, 이미 갔다면 취소를 알린다
            self.outbox.cancel(key)
        try:
            res = await self.net.call(partner, "cancel-shipment", {"order_no": order_no, "business_key": key, "reason": reason},
                                      timeout_s=float(self.cfg.get("call_timeout_s", 5.0)))
        except Exception as error:
            if status == "CONFIRM_PENDING":
                self._set(order_no, "CANCELED", reason or "구매사 취소 (물류사에는 전달되지 않음)")
                return self.order_view(order_no)
            raise RuleError(f"물류사에 연결할 수 없어 취소하지 못했습니다 ({type(error).__name__})") from error
        data = res.first()
        if data.get("status") == "CANCELED" or (status == "CONFIRM_PENDING" and not data.get("found")):
            self._set(order_no, "CANCELED", reason or "구매사 취소")
            return self.order_view(order_no)
        raise RuleError(data.get("reason") or "물류사가 취소를 거절했습니다")
