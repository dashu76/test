"""받은 견적을 믿어도 되는지 판단한다: 계약(JSON Schema) 검증 → 납기 → 유효시간."""

import json
from datetime import datetime, timezone
from pathlib import Path

from jsonschema import Draft202012Validator

CONTRACTS = Path(__file__).resolve().parent.parent / "contracts"
_QUOTE_VALIDATOR = Draft202012Validator(json.loads((CONTRACTS / "quote.v1.schema.json").read_text(encoding="utf-8")))

# 견적 한 건의 판정. OK만 선택할 수 있고 나머지는 사유와 함께 비교표에 남는다.
VERDICT_LABELS = {
    "OK": "사용 가능", "LATE": "납기 초과", "EXPIRED": "견적 만료", "INVALID": "계약 불일치",
    "TIMEOUT": "시간 초과", "DOWN": "응답 없음", "AUTH": "인증 실패", "NEED_INPUT": "추가 정보 필요",
    "REJECTED": "수주 거절", "FAILED": "처리 실패",
}


def contract_errors(data: dict) -> list[str]:
    """계약 위반 내용을 사람이 읽을 말로 돌려준다. 비어 있으면 통과."""
    missing, wrong = [], []
    for error in _QUOTE_VALIDATOR.iter_errors(data):
        if error.validator == "required":
            missing.append(error.message.split("'")[1])
        else:
            wrong.append(".".join(str(p) for p in error.absolute_path) or "(전체)")
    out = []
    if missing:
        out.append("누락 필드: " + ", ".join(sorted(missing)))
    if wrong:
        out.append("형식 오류: " + ", ".join(sorted(set(wrong))))
    return out


def parse_time(value: str) -> datetime | None:
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def is_expired(valid_until: str, now: datetime | None = None) -> bool:
    deadline = parse_time(valid_until)
    return deadline is not None and deadline < (now or datetime.now(timezone.utc))


def judge_quote(data: dict, max_eta_days: int) -> tuple[str, str]:
    """(판정, 사유). 견적 응답 한 건을 평가한다."""
    errors = contract_errors(data)
    if errors:
        return "INVALID", "계약 불일치 — " + " / ".join(errors)
    if data["eta_days"] > max_eta_days:
        return "LATE", f"납기 {data['eta_days']:.0f}일 > 한도 {max_eta_days}일"
    return "OK", ""


def recommend(quotes: list[dict]) -> str | None:
    """사용 가능한(OK) 견적 중 최저가의 carrier_id."""
    usable = [q for q in quotes if q["verdict"] == "OK" and q["price_krw"] is not None]
    return min(usable, key=lambda q: q["price_krw"])["carrier_id"] if usable else None
