"""A2A 엔드포인트(/a2a)의 호출 인증: 헤더 X-A2A-Key로 호출자를 확인하고, 호출자별로 허용된 스킬만 통과시킨다.

secrets/api_keys.json:
  {"keys": [{"key": "...", "caller": "buyer_kjm", "scopes": ["quote", "accept-shipment"]}]}
- 키가 없거나 모르는 키 → 401, 키는 맞지만 scope에 없는 스킬 → 403. 두 경우 모두 Task를 만들지 않는다.
- Agent Card(/.well-known/agent-card.json)와 UI·업무 API는 이 검사의 대상이 아니다.
"""

import hmac
import json
from dataclasses import dataclass
from pathlib import Path

from app.kit import obs_emit

HEADER = "X-A2A-Key"


@dataclass
class Caller:
    name: str
    scopes: set[str]


class ApiKeyAuth:
    def __init__(self, keys_path) -> None:
        path = Path(keys_path)
        if not path.exists():
            raise FileNotFoundError(
                f"API 키 파일이 없습니다: {path}\n"
                "개발용 키는 `dev/gen_keys.ps1`로 만들 수 있고, 인증 없이 실험하려면 config.yaml의 auth.mode를 off로 바꾸세요."
            )
        raw = json.loads(path.read_text(encoding="utf-8"))
        self._keys = [(item["key"], Caller(item["caller"], set(item.get("scopes", [])))) for item in raw.get("keys", [])]

    def identify(self, key: str) -> Caller | None:
        found = None
        for known, caller in self._keys:  # 모든 키를 같은 시간으로 비교한다 (타이밍으로 키를 추측하지 못하게)
            if key and hmac.compare_digest(known.encode(), key.encode()):
                found = caller
        return found


def skill_of(body: bytes, default_skill: str) -> str | None:
    """JSON-RPC 본문에서 호출 스킬을 꺼낸다. 메시지 전송이 아니면 None."""
    try:
        params = json.loads(body).get("params") or {}
    except (ValueError, AttributeError):
        return None
    message = params.get("message")
    if not isinstance(message, dict):
        return None
    meta = message.get("metadata") or {}
    return str(meta.get("skill") or default_skill)


class ApiKeyMiddleware:
    """순수 ASGI 미들웨어. prefix로 시작하는 POST 요청만 검사한다."""

    def __init__(self, app, auth: ApiKeyAuth, prefix: str = "/a2a", default_skill: str = "") -> None:
        self.app, self.auth, self.prefix, self.default_skill = app, auth, prefix, default_skill

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope["path"].startswith(self.prefix) or scope["method"] != "POST":
            return await self.app(scope, receive, send)
        key = dict(scope["headers"]).get(HEADER.lower().encode(), b"").decode()
        caller = self.auth.identify(key)
        if caller is None:
            obs_emit.emit("auth.denied", "server", {"status": 401, "reason": "API 키가 없거나 올바르지 않습니다"})
            return await self._deny(send, 401, "API 키가 없거나 올바르지 않습니다")
        body, more = b"", True
        while more:  # 스킬을 알아야 하므로 본문을 읽고, 뒤에서 다시 읽을 수 있게 되돌려 준다
            message = await receive()
            body += message.get("body", b"")
            more = message.get("more_body", False)
        skill = skill_of(body, self.default_skill)
        if skill is not None and skill not in caller.scopes:
            obs_emit.emit("auth.denied", "server", {"status": 403, "caller": caller.name, "skill": skill})
            return await self._deny(send, 403, f"'{caller.name}'은(는) '{skill}' 스킬을 호출할 권한이 없습니다")
        sent = False

        async def replay():
            nonlocal sent
            if not sent:
                sent = True
                return {"type": "http.request", "body": body, "more_body": False}
            return await receive()

        scope.setdefault("state", {})["caller"] = caller.name
        return await self.app(scope, replay, send)

    @staticmethod
    async def _deny(send, status: int, message: str):
        payload = json.dumps({"error": {"status": status, "message": message}}, ensure_ascii=False).encode()
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"application/json; charset=utf-8"), (b"content-length", str(len(payload)).encode())]})
        await send({"type": "http.response.body", "body": payload})