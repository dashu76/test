"""A2A 서버 조립: Agent Card, 스킬 실행기, FastAPI 라우트.

스킬은 Message.metadata["skill"]로 고르고, 입력은 data Part(JSON 객체), 결과는 data artifact(JSON 객체)다.
A2A 엔드포인트는 /a2a 이고 `/`는 이 회사의 UI가 쓴다.
"""

from typing import Awaitable, Callable

from a2a.helpers.proto_helpers import get_data_parts, new_data_artifact, new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes.agent_card_routes import create_agent_card_routes
from a2a.server.routes.fastapi_routes import add_a2a_routes_to_fastapi
from a2a.server.routes.jsonrpc_routes import create_jsonrpc_routes
from a2a.server.tasks.task_store import TaskStore
from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    APIKeySecurityScheme,
    Message,
    Part,
    Role,
    SecurityRequirement,
    SecurityScheme,
    StringList,
    TaskState,
)
from fastapi import FastAPI
from google.protobuf.json_format import MessageToDict

RPC_PATH = "/a2a"


class NeedInput(Exception):
    """사람의 추가 입력이 필요하다 → Task를 INPUT_REQUIRED로 만든다."""


SkillHandler = Callable[[str, dict], Awaitable[dict]]


def parse_request(message: Message) -> tuple[str, dict]:
    """메시지에서 (스킬 이름, 입력 JSON)을 꺼낸다. 텍스트만 오면 {"text": ...}로 넘긴다."""
    meta = MessageToDict(message.metadata) if message.HasField("metadata") else {}
    data = [d for d in get_data_parts(message.parts) if isinstance(d, dict)]
    text = "".join(p.text for p in message.parts if p.WhichOneof("content") == "text").strip()
    payload = data[0] if data else ({"text": text} if text else {})
    return str(meta.get("skill", "")), payload


class SkillExecutor(AgentExecutor):
    def __init__(self, handler: SkillHandler) -> None:
        self._handler = handler

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task or new_task_from_user_message(context.message)
        await event_queue.enqueue_event(task)
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        await updater.update_status(TaskState.TASK_STATE_WORKING)
        skill, payload = parse_request(context.message)
        try:
            result = await self._handler(skill, payload)
        except NeedInput as question:
            await updater.update_status(TaskState.TASK_STATE_INPUT_REQUIRED, message=_agent_message(str(question)))
            return
        except Exception as error:
            await updater.update_status(
                TaskState.TASK_STATE_FAILED, message=_agent_message(f"{type(error).__name__}: {error}")
            )
            return
        artifact = new_data_artifact(name=skill or "result", data=result)
        await updater.add_artifact(parts=list(artifact.parts))
        await updater.update_status(TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("Task 취소는 지원하지 않는다 (cancel-shipment 스킬을 쓴다)")


def _agent_message(text: str) -> Message:
    return Message(role=Role.ROLE_AGENT, parts=[Part(text=text)])


def make_card(
    name: str, description: str, public_url: str, skills: list[tuple[str, str]], version: str = "1.0.0", api_key_header: str = "",
) -> AgentCard:
    """api_key_header를 주면 카드에 "이 서버는 이 헤더의 API 키가 필요하다"고 선언한다."""
    security = {}
    if api_key_header:
        security = dict(
            security_schemes={"apiKey": SecurityScheme(api_key_security_scheme=APIKeySecurityScheme(
                description="회사 간 호출용 API 키", location="header", name=api_key_header))},
            security_requirements=[SecurityRequirement(schemes={"apiKey": StringList(list=[])})],
        )
    return AgentCard(
        **security,
        name=name,
        description=description,
        version=version,
        default_input_modes=["application/json", "text/plain"],
        default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[
            AgentInterface(url=f"{public_url}{RPC_PATH}", protocol_binding="JSONRPC", protocol_version="1.0")
        ],
        skills=[
            AgentSkill(
                id=skill_id,
                name=skill_id,
                description=desc,
                input_modes=["application/json"],
                output_modes=["application/json"],
            )
            for skill_id, desc in skills
        ],
    )


def build_app(card: AgentCard, handler: SkillHandler, task_store: TaskStore, lifespan=None, auth=None, default_skill: str = "") -> FastAPI:
    request_handler = DefaultRequestHandler(
        agent_executor=SkillExecutor(handler), task_store=task_store, agent_card=card
    )
    app = FastAPI(title=card.name, lifespan=lifespan)
    add_a2a_routes_to_fastapi(
        app,
        agent_card_routes=create_agent_card_routes(card),
        jsonrpc_routes=create_jsonrpc_routes(request_handler, rpc_url=RPC_PATH),
    )
    if auth is not None:  # /a2a 호출만 API 키로 보호한다 (카드·UI·업무 API는 대상이 아니다)
        from app.kit.auth import ApiKeyMiddleware

        app.add_middleware(ApiKeyMiddleware, auth=auth, prefix=RPC_PATH, default_skill=default_skill)
    return app
