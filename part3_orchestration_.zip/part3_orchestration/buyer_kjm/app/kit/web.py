"""서버 렌더링 HTML(Jinja2) + 정적 파일 공통 설정."""

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates


def setup_web(app: FastAPI, web_dir: Path) -> Jinja2Templates:
    app.mount("/static", StaticFiles(directory=web_dir / "static"), name="static")
    return Jinja2Templates(directory=web_dir / "templates")
