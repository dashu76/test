"""partners.yaml(이 회사가 아는 상대 목록)을 읽고, 상대의 Agent Card를 발견한다."""

from dataclasses import dataclass, field
from pathlib import Path

import httpx
import yaml
from a2a.client import A2ACardResolver
from a2a.types.a2a_pb2 import AgentCard

from app.kit import obs_emit


@dataclass
class Partner:
    id: str
    name: str = ""
    url: str = ""
    card_public_key: str = ""
    skills: list[str] = field(default_factory=list)
    enabled: bool = True


def load_partners(path) -> list[Partner]:
    path = Path(path)
    if not path.exists():
        return []
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return [Partner(**p) for p in raw.get("partners", [])]


async def fetch_card(url: str, timeout_s: float = 2.0, headers: dict | None = None) -> AgentCard:
    """Agent Card를 읽는다. 성공·실패를 관제에 알린다."""
    # 꺼진 서버는 연결 단계에서 빨리 실패해야 "응답 없음"과 "느림"을 구분할 수 있다 (Windows는 거절 응답이 느리다)
    async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_s, connect=min(1.0, timeout_s)), headers=headers) as http:
        try:
            card = await A2ACardResolver(http, url).get_agent_card()
        except Exception as error:
            obs_emit.emit("card.failed", "client", {"url": url, "error": type(error).__name__})
            raise
    obs_emit.emit("card.fetched", "client", {"url": url, "name": card.name, "skills": [s.id for s in card.skills]})
    return card
