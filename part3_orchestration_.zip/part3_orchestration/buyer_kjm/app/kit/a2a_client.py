"""다른 회사의 스킬을 부르는 클라이언트. 결과를 한 덩어리(CallResult)로 모아 주고 관제 이벤트를 남긴다."""

import asyncio
import itertools
import os
import uuid
from dataclasses import dataclass, field

import httpx
from a2a.client import ClientConfig, create_client
from a2a.helpers.proto_helpers import get_data_parts, new_data_part
from a2a.types.a2a_pb2 import AgentCard, Message, Role, SendMessageRequest, TaskState
from google.protobuf.struct_pb2 import Struct

from app.kit import obs_emit

_numbers = itertools.count(1)


@dataclass
class CallResult:
    state: str = ""
    data: list[dict] = field(default_factory=list)
    text: str = ""          # 상태 메시지(질문·오류 사유)
    task_id: str = ""
    context_id: str = ""

    @property
    def completed(self) -> bool:
        return self.state == "TASK_STATE_COMPLETED"

    @property
    def needs_input(self) -> bool:
        return self.state == "TASK_STATE_INPUT_REQUIRED"

    def first(self) -> dict:
        return self.data[0] if self.data else {}


def _text(parts) -> str:
    return "".join(p.text for p in parts if p.WhichOneof("content") == "text")


async def call_skill(
    card: AgentCard,
    skill: str,
    payload: dict,
    *,
    me: str = "",
    headers: dict | None = None,
    signature_verifier=None,
    task_id: str = "",
    context_id: str = "",
    timeout_s: float = 5.0,
) -> CallResult:
    """skill을 호출하고 끝(완료 또는 추가 입력 대기)까지 모은다. 시간이 넘으면 asyncio.TimeoutError."""
    to = card.supported_interfaces[0].url.rstrip("/") if card.supported_interfaces else ""
    request_id = f"{me or 'client'}-{os.getpid()}-r{next(_numbers)}"
    base = {"requestId": request_id, "to": to.removesuffix("/a2a"), "toName": card.name, "skill": skill}
    obs_emit.emit("request.sent", "client", {**base, "text": f"{skill} {payload}"[:160]})
    result = CallResult()
    finished = False
    try:
        async with httpx.AsyncClient(headers=headers, timeout=httpx.Timeout(timeout_s, connect=min(1.0, timeout_s))) as http:
            client = await create_client(
                card, client_config=ClientConfig(httpx_client=http), signature_verifier=signature_verifier
            )
            meta = Struct()
            meta.update({"skill": skill})
            message = Message(
                message_id=str(uuid.uuid4()), role=Role.ROLE_USER, parts=[new_data_part(payload)],
                metadata=meta, task_id=task_id, context_id=context_id,
            )

            async def collect() -> None:
                stream = client.send_message(SendMessageRequest(message=message))
                try:
                    async for response in stream:
                        kind = response.WhichOneof("payload")
                        item = getattr(response, kind)
                        if kind == "task":
                            result.task_id, result.context_id = item.id, item.context_id
                            result.state = TaskState.Name(item.status.state)
                            result.data = [d for a in item.artifacts for d in get_data_parts(a.parts) if isinstance(d, dict)]
                            result.text = _text(item.status.message.parts)
                        elif kind == "status_update":
                            result.task_id, result.context_id = item.task_id, item.context_id
                            result.state = TaskState.Name(item.status.state)
                            result.text = _text(item.status.message.parts) or result.text
                        elif kind == "artifact_update":
                            result.data += [d for d in get_data_parts(item.artifact.parts) if isinstance(d, dict)]
                        obs_emit.emit(
                            "request.event", "client", {**base, "kind": kind, "state": result.state},
                            result.task_id, result.context_id,
                        )
                        # 재개한 Task의 첫 스냅샷은 아직 이전 대기 상태다. 새로 들어온 status_update에서만 멈춘다.
                        if kind == "status_update" and result.state in ("TASK_STATE_INPUT_REQUIRED", "TASK_STATE_AUTH_REQUIRED"):
                            break
                finally:
                    close = getattr(stream, "aclose", None)
                    if close is not None:
                        await close()

            await asyncio.wait_for(collect(), timeout_s)
        finished = True
        return result
    except BaseException as error:
        obs_emit.emit("request.error", "client", {**base, "error": type(error).__name__}, result.task_id, result.context_id)
        raise
    finally:
        obs_emit.emit(
            "request.done", "client", {**base, "state": result.state, "stoppedEarly": not finished},
            result.task_id, result.context_id,
        )
