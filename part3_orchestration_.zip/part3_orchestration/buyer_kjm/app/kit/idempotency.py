"""업무 키(예: ORDER-1001:carrier_a)로 같은 요청이 두 번 처리되지 않게 한다."""

import json
import time

from app.kit.db import Db

_SCHEMA = """
CREATE TABLE IF NOT EXISTS idempotency (
    business_key TEXT PRIMARY KEY,
    result TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
"""


class Idempotency:
    def __init__(self, db: Db) -> None:
        self._db = db
        db.script(_SCHEMA)

    def get(self, business_key: str) -> dict | None:
        row = self._db.one("SELECT result FROM idempotency WHERE business_key=?", (business_key,))
        return json.loads(row["result"]) if row else None

    def put(self, business_key: str, result: dict) -> None:
        self._db.run(
            "INSERT OR IGNORE INTO idempotency(business_key, result, created_at) VALUES (?,?,?)",
            (business_key, json.dumps(result, ensure_ascii=False), int(time.time())),
        )
