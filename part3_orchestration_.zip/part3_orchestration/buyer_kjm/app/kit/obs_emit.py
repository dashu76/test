"""관제 이벤트를 허브로 보낸다. 허브 주소가 없거나 허브가 꺼져 있어도 아무 일도 일어나지 않는다."""

import atexit
import itertools
import os
import queue
import threading
import time

import httpx

_url = ""
_process = ""
_agent = ""
_queue: queue.Queue = queue.Queue(maxsize=10000)
_count = itertools.count(1)


def start(url: str, process: str, agent_url: str) -> None:
    """url이 비어 있으면 이벤트를 만들지도 않는다."""
    global _url, _process, _agent
    _url, _process, _agent = (url or "").rstrip("/"), process, agent_url
    if _url:
        threading.Thread(target=_send_loop, daemon=True).start()
        atexit.register(_flush)


def emit(type_: str, side: str, payload=None, task_id: str = "", context_id: str = "", agent_id: str | None = None) -> None:
    if not _url:
        return
    event = {
        "v": 1,
        "eventId": f"{_process}-{os.getpid()}-{next(_count)}",
        "ts": int(time.time() * 1000),
        "agentId": agent_id or _agent,
        "side": side,  # server: 일을 받은 쪽 / client: 일을 맡긴 쪽
        "type": type_,
        "taskId": task_id,
        "contextId": context_id,
        "process": _process,
        "payload": payload or {},
    }
    try:
        _queue.put_nowait(event)
    except queue.Full:
        pass


def _send_loop() -> None:
    with httpx.Client(timeout=2) as http:
        while True:
            event = _queue.get()
            try:
                http.post(_url + "/events", json=event)
            except Exception:
                pass  # 허브가 없어도 업무는 그대로 진행한다
            finally:
                _queue.task_done()


def _flush() -> None:
    deadline = time.time() + 2
    while _queue.unfinished_tasks and time.time() < deadline:
        time.sleep(0.05)
