"""Agent Card 서명(JWS, EdDSA)과 검증. SDK의 a2a.utils.signing을 쓴다.

- 서명: 내 비밀키(secrets/card_signing.key)로 카드를 서명해 카드에 붙인다.
- 검증: partners.yaml에 적어 둔 상대의 공개키(card_public_key, Base64 DER)로 확인한다. kid가 상대 id와 다르면 거절한다.
"""

import base64
from pathlib import Path
from typing import Callable

from a2a.types.a2a_pb2 import AgentCard
from a2a.utils.signing import create_agent_card_signer, create_signature_verifier
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, load_der_public_key
from jwt.exceptions import InvalidKeyError

ALGORITHM = "EdDSA"


def sign_card(card: AgentCard, private_key_file, kid: str) -> AgentCard:
    pem = Path(private_key_file).read_bytes()
    return create_agent_card_signer(pem, {"kid": kid, "alg": ALGORITHM, "typ": "JOSE"})(card)


def make_verifier(public_key_b64: str, expected_kid: str) -> Callable[[AgentCard], None]:
    """expected_kid(상대 회사 id)가 서명한 카드만 통과시키는 검증 함수."""
    key = load_der_public_key(base64.b64decode(public_key_b64))

    def key_provider(kid, jku):
        if kid != expected_kid:
            raise InvalidKeyError(f"서명한 쪽({kid})이 기대한 상대({expected_kid})가 아닙니다")
        return key

    return create_signature_verifier(key_provider, [ALGORITHM])


def public_key_b64(private_key_pem: bytes) -> str:
    """개발용 키 생성·확인에 쓴다: 비밀키에서 공개키(Base64 DER)를 만든다."""
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    public = load_pem_private_key(private_key_pem, password=None).public_key()
    return base64.b64encode(public.public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)).decode()