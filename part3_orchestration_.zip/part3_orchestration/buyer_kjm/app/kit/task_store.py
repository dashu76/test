"""SQLite에 Task를 저장하는 TaskStore. 서버를 껐다 켜도 Task 이력이 남는다.

저장할 때마다 상태가 바뀌었는지 비교해 관제 이벤트(task.received / task.state)를 낸다.
"""

import json
import time

from a2a.helpers.proto_helpers import get_data_parts
from a2a.server.context import ServerCallContext
from a2a.server.owner_resolver import OwnerResolver, resolve_user_scope
from a2a.server.tasks.task_store import TaskStore
from a2a.types.a2a_pb2 import ListTasksRequest, ListTasksResponse, Task, TaskState

from app.kit import obs_emit
from app.kit.db import Db

_TERMINAL = {"TASK_STATE_COMPLETED", "TASK_STATE_FAILED", "TASK_STATE_CANCELED", "TASK_STATE_REJECTED"}
_SCHEMA = """
CREATE TABLE IF NOT EXISTS a2a_tasks (
    owner TEXT NOT NULL,
    task_id TEXT NOT NULL,
    context_id TEXT NOT NULL,
    state INTEGER NOT NULL,
    data BLOB NOT NULL,
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (owner, task_id)
);
CREATE INDEX IF NOT EXISTS idx_a2a_tasks_context ON a2a_tasks(context_id);
"""


def _text(parts) -> str:
    return "".join(p.text for p in parts if p.WhichOneof("content") == "text")


def _short(text: str, size: int = 160) -> str:
    text = " ".join(text.split())
    return text if len(text) <= size else text[:size] + "…"


class SqliteTaskStore(TaskStore):
    def __init__(self, db: Db, owner_resolver: OwnerResolver = resolve_user_scope) -> None:
        self._db = db
        self._owner = owner_resolver
        self._db.script(_SCHEMA)

    async def save(self, task: Task, context: ServerCallContext) -> None:
        owner = self._owner(context)
        previous = self._db.one("SELECT state FROM a2a_tasks WHERE owner=? AND task_id=?", (owner, task.id))
        self._db.run(
            "INSERT INTO a2a_tasks(owner, task_id, context_id, state, data, updated_at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(owner, task_id) DO UPDATE SET context_id=excluded.context_id, state=excluded.state, "
            "data=excluded.data, updated_at=excluded.updated_at",
            (owner, task.id, task.context_id, task.status.state, task.SerializeToString(), int(time.time() * 1000)),
        )
        self._emit(task, previous["state"] if previous else None)

    async def get(self, task_id: str, context: ServerCallContext) -> Task | None:
        row = self._db.one("SELECT data FROM a2a_tasks WHERE owner=? AND task_id=?", (self._owner(context), task_id))
        if row is None:
            return None
        task = Task()
        task.ParseFromString(row["data"])
        return task

    async def list(self, params: ListTasksRequest, context: ServerCallContext) -> ListTasksResponse:
        sql, args = "SELECT data FROM a2a_tasks WHERE owner=?", [self._owner(context)]
        if params.context_id:
            sql += " AND context_id=?"
            args.append(params.context_id)
        if params.status:
            sql += " AND state=?"
            args.append(int(params.status))
        sql += " ORDER BY updated_at DESC, task_id DESC"
        tasks = []
        for row in self._db.all(sql, args):
            task = Task()
            task.ParseFromString(row["data"])
            tasks.append(task)
        page_size = params.page_size or 50
        return ListTasksResponse(tasks=tasks[:page_size], total_size=len(tasks), page_size=page_size)

    async def delete(self, task_id: str, context: ServerCallContext) -> None:
        self._db.run("DELETE FROM a2a_tasks WHERE owner=? AND task_id=?", (self._owner(context), task_id))

    def _emit(self, task: Task, before_state: int | None) -> None:
        state = TaskState.Name(task.status.state)
        before = TaskState.Name(before_state) if before_state is not None else None
        if before is None:
            first = _text(task.history[0].parts) if task.history else ""
            if not first and task.history:
                first = _short(json.dumps(get_data_parts(task.history[0].parts), ensure_ascii=False))
            obs_emit.emit("task.received", "server", {"text": _short(first)}, task.id, task.context_id)
        if before != state:
            payload = {"from": before, "to": state}
            if state in _TERMINAL or state.endswith("_REQUIRED"):
                result = "\n".join(
                    _text(a.parts) or json.dumps(get_data_parts(a.parts), ensure_ascii=False) for a in task.artifacts
                )
                payload["result"] = _short(result or _text(task.status.message.parts))
            obs_emit.emit("task.state", "server", payload, task.id, task.context_id)
