"""전송에 실패한 요청을 쌓아 두고 나중에 다시 보내기 위한 큐 (SQLite)."""

import json
import time

from app.kit.db import Db

_SCHEMA = """
CREATE TABLE IF NOT EXISTS outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL,
    business_key TEXT NOT NULL UNIQUE,
    payload TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    next_try_at INTEGER NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT ''
);
"""


class Outbox:
    def __init__(self, db: Db, max_attempts: int = 5, backoff_s: int = 5) -> None:
        self._db = db
        self.max_attempts = max_attempts
        self.backoff_s = backoff_s
        db.script(_SCHEMA)

    def enqueue(self, topic: str, business_key: str, payload: dict) -> None:
        self._db.run(
            "INSERT OR IGNORE INTO outbox(topic, business_key, payload, next_try_at) VALUES (?,?,?,?)",
            (topic, business_key, json.dumps(payload, ensure_ascii=False), int(time.time())),
        )

    def due(self) -> list[dict]:
        rows = self._db.all(
            "SELECT * FROM outbox WHERE done=0 AND attempts<? AND next_try_at<=? ORDER BY id",
            (self.max_attempts, int(time.time())),
        )
        for row in rows:
            row["payload"] = json.loads(row["payload"])
        return rows

    def mark_done(self, row_id: int) -> None:
        self._db.run("UPDATE outbox SET done=1 WHERE id=?", (row_id,))

    def mark_failed(self, row_id: int, error: str) -> None:
        self._db.run(
            "UPDATE outbox SET attempts=attempts+1, last_error=?, next_try_at=? WHERE id=?",
            (error, int(time.time()) + self.backoff_s, row_id),
        )

    def exhausted(self) -> list[dict]:
        return self._db.all("SELECT * FROM outbox WHERE done=0 AND attempts>=?", (self.max_attempts,))

    def reset(self, business_key: str) -> bool:
        """재시도 한도를 넘긴 건을 사람이 다시 시도하게 한다."""
        return self._db.run(
            "UPDATE outbox SET attempts=0, next_try_at=?, last_error='' WHERE business_key=? AND done=0",
            (int(time.time()), business_key),
        ) > 0

    def get(self, business_key: str) -> dict | None:
        return self._db.one("SELECT * FROM outbox WHERE business_key=?", (business_key,))

    def cancel(self, business_key: str) -> None:
        self._db.run("UPDATE outbox SET done=1 WHERE business_key=?", (business_key,))
