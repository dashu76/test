"""SQLite 연결 도우미. 이 회사만 쓰는 로컬 DB 파일 하나를 열고, 한 번에 한 스레드만 쓰게 잠근다."""

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path


class Db:
    def __init__(self, path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.RLock()

    def script(self, sql: str) -> None:
        with self._lock:
            self._conn.executescript(sql)

    def run(self, sql: str, params=()) -> int:
        with self._lock:
            return self._conn.execute(sql, params).rowcount

    def all(self, sql: str, params=()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def one(self, sql: str, params=()) -> dict | None:
        rows = self.all(sql, params)
        return rows[0] if rows else None

    @contextmanager
    def transaction(self):
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
            else:
                self._conn.execute("COMMIT")
