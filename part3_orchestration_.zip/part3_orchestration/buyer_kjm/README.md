# buyer_kjm — K정밀웍스 구매사 서버 (독립 실행)

주문 등록 → 견적 비교 → 업체 확정 → 배송 추적 → 취소를 다루는 구매사 한 곳의 서버. UI + 업무 API + A2A 에이전트를 한 프로세스로 제공한다.
이 폴더만 복사해도 실행되며, 다른 회사 폴더의 코드를 참조하지 않는다. 물류사와는 A2A로만 통신한다.

## 실행

```powershell
./run.ps1            # 또는: uv run python -m app.main
```

| 주소 | 내용 |
|---|---|
| `http://127.0.0.1:8010/` | 주문 목록·등록 |
| `http://127.0.0.1:8010/orders/{주문번호}` | 견적 비교표, 확정·취소, 진행 기록 |
| `http://127.0.0.1:8010/tracking` | 배송 추적 |
| `http://127.0.0.1:8010/api/*` | 이 회사의 업무 API (UI가 쓴다) |
| `http://127.0.0.1:8010/a2a` | A2A 엔드포인트 (`compare-quotes`, `route-delivery-inquiry`) |

헤더에 물류사 연결 상태(녹색 = Agent Card 응답)가 보인다.

## 설정

| 파일 | 내용 |
|---|---|
| `config.yaml` | 포트, `public_url`, `obs_url`(비우면 관제 허브 없이 동작), 견적 제한시간(2초), 재시도 횟수·간격 |
| `partners.yaml` | **이 회사가 아는 물류사 목록.** 물류사를 추가·이전할 때는 이 파일의 항목만 바꾼다 (코드 수정 없음) |
| 환경변수 | `PORT`, `PUBLIC_URL`, `A2A_OBS_URL`, `PARTNERS_PATH`, `DATA_DIR`(DB 위치 변경) |

## 업무 흐름과 상태

`DRAFT → REQUESTED → QUOTED → CONFIRM_PENDING → CONFIRMED → IN_TRANSIT → DELIVERED` (분기: `CANCELED`)

| 단계 | 동작 |
|---|---|
| 견적 요청 | `quote` 스킬을 가진 모든 물류사에 **동시에** 요청. 판정: 사용 가능(OK) · 납기 초과 · 견적 만료 · 계약 불일치 · 시간 초과 · 응답 없음 · 인증 실패 · 추가 정보 필요. 일부가 실패해도 나머지로 진행 |
| 추천 | 사용 가능한 견적 중 최저가. 납기 초과·만료 견적은 선택할 수 없다 |
| 추가 정보 | 물류사가 `INPUT_REQUIRED`로 질문하면 화면에서 답하고, **같은 Task에 이어서** 다시 보낸다 |
| 확정 | `business_key`(`주문번호:물류사`)로 한 번만 전송(중복 클릭 방지). 전송은 아웃박스에 쌓이고, 물류사가 꺼져 있으면 자동 재시도(기본 5회). 한도를 넘기면 화면에 경고와 "다시 시도" 버튼 |
| 거절 | 물류사가 수주를 거절하면 사유를 표시하고 견적 단계로 되돌려 다른 업체를 고르게 한다 |
| 추적 | 확정된 물류사에 `check-delivery`. 물류사가 안 되면 마지막으로 알던 상태와 조회 시각을 표시. 보류(ON_HOLD)는 경고로 표시 |
| 취소 | 확정 전은 즉시. 확정 후는 물류사의 `cancel-shipment` (출고 전만 가능) |

## 구조

```
app/main.py      조립(+ 확정 재전송 작업) · app/agent.py A2A 스킬 · app/api.py 업무 API·화면 · app/net.py 물류사 호출
app/domain/      orders.py(주문 서비스) · policy.py(계약 검증·납기·유효시간·추천)
app/kit/         복사해서 쓰는 공통 기능 (VERSION 참고)
app/contracts/   견적·배송 계약 스키마 복사본 (실행 중 검증에 쓴다)
app/web/         templates + static
db/schema.sql    orders · quotes · order_events · counters (+ kit: a2a_tasks, outbox)
tests/           단위 테스트(가짜 물류사로 시나리오 검증) + 계약 예제
```

## 테스트

```powershell
uv run pytest        # 36건: 주문·견적·확정·재시도·추적·취소·정책
```

실제 서버를 모두 띄우는 통합 테스트는 `../dev/e2e`.

## 인증 (회사 간 호출)

- **물류사를 부를 때:** `secrets/peer_keys.json`의 물류사별 API 키를 `X-A2A-Key`로 보낸다. 물류사가 401/403으로 거절하면 견적 비교표에 "인증 실패"로 표시한다.
- **물류사 카드 확인:** Agent Card의 서명을 `partners.yaml`의 `card_public_key`로 검증한 뒤에만 호출한다. 서명이 없거나 다른 회사 것이면 호출하지 않는다 ("인증 실패 — 카드 서명을 확인할 수 없습니다").
- **구매사 A2A 엔드포인트:** `secrets/api_keys.json`의 호출자·허용 스킬(`compare-quotes`, `route-delivery-inquiry`)로 보호한다. 서명된 카드를 제공한다.
- UI(`/`)와 업무 API(`/api/*`)는 A2A 키 대상이 아니다. 운영에서는 사내 로그인·네트워크 제한 뒤에 둔다.
- 개발용 키: 저장소 루트에서 `dev/gen_keys.ps1`. 검사를 끄려면 `config.yaml`의 `auth.mode: off`. 경로는 `PEER_KEYS_FILE`, `API_KEYS_FILE`, `SIGNING_KEY_FILE` 환경변수로 바꿀 수 있다.