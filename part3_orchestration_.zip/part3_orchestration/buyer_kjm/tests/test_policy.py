import json
from pathlib import Path

import pytest

from app.domain import policy

EX = Path(__file__).parent / "contracts" / "examples"


def load(name):
    return json.loads((EX / f"{name}.json").read_text(encoding="utf-8"))


def test_contract_examples():
    assert policy.contract_errors(load("quote.ok")) == []
    assert policy.contract_errors(load("quote.mismatch"))  # 계약과 다른 필드 이름


def test_missing_fields_are_listed():
    errors = policy.contract_errors({"소요일": 4})
    assert errors and "carrier" in errors[0] and "price_krw" in errors[0]


def test_wrong_type_is_reported():
    data = {**load("quote.ok"), "price_krw": "비싸다"}
    assert "price_krw" in policy.contract_errors(data)[0]


@pytest.mark.parametrize("eta, verdict", [(3, "OK"), (4, "OK"), (5, "LATE")])
def test_deadline(eta, verdict):
    assert policy.judge_quote({**load("quote.ok"), "eta_days": eta}, 4)[0] == verdict


def test_invalid_beats_deadline():
    assert policy.judge_quote(load("quote.mismatch"), 4)[0] == "INVALID"


def test_recommend_picks_cheapest_usable():
    rows = [
        {"carrier_id": "a", "verdict": "OK", "price_krw": 5}, {"carrier_id": "b", "verdict": "LATE", "price_krw": 1},
        {"carrier_id": "c", "verdict": "OK", "price_krw": 3}, {"carrier_id": "d", "verdict": "DOWN", "price_krw": None},
    ]
    assert policy.recommend(rows) == "c"
    assert policy.recommend([r for r in rows if r["verdict"] != "OK"]) is None


def test_expiry():
    assert policy.is_expired("2000-01-01T00:00:00Z") and not policy.is_expired("2999-01-01T00:00:00Z")