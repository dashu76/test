import json

import pytest
from a2a.types.a2a_pb2 import AgentCard
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat
from fastapi import FastAPI, Request
from starlette.testclient import TestClient

from app.kit.a2a_server import make_card
from app.kit.auth import ApiKeyAuth, ApiKeyMiddleware, skill_of
from app.kit.card_signing import make_verifier, public_key_b64, sign_card


def keys_file(tmp_path, scopes=("quote",)):
    path = tmp_path / "api_keys.json"
    path.write_text(json.dumps({"keys": [{"key": "good-key", "caller": "buyer_kjm", "scopes": list(scopes)}]}), encoding="utf-8")
    return path


def rpc(skill=None):
    meta = {"skill": skill} if skill else {}
    return {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {"messageId": "m", "metadata": meta}}}


@pytest.fixture
def client(tmp_path):
    app = FastAPI()

    @app.post("/a2a")
    async def echo(request: Request):
        return {"body": await request.json(), "caller": request.scope.get("state", {}).get("caller")}

    @app.get("/.well-known/agent-card.json")
    async def card():
        return {"open": True}

    app.add_middleware(ApiKeyMiddleware, auth=ApiKeyAuth(keys_file(tmp_path)), prefix="/a2a", default_skill="quote")
    return TestClient(app)


def test_missing_and_wrong_key_are_401(client):
    assert client.post("/a2a", json=rpc("quote")).status_code == 401
    assert client.post("/a2a", json=rpc("quote"), headers={"X-A2A-Key": "bad"}).status_code == 401


def test_scope_violation_is_403_and_message_names_the_skill(client):
    r = client.post("/a2a", json=rpc("accept-shipment"), headers={"X-A2A-Key": "good-key"})
    assert r.status_code == 403 and "accept-shipment" in r.json()["error"]["message"]


def test_allowed_call_passes_with_body_intact(client):
    r = client.post("/a2a", json=rpc("quote"), headers={"X-A2A-Key": "good-key"})
    assert r.status_code == 200 and r.json()["body"] == rpc("quote") and r.json()["caller"] == "buyer_kjm"


def test_text_only_request_uses_default_skill(client):
    assert client.post("/a2a", json=rpc(None), headers={"X-A2A-Key": "good-key"}).status_code == 200  # 기본 스킬(quote)이 허용됨


def test_card_and_other_paths_are_open(client):
    assert client.get("/.well-known/agent-card.json").status_code == 200


def test_non_message_calls_need_a_key_but_no_skill():
    assert skill_of(json.dumps({"method": "GetTask", "params": {"id": "t"}}).encode(), "quote") is None
    assert skill_of(b"not json", "quote") is None


def test_missing_key_file_explains_how_to_fix(tmp_path):
    with pytest.raises(FileNotFoundError, match="gen_keys"):
        ApiKeyAuth(tmp_path / "nope.json")


# ---------- Agent Card 서명 ----------
def new_key(tmp_path, name):
    key = Ed25519PrivateKey.generate()
    path = tmp_path / f"{name}.key"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    return path, public_key_b64(path.read_bytes())


def signed_card(path, kid):
    card = make_card("테스트", "설명", "http://127.0.0.1:1", [("quote", "견적")], api_key_header="X-A2A-Key")
    return sign_card(card, path, kid=kid)


def test_signed_card_verifies(tmp_path):
    path, public = new_key(tmp_path, "a")
    make_verifier(public, "carrier_a")(signed_card(path, "carrier_a"))  # 예외 없으면 통과


def test_wrong_public_key_is_rejected(tmp_path):
    path, _ = new_key(tmp_path, "a")
    _, other_public = new_key(tmp_path, "b")
    with pytest.raises(Exception):
        make_verifier(other_public, "carrier_a")(signed_card(path, "carrier_a"))


def test_card_signed_under_another_name_is_rejected(tmp_path):
    path, public = new_key(tmp_path, "a")
    with pytest.raises(Exception):
        make_verifier(public, "carrier_a")(signed_card(path, "carrier_b"))  # 서명한 쪽이 기대한 상대가 아니다


def test_tampered_card_is_rejected(tmp_path):
    path, public = new_key(tmp_path, "a")
    card = signed_card(path, "carrier_a")
    card.supported_interfaces[0].url = "http://evil.example/a2a"
    with pytest.raises(Exception):
        make_verifier(public, "carrier_a")(card)


def test_unsigned_card_is_rejected(tmp_path):
    _, public = new_key(tmp_path, "a")
    with pytest.raises(Exception):
        make_verifier(public, "carrier_a")(AgentCard(name="x"))