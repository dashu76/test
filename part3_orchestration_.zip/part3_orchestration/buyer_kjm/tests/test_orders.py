import asyncio

import pytest

from app.domain.orders import RuleError
from app.kit.a2a_client import CallResult
from tests.conftest import iso, quote_result, run, shipment_result
from datetime import timedelta


def by_carrier(view):
    return {q["carrier_id"]: q for q in view["quotes"]}


# ---------- 주문 ----------
def test_create_order_numbers_and_defaults(svc):
    a = svc.create_order({"item": "노트북", "qty": 1, "origin": "서울", "dest": "부산"})
    b = svc.create_order({"item": "노트북", "qty": 1, "origin": "서울", "dest": "부산"})
    assert (a["order_no"], b["order_no"]) == ("ORDER-1001", "ORDER-1002")
    assert a["status"] == "DRAFT" and a["max_eta_days"] == 4


@pytest.mark.parametrize("data", [
    {"item": "", "qty": 1, "origin": "서울", "dest": "부산"},
    {"item": "x", "qty": 0, "origin": "서울", "dest": "부산"},
    {"item": "x", "qty": "abc", "origin": "서울", "dest": "부산"},
    {"item": "x", "qty": 1, "origin": "", "dest": "부산"},
])
def test_create_order_rejects_bad_input(svc, data):
    with pytest.raises(RuleError):
        svc.create_order(data)


# ---------- 견적 (S2) ----------
def test_all_partners_answer_and_cheapest_valid_is_recommended(svc, order):
    view = run(svc.request_quotes(order["order_no"]))
    q = by_carrier(view)
    assert view["order"]["status"] == "QUOTED"
    assert q["carrier_b"]["verdict"] == "OK" and q["carrier_b"]["recommended"]  # 39,500 최저가
    assert q["carrier_d_mismatch"]["verdict"] == "INVALID"                       # S2-3 계약 불일치
    assert "누락 필드" in q["carrier_d_mismatch"]["reason"]
    assert not q["carrier_d_mismatch"]["recommended"]


def test_partner_down_and_timeout_do_not_block_others(svc, order, net):
    net.set("carrier_a", "quote", ConnectionError("refused"))
    net.set("carrier_c", "quote", asyncio.TimeoutError())
    q = by_carrier(run(svc.request_quotes(order["order_no"])))
    assert q["carrier_a"]["verdict"] == "DOWN" and q["carrier_c"]["verdict"] == "TIMEOUT"   # S2-1, S2-2
    assert q["carrier_b"]["verdict"] == "OK"


def test_late_quote_is_shown_but_not_selectable(svc, order, net):
    net.set("carrier_b", "quote", quote_result("물류사 B", 30000, 9))
    view = run(svc.request_quotes(order["order_no"]))
    q = by_carrier(view)
    assert q["carrier_b"]["verdict"] == "LATE" and not q["carrier_b"]["recommended"]        # S4-2
    assert q["carrier_a"]["recommended"]
    with pytest.raises(RuleError):
        run(svc.confirm(order["order_no"], "carrier_b"))


def test_all_failed_keeps_order_requested(svc, order, net):
    for cid in ("carrier_klogistics", "carrier_a", "carrier_b", "carrier_c"):
        net.set(cid, "quote", ConnectionError("down"))
    view = run(svc.request_quotes(order["order_no"]))
    assert view["order"]["status"] == "REQUESTED" and "사용할 수 있는 견적이 없습니다" in view["order"]["note"]   # S2-5
    net.set("carrier_a", "quote", quote_result("물류사 A", 42000, 3))                          # 다시 요청 가능
    assert run(svc.request_quotes(order["order_no"]))["order"]["status"] == "QUOTED"


def test_double_click_runs_one_round(svc, order, net):
    async def both():
        return await asyncio.gather(svc.request_quotes(order["order_no"]), svc.request_quotes(order["order_no"]))
    first, second = run(both())
    assert sum(1 for r in (first, second) if r["busy"]) == 1                                   # S1-3
    assert sum(1 for c in net.calls if c[1] == "quote") == 5


def test_input_required_then_answer(svc, order, net):
    asked = CallResult(state="TASK_STATE_INPUT_REQUIRED", task_id="T1", context_id="C1", text="도착지를 확인해 주세요")
    net.set("carrier_a", "quote", lambda p: asked if p["dest"] == "제주" else quote_result("물류사 A", 42000, 3))
    svc._set(order["order_no"], dest="제주")
    q = by_carrier(run(svc.request_quotes(order["order_no"])))
    assert q["carrier_a"]["verdict"] == "NEED_INPUT" and q["carrier_a"]["reason"] == "도착지를 확인해 주세요"   # S2-6
    view = run(svc.answer_question(order["order_no"], "carrier_a", {"dest": "부산"}))
    assert by_carrier(view)["carrier_a"]["verdict"] == "OK"
    assert svc.get(order["order_no"])["dest"] == "부산"
    assert net.calls[-1][3] == "T1"                                                            # 같은 Task에 이어서 보냈다


def test_expired_quote_cannot_be_confirmed(svc, order, net):
    net.set("carrier_b", "quote", quote_result("물류사 B", 39500, 4, valid_until=iso(-timedelta(minutes=1))))
    q = by_carrier(run(svc.request_quotes(order["order_no"])))
    assert q["carrier_b"]["verdict"] == "EXPIRED"                                              # S4-3
    with pytest.raises(RuleError):
        run(svc.confirm(order["order_no"], "carrier_b"))


def test_compare_does_not_store_anything(svc, net):
    out = run(svc.compare({"order_no": "ORDER-7", "item": "x", "qty": 5, "origin": "서울", "dest": "부산"}))
    assert out["recommended"] == "carrier_b" and svc.list_orders() == []


# ---------- 확정 (S3) ----------
def accepted(order_no="ORDER-1001"):
    return shipment_result("ACCEPTED", order_no, eta="2026-10-18")


def quoted(svc, order):
    run(svc.request_quotes(order["order_no"]))
    return order["order_no"]


def test_confirm_success(svc, order, net):
    net.set("carrier_b", "accept-shipment", accepted())
    no = quoted(svc, order)
    view = run(svc.confirm(no, "carrier_b"))
    assert view["status"] == "CONFIRMED" and view["chosen_carrier"] == "carrier_b" and view["chosen_price"] == 39500
    sent = [c for c in net.calls if c[1] == "accept-shipment"]
    assert len(sent) == 1 and sent[0][2]["business_key"] == "ORDER-1001:carrier_b"


def test_double_confirm_sends_once(svc, order, net):
    net.set("carrier_b", "accept-shipment", ConnectionError("down"))  # 전송 중 상태를 유지
    no = quoted(svc, order)
    run(svc.confirm(no, "carrier_b"))
    run(svc.confirm(no, "carrier_b"))                                                          # S3-1
    assert svc.outbox.get("ORDER-1001:carrier_b") is not None
    assert len(svc.db.all("SELECT * FROM outbox")) == 1


def test_confirm_survives_partner_outage_and_delivers_after_recovery(svc, order, net):
    net.set("carrier_b", "accept-shipment", ConnectionError("down"))
    no = quoted(svc, order)
    assert run(svc.confirm(no, "carrier_b"))["status"] == "CONFIRM_PENDING"                   # S3-2
    net.set("carrier_b", "accept-shipment", accepted())
    run(svc.process_outbox())
    assert svc.get(no)["status"] == "CONFIRMED"


def test_retries_exhausted_raises_alert_and_manual_retry_works(svc, order, net):
    net.set("carrier_b", "accept-shipment", ConnectionError("down"))
    no = quoted(svc, order)
    run(svc.confirm(no, "carrier_b"))
    for _ in range(3):
        run(svc.process_outbox())
    view = svc.order_view(no)
    assert view["status"] == "CONFIRM_PENDING" and view["alert"] and view["send_exhausted"]      # S3-4
    assert run(svc.process_outbox()) == 0                                                      # 한도 초과 후엔 멈춘다
    net.set("carrier_b", "accept-shipment", accepted())
    svc.retry_confirm(no)
    run(svc.process_outbox())
    assert svc.get(no)["status"] == "CONFIRMED"


def test_rejection_returns_to_quoted_with_reason(svc, order, net):
    net.set("carrier_b", "accept-shipment", shipment_result("REJECTED", reason="수량 한도를 초과했습니다"))
    no = quoted(svc, order)
    view = run(svc.confirm(no, "carrier_b"))
    assert view["status"] == "QUOTED" and view["chosen_carrier"] == ""                          # S3-3
    q = by_carrier({"quotes": svc.quotes(no)})["carrier_b"]
    assert q["verdict"] == "REJECTED" and "수량 한도" in q["reason"]
    assert run(svc.confirm(no, "carrier_a")) is not None                                        # 다른 업체를 고를 수 있다


# ---------- 추적 (S5) ----------
def confirmed(svc, order, net):
    net.set("carrier_b", "accept-shipment", accepted())
    no = quoted(svc, order)
    run(svc.confirm(no, "carrier_b"))
    return no


def test_track_updates_order_status(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "check-delivery", shipment_result("IN_TRANSIT", eta="2026-10-18"))
    t = run(svc.track(no))
    assert t["found"] and t["status"] == "IN_TRANSIT" and not t["stale"]                       # S5-2
    assert svc.get(no)["status"] == "IN_TRANSIT"
    net.set("carrier_b", "check-delivery", shipment_result("DELIVERED"))
    run(svc.track(no))
    assert svc.get(no)["status"] == "DELIVERED"


def test_track_not_found_is_a_result(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "check-delivery", shipment_result("", found=False))
    assert run(svc.track(no))["found"] is False                                                # S5-3
    assert run(svc.track("ORDER-9999"))["found"] is False


def test_track_when_partner_down_returns_last_known_state(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "check-delivery", shipment_result("DISPATCHED"))
    run(svc.track(no))
    net.set("carrier_b", "check-delivery", ConnectionError("down"))
    t = run(svc.track(no))
    assert t["stale"] and t["status"] == "DISPATCHED" and t["tracked_at"]                       # S5-4


def test_on_hold_raises_alert_without_changing_status(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "check-delivery", shipment_result("ON_HOLD", reason="통관 서류 보완"))
    run(svc.track(no))
    order_now = svc.get(no)
    assert "통관 서류 보완" in order_now["alert"] and order_now["status"] == "CONFIRMED"         # S5-5
    net.set("carrier_b", "check-delivery", shipment_result("IN_TRANSIT"))
    run(svc.track(no))
    assert svc.get(no)["alert"] == ""


def test_track_requires_confirmation(svc, order):
    with pytest.raises(RuleError):
        run(svc.track(order["order_no"]))


# ---------- 취소 (S5-6, S5-7) ----------
def test_cancel_before_confirmation_is_local(svc, order, net):
    assert run(svc.cancel(order["order_no"]))["status"] == "CANCELED"
    assert not [c for c in net.calls if c[1] == "cancel-shipment"]


def test_cancel_confirmed_before_dispatch(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "cancel-shipment", shipment_result("CANCELED"))
    assert run(svc.cancel(no, "계획 변경"))["status"] == "CANCELED"


def test_cancel_refused_after_dispatch(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "cancel-shipment", shipment_result("DISPATCHED", reason="출고 이후에는 취소할 수 없습니다"))
    with pytest.raises(RuleError, match="출고"):
        run(svc.cancel(no))
    assert svc.get(no)["status"] == "CONFIRMED"


def test_cancel_when_partner_unreachable_is_refused(svc, order, net):
    no = confirmed(svc, order, net)
    net.set("carrier_b", "cancel-shipment", ConnectionError("down"))
    with pytest.raises(RuleError):
        run(svc.cancel(no))
    assert svc.get(no)["status"] == "CONFIRMED"