import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from app.domain.orders import OrderService
from app.kit.db import Db
from app.kit.a2a_client import CallResult
from app.kit.outbox import Outbox
from app.kit.partners import Partner
from app.settings import ROOT

CFG = {"quote_timeout_s": 2.0, "call_timeout_s": 5.0, "quote_default_max_eta_days": 4}
IDS = ["carrier_klogistics", "carrier_a", "carrier_b", "carrier_c", "carrier_d_mismatch"]


def iso(delta=timedelta(hours=1)):
    return (datetime.now(timezone.utc) + delta).strftime("%Y-%m-%dT%H:%M:%SZ")


def run(coro):
    return asyncio.run(coro)


def quote_result(name, price, eta, valid_until=None, order_no="ORDER-1001"):
    return CallResult(state="TASK_STATE_COMPLETED", task_id="t", context_id="c", data=[
        {"order_no": order_no, "carrier": name, "price_krw": price, "eta_days": eta, "valid_until": valid_until or iso()}])


def shipment_result(status, order_no="ORDER-1001", found=True, **extra):
    data = {"order_no": order_no, "found": found, **({"status": status, "updated_at": iso()} if found else {}), **extra}
    return CallResult(state="TASK_STATE_COMPLETED", task_id="t", context_id="c", data=[data])


class FakeNet:
    """물류사 호출을 흉내 낸다. handlers[(partner_id, skill)] = 함수(payload) → CallResult 또는 예외."""

    def __init__(self):
        self.handlers, self.calls = {}, []

    def set(self, partner_id, skill, handler):
        self.handlers[(partner_id, skill)] = handler

    async def call(self, partner, skill, payload, *, timeout_s=5.0, task_id="", context_id=""):
        self.calls.append((partner.id, skill, payload, task_id))
        handler = self.handlers.get((partner.id, skill))
        if handler is None:
            raise ConnectionError("no handler")
        out = handler(payload) if callable(handler) else handler
        if isinstance(out, BaseException):
            raise out
        return out

    def forget(self, partner):
        pass

    async def is_online(self, partner, timeout_s=1.0):
        return True


@pytest.fixture
def net():
    n = FakeNet()
    n.set("carrier_a", "quote", quote_result("물류사 A", 42000, 3))
    n.set("carrier_b", "quote", quote_result("물류사 B", 39500, 4))
    n.set("carrier_c", "quote", quote_result("물류사 C", 45000, 2))
    n.set("carrier_klogistics", "quote", quote_result("K-Logistics", 43000, 3))
    n.set("carrier_d_mismatch", "quote", CallResult(state="TASK_STATE_COMPLETED", data=[
        {"소요일": 4, "업체": "물류사 D", "가격": 39500, "주문": "ORDER-1001"}]))
    return n


@pytest.fixture
def db(tmp_path):
    database = Db(tmp_path / "buyer.db")
    database.script((ROOT / "db" / "schema.sql").read_text(encoding="utf-8"))
    return database


@pytest.fixture
def svc(db, net):
    partners = [Partner(id=i, name=i, url=f"http://x/{i}", skills=["quote", "accept-shipment", "check-delivery", "cancel-shipment"]) for i in IDS]
    return OrderService(db, dict(CFG), partners, net, Outbox(db, max_attempts=3, backoff_s=0), me="buyer_kjm")


@pytest.fixture
def order(svc):
    return svc.create_order({"item": "노트북", "qty": 20, "origin": "서울", "dest": "부산", "max_eta_days": 4})