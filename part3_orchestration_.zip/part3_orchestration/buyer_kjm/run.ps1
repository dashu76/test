﻿# 이 폴더만으로 기동한다
Set-Location $PSScriptRoot
Remove-Item Env:VIRTUAL_ENV -ErrorAction SilentlyContinue
$env:PYTHONIOENCODING = 'utf-8'
uv run python -m app.main

