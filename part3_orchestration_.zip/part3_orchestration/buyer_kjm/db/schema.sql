CREATE TABLE IF NOT EXISTS orders (
    order_no TEXT PRIMARY KEY,
    item TEXT NOT NULL,
    qty INTEGER NOT NULL,
    origin TEXT NOT NULL,
    dest TEXT NOT NULL,
    max_eta_days INTEGER NOT NULL,
    status TEXT NOT NULL,
    chosen_carrier TEXT NOT NULL DEFAULT '',
    chosen_price INTEGER NOT NULL DEFAULT 0,
    chosen_reason TEXT NOT NULL DEFAULT '',
    carrier_status TEXT NOT NULL DEFAULT '',
    carrier_eta TEXT NOT NULL DEFAULT '',
    carrier_note TEXT NOT NULL DEFAULT '',
    tracked_at TEXT NOT NULL DEFAULT '',
    alert TEXT NOT NULL DEFAULT '',
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS quotes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no TEXT NOT NULL,
    carrier_id TEXT NOT NULL,
    carrier_name TEXT NOT NULL,
    price_krw INTEGER,
    eta_days REAL,
    valid_until TEXT NOT NULL DEFAULT '',
    verdict TEXT NOT NULL,
    reason TEXT NOT NULL DEFAULT '',
    task_id TEXT NOT NULL DEFAULT '',
    context_id TEXT NOT NULL DEFAULT '',
    fetched_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_quotes_order ON quotes(order_no);

CREATE TABLE IF NOT EXISTS order_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no TEXT NOT NULL,
    status TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_order ON order_events(order_no);

CREATE TABLE IF NOT EXISTS counters (name TEXT PRIMARY KEY, value INTEGER NOT NULL);
INSERT OR IGNORE INTO counters(name, value) VALUES ('order_no', 1000);